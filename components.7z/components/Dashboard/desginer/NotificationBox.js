import React from "react";
import { Typography, Grid, Paper, Divider } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import {
  Notifications,
  Cached,
  Description,
  Close,
  DateRange,
  WarningOutlined,
} from "@mui/icons-material";
import { useTranslation } from "react-i18next";
const useStyles = makeStyles((theme) => ({
  root: {
    padding: "20px",
  },
  paper1: {
    height: 220,
    borderRadius: "4px",
    backgroundColor: "#FFFFFF",
    padding: "10px",
    borderTop: "4px solid #0072C6",
    borderTopWidth: "medium",
    boxShadow: "0px 0px 6px #0000001A",
  },
  margin_left_10: {
    marginLeft: 10,
  },
  icons: {
    marginTop: "3px",
    width: "16px",
    height: "16px",
    fontWeight: 500,
  },
  closeIcon: {
    marginTop: "5px",
    width: "16px",
    height: "16px",
    fontWeight: 500,
  },
  title: {
    fontSize: "14px",
    fontWeight: 800,
  },
  marginBot: {
    marginBottom: "13px",
    padding: "13px",
  },

  bullet: {
    width: "3px",
    height: "3px",
    borderRadius: 50,
    backgroundColor: `${theme.palette.primary.main}`,
  },
  grey: {
    backgroundColor: "#F0F0F0",
  },
  text_12: {
    fontSize: "12px",
  },
  dueTo: {
    color: "#DB1D1D",
  },
  primeColor: {
    color: `${theme.palette.primary.main}`,
  },
  scriptIcon: {
    height: "24px",
    width: "24px",
    color: "#C4C4C4",
  },
  errorIcon: {
    fill: "#FF0000",
    height: "22px",
    width: "26px",
    marginTop: "3px",
  },
}));

const NotificationBox = (props) => {
  const { notData, removeNotification, refreshData } = props;
const {t} = useTranslation()
  const classes = useStyles();
  return (
    <Paper className={classes.paper1}>
      <Grid container direction="row" className={classes.marginBot}>
        <Grid item container direction="row" spacing={1} alignItems="center">
          <Grid item>
            <Notifications color="primary" className={classes.icons} />
          </Grid>
          <Grid item>
            <Typography className={classes.title}>{t("Notifications")}</Typography>
          </Grid>
          <Grid
            item
            style={{ marginLeft: "auto", cursor: "pointer" }}
            onClick={() => refreshData()}
            data-testid="refreshBtn"
          >
            <Cached color="primary" className={classes.icons} />
          </Grid>
        </Grid>
      </Grid>
      <Grid container direction="column" spacing={2}>
        {notData.length > 0 ? (
          notData.map((notification, index) => (
            <React.Fragment key={index}>
              <Grid
                item
                container
                direction="row"
                spacing={1}
                alignItems="center"
                className={notification.type === "Error" ? classes.grey : ""}
              >
                <Grid
                  item
                  container
                  direction="row"
                  spacing={1}
                  alignItems="center"
                  style={{ paddingLeft: "15px", paddingRight: "15px" }}
                >
                  <Grid
                    item
                    className={
                      notification.type === "Error" ? classes.bullet : ""
                    }
                  ></Grid>

                  <Grid item>
                    <Description className={classes.scriptIcon} />
                  </Grid>
                  <Grid item>
                    <Typography className={classes.text_12}>
                      Script{" "}
                      <span className={classes.primeColor}>
                        {notification.title}
                      </span>
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography className={classes.text_12}>
                      {notification.message}
                    </Typography>
                  </Grid>
                  {notification.dueTo && (
                    <Grid item>
                      <Typography
                        className={classes.text_12 + " " + classes.dueTo}
                      >
                        {notification.dueTo}.
                      </Typography>
                    </Grid>
                  )}
                  {notification.by && (
                    <Grid item>
                      <Typography
                        className={classes.text_12 + " " + classes.primeColor}
                      >
                        {notification.by}.
                      </Typography>
                    </Grid>
                  )}
                  <Grid item style={{ marginLeft: "auto" }}>
                    <Grid container direction="row" spacing={1}>
                      <Grid item>
                        <Grid
                          container
                          direction="row"
                          spacing={1}
                          alignItems="center"
                        >
                          {notification.type === "Error" && (
                            <Grid item>
                              <WarningOutlined className={classes.errorIcon} />
                            </Grid>
                          )}
                          <Grid item>
                            <DateRange className={classes.icons} />
                          </Grid>
                          <Grid item>
                            <Typography style={{ fontSize: "10px" }}>
                              {notification.time}
                            </Typography>
                          </Grid>
                          <Grid item>
                            <Typography
                              className={classes.text_12}
                              color="primary"
                            >
                              {notification.type === "Error"
                                ? "Notify"
                                : "View"}
                            </Typography>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid
                        item
                        style={{ cursor: "pointer" }}
                        data-testid={"removeNotiBtn" + index}
                        onClick={() => removeNotification(notification.id)}
                      >
                        <Close className={classes.closeIcon} />
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              {index === notData.length - 1 && <Divider variant="fullWidth" />}
            </React.Fragment>
          ))
        ) : (
          <Grid container>
            <Grid item style={{ marginLeft: "24px" }}>
              <Typography>{t("There are no notifications yet.")}</Typography>
            </Grid>
          </Grid>
        )}
      </Grid>
    </Paper>
  );
};

export default NotificationBox;
