import React from "react";
import { Grid, Paper, Typography } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import { Cached } from "@mui/icons-material";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: "20px",
  },
  paper1: {
    height: 220,
    borderRadius: "4px",
    backgroundColor: "#FFFFFF",
    padding: "10px",
    borderTop: "4px solid #0072C6",
    borderTopWidth: "medium",
    boxShadow: "0px 0px 6px #0000001A",
  },
  title: {
    fontSize: "14px",
    fontWeight: 800,
  },
  icons: {
    marginTop: "3px",
    width: "16px",
    height: "16px",
    fontWeight: 500,
  },
  text_12: {
    fontSize: "12px",
  },

  primeColor: {
    color: `${theme.palette.primary.main}`,
  },
  bold: {
    fontWeight: 700,
  },
  btn: {
    fontSize: "12px",
    fontWeight: 600,
    color: `${theme.palette.primary.main}`,
  },
}));
const CommonBox = (props) => {
  const { heading, updatedOn, Content } = props;
  const classes = useStyles();
  return (
    <Paper className={classes.paper1}>
      <Grid
        container
        direction="column"
        style={{
          paddingLeft: "24px",
          paddingTop: "15px",
          paddingRight: "10px",
        }}
      >
        <Grid item container direction="row">
          <Grid item>
            <Typography className={classes.title}>{heading || ""}</Typography>
          </Grid>
          <Grid item style={{ marginLeft: "auto" }}>
            <Cached color="primary" className={classes.icons} />
          </Grid>
        </Grid>
        <Grid item>
          <Typography variant="subtitle2">updated on {updatedOn}</Typography>
        </Grid>
      </Grid>
      {Content}
    </Paper>
  );
};

export default CommonBox;
