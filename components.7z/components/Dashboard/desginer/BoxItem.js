import React from "react";
import { Grid, Typography, Paper } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
const useStyles = makeStyles((theme) => ({
  root: {
    padding: "20px",
  },
  paper: {
    paddingLeft: "28px",
    paddingTop: "11px",
    height: "94px",
    color: "#FFFFFF",
    backgroundColor: "#2D7E1D",
    boxShadow: "0px 0px 6px #0000001A",
  },
  paper1: {
    paddingLeft: "28px",
    paddingTop: "11px",

    height: "94px",
    color: "#FFFFFF",
    backgroundColor: "#D40000",
    boxShadow: "0px 0px 6px #0000001A",
  },
  primeColor: {
    color: `${theme.palette.primary.main}`,
  },
  bold: {
    fontWeight: 700,
  },
  btn: {
    fontSize: "12px",
    fontWeight: 600,
    color: `${theme.palette.primary.main}`,
  },
  text_12: {
    fontSize: "12px",
  },
}));
const BoxItem = ({ total, percentage, type, message }) => {
  const classes = useStyles();
  return (
    <Paper className={type === "Success" ? classes.paper : classes.paper1}>
      <Grid container direction="column" spacing={1}>
        <Grid item>
          <Grid container ddirection="row" spacing={2}>
            <Grid item>
              <Typography variant="h4" className={classes.bold}>
                {total}
              </Typography>
            </Grid>
            <Grid item>
              <Typography variant="overline" style={{ fontSize: "16px" }}>
                ({percentage}%)
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          <Typography className={classes.text_12}>{message} </Typography>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default BoxItem;
