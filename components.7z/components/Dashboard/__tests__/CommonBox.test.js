import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";

import "@testing-library/jest-dom/extend-expect";
import renderer from "react-test-renderer";
import CommonBox from "./../desginer/CommonBox";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  ReactDom.render(
    <CommonBox
      heading="Published Scripts"
      updatedOn="10th Feb 2021, 4:00PM"
      Content={<div>Content</div>}
    />,
    div
  );
});

it("matches snapshot", () => {
  const tree = renderer
    .create(
      <CommonBox
        heading="Published Scripts"
        updatedOn="10th Feb 2021, 4:00PM"
        Content={<div>Content</div>}
      />
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
