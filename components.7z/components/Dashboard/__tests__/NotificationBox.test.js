import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";

import "@testing-library/jest-dom/extend-expect";
import renderer from "react-test-renderer";
import NotificationBox from "./../desginer/NotificationBox";
import userEvent from "@testing-library/user-event";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  const removeNotification = jest.fn();
  const refreshData = jest.fn();

  ReactDom.render(
    <NotificationBox
      notData={notiData}
      removeNotification={removeNotification}
      refreshData={refreshData}
    />,
    div
  );
});

it("checking refresh data btn working", () => {
  const removeNotification = jest.fn();
  const refreshData = jest.fn();

  render(
    <NotificationBox
      notData={notiData}
      removeNotification={removeNotification}
      refreshData={refreshData}
    />
  );
  userEvent.click(screen.getByTestId("refreshBtn"));
  expect(refreshData).toBeCalledTimes(1);
});

it("checking remove notifiation btn working", () => {
  const removeNotification = jest.fn();
  const refreshData = jest.fn();

  render(
    <NotificationBox
      notData={notiData}
      removeNotification={removeNotification}
      refreshData={refreshData}
    />
  );
  userEvent.click(screen.getByTestId("removeNotiBtn1"));
  expect(removeNotification).toBeCalledTimes(1);
});

it("matches snapshot", () => {
  const removeNotification = jest.fn();
  const refreshData = jest.fn();
  const tree = renderer
    .create(
      <NotificationBox
        notData={notiData}
        removeNotification={removeNotification}
        refreshData={refreshData}
      />
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const notiData = [
  {
    id: 1,
    title: "Card Initiation",
    message: "has encounterd error on testing",
    by: "Ramesh Gowda",
    type: "Error",
    time: "14 Feb 2020 6:30PM",
  },
  {
    id: 2,
    title: "Verification_Adhaar",
    message: "is stopped due to",

    dueTo: "Network Failure",
    type: "Error",
    time: "15 Feb 2020 6:30PM",
  },
  {
    id: 3,
    title: "Excel_init",
    message: "has been published by",
    by: "Ramesh Gowda",

    type: "Info",
    time: "15 Feb 2020 5:30PM",
  },
];
