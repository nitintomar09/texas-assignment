import React, { useState, useEffect, useContext } from "react";
import { Grid, IconButton, Typography } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import LoadingIndicator from "../../../utils/loadingIndicator";
import MenuPopper from "../../../utils/MenuPopper";
import {
  HorizontleMore,
  PinIcon,
  FolderIcon,
  TileViewIcon,
  ScriptIcon,
  ListViewIcon,
  TileScriptIcon,
  NewScriptIcon,
  UnPinIcon,
} from "../../../utils/AllImages";
import { Brightness1 } from "@mui/icons-material";
import RecentActivity from "../RecentActivity";
import { getEncryptedId } from "../../../utils/encryptions";
import {
  openScriptInNewTab,
  getToken,
  getUser,
  getUserId,
  doesUserHavePermission,
  truncateStringValues,
  getCalendarDate,
  getDateAndTimeStrForTile
} from "../../../utils/common";
import { useHistory } from "react-router";
import moment from "moment";
import { VIEW_INDEX } from "../../../config";
import { NotificationContext } from "../../../contexts/NotificationContext";
import { setOpenScript, setOpenScriptDetails } from "../../../redux/actions";
import { useDispatch } from "react-redux";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../../utils/UniqueIDGenerator";
import { getRgbafromHex } from "../../../utils/HexToFilter";
const useStyles = makeStyles((theme) => ({
  root: {
    marginBottom: "10px",
    //marginTop: "24px",
  },
  selectedView: {
    //  boxShadow: `0px 0px 2px 2px ${theme.palette.primary.main}`,
    //background: `${theme.palette.primary.secondary} 0% 0% no-repeat padding-box`,
    /**
     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
     * Resolution: Updated the selected view state for icons as per the design
     * Date : 28/01/2025             
     * */
    //background: `${getRgbafromHex(`${theme.palette.primary.main}`, 0.05)}`,
    //color: `${theme.palette.primary.main}`,
    backgroundColor:"white",
    borderRadius:"4px",
    padding:"2px",
    alignContent:"center",
    justifyItems:"center",
    width: "40px",
        //alignItems: "center",
    //padding:6,
    //zIndex: 1,
    cursor: "pointer",
    //border: `1px solid ${theme.palette.primary.main}`,
    //paddingLeft: "9px",
   
  },
  normalView: {
    /**
     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
     * Resolution: Removed bg color for icons as per the design
     * Date : 28/01/2025             
     * */
    //backgroundColor: "#FFFFFF",
    alignContent:"center",
    justifyItems:"center",
    width: "40px",
    padding:4,
    // boxShadow: "0px 0px 2px 2px #d8d7d7",
    //width: "35px",
    //alignItems: "center",
    cursor: "pointer",
    // paddingLeft: "12px",
    //paddingRight: "4px",
    //border: `1px solid #C4C4C4`,
  },
  root_tile: {
    // minWidth: (props) => props.width,
    minWidth: (props) => props.width,
    //maxHeight: (props) => props.height,
    margin: (props) =>
      props.direction === "rtl" ? "0 0 19px 5px" : "0 8px 19px 0",
    boxShadow: "0px 3px 6px #0000001F",
    borderRadius: "4px",
    display: "flex",
    border: "1px solid white",
    backgroundColor: theme.palette.common.white,
    "&:hover": {
      minWidth: "215px",
      boxShadow: "0px 6px 12px #0000001F",
      border: "1px solid #1281DD",
    },
    cursor: "pointer",

    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      minWidth: "215px",
      //boxShadow: "0px 6px 12px #0000001F",
      //border: "1px solid #1281DD",
      border: `2px solid ${theme.palette.tabFocus.mainColor}`,
    },
  },
  tile_container: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "flex-start",

    paddingRight: (props) => (props.direction === "rtl" ? "10px" : 0),
    //maxHeight: (props) =>
    //props.viewLength ? "none" : props.pinnedData.length < 4 ? "none" : "85px",
    overflow: "hidden",
  },
  heading: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  tileServiceFlowStatus: {
    background: `${getRgbafromHex(`${theme.palette.primary.main}`, 0.05)}`,
    color: `${theme.palette.primary.main}`,
  },
  title: {
    //fontSize: "16px",
    fontWeight: 700,
    marginBottom: "10px",
    paddingRight: (props) => (props.direction === "rtl" ? "10px" : 0),
  },
  count: {
    fontSize: "16px",
    marginBottom: "10px",
    color: "#606060",
    padding: (props) => (props.direction === "rtl" ? "0 5px 0 0" : "0 0 0 5px"),
  },
  root_tile_right: {
    //padding: "10px 6px", //6px 16px
    display: "flex",
    width: "100%",
    flexDirection: "column",
    justifyContent: "space-between",
  },
  tile_title: {
    textAlign: (props) => (props.direction === "rtl" ? "right" : "left"),
    fontSize: "12px",
    width: "125px",
    fontWeight: "600",
    letterSpacing: "0px",
    //alignContent:"center",
    paddingLeft: "4px",
    paddingTop: "6px",
    color: "#000000",
    opacity: 1,
    // margin: (props) =>
    //   props.direction === "rtl" ? "0 0 8px 5px" : "",//0 5px 8px 0
  },
  tile_status: {
    textAlign: (props) => (props.direction === "rtl" ? "right" : "left"),
    fontSize: "11px",
    letterSpacing: "0px",
    color: "#606060",
    fontWeight: 600,
    opacity: 1,
    margin: "0 8px 0 3px",
  },
  tile_type: {
    textAlign: (props) => (props.direction === "rtl" ? "right" : "left"),
    fontSize: "11px",
    letterSpacing: "0px",
    color: "#606060",
    fontWeight: 600,
    opacity: 1,
    minWidth: "100px",
    // maxWidth: "100px",
    margin: "0 8px 0 3px",
  },
  tile_subDesc: {
    fontSize: "10px",
    color: "#606060",
    lineHeight: "10px",
    paddingTop: "8px",
  },
  tile_subStatus: {
    display: "flex",
    alignItems: "center",
  },
  view_all: {
    color: "#0072C6",
    margin: "-8px 0px 0px 16px",
    fontWeight: "600",
    fontSize: "12px",
    cursor: "pointer",
    /**
     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
     * Description:  As per the design the 'View All' option is not underlined
     * Date : 28/01/2025             
     * */
    // textDecoration: "underline",
  },
  icon1: {
    // marginRight: "4px",
    width: "7px",
    height: "7px",

    cursor: "pointer",
  },
  pin: {
    height: "16px",
    color: "rgb(15, 122, 201)",

    width: "16px",
    marginRight: "5px",
    marginTop: "4px",
    //  filter: `brightness(0) saturate(100%) invert(0%) sepia(100%) saturate(28%) hue-rotate(63deg) brightness(92%) contrast(108%)`,
  },
  focusVisible: {
    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
      filter: "none",
    },
  },
  selectedIcon: {
    marginTop: "3px",
    height: "16px",
    width: "16px",
    //filter: `brightness(0) saturate(100%) invert(25%) sepia(92%) saturate(1759%) hue-rotate(186deg) brightness(101%) contrast(105%)`,
  },
  icon: {
    marginTop: "3px",
    height: "16px",
    width: "16px",
  },
}));
const Pinned = (props) => {
  const { t } = useTranslation();

  const {
    pinnedData = [],

    defaultView = "Tile View",
    direction = `lft`,
    loading = false,
    height = "80pt",
    width = "165pt",

    label = {
      heading: t("Pinned"),
      viewLess: `View Less`,
      viewAll: `View All`,
      //last_modified: t("Last Modified"),
      last_modified: t("Last opened")
    },
    handleOpenModal,
    handleToBeDeleted,
    setSelectedScript,
    pinOrUnpinScript,
  } = props;
  const userId = getUserId();
  const dispatch = useDispatch();
  const { setValue } = useContext(NotificationContext);
  const [view, setView] = useState(defaultView);
  const [viewLength, setViewLength] = useState(false);
  const [hover, setHover] = useState(null);
  const [recentList, setRecentList] = useState([{ value: pinnedData }]);
  const headerData = [
    { category: t("Name") },
    { category: t("Status") },
    { category: t("Last Opened On") },
  ];
  const classes = useStyles({
    direction,
    width,
    height,
    viewLength,
    pinnedData,
  });
  const history = useHistory();

  useEffect(() => {
    if (pinnedData.length > 4) {
      if (viewLength) {
        setRecentList([{ value: pinnedData }]);
      } else {
        setRecentList([{ value: pinnedData.slice(0, 4) }]);
      }
    } else {
      setRecentList([{ value: pinnedData }]);
    }
  }, [viewLength, pinnedData]);

  const onClickHandler = () => {
    setViewLength(!viewLength);
  };
  const onHover = (key) => {
    setHover(key);
  };
  const onHoverExit = () => {
    setHover(null);
  };
  const handleView = (view) => {
    setView(view);
  };
  const handleScriptAction = (e, action, clickedOnScript) => {
    const { scriptId, versionName, scriptName } = clickedOnScript;

    switch (action) {
      case "Sharing":
        setSelectedScript(clickedOnScript);
        handleOpenModal("Script Sharing");
        e.stopPropagation();

        break;
      case "Open":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          //setSelectedScript(null);
          ///if (scriptId && versionName) {
            // dispatch(setOpenScriptDetails({}));

            // const encStr = getEncryptedId({
            //   scriptId: scriptId,
            //   versionName: versionName,
            // });

            // history.push(`/serviceflow/${encStr}`);
            
         // } else {
           // console.log("falsy versionName/scriptId", versionName, scriptId);
          //}
          setSelectedScript(null);
          if (scriptId && versionName) {

            dispatch(setOpenScriptDetails({ scriptId, versionName, scriptName }))
            history.push(`/serviceflow`);
          } else {
            console.log("falsy versionName/scriptId", versionName, scriptId);
          }
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to view a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();

        break;
      case "Open In New Tab":
        setSelectedScript(null);
        dispatch(setOpenScript(clickedOnScript));
        dispatch(setOpenScriptDetails({}));
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          if (scriptId && versionName) {
            const user = getUser();
            const token = getToken();
            openScriptInNewTab({ scriptId, versionName, token, user });
          } else {
            console.log("falsy versionName/scriptId", versionName, scriptId);
          }
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to view a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();

        break;
      case "History":
        setSelectedScript(clickedOnScript);
        handleOpenModal("Script History");
        e.stopPropagation();

        break;
      case "Open Previous Versions":
        setSelectedScript(clickedOnScript);
        handleOpenModal("Script Previous Versions");
        e.stopPropagation();

        break;

      case "Edit Name and Tags":
        setSelectedScript(clickedOnScript);
        handleOpenModal("Update Script");
        e.stopPropagation();

        break;
      case "Export":
        setSelectedScript(clickedOnScript);
        handleOpenModal("Export");
        e.stopPropagation();
        break;

      case "Delete":
        handleToBeDeleted(clickedOnScript);
        handleOpenModal("Delete Script");

        e.stopPropagation();
        break;
      case "Move To":
        setSelectedScript(clickedOnScript);
        handleOpenModal("Move To");
        e.stopPropagation();

        break;
      case "Unpin":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          pinOrUnpinScript(clickedOnScript, 0);
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to unpin a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();
        break;
      default:
        break;
    }
  };

  const [hoveredItems, setHoveredItems] = useState({});

  const handleMouseEnter = (id) => {
    setHoveredItems((prev) => ({ ...prev, [id]: true }));
  };

  const handleMouseLeave = (id) => {
    setHoveredItems((prev) => ({ ...prev, [id]: false }));
  };

  return (
    // <div className={classes.root}>
      <React.Fragment>
        {/* <div> */}
          <Grid container alignItems="center">
            <Grid item>
              <Typography variant="h6" className={classes.title}>
                {pinnedData.length > 0
                  ? `${t("Pinned")} (${pinnedData.length})`
                  : t("Pinned")}
              </Typography>
            </Grid>
            {pinnedData.length > 0 && (
              <Grid
                item
                className={classes.view_all}
                onClick={onClickHandler}
                //WCAG Keyboard accessibility :[19-07-2023] Added tabIndex and OnKeyPress
                tabIndex={0}
                onKeyPress={(e) => e.key === "Enter" && onClickHandler()}
                role="button"
                id={`${props.id}_${
                  viewLength ? label?.viewLess : label?.viewAll
                }`}
              >
                {viewLength ? label?.viewLess : label?.viewAll}
              </Grid>
            )}

            <Grid item xs>
              <Grid 
                container 
              //role="tablist" 
                justifyContent={"flex-end"} 
                
                //alignItems={"center"}
                >
                  <Grid item 
                    sx={{border: `1px solid #C4C4C4`,borderRadius:0.5}}
                  >
                  <Grid container >
              <Grid item
                  className={
                    view === "List View"
                      ? classes.selectedView
                      : classes.normalView
                  }
                
                  //spacing={1}
                  onClick={() => handleView("List View")}
                  // WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
                  tabIndex={0}
                  onKeyPress={(e) =>
                    e.key === "Enter" && handleView("List View")
                  }
                  //role="tab"
                  aria-selected={view === "List View"}
                  id={`${props.id}_ListView`}
                >
                    <UniqueIDGenerator>
                      <ListViewIcon
                        className={
                          view === "List View"
                            ? classes.selectedIcon
                            : classes.icon
                        }
                        height={30}
                        width={30}
                      />
                    </UniqueIDGenerator>
                </Grid>

                <Grid item
                  className={
                    view === "Tile View"
                      ? classes.selectedView
                      : classes.normalView
                  }
                 
                  //alignItems="center"
                  //spacing={1}
                  onClick={() => handleView("Tile View")}
                  //style={{ marginRight: "7px" }}
                  // WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
                  tabIndex={0}
                  onKeyPress={(e) =>
                    e.key === "Enter" && handleView("Tile View")
                  }
                  //role="tab"
                  aria-selected={view === "Tile View"}
                  id={`${props.id}_TileView`}
                >
                  {/* <Grid item> */}
                    <UniqueIDGenerator>
                      <TileViewIcon
                        className={
                          view === "Tile View"
                            ? classes.selectedIcon
                            : classes.icon
                        }
                        height={30}
                        width={30}
                      />
                    </UniqueIDGenerator>
                  {/* </Grid> */}
                </Grid>
            </Grid>
            </Grid>
              </Grid>
            </Grid>
          </Grid>
          {pinnedData && pinnedData.length > 0 ? (
            view !== "List View" ? (
              <div
                className={classes.tile_container}
                style={{ direction: direction }}
              >
                {pinnedData &&
                  pinnedData.slice(0,viewLength?pinnedData.length:4).map((res, key) => {
                    const spanId=`${props.id}_${res?.projectName}_${res.scriptName}_pinnedIcon_${key}`;
                    return (
                      <div
                        key={key}
                        className={classes.root_tile}
                        onMouseEnter={() => onHover(key)}
                        onMouseLeave={() => onHoverExit()}
                        onClick={(e) => handleScriptAction(e, "Open", res)}
                        tabIndex={0}
                        onFocus={() => onHover(key)}
                        onKeyPress={(e) =>
                          e.key === "Enter" &&
                          handleScriptAction(e, "Open", res)
                        }
                        role="button"
                        id={`${props.id}_${
                          res?.projectName ? res?.projectName : "DemoProject"
                        }_${res.scriptName}`}
                      >
                        <Grid container 
                              direction={"column"} 
                              //spacing={1} 
                              className={classes.root_tile_right}
                              sx={{
                                padding:"6px"
                              }}
                        >
                          <Grid item
                            style={{ background:"rgba(0, 114, 198, .07) 0 0 no-repeat padding-box", padding:"4px"}}
                            //className={classes.tileServiceFlowStatus}
                          >
                            <Grid container>
                              <Grid item xs={2}
                                sx={{ 
                                  display: 'flex', 
                                  alignItems: 'center'
                                }}
                              >
                                <ScriptIcon
                                  style={{height:"30px", width:"30px"}}
                                />
                              </Grid>
                              <Grid item xs={6}>
                                <Grid container 
                                      direction="column" 
                                      //alignItems={"flex-start"} 
                                      //justifyContent={"center"}
                                >
                                  <Grid item
                                    // sx={{
                                    //   display: "flex",
                                    //   alignItems:"flex-end"
                                    // }}
                                  >
                                    <Typography
                                        className={classes.tile_title}
                                        noWrap={true}
                                        title={res.scriptName || ""}
                                    >
                                        {truncateStringValues({
                                          str: res.scriptName,
                                          min: 8,
                                          max: 10,
                                        })}
                                    </Typography>
                                  </Grid>
                                  <Grid item
                                    // sx={{
                                    //   display: "flex",
                                    //   alignItems:"flex-start"
                                    // }}
                                  >
                    
                                  {res?.projectName != "" &&
                                    res?.projectName != undefined && (
                                      <Typography
                                        className={classes.tile_status}
                                        noWrap={true}
                                        title={res?.projectName || ""}
                                      >
                                        {truncateStringValues({
                                          str: res?.projectName,
                                          min: 8,
                                          max: 10,
                                        })}
                                      </Typography>
                                    )}
                           
                                  </Grid>
                                </Grid>
                              </Grid>
                              <Grid item xs={2}>
                              {res.versionName !== "" ? (
                               
                                  <Typography
                                    style={{
                                      color: "#606060",
                                      paddingTop:"6px"
                                    }}
                                  >
                                    {res.versionName}
                                  </Typography>
                              
                             
                            ) : null}
                            </Grid>

                            <Grid item xs
                             onMouseEnter={() => handleMouseEnter(spanId)}
                             onMouseLeave={() => handleMouseLeave(spanId)} 
                             onClick={(e) => handleScriptAction(e, "Unpin", res)}
                               sx={{ 
                                display: 'flex', 
                                justifyContent: 'flex-end'
                              }}
                              
                              >
                              <span
                                  tabIndex={0}
                                  role="button"
                                  aria-pressed="false"
                                  id={spanId}
                                  className={classes.focusVisible}
                                  aria-label="pinBtn"
                                 
                                >
                                  <UniqueIDGenerator>
                                  {hoveredItems[spanId] ? (
                                      <UnPinIcon className={classes.pin} />
                                    ) : (
                                      <PinIcon className={classes.pin} />
                                    )}
                                  </UniqueIDGenerator>
                              </span>
                            </Grid>
                            </Grid>
                          </Grid>
                         
                          <Grid item
                            style={{
                               padding: "4px 4px 4px 35px"
                            }}
                          >
                            <div className={classes.tile_subStatus}>
                              <Brightness1
                                className={classes.icon1}
                                 /**
                                  * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                                  * Resolution: Updated colors for Published and Draft dot.
                                  * Date : 28/01/2025             
                                  * */
                                style={{
                                  color: res?.isPublished
                                  ? "#0D6F08"
                                  : "#F0A229",
                                }}
                              />
                              {res?.isPublished !== "" &&
                                res?.isPublished !== undefined && (
                                  <Typography
                                    className={classes.tile_type}
                                    noWrap={true}
                                  >
                                    {/**
                                    * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                                    * Resolution:Capilatised the "Draft" and "Published"
                                    * Date : 28/01/2025             
                                    * */ }
                                    {res?.isPublished
                                      ? t("Published")
                                      : t("Draft")}
                                  </Typography>
                                )}
                            </div>
                            <div>
                              {res?.lastModified && (
                                <Typography className={classes.tile_subDesc}>
                                  {label.last_modified} :{" "}
                                  {res?.lastModified
                                    ? getDateAndTimeStrForTile(res.lastModified)
                                    : ""}
                                </Typography>
                              )}
                            </div>
                          </Grid>
                        </Grid>
                      </div>
                    );
                  })}
              </div>
            ) : (
              // <div>
                <RecentActivity
                  id={props.id}
                  headerData={headerData}
                  recentList={recentList}
                  isSticky={false}
                  loading={loading}
                  isSearch={false}
                  isDropDownFilter={false}
                  handleScriptAction={handleScriptAction}
                  direction={direction}
                  heading={``}
                  imageInfo={{
                    path: `${process.env.REACT_APP_CONTEXT_PATH}/icons/`,
                    ext: ".svg",
                  }}
                />
              // </div>
            )
          ) : loading ? (
            // <div>
              <LoadingIndicator />
            // </div>
          ) : (
            <Grid container>
              <Grid item>
                <Typography>{t("No pinned Service Flow yet.")}</Typography>
              </Grid>
            </Grid>
          )}
        {/* </div> */}
      </React.Fragment>
    // </div>
  );
};

export default Pinned;

const items = [
  "Open",
  //"Open In New Tab",
  "Unpin",
  "Open Previous Versions",
  "Edit Name and Tags",
  "History",
  "Sharing",
  "Export",
  "Move To",
  "Delete",
];

const menItems = [
  { name: "Tile View", icon: TileViewIcon },
  { name: "List View", icon: ListViewIcon },
];
