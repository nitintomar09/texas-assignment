import React, { useEffect, useState, useContext } from "react";
import { Grid, Typography, Paper, CircularProgress } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { Script1, PublishScriptIcon } from "../../utils/AllImages";

import NewScriptModal from "../modals/NewScriptModal";
import ScriptHistoryModal from "./../modals/ScriptHistoryModal";
import StopSharingModal from "./../modals/StopSharingModal";
import PreviousVersionsModal from "./../modals/PreviousVersionsModal";
import SharingSettingModal from "./../modals/ShareSettingsModal";
import ExportImportModal from "./../modals/Export-Import-Modal";
import ConfirmDeleteModal from "./../modals/ConfirmDeleteModal";
import { setOpenScriptDetails, getUsersList } from "../../redux/actions";
import Pinned from "./Pinned/index";
import RecentActivity from "./RecentActivity";
import { NotificationContext } from "../../contexts/NotificationContext";
import {
  createInstance,
  doesUserHavePermission,
  handleNetworkRequestError,
  getUserId,
} from "../../utils/common";
import {
  HOME,
  RECENT_SCRIPTS,
  SCRIPT_COUNT,
  PINNED_SCRIPT,
  SCRIPT,
  SHARE_INDEX,
  MODIFY_INDEX,
  REMOVE_INDEX,
  EXPORT_SCRIPT_INDEX,
  VIEW_INDEX,
  CREATE_INDEX,
  PROJECTS,
} from "../../config";
import { useHistory } from "react-router-dom";
import { useDispatch } from "react-redux";
import moment from "moment";
import { getDecryptData, getEncryptedId } from "../../utils/encryptions";
import MoveToProjectModal from "../modals/MoveToProject";
import { useTranslation } from "react-i18next";
import Loader from "../loader/loader";

const useStyles = makeStyles((theme) => ({
  root: {
    padding: "20px",
    height: "590px",
    overflowY: "scroll",
  },
  primeColor: {
    color: `${theme.palette.primary.main}`,
  },
  bold: {
    fontWeight: 700,
  },
  header: {
    opacity: 0.6,
    fontWeight: 550,
    fontSize: "12px",
  },
}));
const Dashboard = () => {
  const [scriptDet, setScriptDet] = useState(null);
  const { t } = useTranslation();
  const userId = getUserId();
  const dispatch = useDispatch();
  const [allRecentScripts, setAllRecentsScript] = useState([]);
  const [allPinnedScripts, setAllPinnedScript] = useState([]);
  const [isCountLoading, setIsCountLoading] = useState(false);
  const [isRecentLoading, setIsRecentLoading] = useState(false);
  const [isPinnedLoading, setIsPinnedLoading] = useState(false);
  const [openModalName, setOpenModalName] = useState(null);
  const [selectedScript, setSelectedScript] = useState(null);
  const [toBeDeleted, setToBeDeleted] = useState(null);
  const { setValue } = useContext(NotificationContext);
  const [allOwnerProjects, setAllOwnerProjects] = useState([]);
  const [allSharedProjects, setAllSharedProjects] = useState([]);
  const [applicationDetails, setApplicationDetails] = useState(null);

  const history = useHistory();

  const headerData = [
    { category: t("Name") },
    { category: t("Status") },
    { category: t("Last Opened On") },
  ];

  useEffect(() => {
    const params = new Proxy(new URLSearchParams(window.location.search), {
      get: (searchParams, prop) => searchParams.get(prop),
    });
    if (params) {
      if (params.applicationDetails) {
        const decryptedApplicationDetails = getDecryptData(
          params.applicationDetails
        );
        setApplicationDetails(decryptedApplicationDetails);
      }
    }
  }, [allOwnerProjects]);

  // useEffect(()=>{
  //   window.loadConfig();
  // },[])

  useEffect(() => {
    dispatch(
      getUsersList({
        history,
      })
    );
  }, []);
  useEffect(() => {
    getRecentScripts();
    getPinnedScripts();
  }, []);

  const getProjects = async () => {
    const axiosInstance = createInstance();
    try {
      let res = await axiosInstance.get(`${PROJECTS}`);

      if (res.status === 200) {
        const ownerProject = res.data.data
          ? res.data.data[0]["ownerProject"]
            ? res.data.data[0]["ownerProject"]
            : []
          : [];
        const sharedProject = res.data.data
          ? res.data.data[0]["sharedProject"]
            ? res.data.data[0]["sharedProject"]
            : []
          : [];

        setAllOwnerProjects(
          ownerProject.filter((item) => item.createdBy === +userId)
        );

        setAllSharedProjects([...sharedProject]);
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
      });
    }
  };

  useEffect(() => {
    getProjects();
  }, []);
  useEffect(() => {
    if (applicationDetails) {
      if (applicationDetails.launchpadNew.value.option == "CREATE") {
        setOpenModalName("New Script");
      } else {
        const clickedOnScript = {
          scriptId: Number(applicationDetails.launchpadNew.value.data.id),
          scriptName: applicationDetails.launchpadNew.value.data.name,
          versionName: "V" + applicationDetails.launchpadNew.value.data.version,
        };
        handleScriptAction(null, "Open", clickedOnScript);
      }
    }
  }, [applicationDetails]);
  const getScriptCounts = async () => {
    setIsCountLoading(true);
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${HOME}${SCRIPT_COUNT}`);
      if (res.status === 200) {
        const data = res.data?.data ? res.data?.data[0] : null;
        if (data) {
          const failed = data["totalFailureScript"];
          const total = data["totalScript"];
          const published = data["totalPublishedScript"];
          const success = data["totalSuccessScript"];
          setScriptDet({ published, failed, total, success });
          setIsCountLoading(false);
        }
      }
    } catch (error) {
      console.log(error);
      setIsCountLoading(false);
      handleNetworkRequestError({ error, history });
    }
  };
  const getPinnedScripts = async () => {
    setIsPinnedLoading(true);
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${HOME}${PINNED_SCRIPT}`);
      if (res.status === 200) {
        const data = res.data?.data ? res.data?.data : null;
        if (data) {
          setAllPinnedScript(data);
          setIsPinnedLoading(false);
        }
      }
      setIsPinnedLoading(false);
    } catch (error) {
      console.log(error);
      setIsPinnedLoading(false);
      handleNetworkRequestError({ error, history });
    }
  };
  const getRecentScripts = async () => {
    setIsRecentLoading(true);
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${HOME}${RECENT_SCRIPTS}`);
      if (res.status === 200) {
        const data = res.data?.data ? res.data?.data : [];

        if (data) {
          const rec = { category: "", value: [] };
          const yesterday = { category: "Yesterday", value: [] };
          const lastWeek = { category: "Last Week", value: [] };
          const earlier = { category: "Earlier", value: [] };

          data.forEach((item) => {
            const { lastModified } = item;
            if (lastModified) {
              if (moment().isSame(moment(lastModified), "day")) {
                rec["value"].push(item);
              } else if (
                moment().subtract(1, "days").isSame(moment(lastModified), "day")
              ) {
                yesterday["value"].push(item);
              } else if (
                moment().subtract(6, "days").isBefore(moment(lastModified)) &&
                moment(lastModified).isBefore(moment().subtract(1, "days"))
              ) {
                lastWeek["value"].push(item);
              } else if (
                moment().subtract(7, "days").isAfter(moment(lastModified))
              ) {
                earlier["value"].push(item);
              }
            } else {
              earlier["value"].push(item);
            }
          });
          const newRecScripts = [
            { ...rec },
            { ...yesterday },
            { ...lastWeek },
            { ...earlier },
          ];
          setAllRecentsScript(newRecScripts);
          setIsRecentLoading(false);
        }
      }
      setIsRecentLoading(false);
    } catch (error) {
      console.log(error);
      setIsRecentLoading(false);

      handleNetworkRequestError({ error, history });
    }
  };

  const updateProjects = (project) => {
    setAllOwnerProjects([project, ...allOwnerProjects]);
  };

  const updateScripts = (script) => {
    if (script) {
      const newAllScripts = [...allPinnedScripts];
      if (newAllScripts) {
        const scriptIndex = newAllScripts.findIndex(
          (obj) => obj.scriptId === script.scriptId
        );
        const scriptObj = newAllScripts.find(
          (obj) => obj.scriptId === script.scriptId
        );
        if (scriptIndex !== -1) {
          if (!script.lastVersion) {
            newAllScripts.splice(scriptIndex, 1, {
              ...scriptObj,
              ...script,
            });
          } else {
            newAllScripts.splice(scriptIndex, 1);
          }
        }
        setAllPinnedScript(newAllScripts);
      }
    }
  };
  const deleteScript = async () => {
    const { versionId, scriptId, versionName } = toBeDeleted;
    const axiosInstance = createInstance();

    try {
      let res = await axiosInstance.delete(
        `${SCRIPT}/${scriptId}/${versionId}/${versionName}`
      );
      if (res.status === 200) {
        const newScriptDetails = res.data?.data ? res.data.data[0] : null;
        console.log(res);

        if (newScriptDetails) {
          const newScript = { ...toBeDeleted, ...newScriptDetails };
          updateScripts(newScript);
        } else {
          updateScripts({ scriptId: scriptId, lastVersion: true });
        }
        setValue({
          isOpen: true,
          message: res.data.message || "deleted successfully.",
          title: toBeDeleted.scriptName || "",
          notificationType: "SUCCESS",
        });
        handleCancelDelete();
      }
    } catch (error) {
      console.log(error);
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setValue({
            isOpen: true,
            message: errMsg || "could not be deleted.",
            title: "Script",
            notificationType: "ERROR",
          });
        },
      });
    }
  };

  const onScriptDelete = () => {
    deleteScript();
  };
  const handleCancelDelete = () => {
    setToBeDeleted(null);
    handleCloseModal();
  };

  const handleOpenModal = (name) => {
    setOpenModalName(name);
  };
  const handleCloseModal = () => {
    setOpenModalName(null);
    setSelectedScript(null);
  };
  const handleToBeDeleted = (item) => {
    setToBeDeleted(item);
  };

  const showModal = () => {
    let modalToOpen = null;
    switch (openModalName) {
      case "New Script":
        modalToOpen = (
          <NewScriptModal
            id="RPA_ScriptDesigner_NewScript"
            folderOptions={[...allOwnerProjects].map((item) => ({
              name: item.projectName,
              value: item.projectId,
            }))}
            handleClose={handleCloseModal}
            updateProjects={updateProjects}
            isOpen={true}
            isOpenFromDashboard={true}
            applicationDetails={applicationDetails}
          />
        );
        break;
      case "Update Script":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: MODIFY_INDEX,
          })
        ) {
          modalToOpen = (
            <NewScriptModal
              handleClose={handleCloseModal}
              editedScript={selectedScript}
              updateScripts={updateScripts}
              isOpen={true}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to update a script.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Script Sharing":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: SHARE_INDEX,
          })
        ) {
          modalToOpen = (
            <SharingSettingModal
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
              updateScripts={updateScripts}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to share a script.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Script History":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,

            permissionNum: VIEW_INDEX,
          })
        ) {
          modalToOpen = (
            <ScriptHistoryModal
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to view history of a script.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Stop Sharing":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: SHARE_INDEX,
          })
        ) {
          modalToOpen = (
            <StopSharingModal
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
              updateScripts={updateScripts}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to change sharing settings.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Script Previous Versions":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,

            permissionNum: VIEW_INDEX,
          })
        ) {
          modalToOpen = (
            <PreviousVersionsModal
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message:
              "You Don't have permission to view previous versions of a script.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Export":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: EXPORT_SCRIPT_INDEX,
          })
        ) {
          modalToOpen = (
            <ExportImportModal
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
              actionType="Export"
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to export a script.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Move To":
        if (
          doesUserHavePermission({
            isShared: false,
            permissionNum: CREATE_INDEX,
          })
        ) {
          modalToOpen = (
            <MoveToProjectModal
              handleClose={handleCloseModal}
              projectList={[...allOwnerProjects, ...allSharedProjects]}
              updateScripts={updateScripts}
              selectedScript={selectedScript}
              isOpen={true}
              fromDashboard={true}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to create a project.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Delete Script":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: REMOVE_INDEX,
          })
        ) {
          modalToOpen = (
            <ConfirmDeleteModal
              handleClose={handleCloseModal}
              isProject={false}
              isOpen={true}
              onDelete={onScriptDelete}
              handleCancel={handleCancelDelete}
              title={toBeDeleted ? toBeDeleted.scriptName : ""}
              description={"this version of the script will be deleted."}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to delete a script.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;

      default:
        break;
    }
    return modalToOpen;
  };
  const pinOrUnpinScript = async (script, isPinned) => {
    const { scriptId, versionId } = script;
    if (scriptId && versionId) {
      const axiosInstance = createInstance();
      debugger;
      try {
        const res = await axiosInstance.post(`${HOME}${PINNED_SCRIPT}`, {
          scriptId,
          versionId,
          isPinned,
        });
        {
          /*
           * @author sanya.mahajan For Bug 156099 - UX Home - On hover interaction of table
           * Reason:Earlier no Pin functionality was provided to pin the scripts from the dashboard
           * Resolution: Updated the logic to introduce the same.
           * Date : 03/02/2025
           * */
        }
        if (res.status === 200) {
          if (isPinned) {
            setAllPinnedScript((prev) => [...prev, { ...script, isPinned: 1 }]);
          } else {
            setAllPinnedScript((prev) =>
              prev.filter((pinnedScr) => pinnedScr.scriptId !== scriptId)
            );
            // setValue;
          }
          setValue({
            isOpen: true,
            message: res.data["message"] || "done successfully.",
            notificationType: "SUCCESS",
            title: script.scriptName,
          });
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (err) => {
            setValue({
              isOpen: true,
              message: err || "pin/unpin error.",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
      }
    }
  };

  const handleScriptAction = (e, action, clickedOnScript) => {
    const { scriptId, versionName, scriptName } = clickedOnScript;

    switch (action) {
      case "Open":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          setSelectedScript(null);
          if (scriptId && versionName) {
            dispatch(
              setOpenScriptDetails({ scriptId, versionName, scriptName })
            );
            history.push(`/serviceflow`);
          } else {
            console.log("falsy versionName/scriptId", versionName, scriptId);
          }
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to view a script.",
            notificationType: "ERROR",
            title: "",
          });
        }
        if (e != null) {
          e.stopPropagation();
        }
        break;
      /*
         * @author sanya.mahajan For Bug 156099 - UX Home - On hover interaction of table
         * Reason:Earlier no Pin functionality was provided to pin the scripts from the dashboard
         * Resolution: Introduced the case for the same.
         * Date : 03/02/2025
         * */
      case "Pin":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          pinOrUnpinScript(clickedOnScript, 1);
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to Pin a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();
        break;
      default:
        break;
    }
  };

  const classes = useStyles();

  if (isRecentLoading || isPinnedLoading) {
    return <Loader size={30} />;
  }

  return (
    <Grid className={classes.root}>
      <Grid container direction={"column"}>
        <Grid item>
          {/* <div style={{ marginBottom: "27px" }}> */}
          <Pinned
            id="RPA_Dashboard_Pinned"
            pinnedData={allPinnedScripts}
            loading={isPinnedLoading}
            width="215px"
            handleOpenModal={handleOpenModal}
            handleToBeDeleted={handleToBeDeleted}
            setSelectedScript={setSelectedScript}
            pinOrUnpinScript={pinOrUnpinScript}
          />
          {/* </div> */}
        </Grid>
        <Grid item>
          <RecentActivity
            id="RPA_Dashboard_Recent"
            headerData={headerData}
            recentList={allRecentScripts}
            isSticky={true}
            loading={isRecentLoading}
            handleScriptAction={handleScriptAction}
            isSearch={true}
            direction={"ltr"}
            t={t}
            pinOrUnpinScript={pinOrUnpinScript}
          />
        </Grid>
      </Grid>
      {/*will return the modal whichever selected */}
      {openModalName ? showModal() : null}
    </Grid>
  );
};

export default Dashboard;
