import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";
import SearchBox from "../../../utils/Search-Component";
import {
  Typography,
  Grid,
  TextField,
  MenuItem,
  IconButton,
} from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import {
  DocIcon,
  StatusIcon,
  FolderFilledIcon,
  PublishedDotIcon,
  FolderBrowseIcon,
  FolderIcon,
  ChevronIcon,
  HoverPinIcon,
} from "../../../utils/AllImages";
import LoadingIndicator from "../../../utils/loadingIndicator";
import moment from "moment";
import clsx from "clsx";
import _ from "lodash";
import { useSelector } from "react-redux";
import {
  getUserId,
  getDateOnly,
  truncateStringValues,
  getCalendarDate,
  generateUniqueId,
  getDateOnlyBy,
} from "./../../../utils/common";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../../utils/UniqueIDGenerator";
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  subRoot: {
    width: "100%",
    //height: "100%",
    marginBottom: "20px",
    //paddingRight: "5px",
    direction: (props) => props.direction,
  },
  /**
   * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
   * Reason: The table was not according to NODS
   * Resolution: Updated the Ui according to designs provided
   * Date : 28/01/2025
   * */
  comp: {
    // display: "flex",
    alignItems: "center",
    background: "white",
    // boxShadow: "none",
    width: "100%",
    minHeight: "45px",
    paddingRight: "12px",
    paddingLeft: "12px",
    marginBottom: "4px",
    cursor: "pointer",
    /**
     * @author sanya.mahajan For Bug 156099 - UX Home - On hover interaction of table
     * Reason: The table had a transition and boxShadow effect earlier
     * Resolution: Updated the background Color and removed the styling not required
     * Date : 03/02/2025
     * */
    // transition: "all 100ms ease-in",
    "&:hover": {
      //boxShadow: "0px 3px 6px #00000029",
      backgroundColor: "#F0F0F0",
    },
  },

  spinner: {
    height: "600px",
  },

  heading: {
    //display: "flex",
    paddingLeft: "8px",
    // flexWrap: "wrap",
    width: "100%",
    /**
     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
     * Resolution: Updated the margin as per the designs provided
     * Date : 28/01/2025
     * */
    marginBottom: "4px",
  },

  headerRightWrapper: {
    display: "flex",
    flexWrap: "wrap",
    gap: 2,
    // padding: (props) => (props.direction === "rtl" ? "0 22px" : "0 32px"),
    padding: "0 1px",
  },

  buttonWrapper: {
    margin: "0px 16px",
    height: "27.5px",
    width: "138px",
    backgroundColor: theme.palette.common.white,
  },
  headingText: {
    color: "#000000",
    /**
     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
     * Resolution: Updated the fontSize as per the designs provided
     * Date : 28/01/2025
     * */
    fontSize: "12px",
    fontWeight: 600,
    lineHeight: "1.5rem",
    height: "30px",
    flex: 1,
    paddingTop: "4px",
  },

  separetorHeading: {
    fontSize: "12px",
    /**
     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
     * Resolution: Updated the fontSize and margin as per the designs provided
     * Date : 28/01/2025
     * */
    fontWeight: 600,
    margin: (props) =>
      props.direction === "rtl" ? "15px 53px 15px 0" : "8px 0 8px 57px",
  },
  title: {
    fontSize: "15px",
    fontWeight: 700,
    marginBottom: "10px",
    marginRight: "10px",
  },
  sticky: {
    display: "flex",
    justifyContent: "space-between",
    paddingTop: "15px",
    width: "100%",
    flexWrap: "wrap",
    zIndex: 99,
    background: "#f8f8f8",
    position: "sticky",
    top: "55px",
    boxShadow: (props) => (props.stick === true ? "0px 3px 6px #00000029" : ""),
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    // paddingTop: props => props.heading !== '' ? "15px" : 0,
    width: "100%",
    flexWrap: "wrap",
    zIndex: 99,
    marginBottom: "8px",
    // background: "#f8f8f8",
  },
  /**
   * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
   * Resolution: Updated the fontSize and fontWeight as per the designs provided
   * Date : 28/01/2025
   * */
  scriptTitle: {
    fontWeight: 400,
    //color: "#606060",
    fontFamily: "Open Sans",
    size: "12px",
  },
  light: {
    fontWeight: 400,
    color: "#606060",
    fontFamily: "Open Sans",
    size: "11px",
  },
  tile_type: {
    textAlign: (props) => (props.direction === "rtl" ? "right" : "left"),
    fontSize: "12px",
    letterSpacing: "0px",
    //color: "#606060",
    fontWeight: 600,
    opacity: 1,
    maxWidth: "98px",
    margin: "0 8px 0 3px",
  },
  /**Bug 156086 closes here in context to fontSize and fontWeight */

  icon: {
    // marginRight: "4px",
    width: "7px",
    height: "7px",

    cursor: "pointer",
  },
  input: {
    height: 30,
    paddingRight: "10px",
    fontSize: 12,
    width: "156px",
    backgroundColor: "#FFFFFF",

    //border: "1px solid #C4C4C4",
  },
  noBorder: {
    border: "none",
    //color: "#0072C6",
  },
  selectIcon: {
    color: "#C4C4C4",
    marginTop: "3px",
  },
  rootSel: {
    color: "#000000",
  },
  selectedTab: {
    borderBottom: `4px solid ${theme.palette.primary.main}`,
  },
  icons: {
    height: "16px",
    width: "16px",
  },
}));

const RecentActivity = (props) => {
  const {
    loading = false,
    isSearch = true,
    isDropDownFilter = true,
    recentList = [],
    headerData = [],
    isSticky = true,
    heading = props.t("Recents"),
    direction = "ltr",
    searchProps = {
      searchingKey: "scriptName",
      placeholder: "Search",
      regex: null,
    },
    imageInfo = {
      path: undefined, //`${process.env.REACT_APP_CONTEXT_PATH}/icons/`,
      ext: undefined, //'.svg'
    },
    handleScriptAction = () => {
      console.log("please provide handleScriptAction() prop");
    },
  } = props;
  const { t } = useTranslation();
  const [data, setData] = useState([]);
  const [selTab, setSelTab] = useState("Recents");
  const [goingUp, setGoingUp] = useState(false);
  const [stick, setStick] = useState(false);
  const [scriptStatus, setScriptStatus] = useState(t("All status"));
  const classes = useStyles({ direction, heading, stick });
  const allUsers = useSelector((state) => state.scriptsAndProjects.allUsers);
  const currentUserId = getUserId();
  useEffect(() => {
    setData(_.cloneDeep(recentList));
  }, [recentList]);
  useEffect(() => {
    if (isSticky) {
      const header = document.getElementById("myHeader");
      const sticky = header.offsetTop - 55;
      const scrollCallBack = window.addEventListener("scroll", () => {
        if (isSticky) {
          if (window.pageYOffset > sticky) {
            setGoingUp(true);
            if (header.getBoundingClientRect().top === 55) {
              setStick(true);
            } else {
              setStick(false);
            }
          } else {
            setGoingUp(false);
          }
        }
      });
      return () => {
        window.removeEventListener("scroll", scrollCallBack);
      };
    }
  }, []);

  const onSearchSubmit = (searchString) => {
    let ar = [];
    recentList.map((category) => {
      let searchedVal = category.value.filter((val) => {
        return val[searchProps.searchingKey]
          .toLowerCase()
          .includes(searchString.toLowerCase());
      });
      if (searchedVal.length > 0) {
        ar.push({
          ...category,
          value: searchedVal,
        });
      }
    });
    setData(ar);
  };
  const clearSearchResult = () => {
    setData(_.cloneDeep(recentList));
  };
  const getRecentScriptsCount = () => {
    const result = data.reduce((acc, curr) => {
      if (curr?.value?.length > 0) {
        acc = acc + curr?.value?.length;
      }
      return acc;
    }, 0);
    return result || "";
  };
  const handleSelTab = (tab) => {
    setSelTab(tab);
    if (tab === "Recents") {
      setData(_.cloneDeep(recentList));
    } else {
      let newData = [];
      recentList.forEach((item) => {
        const newValue = item.value?.filter((obj) => obj.testStatus === 3);
        if (newValue && newValue.length > 0) {
          item.value = [...newValue];
          newData = [...newData, item];
        }
      });
      setData(_.cloneDeep(newData));
    }
  };
  const handleStatus = (status) => {
    setScriptStatus(status);
    if (status === t("All status")) {
      setData(_.cloneDeep(recentList));
      return;
    }
    /*****************************************************************************************
     * @author asloob_ali BUG ID : 103680  Description : 103680  -Dashboard: Script Status filter on home page is not working correctly
     *  Reason:the data of prop's(recentList) object  passed to the component was mutated while filtering data based on status.
     * Resolution :not mutating the recentList object's data,making a seprate copy then filtering the data.
     *  Date : 31/12/2021             ****************/
    const recentListCopy = _.cloneDeep(recentList);
    let newData = [];
    recentListCopy.forEach((item) => {
      const newValue = item.value?.filter(
        (obj) =>
          (status === t("Published") && obj.isPublished) ||
          (status === t("Draft") && !obj.isPublished)
      );

      if (newValue && newValue.length > 0) {
        item.value = [...newValue];
        newData = [...newData, item];
      }
    });
    setData(_.cloneDeep(newData));
  };
  const getNameOfUser = (id) => {
    const user = allUsers.find((usr) => usr.userIndex === +id);

    if (user) {
      return user.userIndex === +currentUserId
        ? user.userLoginId
        : user.userLoginId;
    }
    return "";
  };
  /**
   * @author sanya.mahajan For Bug 156099 - UX Home - On hover interaction of table
   * Description: Adding a new state to handle the display of pin functionality when hovered on the table row
   * Date : 03/02/2025
   * */
  const [hoveredRow, setHoveredRow] = useState(null);
  const handleMouseEnter = (id) => {
    setHoveredRow(id);
  };

  const handleMouseLeave = (id) => {
    setHoveredRow(null);
  };
  return (
    <Grid container className={classes.root}>
      {loading ? (
        <Grid container className={classes.spinner}>
          <LoadingIndicator />
        </Grid>
      ) : (
        <Grid container className={classes.subRoot}>
          <Grid
            item
            //spacing={1}
            id={isSticky ? "myHeader" : "myHeader_1"}
            className={goingUp ? classes.sticky : classes.header}
          >
            {heading !== "" ? (
              <Grid item>
                <Typography
                  className={classes.title}
                  noWrap={true}
                  onClick={() => handleSelTab(heading)}
                  onKeyPress={(e) => e.key === "Enter" && handleSelTab(heading)}
                  style={{ cursor: "pointer" }}
                  tabIndex={0}
                  id={`${props.id}_Title`}
                >
                  {" "}
                  {heading}{" "}
                  {data.length > 0 && getRecentScriptsCount() > 0
                    ? `(${getRecentScriptsCount()})`
                    : ""}
                </Typography>
              </Grid>
            ) : null}
            <Grid item className={classes.headerRightWrapper}>
              <Grid container spacing={1}>
                {isSearch ? (
                  <Grid item>
                    {/* //Bug Id:Bug 155127 - UI issues on the search tab of the homepage of the service flow
                  Author:dixita.Ruhela
                  Date: 7 JAN 2025
                  RCA: Update the Ui of searchBox */}
                    <SearchBox
                      id={`${props.id}_SearchBox`}
                      height="28px"
                      width="150px"
                      direction={direction}
                      onSearchChange={onSearchSubmit}
                      clearSearchResult={clearSearchResult}
                      placeholder={searchProps.placeholder}
                      regex={searchProps.regex}
                      t={t}
                    />
                  </Grid>
                ) : null}

                {isDropDownFilter && (
                  <Grid item>
                    <TextField
                      id={`${props.id}_Dropdown`}
                      type={"text"}
                      size="medium"
                      InputProps={{
                        className: classes.input,
                      }}
                      value={scriptStatus || ""}
                      onChange={(e) => {
                        handleStatus(e.target.value);
                      }}
                      variant="outlined"
                      select={true}
                      SelectProps={{
                        MenuProps: {
                          anchorOrigin: {
                            vertical: "bottom",
                            horizontal: "left",
                          },
                          transformOrigin: {
                            vertical: "top",
                            horizontal: "left",
                          },
                          getContentAnchorEl: null,

                          PaperProps: {
                            elevation: 3,
                            square: true,
                            style: {
                              border: "1px solid #CCCEEE",
                              boxShadow: "0px 3px 6px #00000029",
                              minWidth: 157,
                              backgroundColor: "#FFFFFF",
                            },
                          },
                        },
                        /**
                         * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                         * Resolution: Updated the icon
                         * Date : 28/01/2025
                         * */
                        IconComponent: ChevronIcon,
                      }}
                      style={{ border: "1px" }}
                    >
                      {[t("All status"), t("Published"), t("Draft")].map(
                        (item, index) => {
                          return (
                            <MenuItem
                              value={item}
                              style={{ textAlign: "center" }}
                              key={index}
                              role="contentinfo"
                            >
                              <Typography
                                style={{
                                  fontSize: "12px",
                                  fontWeight: scriptStatus == item ? 600 : 400,
                                }}
                                variant="h6"
                              >
                                {" "}
                                {item}
                              </Typography>
                            </MenuItem>
                          );
                        }
                      )}
                    </TextField>
                  </Grid>
                )}
              </Grid>
            </Grid>
          </Grid>

          {data?.length > 0 ? (
            <Grid item width={"100%"}>
              <Grid container className={classes.heading}>
                <Grid item xs>
                  <Grid container>
                    {headerData.map((item, index) => (
                      <Grid item xs={4} key={index}>
                        {index === 0 ? (
                          <Grid container alignItems="center">
                            <Grid
                              item
                              style={{
                                margin:
                                  direction === "rtl"
                                    ? "0 10px 0 20px"
                                    : "0 42px 0 0",
                                alignItems: "center",
                              }}
                            >
                              {/**
                               * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                               * Resolution: Removed the icon from the header
                               * Date : 28/01/2025
                               * */
                              /* <UniqueIDGenerator>
                                  <DocIcon
                                    // htmlColor="#606060"
                                    style={{
                                      height: "16px",
                                      width: "16px",
                                      marginTop: "6px",
                                    }}
                                  />
                                </UniqueIDGenerator> */}
                            </Grid>
                            <Grid item>
                              <Typography
                                className={classes.headingText}
                                //noWrap={true}
                              >
                                {item.category}
                              </Typography>
                            </Grid>
                          </Grid>
                        ) : (
                          <Typography
                            className={classes.headingText}
                            //noWrap={true}
                          >
                            {item.category}
                          </Typography>
                        )}
                      </Grid>
                    ))}
                  </Grid>
                </Grid>
              </Grid>

              <Grid container>
                {/* // height={"400px"} overflow={"auto"}*/}
                {data?.map((item, index) => {
                  return (
                    <Grid
                      container
                      key={index}
                      direction={"column"}
                      spacing={1}
                    >
                      {item.category && item.value.length > 0 ? (
                        <Typography
                          className={
                            item.category ? classes.separetorHeading : ""
                          }
                          noWrap={true}
                        >
                          {" "}
                          {item.category}
                        </Typography>
                      ) : null}
                      {item?.value?.map((res, index) => {
                        return (
                          // <React.Fragment   >
                          <Grid
                            container
                            key={index}
                            direction="row"
                            className={classes.comp}
                            onClick={(e) => handleScriptAction(e, "Open", res)}
                            //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
                            tabIndex={0}
                            onKeyPress={(e) =>
                              e.key === "Enter" &&
                              handleScriptAction(e, "Open", res)
                            }
                            role="button"
                            aria-pressed="false"
                            id={`${props.id}_${res.projectName || ""}_${
                              res.scriptName || ""
                            }_${generateUniqueId()}`}
                            //justify="space-between"

                            onMouseEnter={() => handleMouseEnter(res.scriptId)}
                            onMouseLeave={() => handleMouseLeave(res.scriptId)}
                          >
                            <Grid item xs={4}>
                              <Grid container alignItems="center">
                                <Grid
                                  item
                                  style={{
                                    margin:
                                      direction === "rtl"
                                        ? "0 10px 0 16px"
                                        : "0 20px 0 10px",
                                    alignItems: "center",
                                  }}
                                >
                                  <UniqueIDGenerator>
                                    {/* /**
                                     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                                     * Resolution:Updated the icon size
                                     * Date : 28/01/2025
                                     * */}
                                    <DocIcon
                                      style={{
                                        height: "16px",
                                        width: "16px",
                                      }}
                                    />
                                  </UniqueIDGenerator>
                                </Grid>
                                <Grid item>
                                  <Grid container direction="column">
                                    <Grid item>
                                      <Typography
                                        className={classes.scriptTitle}
                                        title={res.scriptName}
                                        noWrap={true}
                                      >
                                        {res.scriptName || ""}
                                      </Typography>
                                    </Grid>
                                    <Grid item>
                                      <Grid
                                        container
                                        direction="row"
                                        spacing={1}
                                      >
                                        <Grid item>
                                          <Typography
                                            className={classes.light}
                                            variant="body2"
                                          >
                                            {res.versionName}
                                          </Typography>
                                        </Grid>
                                        <Grid item>
                                          <Grid container spacing={1}>
                                            <Grid item>
                                              {/*
                                               * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                                               * Resolution:Removed the folder icon and added dot as required
                                               * Date : 28/01/2025
                                               * */}
                                              {/* <UniqueIDGenerator> */}
                                              {/* <FolderFilledIcon
                                                  className={classes.icons}
                                                /> */}
                                              {/* <FolderIcon height={16} width={16}/> */}
                                              {/* </UniqueIDGenerator> */}
                                              <div
                                                style={{
                                                  width: "4px",
                                                  height: "4px",
                                                  borderRadius: "50%",
                                                  backgroundColor: "#707070",
                                                  marginTop: "4px",
                                                }}
                                              />
                                            </Grid>
                                            <Grid item>
                                              <Typography
                                                className={classes.light}
                                                variant="body1"
                                                noWrap={true}
                                                title={res.projectName || ""}
                                              >
                                                {res.projectName || ""}
                                              </Typography>
                                            </Grid>
                                          </Grid>
                                        </Grid>
                                      </Grid>
                                    </Grid>
                                  </Grid>
                                </Grid>
                              </Grid>
                            </Grid>
                            <Grid item xs={4}>
                              <Grid
                                container
                                direction="column"
                                //spacing={1}
                                sx={{ paddingLeft: "8px" }}
                              >
                                <Grid item>
                                  <Grid container alignItems={"center"}>
                                    <Grid item>
                                      <UniqueIDGenerator>
                                        <StatusIcon
                                          //className={classes.icon}
                                          /**
                                           * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                                           * Resolution: Updated colors for Published and Draft dot.
                                           * Date : 28/01/2025
                                           * */
                                          style={{
                                            color: res?.isPublished
                                              ? "#0D6F08"
                                              : "#F0A229",
                                            height: 6,
                                            width: 6,
                                          }}
                                        />
                                      </UniqueIDGenerator>
                                    </Grid>
                                    <Grid item>
                                      {res?.isPublished !== "" &&
                                        res?.isPublished !== undefined && (
                                          <Typography
                                            className={classes.tile_type}
                                            noWrap={true}
                                          >
                                            {/**
                                             * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                                             * Resolution:Capilatised the "Draft" and "Published"
                                             * Date : 28/01/2025
                                             * */}
                                            {res?.isPublished
                                              ? t("Published")
                                              : t("Draft")}
                                          </Typography>
                                        )}
                                    </Grid>
                                  </Grid>
                                </Grid>
                                <Grid item>
                                  <Typography
                                    className={classes.light}
                                    variant="body2"
                                  >
                                    {res?.isPublished
                                      ? `on ${
                                          res?.actionDoneOn
                                            ? getDateOnlyBy(res.actionDoneOn)
                                            : ""
                                        }`
                                      : `Created on ${
                                          res?.actionDoneOn
                                            ? getDateOnlyBy(res.creationDateTime)
                                            : ""
                                        }`}
                                  </Typography>
                                </Grid>
                              </Grid>
                            </Grid>
                            <Grid item xs={3}>
                              <Grid
                                container
                                direction="column"
                                //spacing={1}
                                sx={{ paddingLeft: "8px" }}
                              >
                                {/* BugId:Bug 155264 - Incorrect date for the last opened on is getting displayed 
                                Author Name=dixita.ruhela
                                Date: 8 JAN 2025
                                RCA: Modify the last opened date */}
                                {res?.lastModified && (
                                  <Grid item>
                                    {/**
                                     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
                                     * Resolution:Updated fontWeight
                                     * Date : 28/01/2025
                                     * */}
                                    <Typography style={{ fontWeight: 400 }}>
                                      {res?.lastModified
                                        ? getCalendarDate(res.lastModified)
                                        : ""}
                                    </Typography>
                                  </Grid>
                                )}
                                <Grid item>
                                  <Typography
                                    className={classes.light}
                                    variant="body2"
                                  >
                                    {res.actionPerformedBy &&
                                    allUsers.length > 0
                                      ? `Edited by ${getNameOfUser(
                                          res.actionPerformedBy
                                        )} on ${
                                          res?.lastModified
                                            ? getDateOnly(res.lastModified)
                                            : ""
                                        }`
                                      : ""}
                                  </Typography>
                                </Grid>
                              </Grid>
                            </Grid>
                            {/*
                             * @author sanya.mahajan For Bug 156099 - UX Home - On hover interaction of table
                             * Description: Pin icon added to display it on dashboard when hovered on a row
                             * Date : 03/02/2025
                             * */}
                            <Grid item xs={1}>
                              {hoveredRow === res?.scriptId && (
                                <IconButton
                                  onClick={(e) => {
                                    handleScriptAction(e, "Pin", res);
                                  }}
                                >
                                  <HoverPinIcon />
                                </IconButton>
                              )}
                            </Grid>
                          </Grid>
                          // </React.Fragment>
                        );
                      })}
                    </Grid>
                  );
                })}
              </Grid>
            </Grid>
          ) : (
            <Grid
              item
              style={{
                height: "100%",
                paddingTop: "150px",
                textAlign: "center",
                width: "100%",
              }}
            >
              <Typography style={{ fontSize: "12px", marginTop: "10px" }}>
                {t("NO DATA FOUND")}
              </Typography>
            </Grid>
          )}
        </Grid>
      )}
    </Grid>
  );
};

RecentActivity.propTypes = {
  loading: PropTypes.bool.isRequired,
  isSearch: PropTypes.bool,
  direction: PropTypes.string,
  recentList: PropTypes.array.isRequired,
  headerData: PropTypes.array.isRequired,
  imageInfo: PropTypes.shape({
    path: PropTypes.string.isRequired,
    ext: PropTypes.string.isRequired,
  }),
  searchProps: PropTypes.shape({
    searchingKey: PropTypes.string,
    placeholder: PropTypes.string,
  }),
};

export default RecentActivity;
