import React, { useState } from "react";
import { Grid, Typography, Divider } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import NotificationBox from "./desginer/NotificationBox";
import CommonBox from "./desginer/CommonBox";
import BoxItem from "./desginer/BoxItem";
import { useTranslation } from "react-i18next";
const failScripts = [
  {
    scriptName: "Newgen_sys",
    version: "v 1.4",
    failedDate: "24-08-2020",
    testedBy: "Satish Routry",
    comment: "Did not accounted for the login popup..",
  },
  {
    scriptName: "Verification_Adhaar",
    version: "v 1.0",
    failedDate: "23-08-2020",
    testedBy: "Satish Routry",
    comment: "The Web browser part is causing error.please check..",
  },
];

const notData = [
  {
    id: 1,
    title: "Card Initiation",
    message: "has encounterd error on testing",
    by: "Ramesh Gowda",
    type: "Error",
    time: "14 Feb 2020 6:30PM",
  },
  {
    id: 2,
    title: "Verification_Adhaar",
    message: "is stopped due to",

    dueTo: "Network Failure",
    type: "Error",
    time: "15 Feb 2020 6:30PM",
  },
  {
    id: 3,
    title: "Excel_init",
    message: "has been published by",
    by: "Ramesh Gowda",

    type: "Info",
    time: "15 Feb 2020 5:30PM",
  },
];

const useStyles = makeStyles((theme) => ({
  root: {
    padding: "20px",
    height: "640px",
    overflowY: "scroll",
  },
  primeColor: {
    color: `${theme.palette.primary.main}`,
  },
  bold: {
    fontWeight: 700,
  },
  btn: {
    fontSize: "12px",
    fontWeight: 600,
    color: `${theme.palette.primary.main}`,
  },
  text_12: {
    fontSize: "12px",
    fontWeight: 550,
  },
  header: {
    opacity: 0.6,
    fontWeight: 550,
    fontSize: "12px",
  },
}));

const FirstItem = ({ available, total }) => {
  const classes = useStyles();
  const { t } = useTranslation()
  return (
    <Grid
      container
      direction="column"
      spacing={4}
      style={{
        paddingLeft: "32px",
        paddingTop: "15px",
        //paddingRight: "10px",
      }}
    >
      <Grid item>
        <Typography variant="h2" className={classes.bold}>
          <span className={classes.primeColor}> {available}</span> / {total}
        </Typography>
      </Grid>
      <Grid item>
        <Typography className={classes.btn}>{t("View All Scripts")}</Typography>
      </Grid>
    </Grid>
  );
};

const SecondItem = ({ available, passed, failed }) => {
  const getPercentage = (numOfScript, total) => {
    if (numOfScript && total) return Math.round((numOfScript / total) * 100);
    return 0;
  };
  const classes = useStyles();
  return (
    <Grid
      container
      direction="column"
      spacing={1}
      style={{
        paddingLeft: "24px",
        paddingTop: "15px",
      }}
    >
      <Grid item>
        <Typography className={classes.text_12}>
          Total Scripts -
          <span className={classes.primeColor}> {available}</span>{" "}
        </Typography>
      </Grid>
      <Grid item>
        <Grid container direction="row" spacing={2}>
          <Grid item sm={5}>
            <BoxItem
              total={passed}
              percentage={getPercentage(passed, available)}
              type="Success"
              message="Scripts passed testing"
            />
          </Grid>
          <Grid item sm={5}>
            <BoxItem
              total={failed}
              percentage={getPercentage(failed, available)}
              type="Error"
              message="Scripts failed testing"
            />
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};

const FailedScript = () => {
  const classes = useStyles();
  const { t } = useTranslation()
  const truncateString = (str) => {
    if (str) {
      return str.trim().length > 35 ? str.substring(0, 33) + ".." : str;
    }
    return "";
  };
  return (
    <div
      style={{
        paddingLeft: "24px",
        paddingTop: "15px",
      }}
    >
      <Grid
        container
        direction="row"
        style={{ marginBottom: "10px" }}
        spacing={1}
      >
        <Grid item xs={3}>
          <Typography className={classes.header}>{t("Script Name")}</Typography>
        </Grid>
        <Grid item xs={1}>
          <Typography className={classes.header}>{t("Version")}</Typography>
        </Grid>
        <Grid item xs={1}>
          <Typography className={classes.header}>{t("Failure Date")}</Typography>
        </Grid>
        <Grid item xs={1}>
          <Typography className={classes.header}>{t("Tested By")}</Typography>
        </Grid>
        <Grid item xs={4}>
          <Typography className={classes.header}>{t("Comment")}</Typography>
        </Grid>
        <Grid item xs>
          <Typography className={classes.header}>{t("Action")}</Typography>
        </Grid>
      </Grid>
      <Divider variant="fullWidth" />
      {failScripts.map((script, index) => (
        <Grid
          container
          direction="row"
          style={{ marginBottom: "10px", marginTop: "5px" }}
          spacing={1}
          key={index}
        >
          <Grid item className={classes.text_12} xs={3}>
            {script.scriptName}
          </Grid>
          <Grid item className={classes.text_12} xs={1}>
            {script.version}
          </Grid>
          <Grid item className={classes.text_12} xs={1}>
            {script.failedDate}
          </Grid>
          <Grid item className={classes.text_12} xs={1}>
            {script.testedBy}
          </Grid>
          <Grid item className={classes.text_12} xs={4} title={script.comment}>
            {truncateString(script.comment)}
          </Grid>
          <Grid item className={classes.text_12 + " " + classes.primeColor} xs>
            {t("View / Edit Script")}
          </Grid>
        </Grid>
      ))}
    </div>
  );
};

const Dashboard = () => {
  const classes = useStyles();
  const [notiData, setNotiData] = useState(notData);
  const { t } = useTranslation()
  const removeNotification = (id) => {
    const newData = [...notiData];
    const index = notiData.findIndex((item) => item.id === id);
    if (index !== -1) {
      newData.splice(index, 1);
    }
    setNotiData(newData);
  };
  const refreshData = () => {
    setNotiData(notData);
  };

  return (
    <div className={classes.root}>
      <Grid
        container
        direction="row"
        spacing={1}
        style={{ marginBottom: "18px" }}
      >
        <Grid item xs>
          <NotificationBox
            notData={notiData}
            removeNotification={removeNotification}
            refreshData={refreshData}
          />
        </Grid>
      </Grid>

      <Grid
        container
        direction="row"
        spacing={1}
        style={{ marginBottom: "18px" }}
      >
        <Grid item sm={12} md={6}>
          <CommonBox
            heading={t("Published Scripts")}
            updatedOn="10th Feb 2021, 4:00PM"
            Content={<FirstItem available={37} total={60} />}
          />
        </Grid>
        <Grid item sm={12} md={6}>
          <CommonBox
            heading={t("Published Scripts")}
            updatedOn="10th Feb 2021, 4:00PM"
            Content={<SecondItem available={37} passed={35} failed={2} />}
          />
        </Grid>
      </Grid>
      <Grid container direction="row">
        <Grid item xs>
          <CommonBox
            heading={t("Failed Scripts")}
            updatedOn="10th Feb 2021, 4:00PM"
            Content={<FailedScript />}
          />
        </Grid>
      </Grid>
    </div>
  );
};

export default Dashboard;
