import { add } from "lodash";


export const getAdditionalDetails = (activity) => {
  let additionalData = "EmptyInformation ";
  let method="EmptyData";
  switch (activity.activityName) {
    case "OpenExcel":
      additionalData = activity.params.filter(
        (param) => param.paramName == "ExcelFilePath"
      )[0].paramValue;
      additionalData = additionalData == null ||additionalData.length==0? null : additionalData;
      break;
    case "OpenSheet":
      additionalData = activity.params.filter(
        (param) => param.paramName == "SheetName"
      )[0].paramValue;
      additionalData =
        additionalData == null ||additionalData.length==0? null : additionalData;
      break;
    case "ForEachRow":
      additionalData=null;
    
      break;
  
    case "ReadRow":
      additionalData = activity.params.filter(
        (param) => param.paramName == "RowIndex"
      )[0].paramValue;
      additionalData = additionalData == null||additionalData.length==0? null : additionalData;
      break;
    case "ReadCell":
      additionalData =activity.params.filter((param)=>param.paramName=="CellIndex")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null:additionalData;
      break;
    case "FilterTable":
      additionalData = activity.params.filter((param)=>param.paramName=="TableName")[0].paramValue;
      additionalData=additionalData==null||additionalData.length==0?null:additionalData;
      break;
    case "GetSheets":
      additionalData = activity.params.filter((param)=>param.paramName=="SheetName")[0].paramValue;
      additionalData=additionalData==null||additionalData.length==0?null:additionalData;
      break;
    case "WriteCell":
      additionalData = activity.params.filter((param)=>param.paramName=="CellIndex")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null:additionalData;
      break;
    case "AddNewSheet":
      additionalData = activity.params.filter((param)=>param.paramName=="SheetName")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null:additionalData;
      break;
    case "GetTableRange":
      additionalData = activity.params.filter((param)=>param.paramName=="Range")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null:additionalData;
      break;
    case "DeleteColumn":
      additionalData = activity.params.filter((param)=>param.paramName=="ColumnName")[0].paramValue;
      additionalData=additionalData==null||additionalData.length==0?null:additionalData;
      break;
    case "ReadColumn":
      additionalData =activity.params.filter((param)=>param.paramName=="SheetColumnIndex")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null :additionalData;
      break;
    case "ReadRange":
      additionalData = activity.params.filter((param)=>param.paramName=="SpecifyRange")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null:additionalData;
      break;
    case "WriteRange":
      additionalData = activity.params.filter((param)=>param.paramName=="DataRange")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null:additionalData;
      break;
    case "CreateTable":
      additionalData = activity.params.filter((param)=>param.paramName=="TableName")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null :additionalData;
      break;
    case "CopySheet":
      additionalData = activity.params.filter((param)=>param.paramName=="DestinationSheetName")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null : additionalData;
      break;
    case "DeleteRange":
      additionalData = activity.params.filter((param)=>param.paramName=="SpecifyRange")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null : additionalData;
      break;
    case "ReadCellFormula":
      additionalData=null;
      
      break;
    case "WriteCellFormula":
      additionalData=null;
      
      break;
    case "ReadRows":
      additionalData=null;
     
      break;
    case "ExecuteMacro":
      additionalData = activity.params.filter((param)=>param.paramName=="MacroName")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null : additionalData;
      break;
    case "PrintOutput":
      additionalData = activity.params.filter((param)=>param.paramName=="Target")[0].paramValue;
      additionalData=additionalData==null||additionalData.length==0?null:additionalData
      break;
    case "Assignment":
      let additionalDataArr = activity.params.filter(
        (param) => param.paramName =="Param1"
      );
      additionalData = additionalDataArr[0].paramValue;
      additionalData =
        additionalData == null ||additionalData.length==0
          ? null
          : additionalData;
      break;
   
    case "Repeat":
      additionalData = activity.params.filter((param)=>param.paramName=="RepeatCount")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null : additionalData;
      break;
    case "RepeatIf":
      additionalData = null;
      break;
    case "ForEach":
      additionalData=null;
      
      break;
    case "CSVOpen":
      additionalData = activity.params.filter((param) => param.paramName == "CSVFile")[0].paramValue;
      additionalData = additionalData == null ||additionalData.length==0 ? null : additionalData;
     break;
    case "ReadAllCSVLines":
      additionalData=null;
     
     break;

    case "WriteCSVLine":
      additionalData=null;
    
      break;
      case "ConditionOf":
        additionalData=null;
      
        break;
      case "Retry":
        additionalData=activity.params.filter((param)=>param.paramName=="RetryCount")[0].paramValue
        additionalData=additionalData==null ||additionalData.length==0 ?null:additionalData
        break;
      case "RestServices":
        additionalData=activity.params.filter((param)=>param.paramName=="Endpoint")[0].paramValue;
        method=activity.params.filter((param)=>param.paramName=="Methods")[0].paramValue;
      
        additionalData=additionalData==null && method==null || additionalData.length==0 && method.length==0?null:`${method},${additionalData}`
        break;
        case 'GetAllFoldersFromPath':
          additionalData=null;
          
          break;
        case "GetDriveLetter":
          additionalData=null;
         
          break;
        case "GetFileNameFromFullPath":
          additionalData=null;
        
          break;
        case "GetFileExtension":
          additionalData=null;
         
          break;
        case "GetPathFromFullPath":
          additionalData=null;
         
          break;
        case "GetSeparator":
          additionalData=null;
         
          break;
         case "GetHost":
          additionalData=null;
        
          break;
          case "GetPort":
            additionalData=null;
         
          break; 
          case "GetProtocolHandler":
            additionalData=null;
          
            break;
          case "ConnectMail":
            additionalData=activity.params.filter((param)=>param.paramName=="EmailAccount")[0].paramValue;
            additionalData=additionalData==null || additionalData.length==0?null :additionalData;
            break;
          case "GetMails":
          additionalData=null;
            break;
          case "SendMailSMTP":
            additionalData=activity.params.filter((param)=>param.paramName=="To")[0].paramValue;
            additionalData=additionalData==null || additionalData.length==0?null :additionalData;
            break;
          case "DeleteMail":
            additionalData=null;
            break;
          case "ForEachMail":
           additionalData=null;
            break;
          case "SaveMailAttachments":
           additionalData=null;
            break;
          case "SaveMail":
            additionalData=null;
            break;  
case "ConnectDatabase":
  additionalData=activity.params.filter((param)=>param.paramName=="DatabaseName")[0].paramValue;
  additionalData=additionalData==null || additionalData.length==0?null:additionalData;
  break;
  case "FetchRecords":
    additionalData=activity.params.filter((param)=>param.paramName=="TableName")[0].paramValue;
    additionalData=additionalData==null || additionalData.length==0?null:additionalData;
    break;
           
    case "UpdateRecords":
      additionalData=activity.params.filter((param)=>param.paramName=="TableName")[0].paramValue;
      additionalData=additionalData==null || additionalData.length==0?null:additionalData;
      break;
      case "AddRecords":
        additionalData=activity.params.filter((param)=>param.paramName=="TableName")[0].paramValue;
        additionalData=additionalData==null || additionalData.length==0?null:additionalData;
        break;
        case "DeleteRecords":
          additionalData=activity.params.filter((param)=>param.paramName=="TableName")[0].paramValue;
          additionalData=additionalData==null || additionalData.length==0?null:additionalData;
          break;

      
          case "ExecuteProcedure":
            additionalData=activity.params.filter((param)=>param.paramName=="ProcedureName")[0].paramValue;
            additionalData=additionalData==null || additionalData.length==0?null:additionalData;
            break;
 case "CreateWorkItem":
  additionalData=additionalData=activity.params.filter((param)=>param.paramName=="processId")[0].paramValue;
  additionalData=additionalData==null || additionalData.length==0?null:additionalData;
  break;
  case "GetWorkItem":
    additionalData=additionalData=activity.params.filter((param)=>param.paramName=="processId")[0].paramValue;
    additionalData=additionalData==null || additionalData.length==0?null:additionalData;
    break;
  case "SaveWorkitem":
    additionalData=null;
    break;
  case "CompleteWorkItem":
  additionalData=null;
  break;  
  case "ServerConnect":
    additionalData=additionalData=activity.params.filter((param)=>param.paramName=="ServerUrl")[0].paramValue;
    additionalData=additionalData==null || additionalData.length==0?null:additionalData
    break;
  case "ExtractData":
    additionalData=null;
    break;
  case "ConnectXtract":
    additionalData=activity.params.filter((param)=>param.paramName=="oxServerUrl")[0].paramValue;
    additionalData=additionalData==null || additionalData.length==null?null:additionalData;
    break;
  case "FTPConnect":
  additionalData=activity.params.filter((param)=>param.paramName=="ftpUrl")[0].paramValue;
  additionalData=additionalData==null || additionalData.length==null?null:additionalData;
  break;
  case "CodeBlock":
    additionalData=null;
    break;
  case "Start":
      additionalData = "AdditionalInfo";
      break;
    case "End":
      additionalData = "AdditionalInfo";
      break;
    case "customDottedNode":
      additionalData = "AdditionalInfo";
      break;
    default:
      additionalData = "AdditionalInfo";
      break;
  }
  return additionalData;
};
