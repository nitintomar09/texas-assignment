import React, { useState } from "react";
import { Handle, Position } from "reactflow";
import { API_BASE_URL, ICONS } from "../../../../config";
import { makeStyles } from "@mui/styles";
import { Grid, IconButton, Typography } from "@mui/material";
import { ConditionIcon, MainScript } from "../../../../utils/AllImages";
import CustomTooltipComponent from "../../TooltipContent";
import { truncateStringValues } from "../../../common";
import { useDispatch, useSelector } from "react-redux";
import useExpandCollapse from "../../HandleSyncingOperation";
const useStyles = makeStyles((theme) => ({
  wrapper: {
    position: 'relative',
    width: '100px',
    height: '100px',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
  },
  wrapperExpand: {
    position: 'relative',
    width: '150px',
    height: '140px',
    display: 'flex',
    //border: '1px dashed purple',
    justifyContent: 'center',
    alignItems: 'center',
  },
  wrapperCollapse: {
    position: 'relative',
    width: '160px',
    height: '160px',
    display: 'flex',
    //border: '1px dashed purple',
    justifyContent: 'center',
    alignItems: 'center',
  },
  shadow: {
    position: 'absolute',
    width: '100px',
    height: '100px',
    background: '#F0FCF4',  // Shadow color
    transform: 'rotate(45deg)',
  //  border: '1px dashed #0D6F08',  // Border around the shadow
    borderRadius:'4px 4px 4px 4px',
    //top: '4px',  // Slight offset for shadow effect
    left: '10px', // Slight offset for shadow effect
  },
  diamond: {
    position: 'absolute',
    width: '100px',
    height: '100px',
    background: '#F0FCF4',
    // border: '1px solid #0D6F08',  // Dashed border
    transform: 'rotate(45deg)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: '4px',
  },
  content: {
    transform: 'rotate(-45deg)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    textAlign: 'center',
    width: '100%',
    height: '40%',
  },
  text: {
    fontFamily: 'Open Sans',
    fontSize: '12px',
    fontWeight: '600',
    lineHeight: '16px',
    textAlign: 'left',
    color:"#027A48",
  },
  infoContainer:{
    height:'16px'
  }
 
}));

const IfNode = ({ data }) => {
  const collapsedActs = useSelector((state) => state.editorHomepage.collapsedActivities);
  const uuidRuleOrderId=data.uuidsAgainstRuleOrderIds
 // const [isExpanded, setIsExpand] = useState(true);
  const { label, tooltip, additionalText, ruleOrderId, type, isSelectedNode, onClick,isExpanded } = data;
  const { handleExpandCollapse } = useExpandCollapse(ruleOrderId, uuidRuleOrderId, collapsedActs, data,null,null,null);


  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };

  const classes = useStyles();

  return (
    
      <div className={isExpanded?classes.wrapperExpand:classes.wrapperCollapse}>
        
        <div className={classes.wrapper} >
        
       
        <div className={classes.diamond} onClick={onClick} style={{border:isSelectedNode?'1px solid #027A48':"" }}>
        <CustomTooltipComponent activityType={type}    ruleOrderId={ruleOrderId} label={label} tooltip={tooltip} toggleAction={handleExpandCollapse}>
          <div className={classes.content}>
          
            <Grid container className={classes.infoContainer} justifyContent={"center"} alignItems={"center"}>
              <Grid item xs={3}>
                <IconButton><ConditionIcon height={16} width={16}/></IconButton>
              </Grid>
              <Grid item>
                <Typography className={classes.text}>{truncateStringValues({ str: label, min: 9, max: 11 })}</Typography>
              </Grid>
            </Grid>
           {/* <Grid container justifyContent="center" alignItems="center">
         <Grid item>
          <div className={classes.additionalText}>{additionalText}</div>
        </Grid> 
      </Grid>*/}
      
          </div>
          
          </CustomTooltipComponent>
        </div>
        
       </div>
       {isExpanded?<>
          <Handle type="target" position="top" style={{ background: '#555', opacity: 0,  pointerEvents: 'all' }} />
          <Handle type="source" id='b' position="left" style={{ background: '#555'}} />
          <Handle type="source" id='a' position="right" style={{ background: '#555' }} />
        </>:
        <>
         <Handle type="target" position="top" style={{ background: '#555', top: '-6px', left: '50%', opacity: 0,  pointerEvents: 'all' }} />
         <Handle type="source" position="bottom" style={{ background: '#555', bottom: '-6px', left: '50%'}} />
        </>
        }
      </div>
  );
};

export default IfNode;
