import React from "react";
import { Handle } from "reactflow";
import Tooltip from "@mui/material/Tooltip";
import { Grid, IconButton } from "@mui/material";
import Typography from "@mui/material/Typography";
import { RepeatIcon } from "../../../../utils/AllImages";
import CustomTooltipComponent from "../../TooltipContent";
import makeStyles from "@mui/styles/makeStyles";
import { ClassNames } from "@emotion/react";
import { truncateStringValues } from "../../../common";

const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px solid #0D6F08",
    background: "#f6ffed",
    color: "green",
    borderRadius: "25px",
    width: "115px",

    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
   padding:"2px",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "15px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
  },
}));
const ForEachNode = ({ data }) => {
  const { label, tooltip, additionalText, type,isSelectedNode, ruleOrderId,onClick,isExpanded } = data;
  const handleExpandCollapse = () => {
    //setIsExpand(!isExpand);
    data.toggleExpandCollapse(ruleOrderId,isExpanded);
  };

  const classes = useStyles();
  return (
    <Grid
      container
      className={classes.root}
      direction={"column"}
      onClick={onClick}
      style={{ minHeight: "40px",border:isSelectedNode?"2px Solid #0D6F08":"1px Solid #0D6F08" }}
    >
       <CustomTooltipComponent
          activityType={type}
          label={label}
          tooltip={tooltip}
          ruleOrderId={ruleOrderId}
          toggleAction={handleExpandCollapse} 
        >
      <Grid item>
       
          <Grid
            container
            justifyContent="flex-start"
            alignItems="center"
            direction={"row"}
            paddingRight={"12px"}
          >
            <Grid item>
              <IconButton>
                <RepeatIcon />
              </IconButton>
            </Grid>
            <Grid item>
              <Typography className={classes.text}>
                {truncateStringValues({ str: label, min: 17, max: 20 })}
              </Typography>
            </Grid>
          </Grid>
       
      </Grid>
      {additionalText !== null && (
          <Grid item marginBottom={"4px"}>
            <Grid container justifyContent={"center"} alignItems={"center"}>
              <Grid item>
                <Typography className={classes.additionalText}>
                  {truncateStringValues({
                    str: additionalText,
                    min: 15,
                    max: 17,
                  })}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        )}
 </CustomTooltipComponent>
 {isExpanded? 
 <>
 <Handle
        type="target"
        position="top"
        style={{
          background: "#0D6F08",
          top: "-5px",
          height: "3px",
          left: "50%",
          transform: "translateX(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
      />
      <Handle
        type="target"
        position="bottom"
        id="c"
        style={{
          background: "#0D6F08",
          top: "100%",
          height: "3px",
          left: "60%",
          transform: "translateX(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
      />
      <Handle
        type="source"
        id="b"
        position="bottom"
        style={{
          background: "#0D6F08",
          bottom: "-5px",
          height: "3px",
          left: "50%",
          transform: "translateX(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
      />
      <Handle
        type="source"
        position="right"
        id="a"
        style={{
          background: "#0D6F08",
          top: "50%",
          height: "3px",
          right: "-3%",
          transform: "translateY(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
       
      />
       </>
      :<></>}
     
    </Grid>
  );
};

export default ForEachNode;
