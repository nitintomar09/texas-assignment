import React, { useState } from "react";
import { Handle } from "reactflow";
import { API_BASE_URL, ICONS } from "../../../../config";
import CustomTooltipComponent from "../../TooltipContent";
import { Typography, Grid, IconButton } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { CSVIcon } from "../../../../utils/AllImages";
import { truncateStringValues } from "../../../common";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px solid #0D6F08",
    background: "#e8f5e9",
    borderRadius: "2px 25px 2px 2px",
    width: "154px",
    height: "68px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#0D6F08",
  },
  wrapper: {
    position: "relative",
    width: "154px",
    height: "68px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  wrapperCollapse: {
    position: "relative",
    width: "180px",
    height: "100px",
    display: "flex",
    border: "1px dashed purple",
    justifyContent: "center",
    alignItems: "center",
    padding: 0,
  },
  shadow: {
    position: "absolute",
    width: "153px",
    height: "74px",
    background: "#e8f5e9",
    border: "1px dashed #0D6F08",
    borderRadius: "2px 25px 2px 2px",
    top: "0px",
    left: "5px",
    margin: "2px",
  },
  content: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    textAlign: "center",
    width: "100%",
    height: "40%",
  },
}));

const truncateText = (text, maxLength) => {
  if (text.length <= maxLength) {
    return text;
  }
  return text.substring(0, maxLength) + "...";
};

const ExcelScopeNode = ({ data }) => {
  const classes = useStyles();
  const { label, tooltip, additionalText,isExpanded, ruleOrderId, type, isSelectedNode, onClick } =
    data;
  //const [isExpanded, setIsExpand] = useState(true);

  const handleExpandCollapse = () => {
    // setIsExpand(!isExpanded);
    data.toggleExpandCollapse(ruleOrderId,isExpanded);
  };

  return (
    <Grid
      container
      justifyContent="center"
      alignItems="center"
      className={isExpanded ? classes.wrapper : classes.wrapperCollapse}
    >
      {isExpanded && (
        <Grid
          item
          className={classes.shadow}
          style={{ background: isSelectedNode ? "green" : "#e8f5e9" }}
        />
      )}
      <Grid container className={classes.root} onClick={onClick}>
        <Grid item className={classes.content}>
          <CustomTooltipComponent
            activityType={type}
            label={label}
            tooltip={tooltip}
            toggleAction={handleExpandCollapse}
            ruleOrderId={ruleOrderId}
          >
            <Grid container justifyContent="center" alignItems="center" direction={"row"} paddingRight={"12px"}>
              <Grid item>
                <IconButton>
                  <CSVIcon />
                </IconButton>
              </Grid>
              <Grid item>
                <Typography className={classes.text}> {truncateStringValues({str:label,min:17,max:20})}</Typography>
              </Grid>
            </Grid>
          </CustomTooltipComponent>
        </Grid>
        {additionalText !== null && (
          <Grid container justifyContent="center" alignItems="center">
            <Grid item>
              <Typography className={classes.additionalText}>
                {additionalText}
              </Typography>
            </Grid>
          </Grid>
        )}

        {isExpanded ? (
          <>
            <Handle
              type="source"
              position="bottom"
              style={{
                background: "#0D6F08",
                bottom: "-5px",
                height: "3px",
                left: "50%",
                transform: "translateX(-50%)",
                 opacity: 0,  pointerEvents: 'all'
              }}
            />
            <Handle
              type="target"
              position="top"
              style={{
                background: "#0D6F08",
                top: "-5px",
                height: "3px",
                left: "50%",
                transform: "translateX(-50%)",
                 opacity: 0,  pointerEvents: 'all'
              }}
            />
          </>
        ) : (
          <>
            <Handle
              type="source"
              position="bottom"
              style={{
                background: "#0D6F08",
                bottom: "-21px",
                height: "3px",
                left: "50%",
                transform: "translateX(-50%)",
                 opacity: 0,  pointerEvents: 'all'
              }}
            />
            <Handle
              type="target"
              position="top"
              style={{
                background: "#0D6F08",
                top: "-21px",
                height: "3px",
                left: "50%",
                transform: "translateX(-50%)", 
                opacity: 0,  pointerEvents: 'all'
              }}
            />
          </>
        )}
      </Grid>
    </Grid>
  );
};

export default ExcelScopeNode;
