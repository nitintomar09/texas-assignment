import React from 'react';
import { Handle } from 'reactflow';
import Tooltip from '@mui/material/Tooltip';
import makeStyles from "@mui/styles/makeStyles";
import { Typography } from '@mui/material';

const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px solid #F3F8F3",
    background: '#F3F8F3',
   // color: "#F3F8F3",
    borderRadius: "25px 25px 25px 25px",
    width: '50px',
    height: '32px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
  },
  text:{
    fontFamily:'Open Sans',
    fontSize:'12px',
    fontWeight:'600',
    lineHeight:'16px',
    textAlign:'left',
    color:"#0D6F08",
  }
 

}));

const StartCircleNode = ({ data }) => {
  console.log(data,"tooltip")
  const { label, tooltip } = data;
  const classes = useStyles();

  return (
    <Tooltip title={tooltip} placement='top'>
      <div className={classes.root}>
        <Typography className={classes.text}>
        {label}
        </Typography>
        <Handle type="source" position="bottom" style={{ background: '#000000', bottom: '-4px', left: '50%', transform: 'translateX(-50%)', opacity: 0,  pointerEvents: 'all' }} />
      </div>
    </Tooltip>
  );
};

export default StartCircleNode;
