import React from 'react';
import { Handle } from 'reactflow';
import Tooltip from '@mui/material/Tooltip';
import makeStyles from "@mui/styles/makeStyles";
import { Typography } from '@mui/material';

const useStyles = makeStyles((theme) => ({
    root: {
      border: "1px solid #FCF4F4",
      background: '#FCF4F4',
      //color: "#0D6F08",
      borderRadius: "25px 25px 25px 25px",
      width: '50px',
      height: '32px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      position: 'relative',
      //boxShadow: '4px 4px 0px 0px #FCF4F4',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
    },
    text:{
      color:'#C32525',
      fontFamily:'Open Sans',
      fontSize:'12px',
      fontWeight:'600',
      lineHeight:'16px',
      textAlign:'left',
    }
  }));

const EndCircleNode = ({ data }) => {
  console.log(data,"tooltip")
  const { label, tooltip } = data;
  const classes = useStyles();

  return (
    <Tooltip title={tooltip} placement='top'>
      <div className={classes.root}>
      <Typography className={classes.text}>
        {label}
        </Typography>
        <Handle type="target" position="top" style={{ background: '#000000', bottom: '-8px', left: '50%', transform: 'translateX(-50%)',  
        opacity: 0,  pointerEvents: 'all' }} />
      </div>
    </Tooltip>
  );
};

export default EndCircleNode;
