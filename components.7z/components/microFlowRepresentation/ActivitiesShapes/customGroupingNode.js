import React from 'react';
import { Handle } from 'reactflow';

const CustomDottedNode = ({ data }) => (
  <div style={{
    border: '2px dashed purple',
    background: '#FFF',
    color: 'purple',
    width: '200px',
    height: '200px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.2)',  // Adding shadow effect
  }}>
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontWeight: 'bold' }}>
        {data.label}
      </div>
      <div style={{ 
        background: '#F1F9FF',
        borderRadius: '12px',
        padding: '5px 10px',
        marginTop: '10px',
        border: '1px solid #ccc',
        display: 'inline-block',
        width: '180px'
      }}>
        <div>Line: {data.line}</div>
        <div>Type: {data.type}</div>
        <div>URL: {data.url}</div>
      </div>
    </div>
    <Handle type="target" position="top" style={{ background: '#555', top: '-6px', left: '50%', transform: 'translateX(-50%)' }} />
    <Handle type="source" position="bottom" style={{ background: '#555', bottom: '-6px', left: '50%', transform: 'translateX(-50%)' }} />
    <Handle type="source" id='a' position="right" style={{ background: '#555', right: '-6px', top: '50%', transform: 'translateY(-50%)' }} />
  </div>
);

export default CustomDottedNode;
