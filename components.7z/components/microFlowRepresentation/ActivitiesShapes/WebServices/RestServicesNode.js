import React from "react";
import { Handle } from "reactflow";
import { API_BASE_URL, ICONS } from "../../../../config";
import CustomTooltipComponent from "../../TooltipContent";
import { Typography, Grid, IconButton } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { WebServiceIcon } from "../../../../utils/AllImages";
import { truncateStringValues } from "../../../common";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px solid #EAECF5",
    background: "#EAECF5",
    borderRadius: "4px",
width:"auto",
   // minWidth: "130px",
    // height: "68px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    //padding: "10px",
   // boxShadow: "4px 4px 0px 0px #EAECF5",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
    margin: "2px 2px 2px 2px",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#4E5BA6",
  },
  handleBottom: {
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
  },
  handleTop: {
    background: "#3A3A3A",
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
    opacity: "0",
    pointerEvents: "all",
    color: "#3A3A3A",
  },
}));

const RestServicesNode = ({ data }) => {
  const classes = useStyles();
  const { label, ruleOrderId, additionalText, type, isSelectedNode, onClick } =
    data;
 

  return (
    <Grid
      container
      className={classes.root}
      onClick={onClick}
      direction={"column"}
      style={{
        border: isSelectedNode ? "2px solid #EAECF5" : "1px solid #EAECF5",
        minHeight: "40px",
       
      }}
    >
      <CustomTooltipComponent
        activityType={type}
        label={label}
        ruleOrderId={ruleOrderId}
      >
        <Grid item>
          <Grid
            container
            paddingRight={"12px"}
            justifyContent="center"
            alignItems="center"
            direction={"row"}
          >
            <Grid item>
              <IconButton>
                <WebServiceIcon />
              </IconButton>
            </Grid>
            <Grid item>
              <Typography className={classes.text}>
                {truncateStringValues({ str: label, min: 15, max: 20 })}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        {additionalText !== null && (
        <Grid item style={{ marginBottom: "4px" }}>
          <Grid container justifyContent={"center"} alignItems={"center"}>
            <Grid item>
            <Typography className={classes.additionalText}>
            {truncateStringValues({ str: additionalText, min: 25, max: 30 })}
         
          </Typography>
            </Grid>
          </Grid>
         
        </Grid>
      )}
      </CustomTooltipComponent>

      <Handle
        type="source"
        position="bottom"
       className={classes.handleBottom}
      />
      <Handle
        type="target"
        position="top"
        className={classes.handleTop}
      />
    </Grid>
  );
};

export default RestServicesNode;
