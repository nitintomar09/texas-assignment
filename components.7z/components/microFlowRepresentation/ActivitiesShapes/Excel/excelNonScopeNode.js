import React from "react";
import { Handle } from "reactflow";
import { API_BASE_URL, ICONS } from "../../../../config";
import CustomTooltipComponent from "../../TooltipContent";
import { Typography, Grid, IconButton } from "@mui/material";
import { ClassNames } from "@emotion/react";
import { makeStyles } from "@mui/styles";
import { ExcelIcon } from "../../../../utils/AllImages";
import { truncateStringValues } from "../../../common";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px solid #0D6F08",
    background: "#e8f5e9",
    borderRadius: "2px 25px 2px 2px",
    width: "154px",
    // height: "68px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    //padding: "10px",
    boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#0D6F08",
  },
}));

const ExcelNonScopeNode = ({ data }) => {
 
  const classes = useStyles();
  const { label, ruleOrderId, additionalText, type, isSelectedNode, onClick } =
    data;
    console.log(additionalText,"d")
  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };

  return (
    <Grid
      container
      className={classes.root}
      onClick={onClick}
      direction={"column"}
      style={{
        border: isSelectedNode ? "2px solid #0D6F08" : "1px solid #0D6F08",
        minHeight: "40px",
      }}
    >
      <CustomTooltipComponent
        activityType={type}
        label={label}
        ruleOrderId={ruleOrderId}
      >
        <Grid item>
          <Grid
            container
            paddingRight={"12px"}
            justifyContent="center"
            alignItems="center"
            direction={"row"}
          >
            <Grid item>
              <IconButton>
                <ExcelIcon />
              </IconButton>
            </Grid>
            <Grid item>
              <Typography className={classes.text}>
               
                {truncateStringValues({ str: label, min: 10, max: 15 })}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        {additionalText !== null && (
        <Grid item style={{ marginBottom: "4px" }}>
          <Grid container justifyContent={"center"} alignItems={"center"}>
            <Grid item>
            <Typography className={classes.additionalText}>
            {truncateStringValues({ str: additionalText, min: 15, max: 17})}
         
          </Typography>
            </Grid>
          </Grid>
         
        </Grid>
      )}
      </CustomTooltipComponent>

      <Handle
        type="source"
        position="bottom"
        style={{
          background: "#0D6F08",
          bottom: "-5px",
          height: "3px",
          left: "50%",
          transform: "translateX(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
      />
      <Handle
        type="target"
        position="top"
        style={{
          background: "#0D6F08",
          top: "-5px",
          height: "3px",
          left: "50%",
          transform: "translateX(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
      />
    </Grid>
  );
};

export default ExcelNonScopeNode;
