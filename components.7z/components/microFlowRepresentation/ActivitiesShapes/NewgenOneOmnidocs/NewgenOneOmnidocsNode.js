import React from "react";
import { Handle } from "reactflow";
import CustomTooltipComponent from "../../TooltipContent";
import { API_BASE_URL, ICONS } from "../../../../config";
import { truncateStringValues } from "../../../../utils/common";
import { Grid, IconButton, Typography } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { NewgenOneIcon } from "../../../../utils/AllImages";
import CustomTooltip from "../../../../utils/CustomTooltip";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px Solid #FFF0E5",
    background: "#FFF0E5",
    color: "#FFF0E5",
    borderRadius: "4px",

    width: "auto",
    minWidth: "80px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    //padding: "12px",
    boxShadow: "4px 4px 0px 0px #FFF0E5",
    //  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
  },

  conditionalRoot: {
    border: "1px Solid #FFF0E5",
    background: "#FFF0E5",
    color: "#FFF0E5",
    borderRadius: "4px",
    // width: "170px",
    // height: "40px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    //padding: "12px",
    boxShadow: "4px 4px 0px 0px #FFF0E5",
    //  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
  },
  handleBottom: {
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
  },
  handleTop: {
    background: "#3A3A3A",
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
    opacity: "0",
    pointerEvents: "all",
    color: "#3A3A3A",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#BA4A00",
  },
}));

const NewgenOneOmnidocsNode = ({ data }) => {
  const classes = useStyles();
  const {
    label,
    tooltip,
    additionalText,
    type,
    ruleOrderId,
    activityName,
    isSelectedNode,
    onClick,
  } = data;

  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };
  return (
    <Grid
      container
      className={classes.root}
      direction={"column"}
      onClick={onClick}
      style={{
        minHeight: "40px",
        minWidth: "140px",
        border: isSelectedNode ? "2px Solid #FFF0E5" : "1px Solid #FFF0E5",
      }}
    >
      <CustomTooltipComponent
        activityType={type}
        label={label}
        tooltip={tooltip}
        ruleOrderId={ruleOrderId}
      >
        <Grid item>
          <Grid
            container
            style={{ paddingRight: "12px" }}
            direction={"row"}
            justifyContent={"center"}
            alignItems={"center"}
          >
            <Grid item>
              <IconButton>
                <NewgenOneIcon />
              </IconButton>
            </Grid>
            <Grid item>
              <Typography className={classes.text}>
                {truncateStringValues({ str: label, min: 15, max: 17 })}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        {/* {additionalText !== null && (
          <Grid item marginBottom={"7px"}>
            <Grid container justifyContent={"center"} alignItems={"center"}>
              <Grid item>
                <Typography className={classes.additionalText}>
                  {truncateStringValues({
                    str: additionalText,
                    min: 15,
                    max: 17,
                  })}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        )} */}
      </CustomTooltipComponent>
      <Handle type="source" position="bottom" className={classes.handleBottom} />
      <Handle type="target" position="top" className={classes.handleTop} />
    </Grid>
  );
};

export default NewgenOneOmnidocsNode;
