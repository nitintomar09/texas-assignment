import React, { useState } from "react";
import { Handle } from "reactflow";
import CustomTooltipComponent from "../../TooltipContent";
import { API_BASE_URL, ICONS } from "../../../../config";
import { truncateStringValues } from "../../../../utils/common";
import { Grid, IconButton, Typography } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { NewgenOneIcon } from "../../../../utils/AllImages";
import { useDispatch, useSelector } from "react-redux";
import useExpandCollapse from "../../HandleSyncingOperation";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px solid #FFF0E5",
    background: "#FFF0E5",
    color: "#FFF0E5",
    borderRadius: "4px",
    
    width: "auto", 
    minWidth: "80px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",

    // boxShadow: "4px 4px 0px 0px #FFF0E5",
  },
 
  wrapperCollapse: {
    position: "relative",
    width: "180px",
    height: "100px",
    display: "flex",
    border: "1px dashed purple",
    justifyContent: "center",
    alignItems: "center",
    padding: 0,
  },
  handleBottom: {
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
  },
  handleTop: {
    background: "#3A3A3A",
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
    opacity: "0",
    pointerEvents: "all",
    color: "#3A3A3A",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#BA4A00",
  },
   shadow: {
    position: "absolute",
    width: "150px",
    height: "46px",
    background: "#e8f5e9",
    border: "1px dashed#FFF0E5",
    borderRadius: "2px 10px 2px 2px",
    top: "-2px",
    left: "28px",
    margin: "2px",
   
  },
}));

const NewgenOneScopeNode = ({ data }) => {
  const classes = useStyles();
  const collapsedActs = useSelector((state) => state.editorHomepage.collapsedActivities);
  const uuidRuleOrderId=data.uuidsAgainstRuleOrderIds
 // const [isExpanded, setIsExpand] = useState(true);
  const { label, tooltip, additionalText, ruleOrderId, type, isSelectedNode, onClick,isExpanded } = data;
  const { handleExpandCollapse } = useExpandCollapse(ruleOrderId, uuidRuleOrderId, collapsedActs, data,null,null,null);

 return (
  <Grid container justifyContent="center" alignItems="center" className={classes.wrapper}>
      
  <Grid container className={classes.root} onClick={onClick}  style={{
    minHeight: "40px",
    minWidth: "140px"}}>
    <Grid item className={classes.content}>
      <CustomTooltipComponent activityType={type} label={label} tooltip={tooltip}    ruleOrderId={ruleOrderId} toggleAction={handleExpandCollapse}>
        <Grid container justifyContent="left" alignItems="center" paddingRight={"12px"}>
          <Grid item>
            <IconButton>
              <NewgenOneIcon />
            </IconButton>
          </Grid>
          <Grid item>
            <Typography className={classes.text}>{truncateStringValues({str:label,min:15,max:20})}</Typography>
          </Grid>
        </Grid>
        {additionalText !== null && (
    <Grid item style={{ marginBottom: "4px" }}>
      <Grid container justifyContent={"center"} alignItems={"center"}>
        <Grid item>
        <Typography className={classes.additionalText}>
        {truncateStringValues({ str: additionalText, min: 15, max: 17 })}
     
      </Typography>
        </Grid>
      </Grid>
     
    </Grid>
  )}
      </CustomTooltipComponent>
    </Grid>
   
  
    {isExpanded ? (
      <>
        <Handle
          type="source"
          position="bottom"
          className={classes.handleBottom}
        />
        <Handle
          type="target"
          position="top"
          className={classes.handleTop}
        />
      </>
    ) : (
      <>
        <Handle
          type="source"
          position="bottom"
          className={classes.handleBottom}
        />
        <Handle
          type="target"
          position="top"
          className={classes.handleTop}
        />
      </>
    )}
  </Grid>
</Grid>
  );
};

export default NewgenOneScopeNode;
