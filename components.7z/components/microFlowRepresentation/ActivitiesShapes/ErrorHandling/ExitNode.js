import React from "react";
import { Handle } from "reactflow";
import CustomTooltipComponent from "../../TooltipContent";
import { API_BASE_URL, ICONS } from "../../../../config";
import { truncateStringValues } from "../../../common";
import { Grid, IconButton, Typography } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { ErrorHandleIcon } from "../../../../utils/AllImages";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px Solid #FEF3F2",
    background: "#FEF3F2",
    color: "#FEF3F2",
    borderRadius: "4px",
    width: "65px",
    height: "40px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    boxShadow: "4px 4px 0px 0px #FEF3F2;",
    //padding: "12px",

    //  boxShadow: "0 2px 4px rgba(0, 0, 0, 0.1)",
  },

  handleBottom: {
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
  },
  handleTop: {
    background: "#3A3A3A",
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
    opacity: "0",
    pointerEvents: "all",
    color: "#3A3A3A",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#B42318",
  },
}));

const ExitNode = ({ data }) => {
  const classes = useStyles();
  const { label, tooltip, additionalText, ruleOrderId, type, isSelectedNode, onClick } =
    data;
  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };
  return (
    <Grid
      container
      className={classes.root}
      direction={"column"}
      onClick={onClick}
      style={{
        border: isSelectedNode ? "2px Solid #FEF3F2" : "1px Solid #FEF3F2",
      }}
    >
      <CustomTooltipComponent
        activityType={type}
        label={label}
        tooltip={tooltip}
        ruleOrderId={ruleOrderId}
      >
        <Grid item>
          <Grid
            container
            paddingRight={"8px"}
            justifyContent="center"
            alignItems="center"
            direction={"row"}
          >
            <Grid item>
              <IconButton>
                <ErrorHandleIcon />
              </IconButton>
            </Grid>
            <Grid item>
              <Typography className={classes.text}>
                {truncateStringValues({ str: label, min: 17, max: 20 })}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </CustomTooltipComponent>

      <Handle type="source" position="bottom" className={classes.handleBottom} />
      <Handle type="target" position="top" className={classes.handleTop} />
    </Grid>
  );
};

export default ExitNode;
