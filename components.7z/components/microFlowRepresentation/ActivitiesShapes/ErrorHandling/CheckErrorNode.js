import React from "react";
import { Handle } from "reactflow";
import CustomTooltipComponent from "../../TooltipContent";
import { API_BASE_URL, ICONS } from "../../../../config";
import { truncateStringValues } from "../../../common";
import { Grid, IconButton, Typography } from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { ErrorHandleIcon } from "../../../../utils/AllImages";
import { useDispatch, useSelector } from "react-redux";
import useExpandCollapse from "../../HandleSyncingOperation";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px Solid #FEF3F2",
    background: "#FEF3F2",
    color: "#FEF3F2",
    borderRadius: "4px",
    width: "110px",
    height: "40px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    boxShadow: "4px 4px 0px 0px #FEF3F2;",
    },

  handle: {
    background: "#FEF3F2",
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
     opacity: 0,  pointerEvents: 'all'
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
  },
  wrapperCollapse: {
    position: "relative",
    width: "180px",
    height: "100px",
    display: "flex",
    border: "1px dashed purple",
    justifyContent: "center",
    alignItems: "center",
    padding: 0,
  },
  wrapper: {
    position: "relative",
    width: "154px",
    height: "68px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#B42318",
  },
  handleBottom: {
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
  },
  handleTop: {
    background: "#3A3A3A",
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
    opacity: "0",
    pointerEvents: "all",
    color: "#3A3A3A",
  },
}));

const CheckErrorNode = ({ data }) => {
  const classes = useStyles();
  const collapsedActs = useSelector((state) => state.editorHomepage.collapsedActivities);
  const uuidRuleOrderId=data.uuidsAgainstRuleOrderIds
 // const [isExpanded, setIsExpand] = useState(true);
  const { label, tooltip, additionalText, ruleOrderId, type, isSelectedNode, onClick,isExpanded } = data;
  const { handleExpandCollapse } = useExpandCollapse(ruleOrderId, uuidRuleOrderId, collapsedActs, data,null,null,null);


  return (
    <Grid container justifyContent="center" alignItems="center" className={classes.wrapper}>
    <Grid
      container
      className={classes.root}
      direction={"column"}
      onClick={onClick}
      style={{
        border: isSelectedNode ? "2px solid #FEF3F2" : "1px solid #FEF3F2",
      }}
    >
      <CustomTooltipComponent
        activityType={type}
        label={label}
        tooltip={tooltip}
        ruleOrderId={ruleOrderId}
        toggleAction={handleExpandCollapse}
      >
        <Grid item>
          <Grid
            container
            justifyContent="center"
            alignItems="center"
            direction={"row"}
            paddingRight={"7px"}
          >
            <Grid item>
              <IconButton>
                <ErrorHandleIcon />
              </IconButton>
            </Grid>
            <Grid item>
              <Typography className={classes.text}>
                {truncateStringValues({ str: label, min: 17, max: 20 })}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </CustomTooltipComponent>
      {isExpanded?<>
          <Handle type="target" position="top" style={{ background: '#555', opacity: 0,  pointerEvents: 'all' }} />
          <Handle type="source" id='b' position="left" style={{ background: '#555', opacity: 0,  pointerEvents: 'all' }} />
          <Handle type="source" id='a' position="right" style={{ background: '#555', opacity: 0,  pointerEvents: 'all'}} />
        </>:
        <>
         <Handle type="target" position="top" style={{ background: '#555', top: '-6px', left: '50%', opacity: 0,  pointerEvents: 'all' }} />
         <Handle type="source" position="bottom" style={{ background: '#555', bottom: '-6px', left: '50%', opacity: 0,  pointerEvents: 'all' }} />
        </>
        }
     
    </Grid>
    </Grid>
  );
};

export default CheckErrorNode;
