import React from "react";
import { Handle } from "reactflow";

import { API_BASE_URL, ICONS } from "../../../../config";
import CustomTooltipComponent from "../../TooltipContent";
import { Typography, Grid, IconButton } from "@mui/material";
import { truncateStringValues } from "../../../common";
import { ClassNames } from "@emotion/react";
import { makeStyles } from "@mui/styles";
import { ErrorHandleIcon } from "../../../../utils/AllImages";
const useStyles = makeStyles((theme) => ({
  root: {
    border: "1px Solid #FEF3F2",
    background: "#FEF3F2",
    color: "#FEF3F2",
    borderRadius: "4px",

    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    boxShadow: "4px 4px 0px 0px #FEF3F2;",
  },

  handle: {
    background: "#0072C6",
    top: "-5px",
    left: "50%",
    transform: "translateX(-50%)",
  },
  additionalText: {
    fontSize: "12px",
    color: "#000",
    background: "#fff",
    padding: "2px 10px",
    borderRadius: "20px",
    boxShadow: "0 1px 2px rgba(0, 0, 0, 0.1)",
    border: "1px Solid #C4C4C4",
  },
  text: {
    fontFamily: "Open Sans",
    fontSize: "12px",
    fontWeight: "600",
    lineHeight: "16px",
    textAlign: "left",
    color: "#B42318",
  },
  
}));

const RetryNode = ({ data }) => {
 
  const classes = useStyles();
  const { label, tooltip, ruleOrderId, additionalText, type,isSelectedNode,onClick } = data;
  

  return (
    <Grid
      container
      className={classes.root}
      onClick={onClick}
      direction={"column"}
      style={{ width: "111px", minHeight: "40px",border:isSelectedNode?"2px Solid #FEF3F2":"1px Solid #FEF3F2" }}
    >
       <CustomTooltipComponent
          activityType={type}
          label={label}
          tooltip={tooltip}
          ruleOrderId={ruleOrderId}
        >
      <Grid item>
       
          <Grid
            container
            justifyContent="center"
            alignItems="center"
            direction={"row"}
          >
            <Grid item>
              <IconButton>
                <ErrorHandleIcon />
              </IconButton>
            </Grid>
            <Grid item paddingRight={"4px"}>
              <Typography className={classes.text}>{truncateStringValues({str:label,min:17,max:20})}</Typography>
            </Grid>
          </Grid>
        
      </Grid>
      {additionalText !== null && (
        <Grid item style={{ marginBottom: "4px" }}>
          <Grid container justifyContent={"center"} alignItems={"center"}>
            <Grid item>
            <Typography className={classes.additionalText}>
            {truncateStringValues({ str: additionalText, min: 15, max: 17 })}
         
          </Typography>
            </Grid>
          </Grid>
         
        </Grid>
      )}
</CustomTooltipComponent>
      <Handle
        type="source"
        position="bottom"
        style={{
          background: "#FEF3F2",
          bottom: "-5px",
          height: "3px",
          left: "50%",
          transform: "translateX(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
      />
      <Handle
        type="target"
        position="top"
        style={{
          background: "#FEF3F2",
          top: "-5px",
          height: "3px",
          left: "50%",
          transform: "translateX(-50%)",
           opacity: 0,  pointerEvents: 'all'
        }}
      />
    </Grid>
  );
};

export default RetryNode;
