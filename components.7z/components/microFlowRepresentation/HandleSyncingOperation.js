import { useDispatch } from "react-redux";
import { setCollapsedActivities } from "../../redux/actions"; // Import your action here

const useExpandCollapse = (
  ruleOrderId,
  uuidsAgainstRuleOrderIds,
  collapsedActs,
  data,
  activitiesarr,
  nodes,
  activeTab
) => {
  console.log(
    data,
    "collapsedActivitieee",
    activitiesarr,
    ruleOrderId,
    uuidsAgainstRuleOrderIds
  );
  const dispatch = useDispatch();

  //SplitView
  const handleExpandCollapse = () => {
    const uuid = uuidsAgainstRuleOrderIds?.filter(
      (payload) => payload?.ruleOrderId == ruleOrderId
    )[0].uuid;

    const element = collapsedActs.filter((id) => id === uuid);

    const collapsed = element.length > 0;

    if (collapsed) {
      // Remove from collapsed activities
      dispatch(
        setCollapsedActivities(collapsedActs.filter((id) => id !== uuid))
      );
    } else {
      dispatch(setCollapsedActivities([...collapsedActs, uuid]));
    }

    data.toggleExpandCollapse(ruleOrderId, !collapsed);
  };

  //ListView
  const handleClickToCollapse = (id, activity) => {
    
    const uuid = uuidsAgainstRuleOrderIds.filter(
      (payload) => payload.uuid == id
    )[0].uuid;

    const element = collapsedActs.filter((id) => id === uuid);
    const collapsed = element.length > 0;

    if (collapsed) {
      // Remove from collapsed activities
      dispatch(
        setCollapsedActivities(collapsedActs.filter((id) => id !== uuid))
      );
    } else {
      dispatch(setCollapsedActivities([...collapsedActs, uuid]));
    }

    
    if (activeTab == "Flow Chart") {
      const actElement = nodes.filter(
        (act) => act.id == String(activity.ruleOrderId)
      );

      // activity.toggleExpandCollapse(activity.ruleOrderId, !collapsed);
      
      actElement[0].data.toggleExpandCollapse(
        actElement[0].data.ruleOrderId,
        !collapsed
      );
    }
  };

  return { handleExpandCollapse, handleClickToCollapse };
};

export default useExpandCollapse;
