export const getNodeType = (activityName) => {
  let nodeType = "CustomDiamondNode";
  switch (activityName) {
    case "OpenExcel":
    case "OpenSheet":
      nodeType = "excelScopeNode";
      break;
    case "ForEachRow":
      nodeType = "forEachExcelNode";
      break;
    case "ReadRow":
    case "ReadCell":
    case "FilterTable":
    case "GetSheets":
    case "WriteCell":
    case "AddNewSheet":
    case "GetTableRange":
    case "DeleteColumn":
    case "ReadColumn":
    case "ReadRange":
    case "WriteRange":
    case "CreateTable":
    case "CopySheet":
    case "DeleteRange":
    case "ReadCellFormula":
    case "WriteCellFormula":
    case "ReadRows":
    case "ExecuteMacro":
      nodeType = "excelNonScopeNode";
      break;
    case "PrintOutput":
      nodeType = "printNode";
      break;
    case "Assignment":
      nodeType = "assignmentNode";
      break;
    case "Repeat":
      nodeType = "repeatNode";
      break;
    case "RepeatIf":
      nodeType = "repeatNode";
      break;
    case "IfElse":
      nodeType = "ifNode";
      break;
    case "ForEach":
      nodeType = "forEachNode";
      break;
    case "Start":
      nodeType = "startCircleNode";
      break;
    case "End":
      nodeType = "endCircleNode";
      break;
    case "CSVOpen":
      nodeType = "openCsvNode";
      break;
    case "ReadAllCSVLines":
      nodeType = "readCsvNode";
      break;
    case "WriteCSVLine":
      nodeType = "writeCsvNode";
      break;
    case "GetCurrentDate":
    case "GetCurrentDateTime":
    case "GetCurrentTime":
    case "DateToString":
    case "ChangeDateFormat":
      nodeType = "dateTimeNode";
      break;
    case "CheckError":
      nodeType = "checkErrorNode";
      break;
    case "Exit":
      nodeType = "exitNode";
      break;
    case "Retry":
      nodeType = "retryNode";
      break;
    case "ConditionOf":
      nodeType = "conditionOfNode";
      break;
    case "ConnectDatabase":
      nodeType = "databaseNode";
      break;
    case "FetchRecords":
    case "UpdateRecords":
    case "DeleteRecords":
    case "AddRecords":
    case "ExecuteProcedure":
      nodeType = "nonScopeDatabaseNode";
      break;

    case "RestServices":
      nodeType = "restServicesNode";
      break;
    case "GetPathFromFullPath":
    case "GetAllFoldersFromPath":
    case "GetDriveLetter":
    case "GetSeparator":
    case "GetFileExtension":
    case "GetFileNameFromFullPath":
      nodeType = "pathNode";
      break;

    case "GetHost":
    case "GetPort":
    case "GetProtocolHandler":
      nodeType = "urlNode";
      break;

    case "GetMails":
    case "SendMailSMTP":
    case "DeleteMail":
    case "SaveMail":
    case "SaveMailAttachments":
      nodeType = "mailNonScopeNode";
      break;

    case "ConnectMail":
    case "ForEachMail":
      nodeType = "mailScopeNode";
      break;
    case "StringAfter":
    case "StringBefore":
    case "StringConcat":
    case "StringLowerCase":
    case "StringUpperCase":
    case "StringLength":
    case "SubString":
    case "StringExist":
    case "StringTokenizer":
    case "StringEquals":
      nodeType = "stringNode";
      break;
    case "CreateWorkItem":
      case "CompleteWorkItem":
        case "SaveWorkitem":
    case "GetWorkItem":
      nodeType="newgenOneNoScopeNode";
      break;
    case "ServerConnect":
      nodeType="newgenOneScopeNode";
      break;
    case "AddDocument":
      case "GetDocument":
      nodeType="newgenOneOmnidocsNode";
      break; 

  case "ConnectXtract":
    nodeType="newgenOneOmniXtractScopeNode";
    break;
 case "ExtractData":
  nodeType="newgenOneOmniXtractNoScopeNode";
  break;
case "FTPDownload":
case "FTPUpload":
case "FTPCreate":
case "FTPDelete":
case "FTPMove":
nodeType="nonScopeNodeFTPActivity";
break;
case "FTPConnect":
nodeType="scopeNodeFTPActivity";
break;
case "CodeBlock":
  nodeType="codeBlockNode";
  break;
case "Group":
  nodeType="groupBlockNode";//groupBlockNode
  break;
case "customDottedNode":
  nodeType = "customDottedNode";
  break;
default:
  nodeType = "CustomDiamondNode";
  break;
  }
  return nodeType;
};
