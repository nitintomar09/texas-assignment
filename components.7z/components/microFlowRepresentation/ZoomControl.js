import { useEffect, useState } from "react";
import { Controls } from "react-flow-renderer";

function FlowControls({ zoomLevel }) {
  const [open,setOpen]=useState(false);

  const zoomIn=()=>{
    setOpen(true);
  }

  const zoomOut=()=>{
    setOpen(true);
  }


  useEffect(() => {
    let timer;
    if (open) {
      timer = setTimeout(() => {
        setOpen(false);
      }, 400); 
    }

    // Cleanup the timer when component unmounts or when open changes
    return () => clearTimeout(timer);
  }, [open]);
  return (
    <Controls onZoomIn={zoomIn} onZoomOut={zoomOut} style={{boxShadow:"none"}}>
      {/* <Backdrop
        style={{
          fontFamily: "Open Sans",
          fontSize: "16px",
          fontWeight: "600",
          lineHeight: "16px",
          textAlign: "left",
        }}
        open={open}
      >
        Zoom Level: {Math.round(zoomLevel * 100)}%
      </Backdrop> */}

<span
        style={{
          fontFamily: "Open Sans",
          fontSize: "14px",
          fontWeight: "600",
          lineHeight: "16px",
          textAlign: "left",
        }}
        open={open}
      >
        Zoom Level: {Math.round(zoomLevel * 100)}%
      </span>
    </Controls>
  );
};

export default FlowControls;