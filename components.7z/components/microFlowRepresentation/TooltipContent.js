import React from "react";
import Tooltip from "@mui/material/Tooltip";
import IconButton from "@mui/material/IconButton";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/material/styles";
import makeStyles from "@mui/styles/makeStyles";
import { ExpandNewIcon } from "../../utils/AllImages"; // Adjust the import path as needed
import { Button } from "@mui/material";
import { setActiveTab } from "../../redux/actions";
import { useDispatch } from "react-redux";
const useStyles = makeStyles((theme) => ({
  toolTipContainer: {
    // Custom styles for the tooltip container
  },
  text: {
    fontFamily: 'Open Sans',
    fontSize: '12px',
    fontWeight: '600',
    textAlign: 'left',
    color: '#000000'
  },
}));

const CustomTooltip = styled(({ className, ...props }) => (

  <Tooltip {...props} classes={{ popper: className, tooltip: className }} arrow />
))(({ theme }) => ({
  [`& .MuiTooltip-tooltip`]: {
    backgroundColor: "#FFFFFF",
    border: "1px solid #E7E7E7",
    width: 'auto',
    minWidth: '120px',
    height: '64px',
    borderRadius: '2px',
  },
  [`& .MuiTooltip-arrow`]: {
    color: "#FFFFFF",
    "&::before": {
      border: "1px solid #E7E7E7",
      //left: '10px', // Adjust the left position as needed
    },
  },
}));

const TooltipContent = ({ activityType, label, toggleAction,ruleOrderId }) => {
  
  const classes = useStyles();
 const dispatch=useDispatch();
  const handleAnotherAction = () => {
  
    console.log("Another action");
    toggleAction();
  };

  return (
    <Grid container direction="column" className={classes.toolTipContainer} spacing={1}>
      <Grid item>
        <Typography className={classes.text}>
          {label}
        </Typography>
      </Grid>
      <Grid item>
        <Grid container spacing={1} justifyContent="left" alignItems="center">
          <Grid item>
            <Button variant="text" style={{ fontWeight: '600' }} onClick={()=>dispatch(setActiveTab("Script"))}>Line No. {ruleOrderId}</Button>
          </Grid>
          {activityType === "S" && (
            <Grid item>
              <IconButton onClick={handleAnotherAction}>
                <ExpandNewIcon width={21} height={21} style={{ border: '1px solid grey', padding: '4px' }} />
              </IconButton>
            </Grid>
          )}
        </Grid>
      </Grid>
    </Grid>
  );
};

const CustomTooltipComponent = ({ children, ...props }) => (

  <CustomTooltip title={<TooltipContent {...props} />} placement="top" arrow>
    
    {children}
  </CustomTooltip>
);

export default  CustomTooltipComponent;
//Bug 155559 - properties tab UI is not in sync with the figma design
const ActivityTooltipContent = ({ activityType, label, helperText }) => {
  const classes = useStyles();

  const activityLabel = activityType === "G" ? "Group Activity" : "Scope Activity";

  return (
    <Grid container direction="column" className={classes.toolTipContainer}>
      <Grid container direction="row">
        <Grid item>
        <Typography className={classes.text}>
          {label}:
        </Typography>
        </Grid>
      <Grid item>
        <Typography className={classes.text} fontWeight="600">
          {activityLabel}
        </Typography>
      </Grid>

      </Grid>
      <Grid item sx={{color:"#606060",fontWeight:"400",fontSize:"12px"}}>
        <Typography>{helperText}</Typography>
         
       
      </Grid>
    </Grid>
  );
};

export const CustomActivityTooltipComponent = ({ children, ...props }) => (
  <CustomTooltip title={<ActivityTooltipContent {...props} />} placement="top" arrow 
  sx={{padding:"6px 8px 6px 8px",width:"184px",height:"fit-content"}}
  >
    {children}
  </CustomTooltip>
);



