import React, {
  useCallback,
  useState,
  useEffect,
  useMemo,
  useRef,
} from "react";
import ReactFlow, {
  MiniMap,
  Controls,
  Background,
  ReactFlowProvider,
  applyNodeChanges,
  EdgeLabelRenderer,
  useReactFlow,
} from "reactflow";
import "reactflow/dist/style.css";
import { useDispatch, useSelector } from "react-redux";
import {
  setCollapsedActivities,
  setExpandedNodes,
} from "../../redux/EditorHomepage/actions";
import { getNodeType } from "./getNodeType";
import { processActivities } from "./Nodes/processNodes";
import { handleSelectedActivity } from "../../redux/actions";
import AssignmentNode from "./ActivitiesShapes/ControlFlow/AssignmentNode";
import RepeatNode from "./ActivitiesShapes/ControlFlow/RepeatNode";
import CustomDottedNode from "./ActivitiesShapes/customGroupingNode";
import StartCircleNode from "./ActivitiesShapes/CommonNode/startNode";
import EndCircleNode from "./ActivitiesShapes/CommonNode/endNode";
import RepeatIfNode from "./ActivitiesShapes/ControlFlow/RepeatIfNode";
import ForEachNode from "./ActivitiesShapes/ControlFlow/ForEachNode";
import ExcelNonScopeNode from "./ActivitiesShapes/Excel/excelNonScopeNode";
import ExcelScopeNode from "./ActivitiesShapes/Excel/excelScopeNode";
import PrintNode from "./ActivitiesShapes/ControlFlow/PrintNode";
import OpenCsvNode from "./ActivitiesShapes/CSVNode/OpenCsvNode";
import IfNode from "./ActivitiesShapes/ControlFlow/IfNode";
import ReadCsvNode from "./ActivitiesShapes/CSVNode/ReadCsvNode";
import WriteCsvNode from "./ActivitiesShapes/CSVNode/WriteCsvNode";
import { MarkerType } from "react-flow-renderer";
import DateTimeNode from "./ActivitiesShapes/DateTimeNode/DateAndTimeNode";
import CheckErrorNode from "./ActivitiesShapes/ErrorHandling/CheckErrorNode";
import ExitNode from "./ActivitiesShapes/ErrorHandling/ExitNode";
import RetryNode from "./ActivitiesShapes/ErrorHandling/RetryNode";
import ConditionOfNode from "./ActivitiesShapes/ErrorHandling/ConditionOfNode";
import DatabaseNode from "./ActivitiesShapes/Database/ScopeDatabaseActivityNode";
import NonScopeDatabaseNode from "./ActivitiesShapes/Database/NonScopeDataBaseActivityNode";
import RestServicesNode from "./ActivitiesShapes/WebServices/RestServicesNode";
import PathNode from "./ActivitiesShapes/PathActivity/PathNodes";
import URLNode from "./ActivitiesShapes/URLNode/GetUrlNode";
import MailNonScopeNode from "./ActivitiesShapes/MailActivity/mailNonScopeNode";
import MailScopeNode from "./ActivitiesShapes/MailActivity/mailScopeNode";
import StringNode from "./ActivitiesShapes/StringActivity/StringNode";
import ForEachExcelNode from "./ActivitiesShapes/Excel/forEachExcelNode";
import NewgenOneNoScopeNode from "./ActivitiesShapes/NewgenOneActivity/newgenOneNoScopeNode";
import NewgenOneScopeNode from "./ActivitiesShapes/NewgenOneActivity/newgenOneScopeNode";
import NewgenOneOmnidocsNode from "./ActivitiesShapes/NewgenOneOmnidocs/NewgenOneOmnidocsNode";
import NewgenOneOmniXtractNoScopeNode from "./ActivitiesShapes/NewgenOneOmniXtract/newgenOneOmniXtractNoScopeNode";
import NewgenOneOmniXtractScopeNode from "./ActivitiesShapes/NewgenOneOmniXtract/newgenOneOmniXtractScopeNode";
import NonScopeNodeFTPActivity from "./ActivitiesShapes/FTPNodes/nonScopeNodeFTPActivity";
import ScopeNodeFTPActivity from "./ActivitiesShapes/FTPNodes/scopeNodeFTPActivity";
import CustomSmoothStepEdge from "./Edges/CustomEdge";
import CodeBlockNode from "./ActivitiesShapes/CodeBlock/CodeBlockNode";
import GroupActivity from "./ActivitiesShapes/GroupActivity/activityGroup";
import useCustomHookForNodesState from "./Edges/Customhook";
import { Backdrop } from "@mui/material";
import { propsToClassKey } from "@mui/styles";
import { transformDataToNodes } from "./Utils";
import useExpandCollapse from "./HandleSyncingOperation";
const nodeTypes = {
  excelScopeNode: ExcelScopeNode,
  assignmentNode: AssignmentNode,
  startCircleNode: StartCircleNode,
  endCircleNode: EndCircleNode,
  customDottedNode: CustomDottedNode,
  printNode: PrintNode,
  repeatIfNode: RepeatIfNode,
  repeatNode: RepeatNode,
  forEachNode: ForEachNode,
  excelNonScopeNode: ExcelNonScopeNode,
  ifNode: IfNode,
  openCsvNode: OpenCsvNode,
  readCsvNode: ReadCsvNode,
  writeCsvNode: WriteCsvNode,
  dateTimeNode: DateTimeNode,
  checkErrorNode: CheckErrorNode,
  exitNode: ExitNode,
  retryNode: RetryNode,
  conditionOfNode: ConditionOfNode,
  databaseNode: DatabaseNode,
  nonScopeDatabaseNode: NonScopeDatabaseNode,
  restServicesNode: RestServicesNode,
  pathNode: PathNode,
  urlNode: URLNode,
  mailNonScopeNode: MailNonScopeNode,
  mailScopeNode: MailScopeNode,
  stringNode: StringNode,
  forEachExcelNode: ForEachExcelNode,
  newgenOneNoScopeNode: NewgenOneNoScopeNode,
  newgenOneScopeNode: NewgenOneScopeNode,
  newgenOneOmnidocsNode: NewgenOneOmnidocsNode,
  newgenOneOmniXtractNoScopeNode: NewgenOneOmniXtractNoScopeNode,
  newgenOneOmniXtractScopeNode: NewgenOneOmniXtractScopeNode,
  nonScopeNodeFTPActivity: NonScopeNodeFTPActivity,
  scopeNodeFTPActivity: ScopeNodeFTPActivity,
  codeBlockNode: CodeBlockNode,
  groupBlockNode: GroupActivity,
};

const edgeTypes = {
  custom: CustomSmoothStepEdge,
};

function FlowControls({ zoomLevel }) {
  const [open, setOpen] = useState(false);

  const zoomIn = () => {
    setOpen(true);
  };

  const zoomOut = () => {
    setOpen(true);
  };

  useEffect(() => {
    let timer;
    if (open) {
      timer = setTimeout(() => {
        setOpen(false);
      }, 400);
    }

    // Cleanup the timer when component unmounts or when open changes
    return () => clearTimeout(timer);
  }, [open]);
  return (
    <Controls
      aria-orientation="horizontal"
      onZoomIn={zoomIn}
      onZoomOut={zoomOut}
      style={{
        boxShadow: "none",
        //bottom:10,
        //right:10,
        top: "auto",
        left: "auto",
      }}
      //position="top-left"
    >
      <span
        style={{
          fontFamily: "Open Sans",
          fontSize: "14px",
          fontWeight: "600",
          lineHeight: "16px",
          textAlign: "left",
        }}
        open={open}
      >
        Zoom Level: {Math.round(zoomLevel * 100)}%
      </span>
    </Controls>
  );
}

function MainView({
  activitiesList,
  script,
  updateNodePosition,
  handleSave,
  collapsedActivities,
  handleCollapsedActivities,
  updateNodes,
  addEdgeItem,
  getEdgeItem,
  preserveNodeState,
  getPreviousNodeState,
  preserveExcludedChildState,
  restoreChildState,
}) {
  const initialElements = useMemo(
    () => transformDataToNodes(activitiesList, script),
    [activitiesList, script]
  );

  const dispatch = useDispatch();
  const expandedNodes = useSelector(
    (state) => state.editorHomepage.expandedNodes
  );
  const uuidsAgainstRuleOrderIds = useSelector(
    (state) => state.editorHomepage.uuidRuleOrderId
  );
  const [nodes, setNodes] = useState(initialElements.nodes);
  const [edges, setEdges] = useState(initialElements.edges);
  const [zoomLevel, setZoomLevel] = useState(1);
  const [expandNode, setExpandNode] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [excludedEdge, setExcludedEdge] = useState(null);

  // const {
  //   addEdgeItem,
  //   getEdgeItem,
  //   preserveNodeState,
  //   getPreviousNodeState,
  //   preserveExcludedChildState,
  //   restoreChildState,
  // } = useCustomHookForNodesState();
  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );
  const { handleExpandCollapse } = useExpandCollapse();
  const handleMove = useCallback((event, viewport) => {
    setZoomLevel(viewport.zoom || 1); // Update zoom level based on viewport changes
  }, []);

  const toggleExpandCollapse = useCallback(
    (nodeId, isExpanded) => {
      setIsLoading(true);
      let selectedNodePosition = null;
      let updatePostition = false;
      let ifExist=false;
      let excludedArray = [];

      debugger
      console.log(nodes+edges);

      setTimeout(() => {
        if (isExpanded) {
          let includeNodes = false;
          let parentIdSelected = -2;
          let edgeSource = nodeId;
          let edgeTarget = -2;

          setNodes((prevNodes) => {
            return prevNodes

              .map((nd) => {
                if (
                  nd.data.parentNode == parentIdSelected &&
                  !includeNodes ||
                  (nd.data.parentNode < parentIdSelected && !includeNodes)
                ) {
                  includeNodes = true;

                  edgeTarget = nd.id;
                }

                if (nd.id == nodeId) {
                  let ndUpdate = nd;
                  parentIdSelected = nd.data.parentNode;

                  ndUpdate.data.isExpanded = !isExpanded;

                  selectedNodePosition = nd.position.y;
                  return ndUpdate;
                } else {
                  return nd;
                }
              })
              .filter((node) => {
                if (
                  node.data.parentNode == nodeId ||
                  excludedArray.includes(node.data.parentNode)
                ) {
                  // && node.data.parentNode<nodeId
                  excludedArray.push(Number(node.id));
                  preserveExcludedChildState(nodeId, node);
                  return false;
                } else {
                  return true;
                }
              })
              .map((nde) => {
                if (nde.id === String(nodeId)) {
                  updatePostition = true;
                  if(nde.type=="ifNode"){
                    ifExist=true;
                  }
                  debugger
                  return nde;
                }
                if (selectedNodePosition != null && updatePostition) {
                  let rNode = nde;
                  if(ifExist){
                    selectedNodePosition = selectedNodePosition + 200;
                    ifExist=false;  
                  }else{
                    selectedNodePosition = selectedNodePosition + 100;
                  }
                  
                  rNode.position.y = selectedNodePosition;

                  return rNode;
                } else {
                  return nde;
                }
              });
          });
debugger
          console.log(nodes);

          let newEdge = {
            id: `e${edgeSource}-${edgeTarget}`,
            source: String(edgeSource),
            target: String(edgeTarget),
            type: "smoothstep",
            markerEnd: {
              type: MarkerType.Arrow,
              color: "#3A3A3A",
              height: 20,
              width: 20,
            },
            style: { stroke: "#000000", strokeWidth: 1 },
          };
       
          //addEdgeItem(nodeId, newEdge);

          //let edgeArray = [...edges, newEdge];
          //setEdges(edgeArray);
          //setEdges((prevEdges) => [...prevEdges, newEdge]);
          setEdges((prevEdges) => {
            if (prevEdges.some((edge) => edge.id === newEdge.id)) {
              return prevEdges;
            }
            return [...prevEdges, newEdge];
          });
          // dispatch(setExpandedNodes(nodeId, true));
        } else {
          const nodeChilds = restoreChildState(nodeId);
          //check last child was connected to which Node can be found inside edges array
          const lastChildNodeElementId=Array.from(nodeChilds).pop().id;

          const targetEdges=edges.filter((edge)=>edge.source==lastChildNodeElementId);
          const targetNodeId=targetEdges.shift().target;
          const sourceItemId=String(nodeId);
          debugger
          //const currentIndex = nodes.findIndex((node) => node.id === sourceItemId);
          //const targetNodeId=nodes[currentIndex+1].id;
          const idTobeRemoved='e'+sourceItemId+"-"+targetNodeId;

          setEdges((prevEdges) =>
            prevEdges.filter((edge) => edge.id !== idTobeRemoved)
          );
          //const targetItem=edges.filter((edge) => edge.source == String(nodeId));

          setNodes((prevNodes) => {
            let newNodesState = [...prevNodes, ...nodeChilds].sort((a, b) => {
              // Ensure "Start" comes first
              if (a.id.toLowerCase() === "start") return -1;
              if (b.id.toLowerCase() === "start") return 1;

              // Ensure "End" comes last
              if (a.id.toLowerCase() === "end") return 1;
              if (b.id.toLowerCase() === "end") return -1;

              // For numeric IDs, compare as numbers
              const aNumericId = parseInt(a.id.replace(/\D/g, ""), 10);
              const bNumericId = parseInt(b.id.replace(/\D/g, ""), 10);

              // If IDs are numeric, sort them numerically
              if (!isNaN(aNumericId) && !isNaN(bNumericId)) {
                return aNumericId - bNumericId;
              }

              // Otherwise, keep original order (or apply alphabetical sorting if desired)
              return a.id.localeCompare(b.id);
            });

            let selectedNodePosY = null;

            return newNodesState.map((eachNode) => {
              if (eachNode.id == nodeId) {
                selectedNodePosY = eachNode.position.y;
                eachNode.data.isExpanded = true;
                return eachNode;
              } else {
                if (selectedNodePosY == null) {
                  return eachNode;
                } else {
                  selectedNodePosY = selectedNodePosY + 110;
                  eachNode.position.y = selectedNodePosY;
                  return eachNode;
                }
              }
            });
          });
        }

        setIsLoading(false);
      }, 100);
    },
    [nodes, edges, collapsedActivities, expandedNodes]
  );

  const onNodeDragStop = useCallback(
    (event, node) => {
      // Update the local state with the new position
      setNodes((nds) => {
        const updatedNodes = nds.map((n) => {
          if (n.id === node.id) {
            return { ...n, position: node.position }; // Update position for the dragged node
          }
          return n; // Return unchanged nodes
        });
        updateNodePosition(updatedNodes);

        return updatedNodes;
      });
    },
    [setNodes]
  );

  //here
  const handleNodeClick = useCallback(
    (nodeId) => {
      setNodes((nds) =>
        nds.map((node) => {
          if (node.id === nodeId) {
            //   dispatch(handleSelectedActivity(node.data.orignalActivityData));

            return {
              ...node,
              data: {
                ...node.data,
                isSelectedNode: true,
              },
            };
          }
          return {
            ...node,
            data: {
              ...node.data,
              isSelectedNode: false,
            },
          };
        })
      );
    },
    [setNodes]
  );
  const nodesWithClickHandler = useMemo(
   
    () =>
      
      nodes.map((node) => ({
       
        ...node,
        data: {
          ...node.data,
          onClick: () => handleNodeClick(node.id),
         
          toggleExpandCollapse,
          uuidsAgainstRuleOrderIds:uuidsAgainstRuleOrderIds
        },
      })),
      
    [nodes, handleNodeClick, toggleExpandCollapse, expandedNodes]
  );

  useEffect(() => {
    const updatedNodes1 = nodes.map((node) => ({
      ...node,
      data: {
        ...node.data,

        toggleExpandCollapse,
      },
    }));

    updateNodes(updatedNodes1);
  }, []);

  return (
    <div style={{ height: "80vh", width: "100%", overflow: "hidden" }}>
      {/* {isLoading && (
        <div className="loader">
          <p>Loading...</p>
        </div>
      )} */}
      <ReactFlowProvider>
        <div style={{ width: "100%", height: "100%" }}>
          <ReactFlow
            nodes={nodesWithClickHandler}
            edges={edges}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            onNodesChange={onNodesChange}
            onNodeDragStop={onNodeDragStop}
            defaultViewport={{ x: 0, y: 0, zoom: 1 }} // Set default zoom level here
            onMove={handleMove}
            fitView
          />
          <FlowControls zoomLevel={zoomLevel} />
        </div>
      </ReactFlowProvider>
    </div>
  );
}

export default MainView;
