import React from "react";
import { getNodeType } from "../getNodeType";
import { getAdditionalDetails } from "../getAdditionalDetails";
import { MarkerType } from "react-flow-renderer";

import "./createNode.css";
const createNode = (
  activity,
  x,
  y,
  previousNodeId,
  parentNodeId,
  createdEdges,
  flags,
  excludedEdges,
) => {
  const positionXCoordinate = activity.positionXCoordinate;
  const positionYCoordinate = activity.positionYCoordinate;
 
  // Determine position based on coordinates
  const position =
    positionXCoordinate === 0 && positionYCoordinate === 0
      ? { x, y }
      : { x: positionXCoordinate, y: positionYCoordinate };

  const nodeId = String(activity.ruleOrderId);
  const isParentNode = parentNodeId == activity.ruleOrderId;
  console.log(activity,nodeId,parentNodeId,"activityPuttututut")
  let actEdge = null;
 
  const actNode = {
    id: nodeId,
    type: getNodeType(activity.activityName),
    position: position,
    style: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      width: "200px",
      minheight: "50px",
    background: activity.activityType=="S" ? "#ffffff": "none",
    border:activity.activityType=="S"?"1px dashed #c4c4c4":"none",
    },
    data: {
      label: activity.displayName,
      additionalText: getAdditionalDetails(activity),
      parentNode: parentNodeId,
      ruleOrderId: activity.ruleOrderId,
      positionXCoordinate: x,
      positionYCoordinate: y,
      // xPos: x,  // Store xPos
      // yPos: y,  // Store yPos

      type: activity.activityType,
      isExpanded: true,
      //   isExpanded:false,
      orignalActivityData: activity,
    
    },
  };

  if (previousNodeId) {
    const edgeId = `e${previousNodeId}-${nodeId}`;

    if (!createdEdges.has(edgeId)) {
      actEdge = {
        id: edgeId,
        source: previousNodeId,
        target: nodeId,
        type: "smoothstep",
        markerEnd: { type: MarkerType.Arrow, color: "#3A3A3A",height:"20px",width:"20px" },

        sourceHandle: flags.thenConditionFlag
          ? "a"
          : flags.elseConditionFlag
          ? "b"
          : flags.onErrorFlag
          ? "b"
          : flags.checkErrorFlag
          ? "a"
          : flags.loopFlag
          ? "a"
          : "",
        label: flags.thenConditionFlag
          ? "True"
          : flags.elseConditionFlag
          ? "False"
          : flags.onErrorFlag
          ? "On Error"
          : flags.checkErrorFlag
          ? "Check Error"
          : "",
        labelStyle: {
          fontSize: 16,
          fontWeight: "bold",
          fill: flags.thenConditionFlag ? "#0D6F08" : "red", // Adjust this color as needed
        
        },
        style: { stroke: "#000000", strokeWidth: 1 },
      };

      flags.elseConditionFlag = false;
      flags.thenConditionFlag = false;
      flags.loopFlag = false;
      flags.checkErrorFlag = false;
      flags.onErrorFlag = false;

      if (!excludedEdges.has(Number(nodeId)) || !excludedEdges.has(nodeId)) {
       
        createdEdges.add(edgeId);
      }
    }
  }

  return { nodeId, actNode, actEdge };
};

export { createNode };

const CustomEdgeLabel = ({ label }) => {
  console.log(label, "label");
  return (
    <div
      style={{
        fontSize: "16px",
        fontWeight: "bold",
      }}
    >
      {label}
    </div>
  );
};


