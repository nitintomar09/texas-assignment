import { createNode } from "./createNode";

const processActivities = (
  activities, x, y, previousNodeId, nodes, edges, createdEdges, 
  flags, endEdgesIds, excludedEdges, parentNodeId, parentNextNodeId, level = 0
) => {
  const baseSpacing = 300;
  const nestedSpacing = 230;
    activities.forEach((activity, activityIndex) => {
      //adding this to identify the next Node of the Parent Node
      parentNextNodeId=activities[activities+1]===undefined?'end':activities[activities+1].ruleOrderId;
      const nodeInfo = createNode(activity, x, y, previousNodeId, parentNodeId, createdEdges, flags,excludedEdges,nodes);
      nodes.push(nodeInfo.actNode);
      //Adding this statement for IF-Else activity so that we can prevent extra edge creation with if activity.
      
      if(!(excludedEdges.has(Number(nodeInfo.nodeId)))){
        edges.push(nodeInfo.actEdge);
      }
      const nodeId = nodeInfo.nodeId;
      previousNodeId = nodeId;
      y += 100;
  
      if (activity.subActivities && activity.subActivities.length > 0) {
       
          if (['ForEach', 'RepeatIf', 'Repeat', 'ForEachRow', 'Retry'].includes(activity.activityName)) {
          flags.loopFlag = true;
          const endEdge = {
            source: activity.subActivities[activity.subActivities.length - 1].ruleOrderId,
            target: activity.ruleOrderId,
            targetHandle: 'c',
          };
          endEdgesIds.add(endEdge);
         
          const result = processActivities(activity.subActivities, x + 200, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId);
          y=result.y;
          
        } else {
          //parentNodeId = activity.ruleOrderId;
          const result = processActivities(activity.subActivities, x, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId);
          previousNodeId = result.previousNodeId;//
          y=result.y;
        }
        
      }


     
      if (activity.activityName === 'IfElse' ||  activity.activityName==='CheckError') {

        if (activities[activityIndex + 1]) {
          excludedEdges.add(activities[activityIndex + 1].ruleOrderId);
         
        }
        else if(activities.length==1){
         
          excludedEdges.add('end')
        }
      }
      if(activity.thenActivities && activity.thenActivities.length===0 && activity.elseActivities && activity.elseActivities.length===0){
        y=y+100;
      }
      //let ifElseY=null;// to store last then node position
      const currentSpacing = level === 0 ? baseSpacing : nestedSpacing;
      if (activity.thenActivities) {
        debugger
        let targetToBe='end';
        if(activities[activityIndex + 1] == undefined){
          //Check if Parent has any next Node, that will be the target end edge otherwise 'final end will be target'.
          if(parentNextNodeId!=null ||parentNextNodeId!=undefined){
            targetToBe=parentNextNodeId;
          }
        }else{
          targetToBe=activities[activityIndex + 1].ruleOrderId;
        }
        const endEdge = {
          source: activity.thenActivities.length <= 0 ? activity.ruleOrderId : activity.thenActivities[activity.thenActivities.length - 1].ruleOrderId,
          target: activities[activityIndex + 1] == undefined ? 'end' : activities[activityIndex + 1].ruleOrderId,
          //target:targetToBe,

          sourceHandle: 'a',
          label:'<'
        };
        if (!(activity.thenActivities.length > 0 && activity.thenActivities[activity.thenActivities.length - 1].activityName === 'IfElse')) {
          endEdgesIds.add(endEdge);
        }
        if (activity.thenActivities.length > 0) {
          flags.thenConditionFlag = true;
          //parentNodeId = activity.ruleOrderId;

          const result = processActivities(activity.thenActivities, x + currentSpacing, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId,level+1);
          //previousNodeId = result.previousNodeId;//

          y=result.y;
          //ifElseY=result.y;

        }
      }

      if (activity.elseActivities) {
        const endEdge = {
          source: activity.elseActivities.length <= 0 ? activity.ruleOrderId : activity.elseActivities[activity.elseActivities.length - 1].ruleOrderId,
          target: activities[activityIndex + 1] == undefined ? 'end' : activities[activityIndex + 1].ruleOrderId,
          sourceHandle: 'b',
          label:'>'
        };
        if (!(activity.elseActivities.length > 0 && activity.elseActivities[activity.elseActivities.length - 1].activityName === 'IfElse')) {
          endEdgesIds.add(endEdge);
        }
        if (activity.elseActivities.length > 0) {
          flags.elseConditionFlag = true;
          //parentNodeId = activity.ruleOrderId;

          const result = processActivities(activity.elseActivities, x - currentSpacing, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId,level+1);
          //previousNodeId = result.previousNodeId;//
         // if(ifElseY!=null && ifElseY>result.y){// to maintain previous node postion
            //y=ifElseY;
          //}else{

            y=result.y;
          //}


        }
      }

      if (activity.checkError) {
      
        let targetToBe='end';
        if(activities[activityIndex + 1] == undefined){
          //Check if Parent has any next Node, that will be the target end edge otherwise 'final end will be target'.
          if(parentNextNodeId!=null ||parentNextNodeId!=undefined){
            targetToBe=parentNextNodeId;
          }
        }else{
          targetToBe=activities[activityIndex + 1].ruleOrderId;
        }
        const endEdge = {
          source: activity.checkError.length <= 0 ? activity.ruleOrderId : activity.checkError[activity.checkError.length - 1].ruleOrderId,
          target: activities[activityIndex + 1] == undefined ? 'end' : activities[activityIndex + 1].ruleOrderId,

          sourceHandle: 'a',

        };
        if (!(activity.checkError.length > 0 && activity.checkError[activity.checkError.length - 1].activityName === 'CheckError')) {
          endEdgesIds.add(endEdge);
        }
        if (activity.checkError.length > 0) {
          flags.checkErrorFlag = true;
          //parentNodeId = activity.ruleOrderId;
         // const result = processActivities(activity.checkError, x + 300, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId,level+1);
          //previousNodeId = result.previousNodeId;//

          const result = processActivities(activity.checkError, x + currentSpacing, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId,level+1);

          y=result.y;

        }
      }





      if (activity.onError) {
        const endEdge = {
          source: activity.onError.length <= 0 ? activity.ruleOrderId : activity.onError[activity.onError.length - 1].ruleOrderId,
          target: activities[activityIndex + 1] == undefined ? 'end' : activities[activityIndex + 1].ruleOrderId,
          sourceHandle: 'b',
        };
      //  if (!(activity.onError.length > 0 && activity.onError[activity.checkError.length - 1].activityName === 'CheckError')) {
        if (!(activity.onError.length > 0 && activity.onError[activity.onError.length - 1].activityName === 'CheckError')) {
          endEdgesIds.add(endEdge);
        }
        if (activity.onError.length > 0) {
          flags.onErrorFlag = true;
          //parentNodeId = activity.ruleOrderId;
       //   const result = processActivities(activity.onError, x - 300, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId,level+1);
          //previousNodeId = result.previousNodeId;//
          const result = processActivities(activity.onError, x - currentSpacing, y, nodeId, nodes, edges, createdEdges, flags, endEdgesIds,excludedEdges,activity.ruleOrderId,parentNextNodeId,level+1);
          y=result.y;

        }
      





    }});
  
    return {y,previousNodeId};
  };
  
  export { processActivities };