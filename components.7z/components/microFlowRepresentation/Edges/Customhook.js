import { useState, useCallback } from "react";

const useCustomHookForNodesState = () => {
  const [edgeMap, setEdgeMap] = useState(() => new Map());
  const [prevFlowChartState, setPrevFlowChartState] = useState(() => new Map());
  const [excludedChildState, setExcludedChildState] = useState(() => new Map());

  const preserveNodeState = useCallback((key, item) => {
    setPrevFlowChartState((prevState) => new Map(prevState).set(key, item));
  }, []);

  const getPreviousNodeState = useCallback(
    (key) => {
      return prevFlowChartState.get(key);
    },
    [prevFlowChartState]
  );

  const addEdgeItem = useCallback((key, item) => {
    setEdgeMap((prevMap) => new Map(prevMap).set(key, item));
  }, []);

  const getEdgeItem = useCallback(
    (key) => {
      return edgeMap.get(key);
    },
    [edgeMap]
  );

  const preserveExcludedChildState = useCallback((key, item) => {
    //key is the node Id and items are the childs of that collpased nodes.

    if (excludedChildState.has(key)) {
      excludedChildState.get(key).add(item);
    } else {
      let nodeChilds = new Set();
      nodeChilds.add(item);
      excludedChildState.set(key, nodeChilds);
    }
  }, []);

  const restoreChildState = useCallback((key) => {
    // Key is the nodeId which is going to be expanded.
    if (excludedChildState.has(key)) {
      let nodeChilds = excludedChildState.get(key);
      excludedChildState.delete(key);
      return nodeChilds;
    } else {
      return new Set();
    }
  }, []);

  return {
    addEdgeItem,
    getEdgeItem,
    preserveNodeState,
    preserveExcludedChildState,
    restoreChildState,
    getPreviousNodeState,
  };
};

export default useCustomHookForNodesState;
