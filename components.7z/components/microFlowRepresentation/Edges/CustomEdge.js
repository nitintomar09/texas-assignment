import React from 'react';
import { getSmoothStepPath } from 'reactflow';

const CustomSmoothStepEdge = ({
  id,
  sourceX,
  sourceY,
  sourcePosition,
  targetX,
  targetY,
  targetPosition,
  style = {},
  markerEnd,
}) => {
  // Custom offset values
  const controlOffset = 70; // Adjust this to control the bend
  const curvature = 0.01;   // Adjust this to control the curvature
  const minOffset = 1; // Minimum fixed distance from targetX
const variableOffset = 10; // Additional random offset
const offset = minOffset + variableOffset;

const randomValue = targetX + (Math.random() < 0.5 ? -offset : offset);


  const [edgePath] = getSmoothStepPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX:randomValue,
   // targetX,
    targetY,
    targetPosition,
    borderRadius: controlOffset,
    // centerX: (sourceX + targetX) /2,
    // centerY: (sourceY + targetY) / 2 + curvature * 100, // Customizing bend point
     centerX : sourceX + (targetX - sourceX) * 0.7,
      centerY : sourceY + (targetY - sourceY) * 0.7
  });

  return (
    <path
      id={id}
      style={style}
      className="react-flow__edge-path"
      d={edgePath}
      markerEnd={markerEnd}
    />
  );
};

export default CustomSmoothStepEdge;













// import React from 'react';
// import { getSmoothStepPath } from 'reactflow';

// const CustomBendEdge = ({
//   id,
//   sourceX,
//   sourceY,
//   sourcePosition,
//   targetX,
//   targetY,
//   targetPosition,
//   style = {},
//   markerEnd,
// }) => {
//   // Calculate control points for bending from 30% of the path
//   const controlOffset = 70; // Adjust this value for the desired bend
//   const curvature = 0.7;    // This controls the curvature (30% along the path)

//   // Calculate 30% along the path from source to target
//   const midX = sourceX + (targetX - sourceX) * 0.7;
//   const midY = sourceY + (targetY - sourceY) * 0.7;

//   // Get the smooth step path with the bend occurring at 30% of the path
//   const [edgePath] = getSmoothStepPath({
//     sourceX,
//     sourceY,
//     sourcePosition,
//     targetX,
//     targetY,
//     targetPosition,
//     borderRadius: controlOffset,
//     centerX: midX,  // Set the curve control point at 30% horizontally
//     centerY: midY,  // Set the curve control point at 30% vertically
//   });

//   return (
//     <path
//       id={id}
//       style={style}
//       className="react-flow__edge-path"
//       d={edgePath}
//       markerEnd={markerEnd}
//     />
//   );
// };

// export default CustomBendEdge;

