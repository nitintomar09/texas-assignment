import { constant } from "lodash";
import { getNodeType } from "./getNodeType";
import { processActivities } from "./Nodes/processNodes";
import { MarkerType } from "reactflow";

export const transformDataToNodes = (data, script) => {
    let nodes = [];
    let edges = [];
    let yPos = 5;
    let xPos = window.innerWidth / 2 - 100;
    let lastNodeId = "";
    let parentNodeId = -1;
    const createdEdges = new Set();
    const flags = {
      thenConditionFlag: false,
      elseConditionFlag: false,
      loopFlag: false,
      checkErrorFlag: false,
      onErrorFlag: false,
    };
    const endEdgesIds = new Set();
    const excludedEdge = new Set();
  
    // Start Node
    nodes.push({
      id: "start",
      type: getNodeType("Start"),
      position: { x: xPos, y: yPos },
      style: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "200px",
        minHeight: "50px",
      },
      data: {
        label: "Start",
        additionalText: "Additional Info",
        tooltip: "Tooltip text",
        parentNode: parentNodeId,
      },
    });
  
    yPos += 100;
    const processNodes = processActivities(
      data,
      xPos,
      yPos,
      "start", // lastNode
      nodes,
      edges,
      createdEdges,
      flags,
      endEdgesIds,
      excludedEdge,
      parentNodeId,
      "start"
    );
  
    yPos = processNodes.y;
    lastNodeId = processNodes.previousNodeId;
  
    // End Node
    nodes.push({
      id: "end",
      type: getNodeType("End"),
      position: { x: xPos , y: yPos },
      style: {
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        width: "200px",
        minHeight: "40px",
      },
      data: {
        label: "End",
        additionalText: "Additional Info",
        tooltip: "Tooltip text",
        parentNode: parentNodeId,
      },
    });
  
    if (nodes.length > 1) {
      const edgeId = `e${lastNodeId}-end`;
  
      if (!createdEdges.has(edgeId)) {
        if (
          nodes.filter((el) => el.id === lastNodeId && (el.type === "ifNode" || el.type==="checkErrorNode"))
            .length == 0
        ) {
          edges.push({
            id: edgeId,
            source: lastNodeId,
            target: "end",
            type: "smoothstep",
            markerEnd: { type: MarkerType.Arrow, color: "#3A3A3A" },
            style: { stroke: "#000000", strokeWidth: 1 },
          });
          createdEdges.add(edgeId);
        }
        // else{}
      }
  
      endEdgesIds.forEach((item) => {
        lastNodeId++;
        const nEdgeId = `e${lastNodeId}-end`;
        edges.push({
          id: nEdgeId,
          source: String(item.source),
          target: String(item.target),
          type: "custom",
          sourceHandle: item.sourceHandle,
          targetHandle: item.targetHandle,
          label: item.label,
  
          markerEnd: {
            type: MarkerType.Arrow,
            width: 20,
            height: 20,
            color: "#3A3A3A",
          },
          style: { stroke: "#000000", strokeWidth: 1 },
        });
      });
    }
  
    return { nodes, edges };
  };