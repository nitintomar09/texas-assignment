import React from "react";
import { Grid, Typography } from "@mui/material";
import { useTranslation } from "react-i18next";
const AccessTokenPage = ({ location }) => {
  const { t } = useTranslation()
  return (
    <div>
      <Grid container spacing={1}>
        <Grid item>
          <Typography>{t("Access Token:")}</Typography>
        </Grid>
        <Grid item>
          <Typography>{location?.serach || ""}</Typography>
        </Grid>
      </Grid>
    </div>
  );
};

export default AccessTokenPage;
