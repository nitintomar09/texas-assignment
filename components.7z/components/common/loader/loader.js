import React, { Fragment } from "react";
import { CircularProgress, Grid } from "@mui/material";

import makeStyles from '@mui/styles/makeStyles';
import { RiUserHeartLine } from "react-icons/ri";

const useStyles = makeStyles((AppTheme) => ({
  container: {
    padding: 200,
  },
  progress: { paddingTop: 100 },
}));
const useStylesCustom = makeStyles((theme) => ({
  root: {
    position: "relative",
  },
  bottom: {
    color: "#1a90ff",
  },
  top: {
    color: "0072C6",
    animationDuration: "550ms",
    position: "absolute",
    left: 0,
  },
  circle: {
    strokeLinecap: "round",
  },
}));
function CustomCircularProgress(props) {
  const classes = useStylesCustom();

  return (
  //  BugId:Bug 155115 - On launching the tool loader size should be consistent like other modules
  //   Author: Dixita.ruhela
  //    Date: 8 jan 2025
  //   RCA: The styling is not proper of the loader.
    <div className={classes.root}>
      <CircularProgress
      
        variant="determinate"
        className={classes.bottom}
        size={20}
        thickness={4}
        {...props}
        value={100}
      />
      <CircularProgress
        variant="indeterminate"
        disableShrink
        className={classes.top}
        classes={{
          circle: classes.circle,
        }}
        size={props.size?props.size:20}
        thickness={4}
        {...props}
      />
    </div>
  );
}
const Loader = (props) => {
  const classes = useStyles();
  return (
    <div className={classes.container}>
      <Grid container justifyContent="center" alignItems="center">
        <Grid item>
          <CustomCircularProgress  size={props.size?props.size:20} thickness={4} />
        </Grid>
      </Grid>
    </div>
  );
};

export default Loader;
