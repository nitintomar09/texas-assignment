import React from "react";
import {
  Dialog,
  DialogTitle,
  DialogActions,
  Button,
  DialogContent,
  Typography,
  Grid,
} from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import customStyle from "../../../assets/css/customStyle";
import LoadingButton from "../../common/Button/index";
const useStyles = makeStyles((AppTheme) => ({
  text: { fontSize: 12 },
  title: { fontWeight: "bold", fontSize: 12 },
}));
function Confirm(props) {
  const classes = useStyles();
  return (
    <Dialog open={props.isOpen}>
      <DialogTitle>
        <Typography data-testid="confirm-label" className={classes.title}>
          {props.label}
        </Typography>
      </DialogTitle>
      <DialogContent>
        <Typography data-testid="confirm-content" className={classes.text}>
          {props.content}
        </Typography>
      </DialogContent>
      <DialogActions>
        <Grid container justifyContent="flex-end" spacing={1}>
          <Grid item>
            <LoadingButton
              btnType={"BUTTON-DISABLED"}
              size="small"
              // variant="contained"
              // loading={props.isLoading}
              title={props.btn1Text ? props.btn1Text : "No"}
              // disabled={props.isLoading}
              onClick={props.close}
            />
          </Grid>
          <Grid item>
            {/* <Button
              onClick={props.onConfirm}
              style={customStyle.btnFilled}
              variant="contained"
              size="small"
            >
              Yes
            </Button> */}
            <LoadingButton
              btnType={
                props.btn2disabled ? "BUTTON-DISABLED" : "BUTTON-FILLED"
              }
              size="small"
              variant="contained"
              loading={props.isLoading}
              title={props.btn2Text ? props.btn2Text : "Yes"}
              disabled={props.isLoading}
              onClick={props.onConfirm}
            />
          </Grid>
        </Grid>
      </DialogActions>
    </Dialog>
  );
}

export default Confirm;
