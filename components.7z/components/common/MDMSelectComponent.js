import React, { useState } from "react";
import {
  MenuItem,
  Checkbox,
  ListItemText,
  Select,
  FormControl,
  InputLabel,
  Typography,
  Collapse,
  ListItemIcon,
  Grid,
  Divider,
  MenuList,
  Button,
  Chip,
  IconButton,
  Icon,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import { MDMDataObject } from "../../utils/AllImages";
import CloseIcon from "@mui/icons-material/Close";
import { propsToClassKey } from "@mui/styles";

/**
 * A Select component with expandable options containing sub-options with checkboxes.
 * @param {Array} subVariables - Array of main options with nested subList.
 * @param {Function} onSelectionChange - Callback to return selected sub-options.
 */
const NestedSelect = ({
  subVariables,
  onSelectionChange,
  fetchObjectsMDM,
  subList,
  width,
  setCreateVariableObject,
  globalCategoryName,
  setMdmFlag,
  typeOptions
}) => {
  const [selectedItems, setSelectedItems] = useState([]);
  const [openSubList, setOpenSubList] = useState(null);
  const [expandedParents, setExpandedParents] = useState(new Set());

  // variableType
  const getType = (type) => {
    let variableType = null;
    switch (type) {
      case 2:
        variableType = "Integer";
        break;
      case 1:
        variableType = "Text";
        break;
      case 8:
        variableType = "Float";
        break;
      case 4:
        variableType = "Date";
        break;
      case 3:
        variableType = "Boolean";
        break;
      case 5:
        variableType = "List";
        break;
      case 7:
        variableType = "DataRecord";
        break;
      case 6:
        variableType = "DataTable";
        break;
      case 9:
        variableType = "DateTime";
        break;
      case 10:
        variableType = "MailMessage";
        break;
      case 11:
        variableType = "JSONObject";
        break;
      case 12:
        variableType = "JSONArray";
        break;
      default:
        break;
    }
    return variableType;
  };

  // Handle checkbox selection
  //   const handleCheckboxChange = (option, subItem) => {
  //     let newMdmObject = { ...option, ...subItem };
  //     const updatedSelection = getCheckedState(option, subItem)
  //       ? selectedItems.filter(
  //           (item) =>
  //             item.dataObjectId !== option.dataObjectId &&
  //             item.variableId !== subItem.variableId
  //         )
  //       : [...selectedItems, newMdmObject];

  //     setSelectedItems(updatedSelection);

  //     if (onSelectionChange) {
  //       onSelectionChange(updatedSelection);
  //     }
  //   };

  // Handle checkbox selection
  const handleCheckboxChange = (option, subItem = null) => {
    // If subItem is null, this means the parent checkbox is being clicked
    if (subItem === null) {
      const isParentChecked = getCheckedState(option);

      // If parent is checked, select all sub-items, otherwise unselect all
      const updatedSelection = isParentChecked
        ? selectedItems.filter(
            (item) => item.dataObjectId !== option.dataObjectId
          )
        : [
            ...selectedItems,
            ...option.subList.map((subItem) => ({
              ...option,
              ...subItem,
            })),
          ];

      setSelectedItems(updatedSelection);
      if (onSelectionChange) {
        onSelectionChange(updatedSelection);
      }
    } else {
      let newMdmObject = { ...option, ...subItem };
      const isAlreadySelected = getCheckedState(option, subItem);

      // If already selected, remove it; otherwise, add it to the selectedItems list
      const updatedSelection = isAlreadySelected
        ? selectedItems.filter(
            (item) =>
              item.dataObjectId !== option.dataObjectId ||
              item.variableId !== subItem.variableId
          )
        : [...selectedItems, newMdmObject];

      setSelectedItems(updatedSelection);
      if (onSelectionChange) {
        onSelectionChange(updatedSelection);
      }
    }
  };

  // Remove selection
  const handleRemoveSelection = () => {
    setSelectedItems("");
    if (onSelectionChange) {
      onSelectionChange("");
    }
  };

  // Toggle sublist visibility
  //   const toggleSubList = (index, dataObjectId) => {
  //     setOpenSubList(openSubList === index ? null : index);
  //     fetchObjectsMDM(index, dataObjectId);
  //   };

  const toggleSubList = (index, dataObjectId) => {
    setOpenSubList(openSubList === index ? null : index);
    if (!expandedParents.has(dataObjectId)) {
      // Fetch data from API if sublist is being expanded for the first time
      fetchObjectsMDM(index, dataObjectId);
      setExpandedParents((prev) => new Set(prev).add(dataObjectId)); // Mark this parent as expanded
    }
  };

  const handleClear = () => {
    setSelectedItems([]);
  };

  const handleCheckDone = (e) => {
    let mdmVarArray=selectedItems.map((item)=>{
      debugger
        return {
            variableName: {
                value: item.dataObjectName+"."+item.variableName,
                error: false,
                helperText: "",
              },
              categoryName: {
                value: globalCategoryName,
                error: false,
                helperText: "",
              },   
            variableDefaultValue: "",
            variableType: {
                value: typeOptions.filter(type=>item.variableDataType==type.value)[0].value,
                error: false,
                helperText: "",
              },
            type: {
                value: "",
                error: false,
                helperText: "",
              },
            isDynamicChecked: false,
            isFixedChecked: false,
          }
    });
    setMdmFlag(true);
    setCreateVariableObject(mdmVarArray);
  };

  //   const getCheckedState = (option, subItem) => {
  //     let filteredItem = selectedItems.filter(
  //       (item) =>
  //         item.dataObjectId == option.dataObjectId &&
  //         item.variableId == subItem.variableId
  //     );
  //     if (filteredItem.length > 0) {
  //       return true;
  //     } else

  //     return false;
  //   };.
  const getCheckedState = (option, subItem = null) => {
    if (subItem === null) {
      // Check if all subItems under this parent option are selected
      const filteredItems = selectedItems.filter(
        (item) => item.dataObjectId === option?.dataObjectId
      );
      return filteredItems?.length === option?.subList?.length;
    } else {
      // Check if a specific subItem is selected
      const filteredItem = selectedItems.filter(
        (item) =>
          item.dataObjectId === option.dataObjectId &&
          item.variableId === subItem.variableId
      );
      return filteredItem.length > 0;
    }
  };

  return (
    <FormControl
      style={{
        width: "95%",
        marginTop: "5px",
      }}
    >
      <Select
        labelId="nested-select-label"
        multiple
        value={selectedItems}
        renderValue={() =>
          selectedItems ? (
            <Chip
              label={
                selectedItems[0].dataObjectDisplayName +
                "." +
                selectedItems[0].variableName
              }
              onDelete={handleRemoveSelection}
              //deleteIcon={<CloseIcon />}
              variant="outlined"
              size="small"
              sx={{
                borderRadius: 0,
                // paddingTop:"2px"
              }}
            />
          ) : (
            ""
          )
        }
        sx={{
          height: "28px",
        }}
        MenuProps={{
          PaperProps: {
            sx: {
              paddingTop: "2px",
              maxHeight: 300, // Set a maximum height for the dropdown
              border: "#E7E7E7",
              boxShadow: "0px 3px 6px 0px #00000029",
              borderRadius: 1, // Optional: Rounded corners for the dropdown
            },
          },
        }}
      >
        <MenuItem sx={{ height: "28px",paddingRight:"0px" }}>
          {/* <ListItemText
            primary={ */}
          <Grid
            container
            //spacing={1}
            alignItems="center"
            //justifyContent={"flex-end"}
            sx={{
              fontFamily: "Open Sans",
              fontSize: "12px",
              fontWeight: "400",
            }}
          >
            <Grid item xs>
              <Typography sx={{ color: "#000000" }}>
                <span fontWeight={600}>{selectedItems.length}</span> variable selected
              </Typography>
            </Grid>
            <Grid item xs> 
              <Grid container justifyContent="flex-end">
                <Grid item>
                  <Button
                    sx={{ color: "#606060", fontWeight: 600 }}
                    onClick={handleClear}
                  >
                    Clear
                  </Button>
                </Grid>
                <Grid item>
                  <Button
                    sx={{ color: "#0072C6", fontWeight: 600 }}
                    onClick={(e) => handleCheckDone(e)}
                  >
                    Done
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          {/* }
          /> */}
        </MenuItem>
        <Divider style={{ marginTop: "0px" }} />

        {subVariables.map((option, index) => (
          <>
            <MenuItem
              key={index}
              sx={{
                height: "28px",
                paddingLeft:"8px",
                paddingRight:"8px"
              }}
            >
              <Grid container 
                    alignItems={"center"}
                    justifyContent={"flex-start"}
              >
                <Grid item >
                      <Checkbox
                      sx={{paddingLeft:"0px", paddingRight:"0px"}}
                        checked={getCheckedState(option)} // Check if any of the subItems are selected
                        onChange={() => handleCheckboxChange(option)} // Parent checkbox click
                        disabled={!expandedParents.has(option.dataObjectId)}
                      />
                </Grid>

                <Grid item xs>
                  <Grid
                    container
                    spacing={0.5}
                    alignItems={"center"}
                    //justifyContent={"flex-start"}
                  >
                    <Grid item>
                        <Icon>
                      <MDMDataObject />
                      </Icon>
                    </Grid>
                    <Grid item>
                      <Typography
                        sx={{
                          fontFamily: "Open Sans",
                          fontSize: "12px",
                          fontWeight: "600",
                          color: "#000000",
                        }}
                      >
                        {option.dataObjectDisplayName}
                      </Typography>
                    </Grid>
                    <Grid
                      item
                      onClick={() => toggleSubList(index, option.dataObjectId)}
                    >
                      {openSubList === index ? (
                        <Icon>
                        <ExpandLessIcon />
                        </Icon>
                      ) : (
                        <Icon>
                        <ExpandMoreIcon />
                        </Icon>
                      )}
                    </Grid>
                  </Grid>
                </Grid>

                <Grid item>
                  <Grid container justifyContent={"flex-end"}>
                    <Grid item>
                      <Typography>
                        {option.subList?.length > 0
                          ? option.subList?.length
                          : "00"}
                      </Typography>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </MenuItem>
            <Collapse
              in={openSubList === index}
              timeout="auto"
              unmountOnExit
              sx={{ paddingLeft: "20px" }}
            >
              <Grid
                container
                direction={"column"}
              >
                {option.subList?.map((subItem) => (
                  <MenuItem
                    key={subItem.variableName}
                    sx={{
                      height: "28px",
                      paddingLeft:"8px",
                      paddingRight:"8px"
                    }}
                  >
                    {/* <ListItemText
                      primary={ */}
                        <Grid container alignItems={"center"}>
                          <Grid item>
                            <Checkbox
                            sx={{paddingLeft:"0px"}}
                              checked={getCheckedState(option, subItem)}
                              onChange={
                                () => handleCheckboxChange(option, subItem)
                                // handleCheckboxChange(
                                //   option.dataObjectDisplayName +
                                //     "." +
                                //     subItem.variableName
                                // )
                              }
                              //size="small"

                              // disabled={selectedItems.length === 1}
                            />
                          </Grid>
                          <Grid item>
                            <Typography
                              sx={{
                                fontFamily: "Open Sans",
                                fontSize: "12px",
                                fontWeight: "400",
                                color: "#000000",
                              }}
                            >
                              {subItem.variableName}
                            </Typography>
                          </Grid>
                          <Grid item xs>
                            <Grid container justifyContent={"flex-end"}>
                              <Grid item>
                                <Typography
                                  sx={{
                                    fontFamily: "Open Sans",
                                    fontSize: "12px",
                                    fontWeight: "400",
                                    color: "#606060",
                                  }}
                                >
                                  {getType(subItem.variableDataType)}
                                </Typography>
                              </Grid>
                            </Grid>
                          </Grid>
                        </Grid>
                      {/* }
                    /> */}
                  </MenuItem>
                ))}
              </Grid>
            </Collapse>
          </>
        ))}
      </Select>
    </FormControl>
  );
};

export default NestedSelect;
