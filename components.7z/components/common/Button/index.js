import React, { Fragment } from "react";
import { Button, Chip, Box, Grid, CircularProgress } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import theme from "../../../assets/theme/theme";
import { Redirect, Switch, useLocation, useHistory } from "react-router-dom";
import { getCssRgbFromHexByDiff } from "../../../utils/HexToFilter";

const useStyles = makeStyles((AppTheme) => ({
  btn: {
    background: "#FFFFFF",
    color: theme.main,
    borderColor: theme.main,
    fontSize: 12,
    opacity: 1,
    borderRadius: 2,
    fontWeight: 600,
    height: 28,
    "&.focus-visible": {
      background: "#FFFFFF",
      fontWeight: 600,
      border: "2px solid black",
    }
  },
  cancelbtn: {
    // flex: 1,
    background: "#FFFFFF",
    border: "1px solid #C4C4C4",
    opacity: 1,
    borderRadius: 2,
    fontSize: 12,
    fontWeight: 600,
    height: 28,
    "&.focus-visible": {
      background: "#FFFFFF",
      fontWeight: 600,
      border: "2px solid black",
    }
  },
  /* Author Name:- Siddhant Rastogi
        Bug 121582 - DM -   Ui getting distorted when clicking on generate buttton.
        Resolution:- We have adjusted the height of button to 28px.
        Date:-09 Jan 2023*/
  btnFilled: {
    background: "#0072C6",
    color: "#FFFFFF",
    fontSize: 12,
    fontWeight: 600,
    height: 28,
    // opacity: 1,
    // borderRadius: 2,
    "&:focus": {
    //   background: "#d5d5d5",
    //   color: "#FFFFFF",
    //  outline: "2px solid #0072C6",
    //   fontWeight: 600,
    background: `${getCssRgbFromHexByDiff(`${AppTheme?.palette?.primary?.main}`)}`,
    },
    "&:hover": {
      background: "#005EA3",
      color: "#FFFFFF",
      //border: "1px solid #005EA3",
      fontWeight: 600,
    },
  },

  btnDelete: {
    background: "#df5a5a",
    color: "#FFFFFF",
    fontSize: 12,
    opacity: 1,
    borderRadius: 2,
    fontWeight: 600,
    height: 28,
    "&:hover": {
      background: "#df5a5a",
      color: "#FFFFFF",
      fontWeight: 600,
      border: "1px solid black",
    },
    "&.focus-visible": {
      background: "#df5a5a",
      color: "#FFFFFF",
      fontWeight: 600,
      border: "2px solid black",
    }
  },
  btnOutlineGrey: {
    background: "#FFFFFF",
    color: "#606060",
    border: "1px solid #C4C4C4",
    fontSize: 12,
    opacity: 1,
    borderRadius: 2,
    height: 28,
    fontWeight: 600,
    "&.focus-visible": {
      background: "#df5a5a",
      color: "#FFFFFF",
      fontWeight: 600,
      border: "2px solid black",
    }
  },
  btnOutlinedCancel: {
    // flex: 1,
    background: "#FFFFFF",
    border: "1px solid #C4C4C4",
    opacity: 1,
    borderRadius: 2,
    height: 28,
    fontSize: 12,
    fontWeight: 600,
    "&:focus": {
      // background: "#E5F1F9",
      background: "#d5d5d5",
      // color: "#005EA3",
      color: "#FFFFFF",
      border: "2px solid #0072C6",
      fontWeight: 600,

    },
  },
  btnOutlined: {
    background: "#FFFFFF",
    color: "#0072C6",
    border: "1px solid #0072C6",
    opacity: 1,
    borderRadius: 2,
    fontSize: 12,
    height: 28,
    "&.focus-visible": {
      background: "#FFFFFF",
      color: "#0072C6",
      fontWeight: 600,
      border: "2px solid black",
    }
  },
  btnOutlinedMenu: {
    background: "#FFFFFF",
    color: "#0072C6",
    borderTop: "1px solid #0072C6",
    borderRight: "1px solid #0072C6",
    borderBottom: "1px solid #0072C6",
    opacity: 1,
    borderRadius: 2,
    fontSize: 12,
    height: 28,
    width:0,
    paddingRight:0,
    // "&:hover": {
    //   background: "#E5F1F9",
    //   color: "#005EA3",
    //   border: "1px solid #005EA3",
    //   fontWeight: 600,
    // },
    "&.focus-visible": {
      background: "#FFFFFF",
      color: "#0072C6",
      fontWeight: 600,
      //border: "2px solid black",
    }
  },
  btnBorderless: {
    background: "#B2D5EE",
    opacity: 1,
    color: "#FFFFFF !important",
    borderRadius: 1,
    fontSize: 12,
    height: 28,
  },
  btnGreenFilled: {
    background: "#0D6F08 0% 0% no-repeat padding-box",
    borderRadius: "2px",
    fontSize: 12,
    // fontWeight: 600,
    height: 28,

    // cursor: "pointer",
    color: "#FFFFFF",
    "&:hover": {
      backgroundColor: "#026hbd",
      color: "#000000",
    },
  },
  btnOutlinedDisabled: {
    background: "#FFFFFF",
    color: "#E5F1F9",
    border: "1px solid #E5F1F9",
    opacity: 1,
    borderRadius: 2,
    fontSize: 12,
    fontWeight: 600,
    height: 28,
  },
  btnDisabled: {
    background: "#C4C4C4",
    color: "#FFFFFF",
    fontSize: 12,
    opacity: 1,
    fontWeight: 600,
    height: 28,
    borderRadius: 2,
  },
  white: {
    color: "#FFFFFF",
  },
  blue: {
    color: "#0072C6",
  },
  default: {
    color: "purple",
  },
}));

const CustomButton = (props) => {
  const classes = useStyles();
  const location = useLocation()
  let btnClass;
  let circularClass;
  switch (props.btnType) {
    case "BUTTON":
      btnClass = classes.btn;
      circularClass = classes.white;
      break;
    case "BUTTON-FILLED":
      btnClass = classes.btnFilled;
      circularClass = classes.white;
      break;
    case "BUTTON-OUTLINED":
      btnClass = classes.btnOutlined;
      circularClass = classes.blue;
      break;
      case "BUTTON-OUTLINED-MENU":
        btnClass = classes.btnOutlinedMenu;
        circularClass = classes.blue;
        break;
    case "BUTTON-OUTLINED-GREY":
      btnClass = classes.btnOutlineGrey;
      circularClass = classes.blue;
      break;
    case "BUTTON-OUTLINED-DISABLED":
      btnClass = classes.btnOutlined;
      break;
    case "BUTTON-DISABLED":
      btnClass = classes.btnDisabled;
      break;
    case "BUTTON-OUTLINED-CANCEL":
      btnClass = classes.btnOutlinedCancel;
      circularClass = classes.blue;
      break;
    case "BUTTON-DELETE":
      btnClass = classes.btnDelete;
      circularClass = classes.white;
      break;
    case "BUTTON-BORDERLESS":
      btnClass = classes.btnBorderless;
      circularClass = classes.blue;
      break;
    case "BUTTON-GREEN-FILLED":
      btnClass = classes.btnGreenFilled;
      circularClass = classes.white;
      break;

    default:
      btnClass = classes.default;
  }

  return (
    <Fragment>
      {props.loading ? (
        <Button
          id={`rpa_${location.pathname}_${props.title}_${props.id ? props.id : "default"}`}
          disableTouchRipple={true}
          disableRipple={true}
          focusVisibleClassName="focus-visible"
          style={{ ...props.style, fontWeight: 600 }}
          className={props.className ? props.className : btnClass}
          disabled={props.disabled}

        >
          {props.loading && (
            <CircularProgress
              size={14}
              style={{ color: "#FFFFFF" }}
              className={classes.loader}
            ></CircularProgress>
          )}

          {props.title}
        </Button>
      ) : (
        <Button
          {...props}
          id={`rpa_${location.pathname}_${props.title}_${props.id ? props.id : "default"}`}
          disableTouchRipple={true}
          disableRipple={true}
          focusVisibleClassName="focus-visible"
          // onClick={!props.loading ? props.onClick : () => console.log("restricted")}
          style={{ ...props.style, fontWeight: 600 }}
          className={props.disabled ? classes.btnBorderless : props.className ? props.className : btnClass}
          disabled={props.disabled}

        >
          {props.title}
        </Button>
      )}
    </Fragment>

    // </div>
  );
};

export default CustomButton;
