import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import { NotificationProvider } from "../../../contexts/NotificationContext";

import ScriptInitiate from "./../script-initiate";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(
    <NotificationProvider>
      <ScriptInitiate />
    </NotificationProvider>,
    div
  );
});

it("matches snapshot", () => {
  const tree = renderer
    .create(
      <NotificationProvider>
        <ScriptInitiate />
      </NotificationProvider>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
