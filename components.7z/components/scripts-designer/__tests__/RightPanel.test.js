import React from "react";
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";
import { NotificationProvider } from "../../../contexts/NotificationContext";

import "@testing-library/jest-dom/extend-expect";
import RightPanel from "./../RightPanel";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(
    <NotificationProvider>
      <RightPanel />
    </NotificationProvider>,
    div
  );
});

/*it("matches snapshot", () => {
  const tree = renderer
    .create(
      <NotificationProvider>
        <RightPanel
          
        />
      </NotificationProvider>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});*/
