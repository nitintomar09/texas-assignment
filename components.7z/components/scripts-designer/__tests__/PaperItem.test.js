import React from "react";
import ReactDom from "react-dom";
import { render, cleanup, act } from "@testing-library/react";
import renderer from "react-test-renderer";

import CustomAppComp from "../../../utils/CustomAppComp";

import "@testing-library/jest-dom/extend-expect";
import PaperItem from "./../PaperItem";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  act(() => {
    ReactDom.render(
      <CustomAppComp>
        <PaperItem data={data} />
      </CustomAppComp>,

      div
    );
  });
});

it("renders correctly", () => {
  const { getByTestId } = render(
    <CustomAppComp>
      <PaperItem data={data} />
    </CustomAppComp>
  );
  expect(getByTestId("cardItem")).toHaveTextContent("Test");
});

it("matches snapshot", () => {
  const tree = renderer
    .create(
      <CustomAppComp>
        <PaperItem data={data} />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const data = {
  createdBy: 5,
  createdOn: "2021-04-04T08:34:13.407+00:00",
  description: null,
  isLocked: 1,
  lockedBy: 5,
  projectId: 1006,
  scriptId: 34,
  scriptName: "Test",
  tagName: ["test"],
  versionId: 1132,
  versionName: "V1.0",
};
