import React, { useContext } from "react";
import { makeStyles } from "@mui/styles";
import { Typography, Grid, Paper } from "@mui/material";
import { Share } from "@mui/icons-material";
//import GoogleDriveLogo from "../../assets/img/GDrive.png";
//import ExcelLogo from "../../assets/img/excelPng.png";
import MenuPopper from "../../utils/MenuPopper";
import axios from "axios";
import { NotificationContext } from "../../contexts/NotificationContext";
import { API_BASE_URL, SCRIPT } from "./../../config/index";
import { useDispatch } from "react-redux";
import { setOpenScript } from "./../../redux/script/actions";
import { setScriptDataInLs } from "../../utils/common";

const useStyles = makeStyles((theme) => ({
  text_bold: {
    fontWeight: 700,
  },

  text_lead: {
    color: "#BABABA",
  },
  text_lead_small: {
    color: "#767676",
    fontSize: "10px",
  },
  text_12: {
    fontSize: 12,
  },
  paperRoot: {
    paddingLeft: "19px",
    paddingRight: "18px",
    paddingTop: "15px",
    paddingBottom: "14px",
    marginLeft: 4,
    width: 218,
    height: 123,
    display: "flex",
    border: "1px solid #DFDFDF",
    cursor: "pointer",
    "&:hover": {
      zIndex: 1,
      border: `2px solid ${theme.palette.primary.main}`,
      borderRadius: "5px",
    },
  },

  paperImg: {
    height: 13,
    width: 14,
    opacity: 1,
    borderRadius: 50,
    marginRight: 8,
  },
  imgAvatar: {
    height: 20,
    width: 20,
    borderRadius: "50px",
  },
}));
const PaperItem = (props) => {
  const {
    data,
    selectedProject,
    setSelectedScript,
    handleOpenModal,
    updateScripts,
  } = props;

  const { setValue } = useContext(NotificationContext);
  const dispatch = useDispatch();

  const deleteScript = async (scriptId, versionId, versionName) => {
    try {
      let res = await axios.delete(
        `${API_BASE_URL}${SCRIPT}/${scriptId}/${versionId}/${versionName}`
      );
      if (res.status === 200) {
        const newScriptDetails = res.data?.data[0];

        if (newScriptDetails) {
          const newScript = { ...data, ...newScriptDetails };
          updateScripts(newScript);
          setValue({
            isOpen: true,
            message: res.data.message || "deleted successfully.",
            title: data.scriptName || "",
            notificationType: "SUCCESS",
          });
        }
      }
    } catch (error) {
      console.log(error);
      setValue({
        isOpen: true,
        message: error.response?.message || "could not be deleted.",
        title: data.scriptName || "",
        notificationType: "ERROR",
      });
    }
  };
  const handleScriptAction = (e, action, clickedOnScript) => {
    const { versionId, scriptId, versionName } = data;
    switch (action) {
      case "Sharing":
        setSelectedScript(data);
        handleOpenModal("Script Sharing");
        e.stopPropagation();

        break;
      case "Open Service Flow":
        setSelectedScript(null);
        dispatch(setOpenScript(data));

        let element = document.createElement("a");

        if (scriptId && versionName) {
          setScriptDataInLs({ scriptId, versionName });
         element.setAttribute("href", `http://${window.location.host}/serviceflow`);
          element.setAttribute("target", "_blank");
          element.click();
        } else {
          console.log("falsy versionName/scriptId", versionName, scriptId);
        }
        e.stopPropagation();

        break;
      case "History":
        setSelectedScript(data);
        handleOpenModal("Script History");
        e.stopPropagation();

        break;
      case "Open Previous Versions":
        setSelectedScript(data);
        handleOpenModal("Script Previous Versions");
        e.stopPropagation();

        break;

      case "Edit Details":
        setSelectedScript(data);
        handleOpenModal("Update Script");
        e.stopPropagation();

        break;

      case "Delete":
        if (versionId && scriptId && versionName) {
          deleteScript(scriptId, versionId, versionName);
        } else {
          console.log("version id/ script id/ version name not available.");
        }
        e.stopPropagation();
        break;
      default:
        e.stopPropagation();

        break;
    }
  };
  const classes = useStyles();
  const truncateString = (str) => {
    return str.trim().length > 16 ? str.substring(0, 14) + ".." : str;
  };

  const handleClickPaper = (e) => {
    handleScriptAction(e, "Open Service Flow");
  };
  return (
    <Grid item>
      <Paper
        className={classes.paperRoot}
        square
        elevation={3}
        onClick={(e) => handleClickPaper(e)}
        data-testid="cardItem"
        id="cardItem"
      >
        <Grid
          container
          direction="column"
          // spacing={1}
        >
          <Grid item>
            <Grid container direction="row" spacing={1}>
              <Grid item title={data.scriptName ? data.scriptName : ""}>
                <Typography component="h5" className={classes.text_bold}>
                  {data.scriptName ? truncateString(data.scriptName) : ""}
                </Typography>
              </Grid>
              <Grid item>
                <Typography className={classes.text_bold}>
                  {selectedProject && selectedProject.sharedWithMe ? (
                    <Share style={{ width: "12px", height: "12px" }} />
                  ) : null}
                </Typography>
              </Grid>
              <Grid item style={{ marginLeft: "auto", zIndex: 1 }}>
                <Typography className={classes.text_bold}>
                  <MenuPopper
                    selfClicked={data}
                    handleSelectedItem={handleScriptAction}
                    items={items}
                  />
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item>
            <Typography component="h5" className={classes.text_lead}>
              {data.versionName
                ? data.versionName
                : data.description
                ? truncateString(data.description)
                : "v1.0"}
            </Typography>
          </Grid>
          <Grid item>
            <Grid container spacing={1}>
              <Grid item>
                <Typography className={classes.text_lead_small}>
                  Last Commented By:
                </Typography>
              </Grid>
              <Grid item>
                <img
                  className={classes.imgAvatar}
                  src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxITEhUTEhMVFhUWFRUXFxUYFxUVGBUVFRUWFhUVFRYYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OGhAQGi0lHx8tLS0tKy0tLS0rLS8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIALcBEwMBIgACEQEDEQH/xAAbAAABBQEBAAAAAAAAAAAAAAAFAQIDBAYAB//EAD8QAAEDAgQDBQYDBQgDAQAAAAEAAhEDIQQFEjFBUWEGEyJxgTKRobHB8BRS0RUjQnLhBzNTYoKSwvFDorIk/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAIxEBAQACAgICAwADAAAAAAAAAAECERIhAzETQSJRYQQycf/aAAwDAQACEQMRAD8AqQlAUkLgFzug2EsJwCcAkDIS6U+EulGwZCcAn6UulBG6VSx+YCmdI8T+XLqV2cY002gN9t1m9ObvRUMBgYEuuTc85O89VOWWmnjw5VC9r3GXXnmnUmmUT7hSfhxO3wWXN0/GqUHlEcNWO3RQtpjh9/1VqlSH35qbT4iuBDXEAf19UXoYBrhff7CCZeQ0+XHZa7JqAfc8NuqWM3WefQfVyYEb25oHjsseyTEgcenUL00YFkbIZmGXwLei24XHuMOcy6rzaEmlGs/y8MOtoAkw4DYHmOhQkBXLuJs1SAJwCUBOhANhLCcEsIM0BdCeGpdKAaGpYToSwgGQlToXQgGpwCkFJ3AH3JTSI3BHmEEjhOAU1LDOd7LSY5JauHc32gQgIVykhckAKEsJwanQmZsLtKeAnAIBgalAToTgEEaAlDU8NTaztLXO5An3BBAVQd5Xc7g3wt9N/eZ+Ctn74KHBUoA+7ndX20wufPLdd/jx1DabbSl0HjfiPor1OkIvEpe6E79So2vYdptZL30WV2tSAkj7+4VDEUz9fROBNRxPUj0Wv7P5iRzI28jc/qsJUBiUuGzHu5ufftf+iqdXpnnjuae20MQCJGyqZhWkgA8Fj8p7ReEaXTyDiAbmBB2PkfeUSqZlqdxBFjNjP6Gfitb5NxyfFZTM2pBw08xH36rKFvBaivVk+XwIQbNcOWVSDxg+8frKWF70ec6UgEsJwCXStEGwnAJQE4NQDQE4BOAXJAkKShQLyA0SSuYEawmYMYLAICChkFQnxQAi2Hyei25uRzUYzlqkOJa7ijYX6dZnABWO7Y7cA+iGtDAJJTm4kT4SjZaX6OFYwnSAJ3VfNcGKlMiLi4806niBzTziQq6JiX04MHguWjr4aiXEk7rlO1MDCXSieMy8A+FUiwhKU7EYalDU8BOhMIw1ODU8NTg1GwYGqDMh+6f5fUK6GKDMqf7mp/KT7hKCnsLwzRARCkBb4/fNUKBsFbp1eUmOX68VzV6EX2xaSPP5eSjrs8UC87qFkbw7bhHPffdQPcJu5w6nVy5hIaT1mmDvy91lUe0mmDJ3IjpKnwxBBhxM8nen0lccKY3cYPNBqYZ4Zk7H7g/d0O/Blx9oDzMT0lX69IAHxGCQNz98vcqVOtTaTqp6+hBKuJyFMowDSG+cyKoEjgINp4+hstFVIploJubNJIi+9J8ExN4O2+2xx+FxuDMNq0dI/MHVAR18LvoUaZQIbpp1HVaThZlRpLmjcgPkeYIFvinYzrRZXVL3EbwDfnEi/UXBV/F5eKjg4/lA+aHdlqREk7k3POw0n1Gk+a0Abb75lGDHyBv7CZe6SlkDJu4q3iKxbwkJjMxaLlasg/E5cynuJCrswrahhgjqUSxWOpuGxQ+m+DLbINK/JH8IKo4jCOZ7QV8Zi/mlqY7WIeEEEgJ4CtNDSQIR/DupxphqYZcKR7ybgEBamlhKbXS1ourFTDsIjSEBjnVnGxJT21XbSrxy/wAekiOqtDKBMzbkgBdPUTAkqzUZVbuCjFBjKdgEQpuBCcG2PJKVa04ZvILkcS284FZ3NcXzuj9TIWzIJjkqePyrT7EkKFBQCcGqQ0yNwlDU9gwBPaxPU1AgGSgGsw5Kgx1H93UH+R//AMlFTWZuN1lDmLqGt9RxewEh4JuDJEsnntpS2rHDfr6VMMbDyCtsvA1R0AQB+YHu2lgO3mWnl5jZV8JmeJN6dFjuRfJn/wBws+G3T8kjZU2u3B85APyTsQDeYu3y2jz5LKPzDMAP7lgB3jU3fqHof+1MQDDiRNt9QE9Jk+9Hx0vl/jSgAtBjgZncRN59AiOFrUzSFhcXHVZvIsQ57apqEQwSbiAJgfJDq+cNAIa/YkiLHyE9UcKv5JrbT1m/u4JAu752PQQUEfiKbJGobyTzOxQWr31QNcXwHGBJPDiVZGRMiXYqkOYET5GSrmMnusr5LfUaDKs7NMh1N7WDYjSHAjjrEgx/VFKGNY4uhndGNeluvu3tFtdJos0iRIjbksJWwDWHwVNUciOvJX8qzHR7RsJ1Dchpa5rtM72cbHkNkXHropld9vX8kxDe5DyRsBtxlwAI8i1XjjG02kvcBpiZI+nHayyXZrG/i8PVGHcGuBju3ghwIDXB8fl8W88eYWAx2cVHVjTDj3VGo6BtOlxBe7qfrbdLGXabJXujnAtvafsjoeiC4yg0GxQTKcV/+nFUWk6WdwWiSQ0Opy6JNgSQfVFXFXGeU43SbA4TUZOytVmAWDQqNGsWmyl/FulCUn7NnjC5mVT/ABK3h6pPtBXG0WxyQA+hgGDe6e7CsbcGCrVTBNMGSFVxOW2s5AdRxRDoJCIDEDmg7MvM3NkQZTYNgiBK6o2ZSVK4hOp1AbQE57WncBMKL2A3lSYasQn4jAkizvJdQwpbclLQ2sfily7wLkyDhjRChr1rbSmMDYjdQVPDsVm00gqUS/hBVF1ODCLF9rEyqlTCO3KJRVVOa1PbRPJTDDO5KklZhSstm2XNc9weD4X6hBg7EfIrVAPHNAO0TfF1c0A/EAlTl6beHW7P2yRyuo5rX0yZcA545uN3O85J2XNwtaowCmTSaBBP8RcLG8WCO5Y6GubxYT/tMub84/0lWsnw37sHeRPIeIyeElTc2vGMhiOz9UiXVXkSbaz8plLlWWND3FxDWxeRIgXMRcGFvHYJpiR6AAe+N+G5QvN6TGMgbukW4N/id7jA6uCPkt6LhAjK6VN8u0ghpfpJAPtPcSb+n2UI7RUWhw0gCQdgNwJHyhHsFT7thAGniQNgSNvSAFmu0DyY5g2+avD/AGHkmsOw/A6HaWkm7hI2mTz5dFpsyypjwHEEw0ARwDZjbeJKAjLi5zXDZ2x/zclsMpxXes0mNYsQRYkWVeS2dxnhj9VkamX6DLZETHCekcfVWMPQe5+oQJBnYCIg2R3EYBxcZERvHNWRVFOm5jCNVRpYIEESILh/LvH1MKeavjbL+z2mWe2Q59Qa3OvLiQCJJ5bAcgvKc+omlXxDHAhzq1QwbeDvXOafIwPcvV+yOJb3hgAQ10AWi20Lzv8AtCxoq1DMaqVV7Opa4B0dQHA+Wo80YUrNVq+yeHJdWxB/8rcMB/ow9PV8T8FoYUHY/Bn8Fh9QuaQPoZLfhC0FPCgRLVTHO7yD8O5o3CuOpsIGyXE4QG4SCgEkm7bXVinWtcQmCtCr4iuTwsjZ6X2VtWykgoXg8TG6uVsYOBTlFidx6JllVOOTKmLB3S2NCAIXcUMwuOAkOVnC45oT2NLZrwFUdiSbKd+JpniFXa9uroiiE1rleD2dFyNDbNV6sHwqE1TxVgU5KirU7qFH06nIqwKvNUm0jyT+5dyRobWg4JTUHNV2UDxU7aDdkB3eyhHaDA6mB49ppHum3x+aMsowoszpHungblp9UU8LrKMRgwHEz4SJHpPskcQiGGFSkNIGtvATBAna9iBPNDW2qTO4B+iKUKsx9+SyrsJicVUN20nzt4ixg94c6fJCK9N86qhbqsdDb+WowJi8ADjNyiubY7u2GIk7IPWo1GUg8guc6SW2kDhYpwSOpPvJFjPkhGaYDW46eU+u6K08yimQW6Zg33Ecjw3WfzbPdL5ZEzwutcJd9J8lx49osBjHUToqN8BOxHDotIcLTjvKL3NfAIkhzT77+slZHE593zXNc0XBjoSIlGuylZxpljpMez5FVnLrbLx2W6Wq1WvpMvHWA0f8UKGLe0za+5kk22uUVxvhuSOFpuRBk/BAsxbDgeBEjyU4nn09E7G1DOvoPiB/0q2RxUzPFU/C+jU75tQOaBd0hzRzuPcPRS9iwe4dN7Ax5CEU7I4RxDqtTDOoP1u1SC3vHXh+k3BhxnhyUT3RlftqxAAiABYAcANgE2rjI2VZ9MnYkKJ2DdxNlo5tL1HGSDMJ1Ih6p/gABMpzXOZ7IS2elsYYG0qKvRgwoqbnpC503QE7QOSRlJp3HokZiBxULql5CZLZw1NNODaq3eFPFUoCQ5aDso3ZcQp6dYqwCTxQAxuGPJcWEK1W1BQuM7oGzdZXJdK5MlJjOqka5vEqtVmIlVi2Dus2gv3VpaoamJPJV2VzG6je88UBJ35Vqk8Kjp4rm1CeKAJynGIQ9peo31XSmQH2qoNZVY9oDQ4GY2kG5j1Cp06obboCinaSmX0tRE6DPobH6e5Z/GiGtfwAv9Pvqoynbp8d/FVzbOGMc3VczMcuUoBmHaF1UbkHfcxACCYzEOqPLiTLj/0FJRwwje5G1+vRbzxyTtjfLllelyjnTtBDgHA8xKr5g6k4BzWwYEiTvG49VEMJBE287J+IotgQ4T5393oq630i3KztVYQDwm1+EmLH0n3Ill+cupOBi3EdOKGd0Ofn0XNbxFx8lVkvtEtxvTVYvFsq+NsQY9OiWlSFRwp8iBP83P0KFYOkXvAHh1egnpw9Ea7NUpxL2Hg645aYt8FlZqOiZcmp7E1YxDqUbNj3On9fcvRWtHmvN/7O8OX4qvWghg283Ex8JK9ELwFMjPyXddWYBcFR65sTCR1QKuChK6ymPzSmPpKKm7oVJ3iAVtB28ptSm7iFKHJDUKZKulKKZUzhPBO7ooCNtJO7mVxlcAUAvcxxTgw80sFLJQCGkeJSigEt04FMI+6C5SQFyCAqhEbqFtM8EHdin809mZOCjS9izKMbqwxo5oJ+0ndEgzE8gjQ2L1mRsZUbKZ3VCnmJ5KUZhyCWjXmuchPaPtRRwbJqmXEeGmI1O6/5W9Sg/aztf+GbpZBrOHhHBg/M76DivJMfin1qhdUe573GXOcZJ++WwWuHj33WeWWmhzrtrisSS4nRTaQW0mSGyDbUd3+tuQC2OCxLatDoWg+hAPyK80FPwkdPqt5kbx3DC3/DDfhYHl/RHmk1NNP8e3dlY+qwCqWg2mJ+q1+AdTawWBj7JlY6oIqE9THW+6u0sSXjSNr32F/oE88dw/HnxtaPE42iB/dtInePgqLsdSJgMb6AIPVcdgDA+vE+9VWlwJ34z+qUwVl5aJ4usz+EN93RVRVAG33+qrioR6pjyFcjO5CuXmXtIMt3I423t7yifZfVUr16jRLiHBsfnqHQzy9qfQofklHxujZoJO3LhsbD7Cu5TnjsDD6bWv0uH4hpFw14inpd/Dxn+cBRZvchy6m69YyHLRhqLaY33ceboA9wgD0V6eaF5PntPE0xUpOkHccWnkQr3f8ARQne0wDVM0AKo2sOSkbVCAk7wqZrpGygFQcwpGVOoQChcXKN+JbOnU2TwkKN9ZvFw94QSeTzUjHGLqiMZT/xG/7guOZ0BvWZ/uCBpdcVzHc1QOcYbjWp/wC4J37bwwEmtTj+YIPS9qunFyFu7RYSY7+nfa4TH9psIP8AzM96Zaow0qNzUKHanCR/fN+Kgqds8ECB3l+gNvNA1Wha7ouQEdssH/ifArkxpkjV6pO/lU6GIJnw3BiJCQ44hwYaboPG0BZ8q24YrgqpQ9Ok8GqJpfckBoCXOn8cTNqIXn/aQYdulkGqRYHZo5u/RVs3zzuRYtLzs2xjq7p81hcTVc4lzjJJkk8SVr48be6y8lk6iPGYh73Oe8lziZJPEqtQbL+XH4KWqbFRYN3jErpc1EmD780a7K5iKbzReYY/2Sdg7l6oM0fp6jZLVpz63HmFnlJZpphlcbuLeZ4bTVc025cLbgef6JKZhttz8t0mGxHf6WPIFQW1H+IAWnqnOY5pcHCI2sl/K0+9w/DuGk8+fqoalTn6j9FX1/NMqG9uiJCuTn1LfqoWv2BFp4KVrSVfy3LgbvswESfM8Bx2IVbkTq2tD2QwzZJJg6ZG8wBa3lMoJk5OKrY47iqyqR5kl1P3FrVdx2YCjReQYcQ5jLmRrkW8rn0TP7PqMCo7npHpI/qs/UuS8/rEJ7KZy+i8Bri3VboZ4Hmt4/P6pbI123giy8xr0tGIe3YNquHucYWoFc6Q7iJa4HjxE/FPyYy3ZePLrVF/25WIF6nHiVBVzqpO7x0k3RLBYqjVa1wIaRYt4g8v6p1Sth2nS54kc4t0lY779Ntf0AxWcVp3cP8AU5QuzGvU2e/0c4fVHcRiMOxpc57CDsAJKgo47DDY79AFUv8AC137CGGuTIJLhx1EmPNOfQxO51HzJKvnPKLSQ0AX3VnL8w7ySHC17jh1RbZ9Fqetgf4CsbEEdSUrcqqn+GAeK0hzBpcAYPX9FFj62gSSNJPC26XOq4QBbklQybdOqnpdnnAS4gDdFMHiIFpje6kFZr3BusgQTbnyRcqOGIUzJHHxMf5TZWf2aRDS839riiWJwhDCWztueSbXyt5bIJsJ5cEuez4xQp4XSY1eVhCizDLHWqTLjaP+kVq0AyhqcQPDzG6EU86pvhskXF05be4V1OqczKjAmmZ6lcjrsNyqBclzHFhxXfBEmSZmSnnGVSRBPh2uTKezDAe24DoLlRVsxY2zR7tz5lbaZb/Yi3MsRfU+PhH6IfmWc1i0M70xyHHzPFCq+Jc7c+gUAVTCIudSvqEm5lNTU5aIRuFlUYYIKvQqlZkFETRVjp9Y9/AqQn9R0PEKjgKtoPD5K4Pvz/qosNWxlO4c3jf1RfKs3DwKda54OPyVItkEeo8+IVCtRIMjj80aliscri2DsppHbfgQd+VkGqZc7URyHLzTspzsgaKnofoVd1apIi/r5rP8o6LxynQM9zxIGx4Qkw1QtNyY+990YGGhs8/uw4oTi6eqoGgR81csrO42KmLrOrPaB0AF/UrbZcwYfD1HGwaP/lv6wgWTZfFYE8DZWu2mMLaTKQPtlzj/ACtIj4j4JZflZjE+t2sniK5qVXPO7nE+8rVYczhzO8NPo12n4SsjhxdarCn93HImerXCPgQPeqzLxqprFuySpT1XB3P3PJI5spGOIv70lbWcLgtTg0tc6RaDxV8dl6lv4SeBM/JD6dabbFGcuzypT3Oscjf+qjLl9Kx4/YdUyDE69Pdkj81o80Qy/s5VbUdTNSAWAmOpiFqctzulVtIa7kfoU04hoxJJIg0/+SyueXppMMfalT7L0xpJe4wPIKn2jxWHpNDAJcCDH6q92lzIMpHS8SbdfNYjEBxBfOraSjCW90ZXXUWMTnJcLQOg5JmX406pVarQgTFimtbyW2oy3dttWzgCkGgzIuhRzV2uZMRsfJDcDXOxRzJvw1QkOsTa+yzuMxay2hmPxLq1IUy6w29EKZljmkHxEGLwtZiuym5pvjzkj3q7l+FqNAD2Dw8dwQj5JJ0XDd7Zx2XVTs+3quW7DuTW+5cs/kq+EePVa5M3UWpcEhXa4yJQmgpwTI4JxTWpyASVBiQpio6+yAgpOgyEWY6QDwP3CDq/l9S2k/8ARRlCi4D+o8/6qLFOaASdjcefIKX79UPxvie1sx74k8VE9mv4Z+tsuAPQ3Mc0cyF2E1RWY4dWvcB6gyFm8C8yIEEARMkFwmd+drdFLjMXAECCfh5IuO+lTLT0bOcblWHpxrqVHEWpsLNV/wAxgBvr7lh62f4Zri6jgwHfmqVqj9/8o0tCA6SdykNHj0n4wjHxyDLyZVaw2b1hW7xroMk6f4PKOXBLn+MNWsXcAGtA5ACT/wCxcr2R5WO7fXf7LZ0t/MRz6fNA9JP3xVTW03eiUd1pcE/wg8Nis/TpcUYyl8jSlkeHs+q2HFMN3KeuFXb7SmLMrSL8vkpsPV1Cx9N0lZt/RD2u0P6cPL7+SetlvQpRxBBhXaWN1jSXEOiAeY5XQur4gHNTaZkwbEiErJVTKwZOXOqi9QabcLhT/gWtbo9oSFn6GZPY65IcPj5rT5EWYt1n6ag/h4GNy39FnlLP+LxsoZjmcrRwQw4u2ngthX7M1XVIqRoIPiZYt5SDug+YdjajNRp1GuA52KMc8f2Msb9QHo4iCrYds5tjxVWnhHjdquYek7krukzbVZTmxDBqnktCyo0hplYanhXi43HCVO3EV+PNc+WG/TeX9t41zY2XLHBtbn8SlU8P6bz1cVy5d7hM4py5cgFCeEi5AIU1y5cgIX0uIXUKkHoVy5MqvDFjkdr+Q4qviP71volXKdaFXyeHCfjzCG4gy4BcuSxOpAPquLben1SrkwINxRFB1McHCoerSII9HFpQtjTInzXLkQVIRw6qzhgWEOBkWnhE7LlyRwTxIueW6qtF1y5TGlPqtlD8ZTsT+X5cfolXJxNJga8W4FT4gcRuuXJ32U9I8aJa13HY+ihweJNJwe2Q4GxmFy5P6K+3qORdo+/pjU3xgCT+YHY9Cpcw0kS6w6Lly4spJl07MLvFVp4Kk6HX2i4t7k6hlQmQ0Eyd9ly5TbVahrqDQ8NDIdxNiIUeMy5w49YXLk9g2nl9SBt71y5cltT/2Q=="
                  alt="image"
                />
              </Grid>
            </Grid>
          </Grid>

          <Grid item style={{ marginTop: "auto" }}>
            {/*<Grid container>
              <Grid item>
                <img className={classes.paperImg} src={ExcelLogo} alt="Excel" />
                <img
                  className={classes.paperImg}
                  src={GoogleDriveLogo}
                  alt="Google Drive"
                />
              </Grid>
              <Grid item style={{ marginLeft: "auto" }}>
                {" "}
                <Typography className={classes.text_lead_small}>
                  1 day ago.
                </Typography>
            </Grid>
            </Grid>*/}
          </Grid>
        </Grid>
      </Paper>
    </Grid>
  );
};

export default PaperItem;

const items = [
  "Open Service Flow",
  "Open Previous Versions",
  "Edit Details",
  "History",
  "Sharing",
  "Export",
  "Move To",
  "Make Copy",
  "Delete",
];
