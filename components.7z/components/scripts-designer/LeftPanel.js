import React, { useEffect, useState } from "react";
import {
  Grid,
  Typography,
  List,
  ListItem,
  IconButton,
  MenuItem,
  Menu,
} from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import {
  FolderIcon,
  ShareIcon,
  ActionsMenu,
  RenameIcon,
  IconDelete,
  SharedFolderIcon
} from "./../../utils/AllImages";
import CircularProgress from "@mui/material/CircularProgress";
import { getUserId, truncateStringValues } from "../../utils/common";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";
import { useSelector } from "react-redux";
const useStyles = makeStyles((theme) => ({
  selectedTab: {
    background: `${theme.palette.primary.light} 0% 0% no-repeat padding-box`,
    opacity: 1,
  },
  title: {
    fontWeight: 600,
    color: "#606060",
  },

  text_12: {
    fontSize: 12,
  },
  paddingItems: {
    paddingLeft: 13,
    paddingRight: 13,
  },
  text_bold: {
    fontWeight: 700,
  },
  create_folder: {
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
  },
  cursor: {
    cursor: "pointer",
  },
  margin_top_3: {
    marginTop: 3,
  },
  icons: {
    width: "16px",
    height: "16px",
  },
  scrollDiv: {
    // BugId:Bug 142800 - My Projects list not scrollable till last end (edit)
    // Author:Dixita
    // Date:23-01-2024
    // RCA:This is the Ui specific issue. Height is in px. Now gives the height in the vh
    // Now the project list is scrollable, and the projects are visible after scrolling the list.
    // paddingRight: "8px",
    // height: (props) =>
    //   props.windowInnerHeight ? props.windowInnerHeight - 250 : "65vh",
    paddingBottom: "10px",
    // height: "510px",
    width: "100%",
    overflow: "hidden",

    overflowY: "auto",
    height:"70vh"
  },
  selectedTabText: {
    fontWeight: 600,
  },
}));
const LeftPanel = (props) => {
  const [actionMenu, setActionMenu] = useState(null);
  const {
    listOfProjects,
    selectedProjects,
    selectedProject,

    isFetchingProjects,
    recentProjects,
    setEditedProject,
    handleSelectedProject,
    handleOpenModal,
    handleToBeDeleted,
  } = props;

  const userId = getUserId();
  const windowInnerHeight = useSelector(
    (state) => state.appGlobalState.windowInnerHeight
  );

  const handleSelectedActionForProject = async (action, clickedOnProject) => {
    switch (action) {
      case "Remove":
        handleToBeDeleted(clickedOnProject);
        handleOpenModal("Delete Project");

        break;
      case "Modify":
        setEditedProject(clickedOnProject);
        handleOpenModal("Add Project");
        break;
      default:
        break;
    }
  };
  useEffect(() => {
    if (listOfProjects.length > 0 && !selectedProject) {
      handleSelectedProject(listOfProjects[0]);
    } else if (selectedProject) {
      const index = listOfProjects.findIndex(
        (project) => project.projectId === selectedProject.projectId
      );
      if (index === -1) {
       
        if (selectedProjects === "Shared With Me") {
          handleSelectedProject(listOfProjects[0]);
        }
      } else {
        // setActiveTab(index);
      }
    }
  }, [listOfProjects, selectedProject]);
  const classes = useStyles({ windowInnerHeight });

  const handleActiveTab = (item) => {
    handleSelectedProject(item);
  };
  const handleActionsMenuClick = (event) => {
    setActionMenu(event.currentTarget);
  };
  const handleActionsMenuClose = () => {
    setActionMenu(null);
  };
  return (
    <>
      <div className={classes.scrollDiv}>
        <List>
          {selectedProjects && listOfProjects.length > 0 && (
            <>
              <ListItem disableGutters className={classes.paddingItems}>
                <Grid
                  container
                  justifyContent="flex-start"
                  direction="column"
                  spacing={1}
                >
                  <Grid item>
                    <Typography variant="subtitle2" className={classes.title}>
                      Recents
                    </Typography>
                  </Grid>
                </Grid>
              </ListItem>
            </>
          )}

          {!isFetchingProjects &&
            recentProjects.length > 0 &&
            recentProjects.map((item, index) => {
              return (
                <React.Fragment key={item.projectId || index}>
                  <div className={classes.tab}>
                    <ListItem
                      button
                      key={index}
                      onClick={() => handleActiveTab(item)}
                      disableGutters
                      className={classes.paddingItems}
                      id={`RPA_ScriptDesigner_Recents_${
                        userId && item.createdBy !== +userId ? "Shared_" : ""
                      }${item.projectName}`}
                    >
                      <Grid
                        container
                        direction="row"
                        justifyContent="flex-start"
                        alignItems="center"
                        spacing={1}
                      >
                        <Grid item>
                          <UniqueIDGenerator>
                            <FolderIcon className={classes.icons} />
                          </UniqueIDGenerator>
                        </Grid>

                        <Grid item>
                          <Typography title={item.projectName || ""}>
                            {truncateStringValues({
                              str: item.projectName
                                ? item.projectName
                                : "Unknown",
                              min: 20,
                              max: 30,
                            })}
                          </Typography>
                        </Grid>

                        {/* here */}

                        <Grid item style={{ marginLeft: "auto", zIndex: 1 }}>
                          <Grid container direction="row" spacing={1}>
                            {userId && item.createdBy !== +userId && (
                              <Grid item>
                                {/* <UniqueIDGenerator>
                                  <ShareIcon className={classes.icons} />
                                </UniqueIDGenerator> */}
                              </Grid>
                            )}
                          </Grid>
                        </Grid>
                      </Grid>
                    </ListItem>
                  </div>
                </React.Fragment>
              );
            })}
        </List>
        <List disablePadding>
          {selectedProjects && listOfProjects.length > 0 && (
            <>
              <ListItem disableGutters className={classes.paddingItems}>
                <Grid
                  container
                  justifyContent="flex-start"
                  direction="column"
                  spacing={1}
                >
                  <Grid item>
                    <Typography variant="subtitle2" className={classes.title}>
                      All
                    </Typography>
                  </Grid>
                </Grid>
              </ListItem>
            </>
          )}
          {isFetchingProjects && (
            <div
              style={{
                width: "100%",
                height: "100%",
                textAlign: "center",
                zIndex: 1,
                verticalAlign: "center",
                marginTop: "10px",
             
              }}
            >
              <CircularProgress
                style={{
                  alignItems: "center",
                  width: "20px",
                  height: "20px",
                  textAlign: "center",
                }}
              />
            </div>
          )}
          {!isFetchingProjects &&
            listOfProjects.length > 0 &&
            listOfProjects.map((item, index) => {
              return (
                <React.Fragment key={item.projectId || index}>
                  <div
                    className={
                      selectedProject &&
                      selectedProject.projectId === item.projectId
                        ? classes.selectedTab
                        : classes.tab
                    }
                  >
                    <ListItem
                      button
                      key={index}
                      onClick={() => handleActiveTab(item)}
                      disableGutters
                      style={{paddingLeft:"13px"}}
                    //  className={classes.paddingItems}
                      id={`RPA_ScriptDesigner_ProjectList_${
                        userId && item.createdBy !== +userId ? "Shared_" : ""
                      }${item.projectName}`}
                    >
                      <Grid
                        container
                        direction="row"
                        justifyContent="flex-start"
                        alignItems="center"
                        spacing={1}
                      >
                        {/* 
     * @author sanya.mahajan For Bug 155812 - UX Shared folder icon change
     * Reason:New icon to be updated as per the design
     * Date : 03/02/2025             
     * */
                         }
                        {userId && item.createdBy !== +userId ?(
                          <Grid item>
                          <UniqueIDGenerator>
                            <SharedFolderIcon className={classes.icon}/>
                          </UniqueIDGenerator>
                          </Grid>
                        ):(<Grid item>
                        <UniqueIDGenerator>
                          <FolderIcon className={classes.icons} />
                        </UniqueIDGenerator>
                        </Grid>)}
                          
                        

                        <Grid item>
                          <Typography
                            className={
                              selectedProject &&
                              selectedProject.projectId === item.projectId
                                ? classes.selectedTabText
                                : classes.tabText
                            }
                            title={item.projectName || ""}
                          >
                            {truncateStringValues({
                              str: item.projectName
                                ? item.projectName
                                : "Unknown",
                                min: 20,
                                max: 30,
                            })}
                          </Typography>
                        </Grid>
                        <Grid item style={{ marginLeft: "auto", zIndex: 1 }}>
                          <Grid container direction="row" spacing={1}>
                            {userId && item.createdBy !== +userId ? (
                              <Grid item style={{paddingRight:"13px"}}>
                                {/* <ShareIcon className={classes.icons} /> */}
                              </Grid>
                            ) : selectedProject &&
                              selectedProject.projectId === item.projectId ? (
                              <Grid item>
                                <IconButton
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleActionsMenuClick(e);
                                  }}
                                >
                                  <ActionsMenu />
                                </IconButton>

                                <Menu
                                  anchorEl={actionMenu}
                                  open={Boolean(actionMenu)}
                                  onClose={handleActionsMenuClose}
                                  PaperProps={{
                                    elevation: 3,
                                    style: {
                                      borderRadius: "4px",
                                      boxShadow: "0px 6px 12px 0px #00000029",
                                    },
                                  }}
                                  transformOrigin={{
                                    horizontal: "right",
                                    vertical: "top",
                                  }}
                                  anchorOrigin={{
                                    horizontal: "right",
                                    vertical: "bottom",
                                  }}
                                >
                                  <MenuItem
                                    onClick={() => {
                                      handleActionsMenuClose();
                                      handleOpenModal("Project Sharing");
                                    }}
                                  >
                                    <ShareIcon
                                      className={classes.icons}
                                      style={{ marginRight: "5px" }}
                                    />
                                    Share
                                  </MenuItem>
                                  <MenuItem
                                    onClick={() => {
                                      handleActionsMenuClose();
                                      handleSelectedActionForProject(
                                        "Modify",
                                        selectedProject
                                      );
                                    }}
                                  >
                                    <RenameIcon
                                      className={classes.icons}
                                      style={{ marginRight: "5px" }}
                                    />
                                    Rename
                                  </MenuItem>
                                  <MenuItem
                                    onClick={() => {
                                      handleActionsMenuClose();
                                      handleSelectedActionForProject(
                                        "Remove",
                                        selectedProject
                                      );
                                    }}
                                  >
                                    <IconDelete
                                      className={classes.icons}
                                      style={{ marginRight: "5px" }}
                                    />
                                    Delete
                                  </MenuItem>
                                </Menu>
                              </Grid>
                            ) : null}
                          </Grid>
                        </Grid>
                      </Grid>
                    </ListItem>
                  </div>
                </React.Fragment>
              );
            })}
        </List>
        {!isFetchingProjects && listOfProjects.length === 0 && (
          <Grid
            container
            alignItems="center"
            justifyContent="center"


            style={{ height: "90%"}}
          >
            <Grid item>
              <Typography
                variant="subtitle1"
                style={{ paddingLeft: "15px", fontWeight: 600 }}
              >
                No folder present.
              </Typography>
            </Grid>
          </Grid>
        )}
      </div>
    </>
  );
};

export default LeftPanel;
