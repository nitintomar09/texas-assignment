import React, { useState, useEffect, useContext, Fragment } from "react";
import { Typography, Grid, Paper, Box, Divider, IconButton } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import { AddIcon } from "../../utils/AllImages";

import LeftPanel from "./LeftPanel";
import RightPanel from "./RightPanel";
import NewScriptModal from "../modals/NewScriptModal";
import RenameScriptModal from "../modals/RenameScriptModal";
import ScriptHistoryModal from "./../modals/ScriptHistoryModal";
import StopSharingModal from "./../modals/StopSharingModal";
import PreviousVersionsModal from "./../modals/PreviousVersionsModal";
import AddProjectModal from "./../modals/AddProjectModal";
import SharingSettingModal from "./../modals/ShareSettingsModal";
import ExportImportModal from "./../modals/Export-Import-Modal";
import ConfirmDeleteModal from "./../modals/ConfirmDeleteModal";
import {
  PROJECTS,
  SCRIPT,
  PROJECT,
  HOME,
  CREATE_INDEX,
  MODIFY_INDEX,
  VIEW_INDEX,
  REMOVE_INDEX,
  SHARE_INDEX,
  IMPORT_SCRIPT_INDEX,
  EXPORT_SCRIPT_INDEX,
  API_BASE_URL,
  //COMMIT_SCRIPT_INDEX,
  //PUBLISH_SCRIPT_INDEX,
  //CREATE_PROJECT_INDEX,
  // MODIFY_PROJECT_INDEX,
  //VIEW_PROJECT_INDEX,
} from "../../config/index";
import { NotificationContext } from "../../contexts/NotificationContext";
import SearchBox from "./../../utils/Search-Component/index";
import CustomTabs from "../../utils/CustomTabs";
import { useDispatch } from "react-redux";
import { getUsersList } from "../../redux/actions";

import {
  createInstance,
  doesUserHavePermission,
  getCancelTokenAxios,
  getToken,
  getUserId,
  getUserRights,
  handleNetworkRequestError,
} from "./../../utils/common";
import { useHistory } from "react-router-dom";
import { PINNED_SCRIPT } from "./../../config/index";
import MoveToProjectModal from "../modals/MoveToProject";
import axios from "axios";
const useStyles = makeStyles((theme) => ({
  root: {
    padding: "0px 20px 20px 0px",
    overflowY: "hidden"
    // height: "650px",
    // height: "60%",
  },
  item: {
    marginLeft: 10,
    marginTop: 5,
  },

  paper1: {
    // paddingLeft: 13,
    paddingTop: 20,
    //paddingRight: 13,
    fontSize: 12,

    width: "240px",
    marginBottom: 1,
    marginRight: 1,
    boxShadow: "0px 2px 6px #00000014",
  },
  paddingItems: {
    paddingLeft: 13,
    paddingRight: 13,
  },

  active: {
    fontWeight: 600,
    opacity: 1,
    textAlign: "center",
    borderBottom: `2px solid ${theme.palette.primary.main}`,
  },
  activeFullScreen: {
    fontWeight: 800,
    opacity: 1,
    textAlign: "center",
    borderBottom: `2px solid ${theme.palette.primary.main}`,
  },
  d_none: {
    height: 0,
  },
  margin_left_10: {
    marginLeft: 10,
  },
  icons: {
    width: "14px",
    height: "14px",
  },
  addProjectBtn: {
    // width: "16px",
    // height: "16px",
    // color: `${theme.palette.primary.main}`,
    cursor: "pointer",
  },
  addIcon: {
    color: `${theme.palette.primary.main}`,
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  title: {
    fontWeight: 600,
    fontSize: "16px",
  },
  divider: {
    marginTop: "-1px",
    height: 0,
    border: "1px solid #C4C4C4",
  },
  selectedTab: {
    paddingBottom: "8px",
    borderBottom: "2px solid #0072C6",
  },
  flex: {
    display: "flex",
  },
  flexGrow: {
    display: "flex",
    flexGrow: 1,
  },
  flexColumn: {
    display: "flex",
    flexDirection: "column",
  },
}));
const ScriptInitiate = () => {
  const classes = useStyles();
  const history = useHistory();
  const userId = getUserId();

  const { setValue } = useContext(NotificationContext);
  const dispatch = useDispatch();

  const [selectedProjects, setSelectedProjects] = useState("My Folders");
  const [selectedProject, setSelectedProject] = useState(null);
  const [openModalName, setOpenModalName] = useState(null);
  const [selectedScript, setSelectedScript] = useState(null);
  let cancelToken;

  const [allProjects, setAllProjects] = useState([]);

  const [allSharedProjects, setAllSharedProjects] = useState([]);
  const [recentProjects, setRecentProjects] = useState([]);
  const [allFetchedProjects, setAllFetchedProjects] = useState([]);
  const [allScripts, setAllScripts] = useState([]);
  const [allFetchedScripts, setAllFetchedScripts] = useState([]);
  const [editedProject, setEditedProject] = useState(null);
  const [isFetchingScripts, setIsFetchingScripts] = useState(false);
  const [isFetchingUsers, setIsFetchingUsers] = useState(false);
  const [isFetchingProjects, setIsFetchingProjects] = useState(false);
  const [selectedTags, setSelectedTags] = useState([]);
  const [toBeDeleted, setToBeDeleted] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    dispatch(
      getUsersList({
        OnCall: () => {
          setIsFetchingUsers(true);
        },
        OnSuccess: () => {
          setIsFetchingUsers(false);
        },
        OnError: () => {
          setIsFetchingUsers(false);
        },
        history,
      })
    );
  }, []);
  const getScripts = async (source) => {
    //const axiosInstance = createInstance();
    // setIsFetchingScripts(true);

    const config = {
      headers: {
        Authorization: "Bearer " + getToken(),
      },
      cancelToken: source?.token,
    };

    if (selectedProject) {
      const projectId = selectedProject.projectId;
      const isShared = selectedProject?.createdBy !== +userId || false;

      try {
        /*let res = await axiosInstance.get(
          `${SCRIPT}` + "/" + projectId + "/" + isShared,
          { cancelToken: source.token }
        );*/
        let res = await axios.get(
          `${API_BASE_URL}${SCRIPT}` + "/" + projectId + "/" + isShared,
          config
        );

        if (res.status === 200) {
          const scripts = res.data.data || [];
          if (scripts) {
            setAllScripts(scripts);
            setAllFetchedScripts(scripts);
            setIsFetchingScripts(false);
          }
        }
      } catch (error) {
        if (error.message !== "previous getAllScripts request cancelled") {
          setAllScripts([]);
          setIsFetchingScripts(false);

          handleNetworkRequestError({
            error,
            history,
          });
        }
      }
    } else {
      setIsFetchingScripts(false);
    }
  };

  const getProjects = async () => {
    setIsFetchingProjects(true);

    const axiosInstance = createInstance();
    try {
      let res = await axiosInstance.get(`${PROJECTS}`);

      if (res.status === 200) {
        const ownerProject = res.data.data
          ? res.data.data[0]["ownerProject"]
            ? res.data.data[0]["ownerProject"]
            : []
          : [];
        const sharedProject = res.data.data
          ? res.data.data[0]["sharedProject"]
            ? res.data.data[0]["sharedProject"]
            : []
          : [];

        setAllProjects([...ownerProject, ...sharedProject]);

        setAllFetchedProjects([...ownerProject, ...sharedProject]);
        setAllSharedProjects([...sharedProject]);
        setIsFetchingProjects(false);
      }
    } catch (error) {
      setIsFetchingProjects(false);
      handleNetworkRequestError({
        error,
        history,
      });
    }
  };

  useEffect(() => {
    getProjects();
  }, []);

  /*useEffect(() => {
    if (selectedProject) {
      setAllScripts([]);

      getScripts();
      const newRecentProjects = [...recentProjects];

      const index = newRecentProjects.findIndex(
        (proj) => proj.projectId === selectedProject.projectId
      );
      if (index !== -1) {
        newRecentProjects.splice(index, 1);
      }
      newRecentProjects.unshift(selectedProject);
      setRecentProjects(
        newRecentProjects.length > 5
          ? newRecentProjects.splice(0, 5)
          : [...newRecentProjects]
      );

      if (selectedProject.createdBy === +userId) {
        setSelectedProjects("My Folders");
      }
    } else {
      setAllScripts([]);
    }
    setSelectedTags([]);
  }, [selectedProject]);*/

  useEffect(() => {
    const cancelToken = axios.CancelToken;
    const source = cancelToken.source();
    if (selectedProject) {
      setAllScripts([]);
      setIsFetchingScripts(true);

      getScripts(source);
      const newRecentProjects = [...recentProjects];

      const index = newRecentProjects.findIndex(
        (proj) => proj.projectId === selectedProject.projectId
      );
      if (index !== -1) {
        newRecentProjects.splice(index, 1);
      }
      newRecentProjects.unshift(selectedProject);
      setRecentProjects(
        newRecentProjects.length > 5
          ? newRecentProjects.splice(0, 5)
          : [...newRecentProjects]
      );

      if (selectedProject.createdBy === +userId) {
        setSelectedProjects("My Folders");
      }
    } else {
      setAllScripts([]);
    }
    setSelectedTags([]);
    return () => {
      source.cancel("previous getAllScripts request cancelled");
    };
  }, [selectedProject]);

  const handleSelectedProject = (project) => {
    if (project) {
      setSelectedProject(project);
    }
  };

  const handleOpenModal = (name) => {
    setOpenModalName(name);
  };
  const handleCloseModal = () => {
    setOpenModalName(null);
    setSelectedScript(null);
  };
  const updateScripts = (script) => {
    if (script) {
      const newAllScripts = [...allScripts];
      const newFetchedScripts = [...allFetchedScripts];
      if (newFetchedScripts) {
        const scriptIndex1 = newFetchedScripts.findIndex(
          (obj) => obj.scriptId === script.scriptId
        );
        const scriptObj = newFetchedScripts.find(
          (obj) => obj.scriptId === script.scriptId
        );

        if (scriptIndex1 !== -1) {
          if (!script.lastVersion) {
            newFetchedScripts.splice(scriptIndex1, 1, {
              ...scriptObj,
              ...script,
            });
          } else {
            newFetchedScripts.splice(scriptIndex1, 1);
          }
        } else {
          newFetchedScripts.push(script);
        }

        setAllFetchedScripts(newFetchedScripts);
        setSelectedTags([]);
      }
      if (newAllScripts) {
        const scriptIndex = newAllScripts.findIndex(
          (obj) => obj.scriptId === script.scriptId
        );
        const scriptObj = newFetchedScripts.find(
          (obj) => obj.scriptId === script.scriptId
        );
        if (scriptIndex !== -1) {
          if (!script.lastVersion) {
            newAllScripts.splice(scriptIndex, 1, { ...scriptObj, ...script });
          } else {
            newAllScripts.splice(scriptIndex, 1);
          }
        } else {
          newAllScripts.push(script);
        }

        setAllScripts(newAllScripts);

        setSelectedTags([]);
      } else {
        newAllScripts.push(script);

        setAllScripts(newAllScripts);
        setSelectedTags([]);
      }
    }
  };

  const deleteProject = (projectId) => {
    const newProjects = [...allProjects];
    const newRecProjects = [...recentProjects];
    //after deleting project we are removing it from the all Projects object

    //looking if project available with the same project id in all projects.
    const projectIndex = allProjects.findIndex(
      (project) => project.projectId === projectId
    );
    // looking for project in recents
    const projectInd = recentProjects.findIndex(
      (p) => p.projectId === projectId
    );

    if (projectIndex !== -1) {
      newProjects.splice(projectIndex, 1);
    } else {
      console.log("Invalid project id");
    }
    if (projectInd !== -1) {
      newRecProjects.splice(projectInd, 1);
    }

    setAllProjects(newProjects);
    setAllFetchedProjects(
      allFetchedProjects.filter((project) => project.projectId !== projectId)
    );

    setRecentProjects(newRecProjects);
    if (newProjects.length === 0) {
      setSelectedProject(null);
    } else {
      setSelectedProject(
        newProjects[projectIndex]
          ? newProjects[projectIndex]
          : newProjects.length > 0
            ? newProjects[newProjects.length - 1]
            : null
      );
    }
  };

  const updateProjects = (project) => {
    const newProjects = [...allProjects];
    const newFetchedProjects = [...allFetchedProjects];

    //after creating/updating project we are appending it to the all Projects object
    const projectId = project.projectId;

    //looking if project available with the same project id in all projects.
    const projectIndex = allProjects.findIndex(
      (projectItem) => projectItem.projectId === projectId
    );
    const projectObj = allProjects.find(
      (projectItem) => projectItem.projectId === projectId
    );

    //updating allFetched projects
    const projectIndexFetched = allFetchedProjects.findIndex(
      (projectItem) => projectItem.projectId === projectId
    );
    const projectObjFetched = allFetchedProjects.find(
      (projectItem) => projectItem.projectId === projectId
    );

    if (projectIndex !== -1) {
      newProjects.splice(projectIndex, 1, { ...projectObj, ...project });
    } else {
      newProjects.push(project);
    }
    if (projectIndexFetched !== -1) {
      newFetchedProjects.splice(projectIndexFetched, 1, {
        ...projectObjFetched,
        ...project,
      });
    } else {
      newFetchedProjects.push(project);
    }
    setAllProjects(newProjects);
    setAllFetchedProjects(newFetchedProjects);
    setSelectedProject({ ...projectObj, ...project });
  };

  const deleteScript = async () => {
    const { versionId, scriptId, versionName } = toBeDeleted;
    const axiosInstance = createInstance();
    setIsDeleting(true);

    try {
      let res = await axiosInstance.delete(
        `${SCRIPT}/${scriptId}/${versionId}/${versionName}`
      );
      if (res.status === 200) {
        const newScriptDetails = res.data?.data ? res.data.data[0] : null;

        if (newScriptDetails) {
          const newScript = { ...toBeDeleted, ...newScriptDetails };
          updateScripts(newScript);
        } else {
          updateScripts({ scriptId: scriptId, lastVersion: true });
        }
        setValue({
          isOpen: true,
          message: res.data.message || "deleted successfully.",
          title: toBeDeleted.scriptName || "",
          notificationType: "SUCCESS",
        });
        handleCancelDelete();
        setIsDeleting(false);
      } else {
        setValue({
          isOpen: true,
          message: res.data.message || "Failed.",
          title: toBeDeleted.scriptName || "",
          notificationType: "ERROR",
        });
        handleCancelDelete();
        setIsDeleting(false);
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setValue({
            isOpen: true,
            message: errMsg || "could not be deleted.",
            title: "Script",
            notificationType: "ERROR",
          });
        },
      });
      setIsDeleting(false);
    }
  };

  const onScriptDelete = () => {
    deleteScript();
  };
  const handleCancelDelete = () => {
    handleCloseModal();

    setToBeDeleted(null);
  };
  const onProjectDelete = async () => {
    const projectId = toBeDeleted?.projectId;
    const axiosInstance = createInstance();
    setIsDeleting(true);

    if (projectId) {
      try {
        let response = await axiosInstance.delete(`${PROJECT}/${projectId}`);

        if (response.status === 200) {
          deleteProject(projectId);
          setIsDeleting(false);
          handleCloseModal();

          //creating notification
          setValue({
            isOpen: true,
            message: "deleted successfully.",
            notificationType: "SUCCESS",
            title: toBeDeleted.projectName,
          });
        } else {
          setValue({
            isOpen: true,
            message: response.data.message,
            notificationType: "ERROR",
            title: toBeDeleted.projectName,
          });
          handleCancelDelete();
          setIsDeleting(false);
        }
      } catch (error) {
        setIsDeleting(false);

        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "",
              title: toBeDeleted.projectName,
              notificationType: "ERROR",
            });
          },
        });
      }
    } else {

      setValue({
        isOpen: true,
        message: "Invalid folder id",
        notificationType: "ERROR",
        title: "",
      });
      handleCancelDelete();
      setIsDeleting(false);
    }
  };

  const handleToBeDeleted = (item) => {
    setToBeDeleted(item);
  };

  const showModal = () => {
    let modalToOpen = null;

    {
      /*****************************************************************************************
       * @author asloob_ali BUG ID :  102417  Description:  Project Sharing: Shared User is able to edit the script even if there is no right assigned to him
       * Reason:restriction according to member rights permissions was not implemented.
       *  Resolution :added the restriction on shared resources according to member rights permissions..
       *  Date : 06/12/2021             ***************************************************************************************/
    }
    {
      /*****************************************************************************************
       * @author asloob_ali BUG ID :  102418  Description:  Project sharing: User to which project\script is shared is able to share the scripts with other users
       * Reason:restriction according to member rights permissions was not implemented.
       *  Resolution :added the restriction on shared resources according to member rights permissions..
       *  Date : 06/12/2021             ***************************************************************************************/
    }
    switch (openModalName) {
      case "New Script":
        if (
          doesUserHavePermission({
            isShared: selectedProject?.createdBy !== +userId,
            permissionNum: CREATE_INDEX,
          })
        ) {
          modalToOpen = (
            <NewScriptModal
              id="RPA_ScriptDesigner_NewScript"
              options={allProjects}
              handleClose={handleCloseModal}
              updateScripts={updateScripts}
              isOpen={true}
              selectedProject={selectedProject}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to create a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Update Script":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: MODIFY_INDEX,
          })
        ) {
          modalToOpen = (
            <RenameScriptModal
              id="RPA_ScriptDesigner_UpdateScript"
              options={allProjects}
              handleClose={handleCloseModal}
              editedScript={selectedScript}
              updateScripts={updateScripts}
              updateProjects={updateProjects}
              isOpen={true}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to update a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;

      case "Project Sharing":
        if (
          doesUserHavePermission({
            isShared: selectedProject?.createdBy !== +userId,
            permissionNum: SHARE_INDEX,
          })
        ) {
          modalToOpen = (
            <SharingSettingModal
              id="RPA_ScriptDesigner_ProjectShareSettingModal"
              handleClose={handleCloseModal}
              isOpen={true}
              selectedProject={selectedProject}
              isFetchingUsers={isFetchingUsers}
              updateProjects={updateProjects}
              updateScripts={updateScripts}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to share this folder.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Script Sharing":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: SHARE_INDEX,
          })
        ) {
          modalToOpen = (
            <SharingSettingModal
              id="RPA_ScriptDesigner_ScriptShareSettingModal"
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
              updateScripts={updateScripts}
              isFetchingUsers={isFetchingUsers}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to share a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;

      case "Import Script":
        if (
          doesUserHavePermission({
            isShared: selectedProject?.createdBy !== +userId,
            permissionNum: IMPORT_SCRIPT_INDEX,
          })
        ) {
          modalToOpen = (
            <ExportImportModal
              id="RPA_ScriptDesigner_ImportScriptModal"
              handleClose={handleCloseModal}
              isOpen={true}
              actionType="Import"
              selectedProject={selectedProject}
              updateScripts={updateScripts}
              allScripts={allScripts}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to import a Service Flow.",
            notificationType: "ERROR",

            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Script History":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,

            permissionNum: VIEW_INDEX,
          })
        ) {
          modalToOpen = (
            <ScriptHistoryModal
              id="RPA_ScriptDesigner_HistoryScriptModal"
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to view history of a script.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Stop Sharing":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: SHARE_INDEX,
          })
        ) {
          modalToOpen = (
            <StopSharingModal
              id="RPA_ScriptDesigner_StopSharingModal"
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to change sharing settings.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Script Previous Versions":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          modalToOpen = (
            <PreviousVersionsModal
              id="RPA_ScriptDesigner_PrevVersionModal"
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message:
              "You don't have permission to view previous versions of a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Export":
        if (
          doesUserHavePermission({
            isShared: selectedScript?.createdBy !== +userId,
            permissionNum: EXPORT_SCRIPT_INDEX,
          })
        ) {
          modalToOpen = (
            <ExportImportModal
              id="RPA_ScriptDesigner_ExportScriptModal"
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={selectedScript}
              selectedProject={selectedProject}
              actionType="Export"
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to export a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Add Project":
        if (
          doesUserHavePermission({
            isShared: false,
            permissionNum: CREATE_INDEX,
          })
        ) {
          modalToOpen = (
            <AddProjectModal
              id="RPA_ScriptDesigner_AddProjectModal"
              handleClose={handleCloseModal}
              editedProject={editedProject}
              setEditedProject={setEditedProject}
              isOpen={true}
              updateProjects={updateProjects}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to create a folder.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Move To":
        if (
          doesUserHavePermission({
            isShared: false,
            permissionNum: CREATE_INDEX,
          })
        ) {
          modalToOpen = (
            <MoveToProjectModal
              id="RPA_ScriptDesigner_MoveToModal"
              handleClose={handleCloseModal}
              projectList={[
                ...allFetchedProjects.filter(
                  (item) => item.createdBy === +userId
                ),
                ...allSharedProjects,
              ]}
              updateScripts={updateScripts}
              selectedScript={selectedScript}
              isOpen={true}
              updateProjects={updateProjects}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to create a folder.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Delete Project":
        if (
          doesUserHavePermission({
            isShared: selectedProject?.createdBy !== +userId,
            permissionNum: REMOVE_INDEX,
          })
        ) {
          modalToOpen = (
            <ConfirmDeleteModal
              id="RPA_ScriptDesigner_DeleteModal"
              handleClose={handleCloseModal}
              isProject={true}
              isOpen={true}
              isDeleting={isDeleting}
              onDelete={onProjectDelete}
              handleCancel={handleCancelDelete}
              title={toBeDeleted ? toBeDeleted.projectName : ""}
              description="Once deleted you cannot get back this folder."
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to delete a folder.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;
      case "Delete Script":
        {
          /*****************************************************************************************
           * @author asloob_ali BUG ID :  105949  Description:   User with Developer role is not able to delete the script
           * Reason:script's wrong value was provided from ui logic.
           *  Resolution :corrected the script value to Be Deleted.
           *  Date : 28/02/2022             ***************************************************************************************/
        }

        if (
          doesUserHavePermission({
            isShared: toBeDeleted?.createdBy !== +userId,
            permissionNum: REMOVE_INDEX,
          })
        ) {
          modalToOpen = (
            <ConfirmDeleteModal
              id="RPA_ScriptDesigner_DeleteScriptModal"
              isProject={false}
              handleClose={handleCloseModal}
              isOpen={true}
              isDeleting={isDeleting}
              onDelete={onScriptDelete}
              handleCancel={handleCancelDelete}
              title={toBeDeleted ? toBeDeleted.scriptName : ""}
              description={"this version of the Service Flow will be deleted."}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: "You don't have permission to delete a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
          setOpenModalName(null);
        }
        break;

      default:
        break;
    }

    return modalToOpen;
  };

  const handleSearchProjects = (searchInputValue) => {
    if (searchInputValue) {
      const newProjects = allFetchedProjects.filter((project) => {
        if (
          project.projectName
            .toLowerCase()
            .includes(searchInputValue.toLowerCase()) ||
          (project.description &&
            project.description
              .toLowerCase()
              .includes(searchInputValue.toLowerCase()))
        ) {
          return project;
        }
      });
      setSelectedProject(null);
      setSelectedProjects("My Folders");
      setAllProjects(newProjects);
      setRecentProjects([]);
    } else {
      setAllProjects(allFetchedProjects);
      setSelectedProject(null);
    }
  };
  const handleSearchScripts = (searchText) => {
    if (searchText) {
      const newScripts = allFetchedScripts.filter((script) => {
        if (
          script.scriptName.toLowerCase().includes(searchText.toLowerCase()) ||
          (script.tagName &&
            script.tagName.some((tag) =>
              tag.toLowerCase().includes(searchText.toLowerCase())
            ))
        ) {
          return script;
        }
      });
      setAllScripts(newScripts);
    } else {
      setAllScripts(allFetchedScripts);
    }
  };

  const handleSelectedTags = (tag) => {
    let selTags = [...selectedTags];
    const index = selectedTags.indexOf(tag);

    if (index == -1) {
      selTags.push(tag);
    } else {
      selTags = selTags.filter((str) => str !== tag);
    }

    const scripts = allFetchedScripts;

    let filteredScripts = scripts.filter((script) => {
      const allScriptTags = script.tagName;
      if (allScriptTags) {
        let indexOfTag = null;
        allScriptTags.some((tagItem) => {
          indexOfTag = selTags.indexOf(tagItem);
          if (indexOfTag !== null && indexOfTag !== -1) {
            return true;
          }
        });

        if (indexOfTag !== null && indexOfTag !== -1) {
          return script;
        }
      }
    });

    if (selTags.length === 0) {
      setAllScripts(scripts);
    } else {
      setAllScripts(filteredScripts);
    }
    setSelectedTags(selTags);
  };

  const handleSelectedProjects = (tabName) => {
    setSelectedProjects(tabName);
    setRecentProjects([]);
  };
  const pinOrUnpinScript = async (script, isPinned) => {
    const { scriptId, versionId } = script;
    if (scriptId && versionId) {
      const axiosInstance = createInstance();
      try {
        const res = await axiosInstance.post(`${HOME}${PINNED_SCRIPT}`, {
          scriptId,
          versionId,
          isPinned,
        });

        if (res.status === 200) {
          updateScripts({ ...script, isPinned });
          setValue({
            isOpen: true,
            message: res.data["message"] || "done successfully.",
            notificationType: "SUCCESS",
            title: script.scriptName,
          });
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (err) => {
            setValue({
              isOpen: true,
              message: err || "pin/unpin error.",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
      }
    }
  };
  return (
    <Fragment>
      <div className={classes.root}>
        <Grid container spacing={3}>
          <Grid item>
            <Paper square elevation={2} className={classes.paper1}>
              <Grid
                container
                direction="column"
                className={classes.paddingItems}
              >
                <Grid
                  item
                  container
                  direction="row"
                  alignItems={'center'}
                  // style={{ marginBottom: "12px" }}
                >
                  <Grid item>
                    <Typography variant="h6" className={classes.title}>
                      Folders
                    </Typography>
                  </Grid>
                  <Grid item style={{ marginLeft: "auto" }}>
                    <IconButton
                      id="RPA_ScriptDesigner_AddIcon"
                      aria-label="Add Project"
                      onClick={() => handleOpenModal("Add Project")}
                      className={classes.addProjectBtn}
                    >
                      <AddIcon
                        className={classes.addIcon}
                      />
                    </IconButton>
                    {/*<Typography
                      className={classes.addProjectBtn}
                      onClick={() => handleOpenModal("Add Project")}
                      //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
                      onKeyPress={(e) =>
                        e.key === "Enter" && handleOpenModal("Add Project")
                      }
                      id="RPA_ScriptDesigner_AddProject"
                    >
                      <AddIcon
                        id="RPA_ScriptDesigner_AddIcon"
                        className={classes.addIcon}
                        tabIndex={0}
                        role="button"
                        aria-hidden="false"
                      />
                    </Typography>*/}
                  </Grid>
                </Grid>
                <Grid item style={{ marginBottom: "8px" }}>
                  <SearchBox
                    id="RPA_ScriptDesigner_Projects_SearchBox"
                    width="205px"
                    onSearchChange={handleSearchProjects}
                  />
                </Grid>
                <Grid item>
                  <CustomTabs
                    tabItems={["My Folders", "Shared With Me"]}
                    selectedTab={selectedProjects}
                    handleTabChange={handleSelectedProjects}
                    className={classes.selectedTab}
                    justify="flex-start"
                    id="RPA_ScriptDesigner_Tab"
                  />
                </Grid>
              </Grid>
              <Divider variant="fullWidth" className={classes.divider} />

              <Box component={Grid} item xs={12}>
                <LeftPanel
                  listOfProjects={
                    selectedProjects === "My Folders"
                      ? allProjects.filter((pr) => pr.createdBy === +userId)
                      : selectedProjects === "Shared With Me"
                        ? allProjects.filter((pr) => pr.createdBy !== +userId)
                        : []
                  }
                  recentProjects={recentProjects}
                  isFetchingProjects={isFetchingProjects}
                  selectedProject={selectedProject}
                  handleOpenModal={handleOpenModal}
                  selectedProjects={selectedProjects}
                  deleteProject={deleteProject}
                  // setSelectedProject={setSelectedProject}
                  setAllScripts={setAllScripts}
                  setEditedProject={setEditedProject}
                  handleSelectedProjects={handleSelectedProjects}
                  handleSelectedProject={handleSelectedProject}
                  handleToBeDeleted={handleToBeDeleted}
                />
              </Box>
            </Paper>
          </Grid>

          <Grid item xs className={classes.flex} >
            {/* //style={{ overflowX: "auto" }} */}
            <div className={classes.flexGrow}>
              <RightPanel
                selectedProject={selectedProject}
                sharedProjects={allSharedProjects}
                selectedTags={selectedTags}
                handleSelectedTags={handleSelectedTags}
                allScripts={allScripts}
                updateScripts={updateScripts}
                pinOrUnpinScript={pinOrUnpinScript}
                isFetchingScripts={isFetchingScripts}
                selectedProjects={selectedProjects}
                handleOpenModal={handleOpenModal}
                setSelectedScript={setSelectedScript}
                setEditedProject={setEditedProject}
                deleteProject={deleteProject}
                handleSearchScripts={handleSearchScripts}
                allFetchedScripts={allFetchedScripts}
                handleToBeDeleted={handleToBeDeleted}
              />
            </div>
          </Grid>
        </Grid>

        {/*will return the modal whichever selected */}
        {openModalName ? showModal() : null}
      </div>
    </Fragment>
  );
};

export default ScriptInitiate;
