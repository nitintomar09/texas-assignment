import React, { useState, useEffect, useContext, version } from "react";
import {
  Grid,
  Typography,
  Button,
  CircularProgress,
  Chip,
  Paper,
  Avatar,
  IconButton,
  Divider,
  Tooltip,
} from "@mui/material";
import { useHistory } from "react-router";
import {
  deepOrange,
  deepPurple,
  brown,
  green,
  lightGreen,
} from "@mui/material/colors";
import { makeStyles } from "@mui/styles";
import { Done } from "@mui/icons-material";
import {
  FolderIcon,
  EditIcon,
  MoreVerticalIcon,
  SortingAtoZIcon,
  SortingZtoAIcon,
  IllustrationIcon,
  ScriptIcon,
  ImportedIcon,
  CreatedIcon,
  HorizontalIcon,
  OpenIcon,
  PreviousVersionIcon,
  HistoryIcon,
  RenameIcon,
  ShareIcon,
  DeleteIcon,
  ExportIcon,
  MoveIcon,
  ChartIcon,
  EndPointIcon,
  DeleteAction,
  SharedProjectIcon,
  IconShare,
  PinIcon,
  PinnedIcon,
  PublishedDotIcon,
  DocIcon,
  StatusIcon,
} from "../../utils/AllImages";
import SearchBox from "../../utils/Search-Component";
import CustomTabs from "../../utils/CustomTabs";
import MenuPopper from "../../utils/MenuPopper";

import { NotificationContext } from "../../contexts/NotificationContext";

import { useDispatch, useSelector } from "react-redux";
import { setOpenScript, setOpenScriptDetails } from "../../redux/actions";

import { getEncryptedId } from "../../utils/encryptions";
import {
  openScriptInNewTab,
  getToken,
  getUser,
  getUserId,
  getDateAndTimeStr,
  doesUserHavePermission,
  truncateStringValues,
} from "../../utils/common";
import CustomTooltip from "../../utils/CustomTooltip";
import {
  SHARE_INDEX,
  VIEW_INDEX,
  MODIFY_INDEX,
  REMOVE_INDEX,
  EXPORT_SCRIPT_INDEX,
} from "../../config";
import {
  getCssRgbFromHexByDiff,
  getRgbafromHex,
} from "../../utils/HexToFilter";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";
const useStyles = makeStyles((theme) => ({
  root: {
    paddingLeft: "20px",
    paddingRight: "16px",
  },
  editIcon1: {
    height: "16px",
    width: "16px",
    filter: `invert(25%) sepia(65%) saturate(3923%) hue-rotate(190deg) brightness(93%) contrast(101%)`,
  },
  text_12: {
    fontSize: 12,
  },
  text_lead: {
    color: "#767676",
    fontWeight: "600",
  },
  text_bold: {
    fontWeight: 700,
  },
  icons: {
    height: "16px",
    width: "16px",
  },
  AllScripts: {
    height: "380px",
    overflowY: "scroll",
    overflowX: "hidden",
  },
  paper2: {
    boxShadow: "0px 2px 6px #00000014",
    // height: "75px",
    display: "flex",
    flexGrow: 1,

    padding: "12px 17px 24px 12px",
    marginTop: "13px",
    marginBottom: "24px",
  },
  projectIcon: {
    height: "24px",
    width: "24px",
  },
  title: {
    fontWeight: 600,
    fontSize: "16px",
  },
  btns: {
    // padding: "5px 8px 6px 8px",
    lineHeight: 1.35,
    fontSize: "12px",
    fontWeight: 600,
  },
  Deletebtn: {
    color: "#D53D3D",
    lineHeight: 1.35,
    fontSize: "12px",
    fontWeight: 600,
  },
  sub: {
    marginTop: "1px",
    paddingLeft: "2px",
    fontSize: "10px",
    fontWeight: 600,
    color: "#000000",
  },
  editIcon: {
    marginTop: "3px",
    cursor: "pointer",
    // width: "12px",
    //height: "12px",
  },
  items: {
    //height: "28px",
    padding: "5px",
    borderRadius: "2px",
    background: "#FFFFFF 0% 0% no-repeat padding-box",
    border: "1px solid #C4C4C4",
    cursor: "pointer",
  },
  headerItems: {
    //color: "#767676",
    color: "#000000",
    fontWeight: 600,
  },
  paperItem: {
    height: "40px",
    transition: "all 100ms ease-in",
    "&:hover": {
      boxShadow: "0px 3px 6px #00000029",
    },

    padding: "12px 12px 12px 20px",
    borderRadius: "2px",
    backgroundColor: "#FFFFFF",
    boxShadow: "0px 2px 6px #00000014",
    opacity: 1,
    cursor: "pointer",
  },
  item2: {
    padding: "0px 20px 0px 30px",
    marginLeft: "0.1px",
  },
  orange: {
    backgroundColor: deepOrange[500],
    fontSize: "12px",
  },
  purple: {
    backgroundColor: deepPurple[500],
    fontSize: "12px",
  },
  brown: {
    backgroundColor: brown[500],
    fontSize: "12px",
  },
  lightGreen: {
    // color: theme.palette.getContrastText(lightGreen[500]),
    backgroundColor: lightGreen[500],
    fontSize: "12px",
  },
  green: {
    backgroundColor: green[500],
    fontSize: "12px",
  },
  moreUser: {
    color: `${theme.palette.primary.main}`,
    backgroundColor: "#FFFFFF",
    fontSize: "12px",
  },
  icons1: {
    width: "20px",
    height: "20px",
    color: "white",
  },
  icons2: {
    width: "28px",
    height: "28px",
    border: "1px solid #C4C4C4",
    // borderRadius: "50px",
  },
  scrollDiv: {
    //height: "auto",
    height: "60vh",
    //  height: "425px",

    overflow: "hidden",
    overflowY: "auto",
  },
  scrollDiv2: {
    //height: "49vh",

    height: "360px",
    overflow: "hidden",
    overflowY: "auto",
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
      filter: `none`,
    },
  },

  focusPrimary: {
    "&:focus": {
      background: `${getCssRgbFromHexByDiff(`${theme.palette.primary.main}`)}`,
    },
  },
  focusSecondary: {
    "&:focus": {
      //filter: "brightness(0.85)",
      background: `${getRgbafromHex(`${theme.palette.primary.main}`, 0.04)}`,
    },
  },
  selectedTab: {
    paddingBottom: "8px",
    borderBottom: "2px solid #0072C6",
  },
  icon: {
    width: "14px",
    height: "14px",
    filter:
      "brightness(0) saturate(100%) invert(45%) sepia(4%) saturate(236%) hue-rotate(339deg) brightness(102%) contrast(95%)",
  },
  illustrationImg: {
    width: "450px",
    height: "250px",
  },
  sortIcon: { width: "16px", height: "16px" },
  tag: {
    height: "24pt",
    fontSize: "12px",
    padding: "8px 10px 8px 10px",
    borderRadius: "17pt",
    border: "1px solid #C4C4C4",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "17pt",
    },
  },
}));
const RightPanel = (props) => {
  const {
    selectedProject,
    selectedProjects,
    handleOpenModal,
    setSelectedScript,
    allScripts,
    isFetchingScripts,
    selectedTags,
    handleSelectedTags,
    setEditedProject,
    handleSearchScripts,
    allFetchedScripts,
    handleToBeDeleted,
    pinOrUnpinScript,
    sharedProjects,
  } = props;

  const classes = useStyles();
  const [isVisible, setIsVisible] = useState(null);
  const [isVisibleProj, setIsVisibleProj] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState("All Service Flows");
  const onMouseover = (actionOn, index) => {
    if (actionOn === "Project") {
      setIsVisibleProj(true);
    } else {
      setIsVisible(index);
    }
  };
  const onMouseout = (actionOn, index) => {
    if (actionOn === "Project") {
      setIsVisibleProj(false);
    } else {
      setIsVisible(null);
    }
  };
  const { setValue } = useContext(NotificationContext);
  const [allTags, setAllTags] = useState([]);

  const [sortType, setSortType] = useState("Asc");
  const { green, lightGreen, brown, purple, orange } = classes;
  const colors = [green, lightGreen, purple, brown, orange];

  const [owner, setOwner] = useState(null);

  const allUsers = useSelector((state) => state.scriptsAndProjects.allUsers);

  const userId = getUserId();

  const dispatch = useDispatch();
  const history = useHistory();
  useEffect(() => {
    if (selectedProject) {
      getOwner();
    }
  }, [allUsers, selectedProject]);

  const getOwner = () => {
    const owner1 = allUsers.find(
      (usr) => usr.userIndex === selectedProject?.createdBy
    );

    if (owner1) {
      setOwner(owner1);
    } else {
      setOwner(null);
    }
  };

  useEffect(() => {
    if (allFetchedScripts) {
      const scripts = allFetchedScripts;
      const tags = [];
      if (scripts) {
        scripts.forEach((data) => {
          if (data.tagName) {
            const allScriptTags = data.tagName;
            allScriptTags.forEach((tag) => {
              if (tag) {
                const index = tags.indexOf(tag);
                if (index == -1) {
                  tags.push(tag);
                }
              }
            });
          }
        });
      }
      setAllTags(tags);
    }
  }, [allFetchedScripts]);

  const handleScriptAction = (e, action, clickedOnScript) => {
    const { versionId, scriptId, versionName, scriptName } = clickedOnScript;

    switch (action) {
      case "Sharing":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: SHARE_INDEX,
          })
        ) {
          setSelectedScript(clickedOnScript);
          handleOpenModal("Script Sharing");
        } else {
          setValue({
            isOpen: true,
            message:
              "You Don't have permission to change Service Flow's sharing settings.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();
        break;
      case "Open":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          setSelectedScript(null);
          dispatch(setOpenScript(clickedOnScript));

          if (scriptId && versionName) {
            //  dispatch(setOpenScriptDetails({}));
            dispatch(
              setOpenScriptDetails({ scriptId, versionName, scriptName })
            );
            /*   const encStr = getEncryptedId({
                 scriptId: scriptId,
                 versionName: versionName,
               });
   */
            // history.push(`/serviceflow/${encStr}`);
            history.push(`/serviceflow`);
          } else {
            console.log("falsy versionName/scriptId", versionName, scriptId);
          }
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to view a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();

        break;
      case "Open In New Tab":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          setSelectedScript(null);
          dispatch(setOpenScript(clickedOnScript));
          dispatch(setOpenScriptDetails({}));

          if (scriptId && versionName) {
            const user = getUser();
            const token = getToken();
            openScriptInNewTab({ scriptId, versionName, token, user });
          } else {
            console.log("falsy versionName/scriptId", versionName, scriptId);
          }
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to view a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();

        break;
      case "History":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          setSelectedScript(clickedOnScript);
          handleOpenModal("Script History");
        } else {
          setValue({
            isOpen: true,
            message:
              "You Don't have permission to view history of a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        } 
        e.stopPropagation();

        break;
      case "Open Previous Versions":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          setSelectedScript(clickedOnScript);
          handleOpenModal("Script Previous Versions");
        } else {
          setValue({
            isOpen: true,
            message:
              "You Don't have permission to view previous versions of a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();

        break;
      case "Move To":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: MODIFY_INDEX,
          })
        ) {
          setSelectedScript(clickedOnScript);
          handleOpenModal("Move To");
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to move a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();

        break;

      case "Rename":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: MODIFY_INDEX,
          })
        ) {
          setSelectedScript(clickedOnScript);
          handleOpenModal("Update Script");
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to edit a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();

        break;
      case "Export":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: EXPORT_SCRIPT_INDEX,
          })
        ) {
          setSelectedScript(clickedOnScript);
          handleOpenModal("Export");
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to export a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();
        break;

      case "Delete":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: REMOVE_INDEX,
          })
        ) {
          if (versionId && scriptId && versionName) {
            handleToBeDeleted(clickedOnScript);
            handleOpenModal("Delete Script");
          } else {
            console.log("version id/ script id/ version name not available.");
          }
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to delete a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();
        break;

      case "Pin":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          pinOrUnpinScript(clickedOnScript, 1);
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to Pin a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();
        break;
      case "Unpin":
        if (
          doesUserHavePermission({
            isShared: clickedOnScript?.createdBy !== +userId,
            permissionNum: VIEW_INDEX,
          })
        ) {
          pinOrUnpinScript(clickedOnScript, 0);
        } else {
          setValue({
            isOpen: true,
            message: "You Don't have permission to unpin a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        e.stopPropagation();
        break;

      default:
        e.stopPropagation();

        break;
    }
  };

  const handleSort = () => {
    if (sortType === "Asc") {
      setSortType("Desc");
    } else if (sortType === "Desc") {
      setSortType("Asc");
    }
  };
  const handleSortScripts = (a, b) => {
    if (a.scriptName && b.scriptName) {
      if (sortType === "Asc") {
        return a.scriptName.localeCompare(b.scriptName);
      } else if (sortType === "Desc") {
        return b.scriptName.localeCompare(a.scriptName);
      }
    }
  };

  const handleSelectedActionForProject = async (action, clickedOnProject) => {
    switch (action) {
      case "Remove":
        handleToBeDeleted(clickedOnProject);
        handleOpenModal("Delete Project");

        break;
      case "Modify":
        setEditedProject(clickedOnProject);
        handleOpenModal("Add Project");
        break;
      default:
        break;
    }
  };

  if (!selectedProject) {
    return (
      <Grid
        container
        justifyContent="center"
        alignItems="center"
        style={{ height: "100vh" }}
      >
        <Grid item>
          <Typography variant="subtitle1" style={{ fontWeight: 600 }}>
            No Service Flow present.
          </Typography>
        </Grid>
      </Grid>
    );
  }

  const getUsers = (arrOfIds) => {
    let newUsers = [];

    if (arrOfIds) {
      newUsers = arrOfIds?.map((item) => {
        return {
          name: item?.fullName?.trim().charAt(0).toUpperCase() || "",
          userLoginId: item?.userId || "",
          fullName: item?.fullName,
        };
      });
    }

    return newUsers || [];
  };

  const handleSelectedStatus = (tabName) => {
    setSelectedStatus(tabName);
  };
  {
    /*****************************************************************************************
     * @author asloob.ali BUG ID :  101290   Description :  Script page: Hamburger menu option name "Pin" is not correct.
     * Reason:when developed the screen ,in design the functionality was not there so when added functionality,we gave an option 'Pin'.
     *  Resolution :changed name 'Pin' to 'Pin to Homepage' and position also...
     *  Date : 11/10/2021             ***************************************************************************************/
  }

  const getFilteredScripts =
    allScripts?.length > 0
      ? allScripts.sort(handleSortScripts).filter((script) => {
          if (selectedStatus === "All Service Flows") return true;
          if (selectedStatus === "Published") return script.isPublished == 1;
          if (selectedStatus === "Draft")
            return script.isPublished === 0 || script.isPublished == null;
          return false;
        })
      : [];

  console.log(getFilteredScripts, "getFidmkdjend", selectedStatus);
  const getMenuActions = (s) => {
    return [
      { name: "Open", icon: <OpenIcon /> },

      //"Open In New Tab",
      { name: s.isPinned === 1 ? "Unpin" : "Pin", icon: <PinnedIcon /> },

      { name: "Open Previous Versions", icon: <PreviousVersionIcon /> },
      { name: "History", icon: <HistoryIcon /> },
      { name: "Sharing", icon: <IconShare /> },
      { name: "Export", icon: <ExportIcon /> },
      { name: "Move To", icon: <MoveIcon /> },
      { name: "Rename", icon: <RenameIcon /> },
      { name: "View Flow Chart", icon: <ChartIcon /> },

      { name: "Delete", icon: <DeleteAction /> },
    ];
  };

  const whenPublishedMenuActions = (s) => {
    return [
      { name: "Open", icon: <OpenIcon /> },
      { name: s.isPinned === 1 ? "Unpin" : "Pin", icon: <PinnedIcon /> },
      { name: "History", icon: <HistoryIcon /> },
      { name: "Export", icon: <ExportIcon /> },
      { name: "View Flow Chart", icon: <ChartIcon /> },
    ];
  };

  const whenCommittedMenuActions = (s) => {
    return [
      {
        icon: (
          <CustomTooltip
            title="Committed Service Flow can not be renamed"
            placement="bottom"
          >
            <span
              style={{
                display: "flex",
                alignItems: "center",
                cursor: "not-allowed",
              }}
            >
              <RenameIcon color="disabled" />
              <span style={{ marginLeft: 8, fontSize: "12px" }}>Rename</span>
            </span>
          </CustomTooltip>
        ),
        disabled: true,
      },
      { name: "View Flow Chart", icon: <ChartIcon /> },
      { name: "Delete", icon: <DeleteAction /> },
    ];
  };
  {
    /*****************************************************************************************
     * @author asloob.ali BUG ID :  106720    Description :   Create project - UI issue if I enter a long project description in it
     * Reason:we are not showing create scripts/omports scripts at two places when project does not have any scripts.
     * ui was distorted when given a long name
     *  Resolution :added truncation of the project name with appropriate length of the string.
     *  Date : 16/03/2022             ***************************************************************************************/
  }
  return (
    <div
      //style={{
      //overflow: "hidden",
      //  overflowY: "auto",
      //maxHeight: "635px",
      //  }}
      style={{
        width: "600px",
        flexGrow: 1,
      }}
    >
      {!isFetchingScripts &&
        allFetchedScripts &&
        allFetchedScripts.length > 0 && (
          <Grid container direction={"row"} style={{ marginTop: "10px" }}>
            <Grid item xs={12}>
              <CustomTabs
                tabItems={["All Service Flows", "Published", "Draft"]}
                selectedTab={selectedStatus}
                handleTabChange={handleSelectedStatus}
                className={classes.selectedTab}
              />
            </Grid>
          </Grid>
        )}
      <Divider
        variant="fullWidth"
        /**
     * @author sanya.mahajan For Bug 155811 - UX - Shared with me folder - tabs not correct on screen
     * Description: To align the divider with the elements on both right and left side.
     * Date : 03/02/2025             
     * */
        //style={{ marginLeft: "16px", marginRight: "16px" }}
      />

      {isFetchingScripts && (
        <div
          style={{
            width: "100%",
            height: "100%",
            textAlign: "center",
            zIndex: 1,
            verticalAlign: "center",
            marginTop: "20px",
          }}
        >
          <CircularProgress
            style={{
              alignItems: "center",
              width: "20px",
              height: "20px",
              textAlign: "center",
            }}
          />
        </div>
      )}
      {!isFetchingScripts &&
        allFetchedScripts &&
        allFetchedScripts.length > 0 && (
          <Grid
            container
            spacing={2}
            alignItems="center"
            style={{ marginTop: "10px" }}
          >
            <Grid item>
              <SearchBox
                id="RPA_ScriptDesigner_Script_SearchBox"
                width="229px"
                onSearchChange={handleSearchScripts}
                placeholder="Search by Name"
              />
            </Grid>

            {/* //Bug 151146 - Script view page structure
            //Author: dixita.Ruhela
            // Date: 7 JAn 2025
            //Description: UI updated based on UX Screens */}

            {/* Bug 155808 - UX In 'Shared with me' folder, crate buttons not required
              Author: sanya.mahajan
              Date: 23rd January, 2025
              Resolution: Introduced a condition that displays the grid containing buttons only when on "My Folders" tab*/}

          {selectedProjects==="My Folders" && (
            <Grid item style={{ marginLeft: "auto" }}>
              <Grid container spacing={1}>
                {!isFetchingScripts && allFetchedScripts.length !== 0
                  ? selectedProject &&
                    userId && (
                      <>
                        <Grid item>
                          <Button
                            variant="outlined"
                            color="primary"
                            className={[
                              classes.btns,
                              classes.focusVisible,
                              classes.focusSecondary,
                            ].join(" ")}
                            onClick={() => {
                              handleOpenModal("Import Script");
                            }}
                            startIcon={<ImportedIcon />}
                            disabled={
                              selectedProject.createdBy !== +userId &&
                              sharedProjects &&
                              !sharedProjects.find(
                                (pro) =>
                                  pro.projectId === selectedProject.projectId
                              )
                            }
                            disableRipple
                            id="RPA_ScriptDesigner_ImportScriptsBtn"
                          >
                            Import
                          </Button>
                        </Grid>
                        <Grid item>
                          <Button
                            variant="contained"
                            color="primary"
                            className={classes.btns}
                            onClick={() => handleOpenModal("New Script")}
                            startIcon={<CreatedIcon />}
                            disabled={
                              selectedProject.createdBy !== +userId &&
                              sharedProjects &&
                              !sharedProjects.find(
                                (pro) =>
                                  pro.projectId === selectedProject.projectId
                              )
                            }
                            disableFocusRipple
                            tabIndex={0}
                            focusVisibleClassName={
                              classes.focusVisible + " " + classes.focusPrimary
                            }
                            id="RPA_ScriptDesigner_CreateScriptBtn"
                          >
                            Create
                          </Button>
                        </Grid>
                      </>
                    )
                  : null}
              </Grid>
            </Grid>
            )}
          </Grid>
        )}
      {allScripts && allScripts.length > 0 ? (
        <div
          role="table"
          //title="scripts"

          //Bug 155227 - tooltip is getting displayed on the incorrect places on the service flow tab
          //Author: nitin_tomar
          //Date: 6 JAN 2025
          //Description: title has been commented out so that it does not appear on the screen while hover any row
          style={{ backgroundColor: "#ffffff" }}
        >
          <div style={{ marginTop: "16px" }} role="rowgroup">
            <Grid
              container
              className={classes.item2}
              style={{ paddingTop: "20px" }}
              role="row"
            >
              <Grid item xs={1} className={classes.item} role="columnheader">
                <Typography className={classes.headerItems}>Sl no.</Typography>
              </Grid>
              <Grid item xs={3} className={classes.item} role="columnheader">
                <Typography className={classes.headerItems}>Name</Typography>
              </Grid>
              <Grid item xs={1} className={classes.item} role="columnheader">
                <Typography className={classes.headerItems}>Version</Typography>
              </Grid>

              <Grid item xs={2} className={classes.item} role="columnheader">
                <Typography className={classes.headerItems}>Status</Typography>
              </Grid>
              <Grid item xs={2} className={classes.item} role="columnheader">
                <Typography className={classes.headerItems}>
                  Last Updated
                </Typography>
              </Grid>
              <Grid item xs className={classes.item} role="columnheader">
                <Typography className={classes.headerItems}>
                  Shared with
                </Typography>
              </Grid>
              <Grid item style={{ marginLeft: "auto" }} role="columnheader">
                <Typography className={classes.headerItems}>Actions</Typography>
              </Grid>
            </Grid>
          </div>
          <div
            className={classes.scrollDiv}
            style={{ paddingRight: "10px" }}
            role="rowgroup"
          >
            <Grid
              container
              direction="column"
              justifyContent="center"
              style={{ marginTop: "5px", marginLeft: "0.1px" }}
              spacing={1}
            >
              {getFilteredScripts.map((s, i) => (
                <Grid item key={s.scriptId || i}>
                  <Paper
                    role="row"
                    className={classes.paperItem}
                    style={{
                      height: "28px",
                      display: "flex",
                      alignItems: "center",
                    }}
                    elevation={2}
                    onClick={(e) => handleScriptAction(e, "Open", s)}
                    //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
                    tabIndex={0}
                    onKeyPress={(e) =>
                      e.key === "Enter" && handleScriptAction(e, "Open", s)
                    }
                    id={`RPA_ScriptDesigner_SortedScript_${s.scriptName}`}
                  >
                    <Grid container spacing={1}>
                      <Grid item xs={1} role="cell">
                        <Typography>{i + 1}.</Typography>
                      </Grid>
                      <Grid item xs={3} role="cell">
                        <Typography title={s.scriptName}>
                          {truncateStringValues({
                            str: s.scriptName,
                            min: 23,
                            max: 30,
                          })}
                        </Typography>
                      </Grid>
                      <Grid item xs={1} role="cell">
                        <Typography>{s.versionName}</Typography>
                      </Grid>

                      {/*****************************************************************************************
                       * @author asloob.ali BUG ID :  101263    Description :   Status Field is missing in Scripts List Page.
                       * Reason:when developed the screen and integrated api, the information related to status was not coming from backend.
                       *  Resolution :now recieving status flag info from api, so added status field..
                       *  Date : 11/10/2021             ***************************************************************************************/}
                      <Grid
                        item
                        xs={2}
                        role="cell"
                        style={{ paddingLeft: "0px" }}
                      >
                        <Grid container alignItems="center" spacing={1}>
                          <Grid item>
                            <StatusIcon
                              //className={classes.icon}
                              style={{
                                color: s.isPublished
                                  ? "#0D6F08"
                                  : s.isPublished == 0
                                  ? "#F0A229"
                                  : "#0F54FB",
                                height: 12,
                                width: 7,
                              }}
                            />
                          </Grid>
                          <Grid item>
                            <Typography
                              style={{
                                color: "#606060",
                                fontWeight: 600,
                              }}
                            >
                              {s.isPublished
                                ? "Published"
                                : s.isPublished == 0
                                ? "Committed"
                                : "Draft"}
                            </Typography>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid
                        item
                        xs={2}
                        role="cell"
                        style={{ paddingLeft: "0px" }}
                      >
                        <Typography>
                          {s.lastModified
                            ? getDateAndTimeStr(s.lastModified)
                            : "Not Available."}
                        </Typography>
                      </Grid>
                      <Grid item xs role="cell">
                        {s?.isShared && (
                          <Grid
                            container
                            spacing={1}
                            alignItems="center"
                            style={{ marginTop: "-8px" }}
                          >
                            {getUsers(s?.sharedUserId)
                              .slice(0, 3)

                              .map((user, index) => (
                                <Grid item key={index}>
                                  <CustomTooltip
                                    title={user.userLoginId || ""}
                                    placement="bottom-start"
                                  >
                                    <Avatar
                                      className={
                                        //  colors[Math.floor(Math.random() * 5)] +
                                        colors[index] + " " + classes.icons1
                                      }
                                    >
                                      {user.name}
                                    </Avatar>
                                  </CustomTooltip>
                                </Grid>
                              ))}
                            {getUsers(s?.sharedUserId).length -
                              getUsers(s?.sharedUserId).slice(0, 3).length >
                            0 ? (
                              <Grid item style={{ position: "relative" }}>
                                <Avatar
                                  className={
                                    classes.moreUser + " " + classes.icons2
                                  }
                                  onMouseEnter={() => onMouseover(null, i)}
                                  onMouseLeave={() => onMouseout(null, i)}
                                >
                                  +
                                  {getUsers(s?.sharedUserId).length -
                                    getUsers(s?.sharedUserId).slice(0, 3)
                                      .length}
                                </Avatar>

                                {isVisible === i && (
                                  <span
                                    style={{
                                      backgroundColor: "#FFFFFF",
                                      padding: 10,
                                      position: "absolute",
                                      zIndex: 2,
                                      border: "1px solid #727272",
                                    }}
                                  >
                                    {getUsers(s?.sharedUserId)
                                      .slice(
                                        3,
                                        getUsers(s?.sharedUserId).length
                                      )
                                      .map((item, index) => {
                                        return index === 0
                                          ? item?.userLoginId
                                          : `, ${item?.userLoginId}`;
                                      })}
                                  </span>
                                )}
                              </Grid>
                            ) : null}
                          </Grid>
                        )}
                      </Grid>
                      <Grid item style={{ marginLeft: "auto" }} role="cell">
                        <MenuPopper
                          id={`RPA_ScriptDesigner_${s.scriptName}_MenuPopper`}
                          selfClicked={s}
                          MenuIcon={HorizontalIcon}
                          className={[classes.icon, classes.focusVisible].join(
                            " "
                          )}
                          handleSelectedItem={handleScriptAction}
                          items={
                            s.createdBy === +userId && s.isPublished == null 
                              ? getMenuActions(s)
                              : s.createdBy === +userId && s.isPublished == 1
                              ? whenPublishedMenuActions(s)
                              : getMenuActions(s).filter(
                                  (it) => it !== "Move To"
                                )
                          }
                        />
                      </Grid>
                    </Grid>
                  </Paper>
                </Grid>
              ))}
            </Grid>
          </div>
        </div>
      ) : !isFetchingScripts && allFetchedScripts.length === 0 ? (
        /* <div className={classes.scrollDiv2}>*/
        <Grid container justifyContent="center" style={{ marginTop: "64px" }}>
          <Grid
            item
            container
            direction="column"
            spacing={1}
            alignItems="center"
            justifyContent="center"
            style={{ textAlign: "center" }}
            // xs
          >
            <Grid item>
              {/*<img
                src={defaultProPic}
                style={{ width: "212px", height: "190px" }}
             />*/}
              <UniqueIDGenerator>
                <IllustrationIcon className={classes.illustrationImg} />
              </UniqueIDGenerator>
            </Grid>
            <Grid item>
              <Typography variant="h6" style={{ fontWeight: 700 }}>
                Service Flow helps in executing tasks.
              </Typography>
            </Grid>
            <Grid item>
              <Typography>
                You can create a Service Flow or import one inside a folder. You
                can share the folder or individual service flows with other
                members too in share settings.
              </Typography>
            </Grid>
            {selectedProject && userId && (
              <Grid item>
                <Grid container spacing={1}>
                  <Grid item>
                    <Button
                      variant="outlined"
                      color="primary"
                      className={classes.btns}
                      onClick={() => {
                        handleOpenModal("Import Script");
                      }}
                      disabled={
                        selectedProject.createdBy !== +userId &&
                        sharedProjects &&
                        !sharedProjects.find(
                          (pro) => pro.projectId === selectedProject.projectId
                        )
                      }
                      disableRipple
                      id="RPA_ScriptDesigner_ImportScriptBtn"
                    >
                      Import Service Flow
                    </Button>
                  </Grid>
                  <Grid item>
                    <Button
                      variant="contained"
                      color="primary"
                      className={classes.btns}
                      onClick={() => handleOpenModal("New Script")}
                      disabled={
                        selectedProject.createdBy !== +userId &&
                        sharedProjects &&
                        !sharedProjects.find(
                          (pro) => pro.projectId === selectedProject.projectId
                        )
                      }
                      disableRipple
                      id="RPA_ScriptDesigner_CreateScriptBtn"
                    >
                      Create a Service Flow
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
            )}
          </Grid>
        </Grid>
      ) : (
        /*</div>*/
        !isFetchingScripts &&
        allScripts.length === 0 &&
        allFetchedScripts.length > 0 && (
          //Bug 155118 - Ui issues on the searching box of the service flows page
          //Author: nitin_tomar
          //Date:06 JAN 2025
          //Description: Message Display location is updated to Center
          <Grid
            container
            spacing={3}
            height={"80%"}
            justifyContent={"center"}
            alignItems={"center"}
          >
            <Grid item>
              <Typography>No Service Flow found based on search.</Typography>
            </Grid>
          </Grid>
        )
      )}
    </div>
  );
};

export default RightPanel;
