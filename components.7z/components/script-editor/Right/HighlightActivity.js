import { fontGrid } from "@mui/material/styles/cssUtils";

export const highlightActivity=(activityName)=>{
   
    let backgroundColor="";
    switch(activityName){
        case "CodeBlock":
            backgroundColor="#FFF9EC";
            break;
        case "IfElse":
            backgroundColor="#F0FCF4";
            break;
        case "Repeat":
            backgroundColor="#F0FCF4";
            break;
        case "RepeatIf":
            backgroundColor="#F0FCF4";
            break;
        case "ForEach":
            backgroundColor="#F0FCF4";
            break;
        case "PrintOutput":
            backgroundColor="#EFEFEF";
            break;
        case "Assignment":
            backgroundColor="#F1EBF5";
            break;
        case "ConnectDatabase":
            backgroundColor="#EBEFF3";
            break;
        case "FetchRecords":
            backgroundColor="#EBEFF3";
            break;
        case "UpdateRecords":
            backgroundColor="#EBEFF3";
            break;
        case "DeleteRecords":
            backgroundColor="#EBEFF3";
            break;
        case "AddRecords":
            backgroundColor="#EBEFF3";
            break;
        case "ExecuteProcedure":
            backgroundColor="#EBEFF3";
            break;
        case "GetCurrentDate":
            backgroundColor="#F4F3FF";
            break;
        case "GetCurrentDateTime":
            backgroundColor="#F4F3FF";
            break;
        case "GetCurrentTime":
            backgroundColor="#F4F3FF";
            break;
        case "DateToString":
            backgroundColor="#F4F3FF";
            break;
        case "ChangeDateFormat":
            backgroundColor="#F4F3FF";
            break;   
        case "CheckError":
            backgroundColor="#FEF3F2";
            break;  
        case "ConditionOf":
            backgroundColor="#FEF3F2";
            break;  
        case "Retry":
            backgroundColor="#FEF3F2";
            break;  
        case "Exit": 
            backgroundColor="#FEF3F2";
            break;  
        case "FTPConnect":
            backgroundColor="#F0EFF6";
            break;
        case "FTPDownload":
            backgroundColor="#F0EFF6";
            break;
        case "FTPUpload":
            backgroundColor="#F0EFF6";
            break;
        case "FTPCreate":
            backgroundColor="#F0EFF6";
            break;
        case "FTPDelete":
            backgroundColor="#F0EFF6";
            break;
        case "FTPMove":
            backgroundColor="#F0EFF6";
            break;
        case "Group":
            backgroundColor="#EEF4FF";
            break;
        case "GetMails":
            backgroundColor="#F9F5EB";
            break;
        case "SendMailSMTP":
            backgroundColor="#F9F5EB";
            break;
        case "DeleteMail":
            backgroundColor="#F9F5EB";
            break;
        case "SaveMail":
            backgroundColor="#F9F5EB";
            break;
        case "SaveMailAttachments":
            backgroundColor="#F9F5EB";
            break;
        case "ConnectMail":
            backgroundColor="#F9F5EB";
            break;
        case "ForEachMail":
            backgroundColor="#F9F5EB";
            break;
        case "ServerConnect":
            backgroundColor="#FFF0E5";
            break;
        case "CreateWorkItem":
            backgroundColor="#FFF0E5";
            break;
        case "CompleteWorkItem":
            backgroundColor="#FFF0E5";
            break;
        case "SaveWorkitem":
            backgroundColor="#FFF0E5";
            break;
        case "GetWorkItem":
            backgroundColor="#FFF0E5";
            break;
        case "AddDocument":
            backgroundColor="#FFF0E5";
            break;
        case "GetDocument":
            backgroundColor="#FFF0E5";
            break;
        case "ConnectXtract":
            backgroundColor="#FFF0E5";
            break;
        case "ExtractData":
            backgroundColor="#FFF0E5";
            break;
        case "GetPathFromFullPath":
            backgroundColor="#EBF3F4";
            break;
        case "GetAllFoldersFromPath":
            backgroundColor="#EBF3F4";
            break;
        case "GetDriveLetter":
            backgroundColor="#EBF3F4";
            break;
        case "GetSeparator":
            backgroundColor="#EBF3F4";
            break;
        case "GetFileExtension":
            backgroundColor="#EBF3F4";
            break;
        case "GetFileNameFromFullPath":
            backgroundColor="#EBF3F4";
            break;
        case "StringAfter":
            backgroundColor="#FDF2FA";
            break;
        case "StringBefore":
            backgroundColor="#FDF2FA";
            break;
        case "StringConcat":
            backgroundColor="#FDF2FA";
            break;
        case "StringLowerCase":
            backgroundColor="#FDF2FA";
            break;
        case "StringUpperCase":
            backgroundColor="#FDF2FA";
            break;
        case "StringLength":
            backgroundColor="#FDF2FA";
            break;
        case "SubString":
            backgroundColor="#FDF2FA";
            break;
        case "StringExist":
            backgroundColor="#FDF2FA";
            break;
        case "StringTokenizer":
            backgroundColor="#FDF2FA";
            break;
        case "StringEquals":
            backgroundColor="#FDF2FA";
            break;
        case "GetHost":
            backgroundColor="#F0F9FF";
            break;
        case "GetPort":
            backgroundColor="#F0F9FF";
            break;
        case "GetProtocolHandler":
            backgroundColor="#F0F9FF";
            break;
        case "RestServices":
            backgroundColor="#EAECF5";
            break;
        
    }
    return backgroundColor;
}




export const highlightActivityBorder=(activityName)=>{
    let borderColor="";
    switch(activityName){
        case "CodeBlock":
            borderColor="1px solid #B54708";
            break;
        case "IfElse":
            borderColor="1px Solid #027A48";
            break;
        case "Repeat":
            borderColor="1px Solid #027A48";
            break;
        case "RepeatIf":
            borderColor="1px Solid #027A48";
            break;
        case "ForEach":
            borderColor="1px Solid #027A48";
            break;
        case "PrintOutput":
            borderColor="1px solid #333333";
            break;
        case "Assignment":
            borderColor="1px Solid #4B0082";
            break;
        case "ConnectDatabase":
            borderColor="1px solid #003366";
            break;
        case "FetchRecords":
            borderColor="1px solid #003366";
            break;
        case "UpdateRecords":
            borderColor="1px solid #003366";
            break;
        case "DeleteRecords":
            borderColor="1px solid #003366";
            break;
        case "AddRecords":
            borderColor="1px solid #003366";
            break;
        case "ExecuteProcedure":
            borderColor="1px solid #003366";
            break;
        case "GetCurrentDate":
            borderColor="1px solid #5925DC";
            break;
        case "GetCurrentDateTime":
            borderColor="1px solid #5925DC";
            break;
        case "GetCurrentTime":
            borderColor="1px solid #5925DC";
            break;
        case "DateToString":
            borderColor="1px solid #5925DC";
            break;
        case "ChangeDateFormat":
            borderColor="1px solid #5925DC";
            break;
        case "CheckError": 
            borderColor="1px solid #B42318";
            break;   
        case "ConditionOf":
            borderColor="1px solid #B42318";
            break;
        case "Retry":
            borderColor="1px solid #B42318";
            break;
        case "Exit":
            borderColor="1px solid #B42318";
            break;
        case "FTPConnect":
            borderColor="1px solid #483D8B";
            break;
        case "FTPDownload":
            borderColor="1px solid #483D8B";
            break;
        case "FTPUpload":
            borderColor="1px solid #483D8B";
            break;
        case "FTPCreate":
            borderColor="1px solid #483D8B";
            break;
        case "FTPDelete":
            borderColor="1px solid #483D8B";
            break;
        case "FTPMove":
            borderColor="1px solid #483D8B";
            break;
        case "Group":
            borderColor="1px solid #3538CD";
            break;
        case "GetMails":
            borderColor="1px solid #785600";
            break;
        case "SendMailSMTP":
            borderColor="1px solid #785600";
            break;
        case "DeleteMail":
            borderColor="1px solid #785600";
            break;
        case "SaveMail":
            borderColor="1px solid #785600";
            break;
        case "SaveMailAttachments":
            borderColor="1px solid #785600";
            break;
        case "ConnectMail":
            borderColor="1px solid #785600";
            break;
        case "ForEachMail":
            borderColor="1px solid #785600";
            break;
        case "ServerConnect":
            borderColor="1px solid #BA4A00";
            break;
        case "CreateWorkItem":
            borderColor="1px solid #BA4A00";
            break;
        case "CompleteWorkItem":
            borderColor="1px solid #BA4A00";
            break;
        case "SaveWorkitem":
            borderColor="1px solid #BA4A00";
            break;
        case "GetWorkItem":
            borderColor="1px solid #BA4A00";
            break;
        case "AddDocument":
            borderColor="1px solid #BA4A00";
            break;
        case "GetDocument":
            borderColor="1px solid #BA4A00";
            break;
        case "ConnectXtract":
            borderColor="1px solid #BA4A00";
            break;
        case "ExtractData":
            borderColor="1px solid #BA4A00";
            break;
        case "GetPathFromFullPath":
            borderColor="1px solid #006D75";
            break;
        case "GetAllFoldersFromPath":
            borderColor="1px solid #006D75";
            break;
        case "GetDriveLetter":
            borderColor="1px solid #006D75";
            break;
        case "GetSeparator":
            borderColor="1px solid #006D75";
            break;
        case "GetFileExtension":
            borderColor="1px solid #006D75";
            break;
        case "GetFileNameFromFullPath":
            borderColor="1px solid #006D75";
            break;
        case "StringAfter":
            borderColor="1px solid #C11574";
            break;
        case "StringBefore":
            borderColor="1px solid #C11574";
            break;
        case "StringConcat":
            borderColor="1px solid #C11574";
            break;
        case "StringLowerCase":
            borderColor="1px solid #C11574";
            break;
        case "StringUpperCase":
            borderColor="1px solid #C11574";
            break;
        case "StringLength":
            borderColor="1px solid #C11574";
            break;
        case "SubString":
            borderColor="1px solid #C11574";
            break;
        case "StringExist":
            borderColor="1px solid #C11574";
            break;
        case "StringTokenizer":
            borderColor="1px solid #C11574";
            break;
        case "StringEquals":
            borderColor="1px solid #C11574";
            break;
        case "GetHost":
            borderColor="1px solid #026AA2";
            break;
        case "GetPort":
            borderColor="1px solid #026AA2";
            break;
        case "GetProtocolHandler":
            borderColor="1px solid #026AA2";
            break;
        case "RestServices":
            borderColor="1px solid #4E5BA6";
            break;
        
    }
    return borderColor;
}

export const applyFontColor=(activityName)=>{
    let fontColor="";
    switch(activityName){
        case "CodeBlock":
            fontColor="#B54708";
            break;
        case "IfElse":
            fontColor="#027A48";
            break;
        case "Repeat":
            fontColor="#027A48";
            break;
        case "RepeatIf":
            fontColor="#027A48";
            break;
        case "ForEach":
            fontColor="#027A48";
            break;
        case "PrintOutput":
            fontColor="#333333";
            break;
        case "Assignment":
            fontColor="#4B0082";
            break;
        case "ConnectDatabase":
            fontColor="#003366";
            break;
        case "FetchRecords":
            fontColor="#003366";
            break;
        case "UpdateRecords":
            fontColor="#003366";
            break;
        case "DeleteRecords":
            fontColor="#003366";
            break;
        case "AddRecords":
            fontColor="#003366";
            break;
        case "ExecuteProcedure":
            fontColor="#003366";
            break;
        case "GetCurrentDate":
            fontColor="#5925DC";
            break;
        case "GetCurrentDateTime":
            fontColor="#5925DC";
            break;
        case "GetCurrentTime":
            fontColor="#5925DC";
            break;
        case "DateToString":
            fontColor="#5925DC";
            break;
        case "ChangeDateFormat":
            fontColor="#5925DC";
            break;
        case "CheckError": 
            fontColor="#B42318";
            break;   
        case "ConditionOf":
            fontColor="#B42318";
            break;
        case "Retry":
            fontColor="#B42318";
            break;
        case "Exit":
            fontColor="#B42318";
            break;
        case "FTPConnect":
            fontColor="#483D8B";
            break;
        case "FTPDownload":
            fontColor="#483D8B";
            break;
        case "FTPUpload":
            fontColor="#483D8B";
            break;
        case "FTPCreate":
            fontColor="#483D8B";
            break;
        case "FTPDelete":
            fontColor="#483D8B";
            break;
        case "FTPMove":
            fontColor="#483D8B";
            break;
        case "Group":
            fontColor="#3538CD";
            break;
        case "GetMails":
            fontColor="#785600";
            break;
        case "SendMailSMTP":
            fontColor="#785600";
            break;
        case "DeleteMail":
            fontColor="#785600";
            break;
        case "SaveMail":
            fontColor="#785600";
            break;
        case "SaveMailAttachments":
            fontColor="#785600";
            break;
        case "ConnectMail":
            fontColor="#785600";
            break;
        case "ForEachMail":
            fontColor="#785600";
            break;
        case "ServerConnect":
            fontColor="#BA4A00";
            break;
        case "CreateWorkItem":
            fontColor="#BA4A00";
            break;
        case "CompleteWorkItem":
            fontColor="#BA4A00";
            break;
        case "SaveWorkitem":
            fontColor="#BA4A00";
            break;
        case "GetWorkItem":
            fontColor="#BA4A00";
            break;
        case "AddDocument":
            fontColor="#BA4A00";
            break;
        case "GetDocument":
            fontColor="#BA4A00";
            break;
        case "ConnectXtract":
            fontColor="#BA4A00";
            break;
        case "ExtractData":
            fontColor="#BA4A00";
            break;
        case "GetPathFromFullPath":
            fontColor="#006D75";
            break;
        case "GetAllFoldersFromPath":
            fontColor="#006D75";
            break;
        case "GetDriveLetter":
            fontColor="#006D75";
            break;
        case "GetSeparator":
            fontColor="#006D75";
            break;
        case "GetFileExtension":
            fontColor="#006D75";
            break;
        case "GetFileNameFromFullPath":
            fontColor="#006D75";
            break;
        case "StringAfter":
            fontColor="#C11574";
            break;
        case "StringBefore":
            fontColor="#C11574";
            break;
        case "StringConcat":
            fontColor="#C11574";
            break;
        case "StringLowerCase":
            fontColor="#C11574";
            break;
        case "StringUpperCase":
            fontColor="#C11574";
            break;
        case "StringLength":
            fontColor="#C11574";
            break;
        case "SubString":
            fontColor="#C11574";
            break;
        case "StringExist":
            fontColor="#C11574";
            break;
        case "StringTokenizer":
            fontColor="#C11574";
            break;
        case "StringEquals":
            fontColor="#C11574";
            break;
        case "GetHost":
            fontColor="#026AA2";
            break;
        case "GetPort":
            fontColor="#026AA2";
            break;
        case "GetProtocolHandler":
            fontColor="#026AA2";
            break;
        case "RestServices":
            fontColor="#4E5BA6";
            break;
    }
    return fontColor;
}