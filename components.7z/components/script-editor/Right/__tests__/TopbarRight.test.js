import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "../../../../utils/CustomAppComp";
import TopbarRight from "./../TopbarRight";
import userEvent from "@testing-library/user-event";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  const handleClipboardActions = jest.fn();

  ReactDom.render(
    <CustomAppComp>
      <TopbarRight
        handleClipboardActions={handleClipboardActions}
        scriptValues={scriptValues}
      />
    </CustomAppComp>,
    div
  );
});

it("clicking on Clipboard buttons", () => {
  const handleClipboardActions = jest.fn();

  render(
    <CustomAppComp>
      <TopbarRight
        handleClipboardActions={handleClipboardActions}
        scriptValues={scriptValues}
      />
    </CustomAppComp>
  );
  expect(screen.getByTitle("Cut")).toBeInTheDocument();
  userEvent.click(screen.getByTitle("Cut"));
  expect(handleClipboardActions).toBeCalledTimes(1);
});

it("matches snapshot", () => {
  const handleClipboardActions = jest.fn();

  const tree = renderer
    .create(
      <CustomAppComp>
        <TopbarRight
          handleClipboardActions={handleClipboardActions}
          scriptValues={scriptValues}
        />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const scriptValues = { scriptName: "Test Script", versionName: "V1.0" };
