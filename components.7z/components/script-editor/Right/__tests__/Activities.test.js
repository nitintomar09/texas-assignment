import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "../../../../utils/CustomAppComp";
import Activities from "./../Activities";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  const handleDrop = jest.fn();
  const handleSelectedActivity = jest.fn();
  const handleDrag = jest.fn();
  ReactDom.render(
    <CustomAppComp>
      <Activities
        handleDrag={handleDrag}
        handleDrop={handleDrop}
        dupList={dupList}
        handleSelectedActivity={handleSelectedActivity}
        activitiesList={activitiesList}
        breakpointsArray={[]}
      />
    </CustomAppComp>,
    div
  );
});

it("matches snapshot", () => {
  const handleDrop = jest.fn();
  const handleSelectedActivity = jest.fn();
  const handleDrag = jest.fn();
  const tree = renderer
    .create(
      <CustomAppComp>
        <Activities
          handleDrag={handleDrag}
          handleDrop={handleDrop}
          dupList={dupList}
          handleSelectedActivity={handleSelectedActivity}
          activitiesList={activitiesList}
          breakpointsArray={[]}
        />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const dupList = [{ id: "S", size: "32px" }];
const activitiesList = [
  {
    activityId: 52,
    activityName: "ServerConnect",
    activityType: "S",
    description: "null",
    displayName: "Server Connect",

    params: [
      {
        paramName: "ServerUrl",
        paramObjectTypeId: 1,
        paramState: 0,
        paramType: "C",
        paramValue: "http://52.187.37.117:8080",
        paramrId: 698,
      },
    ],
    subActivities: [],
  },
];
