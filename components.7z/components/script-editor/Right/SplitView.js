import React, { useState, useRef } from 'react';
import { Grid } from '@mui/material';
import Activities from './Activities';
import MainView from '../../microFlowRepresentation/ChartMainView';
import { useSelector,useDispatch } from 'react-redux';
import { useEffect } from 'react';
import { setCollapsedActivities } from '../../../redux/actions';
const SplitView = ({ 
  id, 
  activitiesList, 
  handleCollapsedActivities, 
//  collapsedActivities, 
  handleDrop, 
  dupList, 
  handleDrag, 
  addOrRemoveElseAct, 
  handleClipboardActions, 
  script,
  updateNodePosition,
  handleSave,
  updateNodes,
  nodes,
  addEdgeItem,
  getEdgeItem,
  preserveNodeState,
  getPreviousNodeState,
  preserveExcludedChildState,
  restoreChildState,
  activeTab,
}) => {
  // Initial xs value for the left grid(Spliting window)
  
  const [leftGridSize, setLeftGridSize] = useState(6); 
  const isResizing = useRef(false);
  const { collapsedActivities } = useSelector((state) => state.editorHomepage);
  
  const handleMouseDown = (e) => {
    isResizing.current = true;
    document.body.style.cursor = 'col-resize';
  };
  const dispatch=useDispatch();
console.log(collapsedActivities,"collapsedActivitess")
  const handleMouseMove = (moveEvent) => {
    if (!isResizing.current) return;

    const delta = moveEvent.clientX / window.innerWidth * 12;
    let newSize = Math.max(2, Math.min(delta, 10));

    if(newSize<3){
      //Keep the min width to 3 grid for list view
      setLeftGridSize(3);
    }else{
      setLeftGridSize(newSize);
    }
  };

  const handleMouseUp = () => {
    if (isResizing.current) {
      isResizing.current = false;
      document.body.style.cursor = 'default';
    }
  };

  React.useEffect(() => {
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  useEffect(()=>{
dispatch(setCollapsedActivities([]));
  },[])

  return (
    <div style={{display: 'grid', gridTemplateColumns: `${(leftGridSize / 12) * 100}% 5px auto`, height: '100%'}}>
      <div style={{ overflow: 'auto' }}>
        <Activities
          id={id}
          activitiesList={activitiesList}
          handleCollapsedActivities={handleCollapsedActivities}
          collapsedActivities={collapsedActivities}
          handleDrop={handleDrop}
          dupList={dupList}
          handleDrag={handleDrag}
          addOrRemoveElseAct={addOrRemoveElseAct}
          handleClipboardActions={handleClipboardActions}
        //updateNodes={updateNodes}
          nodes={nodes}
          activeTab={activeTab}
        />
      </div>

      <div
        style={{
          cursor: 'col-resize',
          backgroundColor: '#ccc',
          width: '2px',
          userSelect: 'none',
        }}
        onMouseDown={handleMouseDown}
      />

      <div style={{ overflow: 'auto' }}>
        <MainView 
        activitiesList={activitiesList}
         collapsedActivities={collapsedActivities} 
         handleCollapsedActivities={handleCollapsedActivities} 
         updateNodePosition={updateNodePosition} 
         handleSave={handleSave} 
         updateNodes={updateNodes}
         script={script} 
         addEdgeItem={addEdgeItem}
        getEdgeItem={getEdgeItem}
        preserveNodeState={preserveNodeState}
        getPreviousNodeState={getPreviousNodeState}
        preserveExcludedChildState={preserveExcludedChildState}
        restoreChildState={restoreChildState}
         />
      </div>
    </div>
  );
};

export default SplitView;
