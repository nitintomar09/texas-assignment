import React, { useState, useEffect, useRef } from "react";
import makeStyles from "@mui/styles/makeStyles";
import { Grid, Backdrop, CircularProgress, Typography } from "@mui/material";
import TopbarRight from "./TopbarRight";
import Activities from "./Activities";
import MainView from "../../microFlowRepresentation/ChartMainView";
import _ from "lodash";
import ModalForm from "../../../utils/modalForm";
import { useSelector, useDispatch } from "react-redux";
import { setActiveTab } from "../../../redux/actions";
import SplitView from "./SplitView";
import useCustomHookForNodesState from "../../microFlowRepresentation/Edges/Customhook";
const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    //height: "650px",
    maxHeight: "630px",
    // backgroundColor: "#F0F0F0",
    // backgroundColor: "#F0F0F0",
    background: "#F8F8F8",
  },
  backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: "#fff",
  },
  reactFlowWrapper: {
    flexGrow: 1,
    display: "flex",
    flexDirection: "column",
    height: "calc(100% - 48px)", // Adjust this height based on the height of your tab buttons
  },
}));
const MainRight = (props) => {
  const dispatch = useDispatch();
  console.log(props, "setAcriveTab");
  const {
    activitiesList,

    handleDrop,
    handleDrag,

    dupList,
    handleClipboardActions,
    openDialog,
    setOpenDialog,
    addOrRemoveElseAct,
    id,
    changeTab,
    activeTab,
    script,
    setSaveListViewDialog,
    saveListViewDialog,
    updateNodePosition,
    saveScriptRules,
    staus,
  } = props;
  console.log(props, "statayusqu");

  const resizableRef = useRef(null);
  const [collapsedActivities, setCollapsedActivities] = useState({});
  const [initialPositions, setInitialPositions] = useState({}); // Store initial positions
  const [isHovered, setIsHovered] = useState(false);
  const [leftWidth, setLeftWidth] = useState(5); // Left grid item width
  const [rightWidth, setRightWidth] = useState(7); // Right grid item width
  const [nodes, setNodes] = useState([]);

  console.log(props.activitiesList, "activitiesList");
  const {
    addEdgeItem,
    getEdgeItem,
    preserveNodeState,
    getPreviousNodeState,
    preserveExcludedChildState,
    restoreChildState,
  } = useCustomHookForNodesState();
  //const [openDialog,setOpenDialog]=useState(false);
  const getNodePositions = (activities) => {
    const positions = {};
    activities.forEach((activity) => {
      console.log(activity, "activityyyyyy");
      positions[activity.activityId] = {
        x: activity.positionXCoordinate,
        y: activity.positionYCoordinate,
      };
      if (activity.subActivities) {
        Object.assign(positions, getNodePositions(activity.subActivities));
      }
      if (activity.thenActivities && activity.thenActivities.length > 0) {
        Object.assign(positions, getNodePositions(activity.thenActivities));
      }
      if (activity.elseActivities && activity.elseActivities.length > 0) {
        Object.assign(positions, getNodePositions(activity.elseActivities));
      }
      if (activity.checkError && activity.checkError.length > 0) {
        Object.assign(positions, getNodePositions(activity.checkError));
      }
      if (activity.onError && activity.onError.length > 0) {
        Object.assign(positions, getNodePositions(activity.onError));
      }
    });
    return positions;
  };

  // Check if positions have changed between initial and current
  const havePositionsChanged = () => {
    const currentPositions = getNodePositions(activitiesList);
    console.log(activitiesList, "activitiesListt");
    for (const [id, pos] of Object.entries(initialPositions)) {
      if (
        pos.x !== currentPositions[id]?.x ||
        pos.y !== currentPositions[id]?.y
      ) {
        return true; // Positions have changed
      }
    }

    return false; // No changes
  };
  const collapseActivities = (activities, collapsedActivitiesLocal) => {
    let listOfCollapsedActivities = _.cloneDeep(collapsedActivities);
    console.log(collapsedActivities);
    activities.forEach((activity) => {
      console.log(activity);
      if (activity.activityType === "G" || activity.activityType === "S") {
        listOfCollapsedActivities[activity.uid] = {};
        if (activity.subActivities) {
          collapseActivities(
            activity.subActivities,
            listOfCollapsedActivities[activity.uid]
          );
        } else if (activity.activityName === "IfElse") {
          collapseActivities(
            activity.thenActivities || [],
            listOfCollapsedActivities[activity.uid]
          );
          collapseActivities(
            activity.elseActivities || [],
            listOfCollapsedActivities[activity.uid]
          );
        } else if (activity.activityName === "CheckError") {
          collapseActivities(
            activity.checkError || [],
            listOfCollapsedActivities[activity.uid]
          );
          collapseActivities(
            activity.onError || [],
            listOfCollapsedActivities[activity.uid]
          );
        }
      }
    });
    setCollapsedActivities(listOfCollapsedActivities);
  };

  const handleClose = () => {
    dispatch(setActiveTab("Flow Chart"));
    setOpenDialog(false);
  };

  const handleListViewClose = () => {
    dispatch(setActiveTab("Script"));
    setSaveListViewDialog(false);
  };
  const handleSave = () => {
    // Call saveScriptRules and pass a callback to switch the tab after saving
    saveScriptRules(() => {
      // After successfully saving the script, close the dialog and switch the tab
      setOpenDialog(false);
      // setActiveTab("Script");
      dispatch(setActiveTab("Script"));
    });
  };

  const handleSaveListView = () => {
    // Call saveScriptRules and pass a callback to switch the tab after saving
    saveScriptRules(() => {
      // After successfully saving the script, close the dialog and switch the tab
      setSaveListViewDialog(false);

      dispatch(setActiveTab("Flow Chart"));
    });
  };

  const updateNodes = (data) => {
    setNodes(data);
  };

  const handleCollapsedActivities = (selectedActivitiesToCollapse) => {
    setCollapsedActivities(selectedActivitiesToCollapse);
  };

  const handleTabChange = (tab) => {
    if (tab === "Script") {
      // Check if positions have changed
      if (havePositionsChanged()) {
        setOpenDialog(true); // Show dialog if positions changed
      } else {
        dispatch(setActiveTab("Script")); // No changes, switch directly
      }
    } else {
      if (props.status == "Design Mode") {
        setSaveListViewDialog(true);
      } else dispatch(setActiveTab("Flow Chart"));

      if (tab === "Flow Chart") {
        setInitialPositions(getNodePositions(activitiesList));
      }
    }
  };

  const classes = useStyles();
  const isSavingRules = useSelector(
    (state) => state.editorHomepage.isSavingRules
  );
  const isGettingRules = useSelector((state) => state.script.isGettingRules);
  const handleMouseDown = (e) => {
    e.preventDefault(); // Prevent default behavior

    const startX = e.clientX;

    const mouseMoveHandler = (e) => {
      const deltaX = e.clientX - startX;
      let newLeftWidth = leftWidth + Math.floor(deltaX / 10);
      let newRightWidth = 12 - newLeftWidth;

      if (newLeftWidth < 3 || newRightWidth < 3) {
        newLeftWidth = 6;
        newRightWidth = 6; // Ensure total width remains 12
      } else {
        newLeftWidth = Math.max(1, Math.min(12, newLeftWidth));
        newRightWidth = Math.max(1, Math.min(12, newRightWidth));
      }

      setLeftWidth(newLeftWidth);
      setRightWidth(newRightWidth);
    };

    const mouseUpHandler = (e) => {
      console.log(e, "hovereddd");
      window.removeEventListener("mousemove", mouseMoveHandler);
      window.removeEventListener("mouseup", mouseUpHandler);
    };

    window.addEventListener("mousemove", mouseMoveHandler);
    window.addEventListener("mouseup", mouseUpHandler);
    console.log(e, "hovereddd");
  };

  return (
    <>
      <Backdrop
        className={classes.backdrop}
        open={isSavingRules ? isSavingRules : isGettingRules}
      >
        <CircularProgress color="primary" />
      </Backdrop>
      <Grid container className={classes.root} direction="column">
        <Grid item>
          <TopbarRight
            id={id}
            handleClipboardActions={handleClipboardActions}
            handleTab={handleTabChange}
            activeTab={activeTab}
          />
        </Grid>
        {activeTab === "Script" && (
          <Grid item>
            <Activities
              id={id}
              activitiesList={activitiesList}
              handleCollapsedActivities={handleCollapsedActivities}
              collapsedActivities={collapsedActivities}
              handleDrop={handleDrop}
              dupList={dupList}
              handleDrag={handleDrag}
              addOrRemoveElseAct={addOrRemoveElseAct}
              handleClipboardActions={handleClipboardActions}
              updateNodes={updateNodes}
              activeTab={activeTab}
            />
          </Grid>
        )}
        {activeTab === "Flow Chart" && (
          <Grid item>
            <SplitView
              id={id}
              activitiesList={activitiesList}
              handleCollapsedActivities={handleCollapsedActivities}
              collapsedActivities={collapsedActivities}
              handleDrop={handleDrop}
              dupList={dupList}
              handleDrag={handleDrag}
              addOrRemoveElseAct={addOrRemoveElseAct}
              handleClipboardActions={handleClipboardActions}
              script={script}
              updateNodePosition={updateNodePosition}
              handleSave={handleSave}
              updateNodes={updateNodes}
              nodes={nodes}
              addEdgeItem={addEdgeItem}
              getEdgeItem={getEdgeItem}
              preserveNodeState={preserveNodeState}
              getPreviousNodeState={getPreviousNodeState}
              preserveExcludedChildState={preserveExcludedChildState}
              restoreChildState={restoreChildState}
             activeTab={activeTab}
            />
          </Grid>
        )}

        {openDialog && (
          <>
            <ModalForm
              containerWidth={"600px"}
              containerHeight={"200px"}
              isOpen={openDialog}
              title="Save Changes"
              description="Please ensure you save the flow before switching to 'Flow Chart' View."
              headerCloseBtn
              onClick2={handleSave}
              onClick1={handleClose}
              btn1Title="Cancel"
              btn2Title="Save"
              onClickHeaderCloseBtn={() => setOpenDialog(false)}
            />
          </>
        )}

        {saveListViewDialog && (
          <>
            <ModalForm
              containerWidth={"600px"}
              containerHeight={"200px"}
              isOpen={saveListViewDialog}
              title="Save Changes"
              description="Please ensure you save the Script before switching to the Split View."
              headerCloseBtn
              onClick2={handleSaveListView}
              onClick1={handleListViewClose}
              btn1Title="Cancel"
              btn2Title="Save"
              onClickHeaderCloseBtn={() => setSaveListViewDialog(false)}
            />
          </>
        )}
      </Grid>
    </>
  );
};

export default MainRight;
