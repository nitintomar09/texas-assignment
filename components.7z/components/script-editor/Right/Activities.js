import React, { useEffect, useRef, useState } from "react";
import makeStyles from "@mui/styles/makeStyles";
import { Grid, Typography, Button, Collapse, Paper } from "@mui/material";
import { ExpandLess, ExpandMore, PausePresentation } from "@mui/icons-material";
import DragIndicatorIcon from "@mui/icons-material/DragIndicator";
import {
  highlightActivity,
  highlightActivityBorder,
  applyFontColor,
} from "./HighlightActivity";
import {
  DropdownIcon,
  InformationIcon1,
  WarningIcon,
  WarningIcon1,
  IconExpanded,
  CloseIcon,
  IconCollapsed,
  CollapseIcon,
} from "../../../utils/AllImages";
import { useSelector, useDispatch } from "react-redux";
import { API_BASE_URL, ICONS } from "../../../config";
import {
  handleBreakpointsArray,
  handleSelectedActivity,
} from "../../../redux/actions";
import MenuPopper from "../../../utils/MenuPopper2";
import CustomTooltip from "../../../utils/CustomTooltip";
import { setCollapsedActivities } from "./../../../redux/EditorHomepage/actions";
import { UniqueIDGenerator } from "../../../utils/UniqueIDGenerator";
import { generateUniqueId } from "../../../utils/common";
import { ReactSVG } from "react-svg";
import useExpandCollapse from "../../microFlowRepresentation/HandleSyncingOperation";
import { DragIndicator } from "../../../utils/AllImages";
import DropGrid from "../../../../src/assets/DropGrid.png";
const useStyles = makeStyles((theme) => ({
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "10px",
    },
  },
  root: {
    paddingTop: "12.5px",
    paddingLeft: "15px",
    paddingRight: "28px",

    maxHeight: (props) => {
      return props.windowInnerHeight - 144 || "500px";
    },
    overflow: "hidden",

    "&:hover": {
      overflowY: "auto",
    },

    fontSize: "12px",
  },
  root1: {
    paddingTop: "12.5px",
    paddingLeft: "15px",
    paddingRight: "28px",
    height: "532px",
    fontSize: "12px",
    textAlign: "center",
    display: "flex",
    alignItems: "top",
    justifyContent: "center",
    //boxShadow: "0px 3px 6px 0px #00000029",

    background: "#F8F8F8",
    //border: "1px solid #606060",
  },

  text_light: {
    fontSize: "12px",
    fontWeight: 600,
    color: "#606060",
  },
  text_white: {
    fontSize: "12px",
    fontWeight: 600,
    color: "#FFFFFF",
  },
  description: {
    color: "#767676",
    fontSize: "12px",
  },
  description1: {
    color: "#000000",
    fontSize: "12px",
  },
  descriptionAct: {
    color: "#000000",
    fontSize: "12px",
    fontWeight: "400",
    fontFamily: "Open Sans",
  },
  descriptionActParam: {
    color: "#606060",
    fontSize: "10px",
    fontWeight: "400",
    fontFamily: "Open Sans",
  },
  countClass: {
    height: "46px",
    marginBottom: "8px",
  },
  text_12: {
    fontSize: "12px",
  },

  activity: {
    minHeight: "28px",
    //height: "32px",
    cursor: "pointer",
    backgroundColor: "#FFFFFF",
    marginBottom: "10px",
    paddingLeft: "8px",
    //border: `1px solid #C4C4C4`,
    borderRadius: "4px",
    // "&:hover": {
    //   border: `1px solid #0072C6`,
    //   backgroundColor: "lightblue",
    // },
  },
  groupActivity: {
    minHeight: "28px",
    //height: "32px",
    backgroundColor: "#FFFFFF",
    marginBottom: "6px",
    paddingLeft: "8px",
    cursor: "pointer",
    //border: `1px solid #C4C4C4`,
    borderRadius: 2,
    // "&:hover": {
    //   border: `1px solid #0072C6`,
    //   backgroundColor: "lightblue",
    // },
  },
  // childGroupActivity: {
  //   minHeight: "32px",
  //   //height: "32px",
  //   backgroundColor: "#FFFFFF",
  //   marginBottom: "8px",
  //   paddingLeft: "8px",
  //   cursor: "pointer",
  //   //border: `1px solid #C4C4C4`,
  //   borderRadius: 2,
  //   // "&:hover": {
  //   //   border: `1px solid #0072C6`,
  //   //   color: "lightblue",
  //   // },
  // },mainColumn
  mainColumn: {
    marginLeft: "2px",
    display: "flex",
  },
  borderCol: {
    borderLeft: `2px solid #C1C1C1`,
  },
  container: {
    display: "flex",
  },
  marginAndBorderParentActivity: {
    marginBottom: "8px",
    backgroundColor: "#FFFFFF",
    //marginLeft:"15px",
    paddingTop: "7px",
    paddingBottom: "0px",
    paddingRight: "6px",
    paddingLeft: "6px",
    borderRadius: "4px",

    //borderLeft: `1px solid #C4C4C4`,
  },

  marginAndBorderCollapsedActivities: {
    marginBottom: "8px",

    backgroundColor: "#FFFFFF",
    //marginLeft:"15px",
    paddingTop: "5px",
    paddingBottom: "0px",
    paddingRight: "5px",
    paddingLeft: "5px",
    borderRadius: "4px",
  },
  marginAndBorderParentActivityWhenSelected: {
    marginBottom: "8px",

    backgroundColor: "#FFFFFF",
    padding: "8px",
    paddingBottom: "4px",
    borderRadius: "4px",
    //borderLeft: `1px solid ${theme.palette.primary.main}`,
  },

  marginAndBorderChildActivity: {
    paddingLeft: "15px",
  },
  marginAndBorderChildGroupActivity: {
    paddingLeft: "15px",
    backgroundColor: "#FFFFFF",
    borderRadius: "4px",
    //borderLeft: "1px solid #D3D3D3",
  },
  BorderOnError: {
    // borderLeft: `1px solid #C4C4C4`,
  },
  BorderOnErrorWhenSelected: {
    //borderLeft: `1px solid ${theme.palette.primary.main}`,
  },
  onDrag: {
    zIndex: 12,
    //borderBottom: `28px solid #F2F8FC`,
    //Bug 155396 - Drop here activities is getting displayed on the incorrect position
    //Author: Dixita Ruhela
    //Date: 08 JAN 2025
    //Description: Grid class updated with Border properties
    borderWidth: "0 0 28px 0", // Only apply border width to the bottom
    borderStyle: "solid",
    borderImageSource: `url(${DropGrid})`, // Path to your image
    borderImageSlice: 30,
  },
  // border: {
  //   boxShadow: `1px 1px 4px 1px ${theme.palette.primary.main}`,
  // },
  // errorBorder: {
  //   boxShadow: `1px 1px 4px 1px #D53D3D`,
  // },
  marginBottomCount: {
    marginBottom: "5px",
  },
  draged: {
    // border: `1px solid black`,
  },
  endOfGroupActivity: {
    minHeight: "32px",
    //height: "32px",
    fontSize: "12px",
    paddingLeft: "5px",
    paddingTop: "8px",
    backgroundColor: "#C4C4C4",
    border: `1px solid #E6E6E6`,
    borderRadius: 2,
  },
  debugPause: {
    border: "3px solid #0072C6",
    borderRadius: "2px",
  },
  errorAct: {
    border: "3px solid #FF0000",
    borderRadius: "2px",
  },
  groupActivityImg: {
    margin: "5px",
    width: "14px",
    height: "14px",
    border: `1px solid #000000`,
  },
  childActivityImg: {
    margin: "5px",
    width: "14px",
    height: "14px",
    border: `1px solid ${theme.palette.primary.main}`,
  },
  parentActivityFont: {
    fontSize: "12px",
    fontWeight: 600,
  },
  childParentFont: {
    fontSize: "12px",
    fontWeight: 600,
  },
  childFont: {
    fontSize: "12px",
    fontWeight: 600,
    color: `${theme.palette.primary.main}`,
  },
  expandIcon: {
    cursor: "pointer",
    marginTop: "5px",
    marginRight: "-15px",
  },
  icons: { width: "12px", height: "12px", marginTop: "3px" },
  dropdownIcon: { width: "16px", height: "16px", marginTop: "3px" },
  thenActivity: {
    minHeight: "28px",
    //height: "32px",
    //color:"#027A48",
    backgroundColor: "#F8F8F8",
    marginBottom: "8px",
    paddingLeft: "5px",
    paddingTop: "8px",
    //alignContent: "center",
    //justifyContent:"center",
    // cursor: "pointer",
    //border: "1px solid #E6E6E6",
    // borderRadius: 2,
  },
  // disbaleAct: {
  //   boxShadow: `inset 5px 10px 13px 0px #d5d5d5`,
  // },
  versionMismatch: {
    height: "40px",
    //cursor: "pointer",
    backgroundColor: "#F7EFE5",
    marginBottom: "8px",
    paddingLeft: "8px",
    border: `1px solid #E6E6E6`,
    borderRadius: 2,
  },
  versionDeprecated: {
    height: "32px",
    //cursor: "pointer",
    backgroundColor: "#D53D3D",
    // marginBottom: "8px",
    paddingLeft: "8px",
    border: `1px solid #E6E6E6`,
    borderRadius: 2,
  },
}));
const allOperators = [
  { name: "=", value: 1 },
  { name: "<", value: 2 },
  { name: ">", value: 3 },
  { name: "<=", value: 4 },
  { name: ">=", value: 5 },
  { name: "!=", value: 6 },
  { name: "isLike", value: 7 },
  { name: "notLike", value: 8 },
  { name: "isNull", value: 9 },
  { name: "notNull", value: 10 },
];
const activityMoreOptions = [
  "Cut",
  "Copy",
  "Paste in Next Line",
  "Enable Breakpoint",
  "Disable Activity",
];

const Activity = React.forwardRef((props, ref) => {
  const windowInnerHeight = useSelector(
    (state) => state.appGlobalState.windowInnerHeight
  );

  const classes = useStyles({ windowInnerHeight });
  const {
    activitiesArr,
    handleDrag,
    handleDrop,
    handleCollapsedActivities,
    //  collapsedActivities,
    addOrRemoveElseAct,
    handleClipboardActions,
    id,
    nodes,
    activeTab,
  } = props;

  const dispatch = useDispatch();
  const debugDetails = useSelector(
    (state) => state.editorHomepage.debugDetails
  );
  const selectedActivity = useSelector(
    (state) => state.editorHomepage.selectedActivity
  );
  const focusItemId = useSelector((state) => state.editorHomepage.focusItemId);
  const errorActivity = useSelector(
    (state) => state.editorHomepage.errorActivity
  );

  const currentCustomActivitiesGroups = useSelector(
    (state) => state.editorLeftPanel.currentCustomActivitiesGroups
  );
  const { breakpointsArray } = useSelector((state) => state.editorHomepage);
  const collapsedActivities = useSelector(
    (state) => state.editorHomepage.collapsedActivities
  );
  const uuidsAgainstRuleOrderIds = useSelector(
    (state) => state.editorHomepage.uuidRuleOrderId
  );
  const handleClickCollapse = (uid) => {
    const list = { ...collapsedActivities };
    if (list[`${uid}`]) {
      delete list[`${uid}`];
    } else {
      list[`${uid}`] = {};
    }
    handleCollapsedActivities(list);
  };

  const { handleClickToCollapse } = useExpandCollapse(
    null,
    uuidsAgainstRuleOrderIds,
    collapsedActivities,
    null,
    activitiesArr,
    nodes,
    activeTab
  );

  // const handleClickToCollapse = (id,activity) => {
  //   debugger
  //   const uuid = uuidsAgainstRuleOrderIds.filter(
  //     (payload) => payload.uuid == id
  //   )[0].uuid;

  //   console.log(collapsedActivities,"collapsedActivitieee",activity)

  //   const element = collapsedActivities.filter((id) => id === uuid);
  //   const collapsed = element.length > 0;

  //   if (collapsed) {
  //     // Remove from collapsed activities
  //     dispatch(
  //       setCollapsedActivities(collapsedActivities.filter((id) => id !== uuid))
  //     );
  //   } else {
  //     dispatch(setCollapsedActivities([...collapsedActivities, uuid]));
  //   }
  // };
  //   let collActs = [...collapsedActivities];
  //   if (collapsedActivities.includes(id)) {
  //     collActs = collActs.filter((uId) => uId !== id);
  //   } else {
  //     collActs.push(id);
  //   }
  //   dispatch(setCollapsedActivities(collActs));
  // };
  const handleSubListActivities = (uid, selectedList) => {
    const list = { ...collapsedActivities };
    list[`${uid}`] = selectedList;
    handleCollapsedActivities(list);
  };

  const getFontStyle = (activity) => {
    const { childParentFont, childFont, parentActivityFont } = classes;
    if (activity.activityType === "G") {
      return parentActivityFont;
    } else if (activity.activityType === "S") {
      return childParentFont;
    } else {
      return childFont;
    }
  };

  // const getImage = (name,color) => {
  //   //return `${API_BASE_URL}${ICONS}/${name}`;
  // }

  const GetColorImage = ({ name, color }) => {
    let src = `${API_BASE_URL}${ICONS}/${name}color`;

    return <ReactSVG src={src} />;
  };

  const showDescription = (activity) => {
    let desc = null;
    if (activity.customActivity === 2) {
      desc = `Version : ${activity.dependency}`;
      return desc;
    }
    if (3 < activity.activityId < 31) {
      desc =
        activity.params.find((obj) => obj.paramName === "Target")?.paramValue ||
        "";
    }
    switch (activity.activityId) {
      case 2:
        desc =
          activity.params.find((obj) => obj.paramName === "BaseUrl")
            ?.paramValue || "";
        break;
      case 45:
        desc =
          activity.params.find((obj) => obj.paramName === "Server")
            ?.paramValue || "";
        break;
      case 46:
        desc =
          activity.params.find((obj) => obj.paramName === "Output(MailList)")
            ?.paramValue || "";
        break;
      case 51:
        desc =
          activity.params.find((obj) => obj.paramName === "SaveLocation")
            ?.paramValue || "";
        break;

      case 77:
        desc =
          activity.params.find((obj) => obj.paramName === "Operand1")
            ?.paramValue +
            ` ${
              allOperators.find(
                (operator) =>
                  operator.value ==
                  activity.params.find(
                    (obj) => obj.paramName === "OperatorType"
                  )?.paramValue
              )?.name
            } ` +
            activity.params.find((obj) => obj.paramName === "Operand2")
              ?.paramValue ||
          "" ||
          "";
        break;
      case 78:
        desc =
          activity.params.find((obj) => obj.paramName === "Param1")
            ?.paramValue +
            " in " +
            activity.params.find((obj) => obj.paramName === "Param2")
              ?.paramValue || "";
        break;
      case 50:
        desc =
          activity.params.find((obj) => obj.paramName === "docPath")
            ?.paramValue || "";
        break;
      case 91:
        desc =
          activity.params.find((obj) => obj.paramName === "SheetName")
            ?.paramValue || "";
        break;
      case 80:
        desc =
          "Repeat Count: " +
            activity.params.find((obj) => obj.paramName === "RepeatCount")
              ?.paramValue || "";
        break;
      case 83:
        desc =
          activity.params.find((obj) => obj.paramName === "Param1")
            ?.paramValue +
            " = " +
            activity.params.find((obj) => obj.paramName === "Param2")
              ?.paramValue || "null";
        break;
      case 88:
        desc =
          activity.params.find((obj) => obj.paramName === "ExcelFilePath")
            ?.paramValue || "";
        break;
      case 96:
        desc =
          activity.params.find((obj) => obj.paramName === "SelectSheets")
            ?.paramValue || "";
        break;
      case 52:
        desc =
          activity.params.find((obj) => obj.paramName === "ServerUrl")
            ?.paramValue || "";
        break;

      case 53:
        desc =
          ("Process: " +
            activity.params.find((obj) => obj.paramName === "Process")
              ?.paramValue || "") +
          (", Queue: " +
            activity.params.find((obj) => obj.paramName === "Queue")
              ?.paramValue || "");
        break;
      case 90:
        desc =
          "position = " +
            activity.params.find(
              (obj) => obj.paramName === "StartingCellPosition"
            )?.paramValue || "";
        break;
      case 106:
        desc =
          ("Process: " +
            activity.params.find((obj) => obj.paramName === "Process")
              ?.paramValue || "") +
          (", Queue: " +
            activity.params.find((obj) => obj.paramName === "Queue")
              ?.paramValue || "");
        break;
      case 107:
        desc =
          activity.params.find((obj) => obj.paramName === "Param1")
            ?.paramValue +
            " in " +
            activity.params.find((obj) => obj.paramName === "Param2")
              ?.paramValue || "";
        break;
      case 211:
      case 212:
      case 213:
        desc =
          activity.params.find((obj) => obj.paramName === "Url")?.paramValue ||
          "";
        break;
      case 217:
        desc =
          "METHOD: " +
            activity.params.find((obj) => obj.paramName === "Methods")
              ?.paramValue +
            " , URL: " +
            activity.params.find((obj) => obj.paramName === "Endpoint")
              ?.paramValue || "";
        break;
      case 249:
        desc =
          activity.params.find((obj) => obj.paramName === "CSVFile")
            ?.paramValue || "";
        break;
      case 259:
        desc =
          "Host: " +
            activity.params.find((obj) => obj.paramName === "HostName")
              ?.paramValue +
            ", Database Name: " +
            activity.params.find((obj) => obj.paramName === "DatabaseName")
              ?.paramValue || "";
        break;
      case 260:
      case 261:
      case 262:
      case 263:
        const actDescQuery =
          activity.params.find((obj) => obj.paramName === "TableName")
            ?.paramValue || "";
        desc = actDescQuery ? "Table Name: " + actDescQuery : "";
        break;
      case 264:
        const actDesc =
          activity.params.find((obj) => obj.paramName === "ProcedureName")
            ?.paramValue || "";

        desc = actDesc ? "Procedure Name: " + actDesc : "";
        break;
      default:
        break;
    }

    if (desc && desc.indexOf("undefined") == -1 && desc.indexOf("null") == -1) {
      return desc;
    }
    return "";
  };
  /*****************************************************************************************
   * @author asloob.ali BUG ID : 101043 Description : RPA: UI issue while selecting Webdriver activities
   *  Resolution : added trucation while showing name
   *  Date : 09/09/2021             ***************************************************************************************/
  const truncateString = (str) => {
    return str.trim().length > 22 ? str.substring(0, 18) + ".." : str;
  };
  const getMenuOptions = (activity) => {
    let newOptions = [...activityMoreOptions];
    if (breakpointsArray.indexOf(selectedActivity.ruleOrderId) !== -1) {
      newOptions.splice(
        newOptions.findIndex((item) => item === "Enable Breakpoint"),
        1,
        "Disable Breakpoint"
      );
    }
    if (activity?.isDisabled) {
      newOptions.splice(
        newOptions.findIndex((item) => item === "Disable Activity"),
        1,
        "Enable Activity"
      );
      newOptions = newOptions.filter((option) => option === "Enable Activity");
    }

    return newOptions;
  };

  const isInCurrentVersions = (cusAct) => {
    return currentCustomActivitiesGroups.some((grp) => {
      const currAct = grp?.activities.find(
        (item) =>
          item.activityId === cusAct.activityId &&
          item.dependency === cusAct.dependency
      );
      if (currAct) return true;
      return false;
    });
  };
  const isDeprecated = (cusAct) => {
    const isDep = false;
    for (let i = 0; i < currentCustomActivitiesGroups.length; i++) {
      const grp = currentCustomActivitiesGroups[i];
      const currAct = grp?.activities.find(
        (item) =>
          item.activityId === cusAct.activityId &&
          item.dependency === cusAct.dependency
      );
      if (currAct) return grp.isDeprecated;
    }
    return isDep;
  };
  //Drag and Drop Activities Component

  const DragAndDropSpace = () => {
    return (
      <Grid
        item
        xs
        className={classes.thenActivity}
        style={{
          color: "#606060",
          border: "2px dashed #EFEFEF",
          textAlign: "center",
          paddingTop: "0px",
        }}
      >
        <Grid container justifyContent={"flex-start"} alignItems={"center"}>
          <Grid item>
            <DragIndicatorIcon />
          </Grid>
          <Grid item>
            <Typography variant="button">Drop Activities Here.</Typography>
          </Grid>
        </Grid>
      </Grid>
    );
  };
  //const [isHovered, setIsHovered] = useState(false);
  return (
    <>
      {activitiesArr
        //.sort((a, b) => a.ruleOrderId - b.ruleOrderId)
        .map((activity, index) => {
          //apropriate css class for activity

          const activityClass =
            activity.activityType === "G" || activity.activityType === "S"
              ? classes.groupActivity
              : classes.activity;

          // const isParentActivity = activity.subActivities && activity.subActivities.length > 0;
          // const isNotChildActivity = !activitiesArr.some(
          //   (parentActivity) =>
          //   (parentActivity) =>
          //     parentActivity.subActivities &&
          //     parentActivity.subActivities.some(
          //       (subActivity) => subActivity.activityId === activity.activityId
          //     )
          // );
          // const isParentButNotChild = isParentActivity && isNotChildActivity;

          return (
            <Grid
              container
              direction="row"
              className={classes.mainColumn}
              key={index}
            >
              {/*activity.activityType === "G" ||
              activity.activityType === "S" ? (
                <Grid item style={{ marginRight: "8px" }}>
                  {collapsedActivities &&
                  !collapsedActivities.includes(
                    `${activity.uid}`
                  ) ? (
                    <WindowsPropertiesCollapseIcon
                      className={classes.dropdownIcon}
                      onClick={() => handleClickCollapse(activity.uid)}
                    />
                  ) : (
                    <WindowsPropertiesExpandIcon
                      className={classes.dropdownIcon}
                      onClick={() => handleClickCollapse(activity.uid)}
                    />
                  )}
                </Grid>
                  ) : null*/}

              <Grid item xs>
                <Grid
                  container
                  direction="column"
                  className={
                    activity.activityType === "G" ||
                    activity.activityType === "S"
                      ? selectedActivity &&
                        selectedActivity.activityId === activity.activityId &&
                        selectedActivity.ruleOrderId === activity.ruleOrderId
                        ? classes.marginAndBorderParentActivityWhenSelected
                        : activity.isDisabled
                        ? classes.disbaleAct +
                          " " +
                          classes.marginAndBorderParentActivity
                        : collapsedActivities &&
                          collapsedActivities.includes(activity.uid)
                        ? classes.marginAndBorderCollapsedActivities
                        : classes.marginAndBorderParentActivity
                      : //:classes.marginAndBorderChildActivity
                        ""
                  }
                  // className={(activity.activityType === "G" ||
                  //    activity.activityType === "S" )&& (activity.subActivities)&&(collapsedActivities && !collapsedActivities.includes(activity.uid))?
                  //   classes.marginAndBorderChildGroupActivity:
                  //   classes.marginAndBorderChildActivity
                  //   } (activity.subActivities&&activity.subActivities.length>1 && collapsedActivities &&  !collapsedActivities.includes(activity.uid))?
                  // classes.marginAndBorderChildGroupActivity:
                  onDrop={(e) => {
                    e.preventDefault();
                    e.currentTarget.classList.remove(`${classes.onDrag}`);
                    let ele = document.getElementById("dropPlace");
                    if (ele) {
                      ele.remove();
                    }
                    handleDrop({
                      e,
                      activityWhereDroped: activity,
                      AddParallelToGroupActivity: "AddNextToGroupActivity",
                    });

                    e.stopPropagation();
                  }}
                  onDragEnter={(e) => {
                    e.preventDefault();

                    e.currentTarget.classList.add(`${classes.onDrag}`);

                    e.stopPropagation();
                  }}
                  onDragOver={(e) => {
                    e.preventDefault();
                    e.currentTarget.classList.add(`${classes.onDrag}`);

                    e.stopPropagation();
                  }}
                  onDragLeave={(e) => {
                    e.preventDefault();

                    e.currentTarget.classList.remove(`${classes.onDrag}`);

                    e.stopPropagation();
                  }}
                >
                  <Grid
                    item
                    container
                    direction="row"
                    title={
                      activity.customActivity === 2 &&
                      !isInCurrentVersions(activity)
                        ? `You have selected the ${
                            activity?.dependency || "unknown"
                          } of this activity for the script. Please remove it from script, drag/drop from the activity panel and configure it or revert back to previous version.`
                        : ""
                    }
                  >
                    <Grid item xs>
                      <Grid
                        container
                        className={
                          (selectedActivity &&
                            selectedActivity.activityId ===
                              activity.activityId &&
                            selectedActivity.ruleOrderId ===
                              activity.ruleOrderId) ||
                          focusItemId === activity.ruleOrderId
                            ? activityClass
                            : debugDetails &&
                              debugDetails.ruleOrderId === activity.ruleOrderId
                            ? activityClass + " " + classes.debugPause
                            : errorActivity &&
                              errorActivity.ruleOrderId === activity.ruleOrderId
                            ? activityClass + " " + classes.errorAct
                            : activityClass
                        }
                        direction="row"
                        alignItems="center"
                        ref={
                          (debugDetails &&
                            debugDetails.ruleOrderId ===
                              activity.ruleOrderId) ||
                          (errorActivity &&
                            errorActivity.ruleOrderId ===
                              activity.ruleOrderId) ||
                          focusItemId === activity.ruleOrderId
                            ? ref
                            : null
                        }
                        onDrop={(e) => {
                          e.preventDefault();

                          let ele = document.getElementById("dropPlace");
                          if (ele) {
                            ele.remove();
                          }
                          if (
                            activity.activityName !== "IfElse" &&
                            activity.activityName !== "CheckError"
                          ) {
                            handleDrop({ e, activityWhereDroped: activity });
                          } else if (activity.activityName === "CheckError") {
                            handleDrop({
                              e,
                              activityWhereDroped: activity,
                              insideError: "CheckError",
                            });
                          }
                          e.stopPropagation();
                        }}
                        onDragEnter={(e) => {
                          e.preventDefault();
                          if (activity.activityName !== "IfElse") {
                            let tempElement = document.createElement("hr");
                            //tempElement.style.borderTop = "2px dashed #0072c6";
                            tempElement.style.borderWidth = "0 0 28px 0";
                            tempElement.style.borderStyle = "solid";
                            tempElement.style.borderImageSource = `url(${DropGrid})`;
                            tempElement.style.borderImageSlice = 30;
                            tempElement.setAttribute("id", "dropPlace");

                            e.currentTarget.insertAdjacentElement(
                              "afterend",
                              tempElement
                            );
                          }

                          e.stopPropagation();
                        }}
                        onDragOver={(e) => {
                          e.preventDefault();

                          e.stopPropagation();
                        }}
                        onDragLeave={(e) => {
                          e.preventDefault();

                          let ele = document.getElementById("dropPlace");
                          if (ele) {
                            ele.remove();
                          }
                          e.stopPropagation();
                        }}
                        draggable
                        onDragEnd={(e) => {
                          e.currentTarget.classList.remove(`${classes.draged}`);
                        }}
                        onDragStart={(e) => {
                          e.currentTarget.classList.add(`${classes.draged}`);
                          handleDrag(e, activity);
                        }}
                        style={{
                          paddingRight: "5px",

                          border:
                            activity.customActivity === 2 &&
                            !isInCurrentVersions(activity)
                              ? "1px solid #AD6503"
                              : activity.customActivity === 2 &&
                                isDeprecated(activity)
                              ? "1px solid #D53D3D"
                              : (selectedActivity &&
                                  selectedActivity.activityId ===
                                    activity.activityId &&
                                  selectedActivity.ruleOrderId ===
                                    activity.ruleOrderId) ||
                                focusItemId === activity.ruleOrderId
                              ? highlightActivityBorder(activity.activityName) // Background color when selected or focused
                              : activity.activityType === "S"
                              ? "#F0FCF4"
                              : "",

                          backgroundColor:
                            (selectedActivity &&
                              selectedActivity.activityId ===
                                activity.activityId &&
                              selectedActivity.ruleOrderId ===
                                activity.ruleOrderId) ||
                            focusItemId === activity.ruleOrderId
                              ? highlightActivity(activity.activityName) // Background color when selected or focused
                              : activity.activityType === "S"
                              ? highlightActivity(activity.activityName)
                              : "",

                          "&:hover": {
                            backgroundColor: activity.isDisabled
                              ? "#f0f0f0"
                              : "lightblue",
                          },
                        }}
                        //WCAG Keyboard Accessible : [19-06-2023] Added tabIndex and onKeyPress
                        tabIndex={0}
                        onKeyPress={(e) =>
                          e.key === "Enter" &&
                          dispatch(handleSelectedActivity(activity))
                        }
                        id={`${id}_${activity.activityName}_${
                          activity.uid ? activity.uid : activity.ruleOrderId
                        }`}
                      >
                        <Grid
                          item
                          xs
                          onClick={() =>
                            dispatch(handleSelectedActivity(activity))
                          }
                        >
                          <Grid
                            container
                            direction="row"
                            spacing={1}
                            justifyItems={"center"}
                            alignItems={"center"}
                          >
                            {/* // onMouseEnter={() => setIsHovered(true)}
                            //  onMouseLeave={() => setIsHovered(false)} */}
                            <Grid item>
                              {/* <img
                                src={getImage(activity.activityName,applyFontColor(activity.activityName))}
                                className={classes.icons}
                                alt={`${activity.activityName} Icon`}
                              /> */}
                              <GetColorImage
                                name={activity.activityName}
                                color={applyFontColor(activity.activityName)}
                              />
                            </Grid>
                            {/* <Grid item title={activity.activityName || ""}>
                              <Typography className={getFontStyle(activity)} style={{color:applyFontColor(activity.activityName)}}>
              
                                {truncateString(activity.activityName || "")}
                              </Typography>
                            </Grid> */}

                            <Grid item title={activity.displayName || ""}>
                              <Typography
                                className={getFontStyle(activity)}
                                style={{
                                  color: applyFontColor(activity.activityName),
                                }}
                              >
                                {truncateString(activity.activityName || "")}:
                              </Typography>
                            </Grid>
                            <Grid item title={activity.displayName || ""}>
                              <Typography className={classes.descriptionAct}>
                                {truncateString(activity.displayName || "")}
                              </Typography>
                            </Grid>
                          </Grid>
                        </Grid>
                        <Grid
                          item
                          style={{ marginRight: "5px" }}
                          // className={
                          //   activity.activityType === "G" ||
                          //   activity.activityType === "S"
                          //     ? classes.description1
                          //     : classes.descriptionAct
                          // }
                          className={classes.descriptionActParam}
                          title={showDescription(activity)}
                        >
                          {showDescription(activity).trim().length > 76
                            ? showDescription(activity).substring(0, 76) + ".."
                            : showDescription(activity)}
                        </Grid>
                        {activity.customActivity === 2 &&
                          isDeprecated(activity) && (
                            <Grid
                              item
                              style={{ marginLeft: "auto" }}
                              title="This Custom Activity is Deprecated"
                            >
                              <WarningIcon
                                style={{
                                  height: "16px",
                                  width: "16px",
                                  marginTop: "3px",
                                }}
                              />
                            </Grid>
                          )}

                        {activity.activityName === "IfElse" &&
                          (activity.elseActivities &&
                          activity.elseActivities.length === 0 ? (
                            <Grid
                              item
                              style={{
                                marginLeft: "auto",
                                zIndex: 1,
                                marginRight: "10px",
                              }}
                              onClick={(e) => {
                                addOrRemoveElseAct(activity, "Remove");
                                e.stopPropagation();
                              }}
                              tabIndex={0}
                              onKeyPress={(e) => {
                                if (e.key === "Enter") {
                                  addOrRemoveElseAct(activity, "Remove");
                                  e.stopPropagation();
                                }
                              }}
                              //id={`${id}_Else_${generateUniqueId()}`}
                              id={`${id}_${activity.activityName}_Else_${
                                activity.uid
                                  ? activity.uid
                                  : activity.ruleOrderId
                              }`}
                              role="button"
                              aria-label="Remove Else"
                            >
                              <Typography
                                className={getFontStyle(activity)}
                                style={{ color: "#0072C6" }}
                              >
                                -Else
                              </Typography>
                            </Grid>
                          ) : (
                            !activity.elseActivities && (
                              <Grid
                                item
                                style={{ marginLeft: "auto", zIndex: 1 }}
                                onClick={(e) => {
                                  addOrRemoveElseAct(activity, "Add");
                                  e.stopPropagation();
                                }}
                                tabIndex={0}
                                onKeyPress={(e) => {
                                  if (e.key === "Enter") {
                                    addOrRemoveElseAct(activity, "Add");
                                    e.stopPropagation();
                                  }
                                }}
                                role="button"
                                aria-label="Add Else"
                              >
                                <Typography
                                  className={getFontStyle(activity)}
                                  style={{ color: "#0072C6" }}
                                >
                                  +Else
                                </Typography>
                              </Grid>
                            )
                          ))}

                        {/* {isHovered && (activity.activityId && activity.ruleOrderId)
                        && <MenuPopper 
                        id={`${id}_${activity.uid? activity.uid:activity.ruleOrderId}_MenuPopper`}
                        placement="bottom-end"/>}
                        */}

                        {selectedActivity &&
                        selectedActivity.activityId === activity.activityId &&
                        selectedActivity.ruleOrderId ===
                          activity.ruleOrderId ? (
                          <MenuPopper
                            //id={`RPA_ScriptEditor_${activity.activityId}_MenuPopper`}
                            id={`${id}_${activity.activityName}_${
                              activity.uid ? activity.uid : activity.ruleOrderId
                            }_MenuPopper`}
                            items={getMenuOptions(activity)}
                            placement="bottom-end"
                            handleSelectedItem={(e, item) => {
                              handleClipboardActions(item);
                              e.stopPropagation();
                            }}
                          />
                        ) : null}

                        {/*
                         * @author sanya.mahajan Bug 156155 - UX Empty Group activity is showing collapse icon
                         * Reason:The collapse icon was previously visible even when no sub-activities were present in a group activity.
                         * Resolution: Modified the conditional check
                         * Date : 03/02/2025
                         * */}
                        {(activity.activityType === "G" ||
                          activity.activityType === "S") &&
                        ((activity.activityName === "CheckError" &&
                          activity.checkError &&
                          activity.checkError?.length > 0) ||
                          (activity.thenActivities &&
                            activity.thenActivities?.length > 0) ||
                          (activity.activityName === "IfElse" &&
                            activity.elseActivities &&
                            activity.elseActivities?.length > 0) ||
                          activity.subActivities?.length > 0) ? (
                          <Grid item style={{ marginLeft: "1px" }}>
                            {collapsedActivities &&
                            !collapsedActivities.includes(activity.uid) ? (
                              <UniqueIDGenerator>
                                <IconExpanded
                                  className={[
                                    classes.dropdownIcon,
                                    classes.focusVisible,
                                  ].join(" ")}
                                  onClick={() =>
                                    handleClickToCollapse(
                                      activity.uid,
                                      activity
                                    )
                                  }
                                  //WCAG
                                  tabIndex={0}
                                  onKeyPress={(e) =>
                                    e.key === "Enter" &&
                                    handleClickToCollapse(
                                      activity.uid,
                                      activity
                                    )
                                  }
                                  role="button"
                                  id={`${id}_Collapse_${activity.uid}`}
                                  aria-expanded={false}
                                  aria-label={`${id}`}
                                />
                              </UniqueIDGenerator>
                            ) : (
                              <UniqueIDGenerator>
                                <IconCollapsed
                                  className={[
                                    classes.dropdownIcon,
                                    classes.focusVisible,
                                  ].join(" ")}
                                  onClick={() =>
                                    handleClickToCollapse(
                                      activity.uid,
                                      activity
                                    )
                                  }
                                  //WCAG
                                  tabIndex={0}
                                  onKeyPress={(e) =>
                                    e.key === "Enter" &&
                                    handleClickToCollapse(
                                      activity.uid,
                                      activity
                                    )
                                  }
                                  role="button"
                                  id={`${id}_Expand_${activity.uid}`}
                                  aria-expanded={true}
                                  aria-label={`${id}`}
                                />
                              </UniqueIDGenerator>
                            )}
                          </Grid>
                        ) : (activity.activityType === "G" ||
                            activity.activityType === "S") &&
                          !(
                            activity.activityName === "IfElse" ||
                            activity.actvityName === "CheckError"
                          ) ? (
                          <Typography
                            sx={{
                              color: "#606060",
                              fontWeight: 400,
                              fontSize: "10px",
                              textAlign: "right",
                            }}
                          >
                            Drag and Drop activities in the group
                          </Typography>
                        ) : null}
                      </Grid>
                    </Grid>
                    <Grid
                      item
                      container
                      style={{
                        paddingLeft: "15px",
                        borderLeft: "1px solid #D3D3D3",
                      }}
                    >
                      {(activity.activityType === "G" ||
                        activity.activityType === "S") &&
                        activity.subActivities &&
                        collapsedActivities &&
                        !collapsedActivities.includes(`${activity.uid}`) && (
                          <Activity
                            id={`${id}`}
                            activitiesArr={activity.subActivities}
                            handleClipboardActions={handleClipboardActions}
                            handleCollapsedActivities={(selectedActivities) =>
                              handleSubListActivities(
                                activity.uid,
                                selectedActivities
                              )
                            }
                            // collapsedActivities={
                            //   collapsedActivities[`${activity.uid}`]
                            // }

                            handleDrop={handleDrop}
                            handleDrag={handleDrag}
                            ref={ref}
                            addOrRemoveElseAct={addOrRemoveElseAct}
                            nodes={nodes}
                            activeTab={activeTab}
                          />
                        )}
                    </Grid>
                    {/**rendering child activities of CheckError */}
                    <Grid
                      item
                      container
                      style={{
                        paddingLeft: "15px",
                        borderLeft: "1px solid #D3D3D3",
                      }}
                    >
                      {activity.activityName === "CheckError" &&
                        activity.checkError &&
                        activity.checkError.length > 0 &&
                        collapsedActivities &&
                        !collapsedActivities.includes(`${activity.uid}`) && (
                          <Activity
                            id={`${id}`}
                            activitiesArr={activity.checkError}
                            handleClipboardActions={handleClipboardActions}
                            handleCollapsedActivities={(selectedActivities) =>
                              handleSubListActivities(
                                activity.uid,
                                selectedActivities
                              )
                            }
                            // collapsedActivities={
                            //   collapsedActivities[`${activity.uid}`]
                            // }
                            handleDrop={handleDrop}
                            handleDrag={handleDrag}
                            ref={ref}
                            addOrRemoveElseAct={addOrRemoveElseAct}
                          />
                        )}
                    </Grid>
                    {/**End child activities of CheckError Activity */}
                  </Grid>
                  {/* {activity.activityType !== "N" &&
                  (!activity.subActivities ||
                    activity.subActivities.length === 0) &&
                  activity.activityName !== "IfElse" &&
                  activity.activityName !== "CheckError" ? (
                    //   <Grid
                    //   item
                    //   xs
                    //   className={classes.thenActivity}
                    //   style={{
                    //     color: "#606060",
                    //     border:'1px dashed #EFEFEF'
                    //     //paddingLeft: "12px",
                    //   }}
                    // >
                    //   <Typography variant="button">
                    //     Drop Activities Here.
                    //   </Typography>

                    <DragAndDropSpace />
                  ) : null} */}

                  {/* *rendering child activities of CheckError */}
                  {/* {activity.activityName === "CheckError" &&
                    activity.checkError &&
                    activity.checkError.length === 0 &&
                    collapsedActivities &&
                    !collapsedActivities.includes(`${activity.uid}`) && (
                      <Grid
                        item
                        container
                        direction="row"
                        justifyContent={"center"}
                      > */}
                  {/* <Grid
                          item
                          xs
                          className={classes.thenActivity}
                          style={{
                            color: "#606060",
                            //paddingLeft: "12px",
                            border:'1px dashed black'
                          }}
                        >
                          <Typography variant="button">
                            Add Activities to be checked for error.
                          </Typography>
                        </Grid> */}

                  {/* <DragAndDropSpace /> */}
                  {/* </Grid>
                    )} */}
                  {/**End child activities of CheckError Activity */}

                  {/**rendering if else Activity logic */}

                  {activity.activityName === "IfElse" &&
                    collapsedActivities &&
                    !collapsedActivities.includes(`${activity.uid}`) && (
                      <Grid container>
                        <Grid
                          item
                          container
                          direction="row"
                          onDrop={(e) => {
                            e.preventDefault();
                            e.currentTarget.classList.remove(
                              `${classes.onDrag}`
                            );
                            let ele = document.getElementById("dropPlace");
                            if (ele) {
                              ele.remove();
                            }
                            handleDrop({
                              e,
                              activityWhereDroped: activity,
                              insideIf: "THEN",
                            });
                            e.stopPropagation();
                          }}
                          onDragEnter={(e) => {
                            e.preventDefault();
                            e.currentTarget.classList.add(`${classes.onDrag}`);
                            e.stopPropagation();
                          }}
                          onDragOver={(e) => {
                            e.preventDefault();
                            e.currentTarget.classList.add(`${classes.onDrag}`);
                            e.stopPropagation();
                          }}
                          onDragLeave={(e) => {
                            e.preventDefault();
                            e.currentTarget.classList.remove(
                              `${classes.onDrag}`
                            );
                            e.stopPropagation();
                          }}
                        >
                          {/* Bug 155926 - UX Then Else corner radius
        Author: Sanya Mahajan
        Date: 23rd January, 2025
        Resolution: Added corner radius for THEN and ELSE. */}
                          <Grid item xs>
                            <Grid container>
                              <Grid
                                item
                                className={classes.thenActivity}
                                style={{
                                  minWidth: "50px",
                                  backgroundColor: highlightActivity(
                                    activity.activityName
                                  ),
                                  borderRadius: "4px",
                                }}
                              >
                                <span
                                  className={getFontStyle(activity)}
                                  style={{
                                    color: applyFontColor(
                                      activity.activityName
                                    ),
                                  }}
                                >
                                  THEN
                                </span>
                              </Grid>
                            </Grid>
                          </Grid>
                        </Grid>

                        <Grid
                          item
                          container
                          direction={"row"}
                          style={{
                            paddingLeft: "20px",
                            borderLeft: "1px solid #D3D3D3",
                          }}
                        >
                          {
                            activity.thenActivities &&
                            activity.thenActivities.length > 0 ? (
                              <Activity
                                id={`${id}`}
                                activitiesArr={activity.thenActivities}
                                handleClipboardActions={handleClipboardActions}
                                handleCollapsedActivities={(
                                  selectedActivities
                                ) =>
                                  handleSubListActivities(
                                    activity.uid,
                                    selectedActivities
                                  )
                                }
                                collapsedActivities={
                                  collapsedActivities[`${activity.uid}`]
                                }
                                handleDrop={handleDrop}
                                handleDrag={handleDrag}
                                ref={ref}
                                addOrRemoveElseAct={addOrRemoveElseAct}
                              />
                            ) : null
                            // Commented out the DragAndDropSpace and Grid holding it
                            // <Grid item container direction="row">
                            //   {/* <DragAndDropSpace /> */}
                            // </Grid>
                          }
                        </Grid>

                        {activity.elseActivities && (
                          <Grid
                            item
                            container
                            direction="row"
                            onDrop={(e) => {
                              e.preventDefault();
                              e.currentTarget.classList.remove(
                                `${classes.onDrag}`
                              );
                              let ele = document.getElementById("dropPlace");
                              if (ele) {
                                ele.remove();
                              }
                              handleDrop({
                                e,
                                activityWhereDroped: activity,
                                insideIf: "ELSE",
                              });
                              e.stopPropagation();
                            }}
                            onDragEnter={(e) => {
                              e.preventDefault();
                              e.currentTarget.classList.add(
                                `${classes.onDrag}`
                              );
                              e.stopPropagation();
                            }}
                            onDragOver={(e) => {
                              e.preventDefault();
                              e.currentTarget.classList.add(
                                `${classes.onDrag}`
                              );
                              e.stopPropagation();
                            }}
                            onDragLeave={(e) => {
                              e.preventDefault();
                              e.currentTarget.classList.remove(
                                `${classes.onDrag}`
                              );
                              e.stopPropagation();
                            }}
                          >
                            <Grid item xs>
                              <Grid container style={{ paddingTop: "4px" }}>
                                <Grid
                                  item
                                  className={classes.thenActivity}
                                  style={{
                                    minWidth: "50px",
                                    backgroundColor: highlightActivity(
                                      activity.activityName
                                    ),
                                    borderRadius: "4px",
                                  }}
                                >
                                  <span
                                    className={getFontStyle(activity)}
                                    style={{
                                      color: applyFontColor(
                                        activity.activityName
                                      ),
                                    }}
                                  >
                                    ELSE
                                  </span>
                                </Grid>
                              </Grid>
                            </Grid>
                          </Grid>
                        )}

                        <Grid
                          item
                          container
                          style={{
                            paddingLeft: "15px",
                            borderLeft: "1px solid #D3D3D3",
                          }}
                        >
                          {
                            activity.elseActivities &&
                            activity.elseActivities.length > 0 ? (
                              <Activity
                                id={id}
                                activitiesArr={activity.elseActivities}
                                handleClipboardActions={handleClipboardActions}
                                handleCollapsedActivities={(
                                  selectedActivities
                                ) =>
                                  handleSubListActivities(
                                    activity.uid,
                                    selectedActivities
                                  )
                                }
                                collapsedActivities={
                                  collapsedActivities[`${activity.uid}`]
                                }
                                handleDrop={handleDrop}
                                handleDrag={handleDrag}
                                ref={ref}
                                addOrRemoveElseAct={addOrRemoveElseAct}
                              />
                            ) : null
                            // Commented out the DragAndDropSpace and Grid holding it
                            // <Grid item container direction="row">
                            //   {/* <DragAndDropSpace /> */}
                            // </Grid>
                          }
                        </Grid>
                      </Grid>
                    )}

                  {/**IfElse rendering logic ends */}

                  {/**CheckErrors rendering Logic starts*/}
                  <Grid
                    item
                    container
                    style={{
                      paddingLeft: "15px",
                      borderLeft: "1px solid #D3D3D3",
                    }}
                  >
                    {activity.activityName === "CheckError" &&
                      collapsedActivities &&
                      !collapsedActivities.includes(`${activity.uid}`) && (
                        <Grid
                          item
                          container
                          className={
                            activity.activityType === "G" ||
                            activity.activityType === "S"
                              ? selectedActivity &&
                                selectedActivity.activityId ===
                                  activity.activityId &&
                                selectedActivity.ruleOrderId ===
                                  activity.ruleOrderId + "OnError"
                                ? classes.BorderOnErrorWhenSelected
                                : classes.BorderOnError
                              : " "
                          }
                        >
                          <Grid
                            item
                            container
                            className={
                              selectedActivity &&
                              selectedActivity.ruleOrderId ===
                                activity.ruleOrderId + "OnError"
                                ? activityClass + " " + classes.border
                                : activityClass
                            }
                            direction="row"
                            alignItems="center"
                            //id={`${id}_${activity.ruleOrderId}`}
                            id={`${id}_${activity.activityName}_OnError_${
                              activity.uid ? activity.uid : activity.ruleOrderId
                            }`}
                            onClick={() =>
                              dispatch(
                                handleSelectedActivity({
                                  ...activity,
                                  ruleOrderId: activity.ruleOrderId + "OnError",
                                })
                              )
                            }
                            onDrop={(e) => {
                              e.preventDefault();
                              e.currentTarget.classList.remove(
                                `${classes.onDrag}`
                              );
                              let ele = document.getElementById("dropPlace");
                              if (ele) {
                                ele.remove();
                              }
                              handleDrop({
                                e,
                                activityWhereDroped: activity,
                                insideError: "OnError",
                              });
                              e.stopPropagation();
                            }}
                            onDragEnter={(e) => {
                              e.preventDefault();

                              e.currentTarget.classList.add(
                                `${classes.onDrag}`
                              );

                              e.stopPropagation();
                            }}
                            onDragOver={(e) => {
                              e.preventDefault();
                              e.currentTarget.classList.add(
                                `${classes.onDrag}`
                              );

                              e.stopPropagation();
                            }}
                            onDragLeave={(e) => {
                              e.preventDefault();

                              e.currentTarget.classList.remove(
                                `${classes.onDrag}`
                              );

                              e.stopPropagation();
                            }}
                            style={{
                              paddingRight: "5px",

                              backgroundColor: "#FEF3F2",

                              border:
                                activity.activityType === "G" ||
                                activity.activityType === "S"
                                  ? selectedActivity &&
                                    selectedActivity.activityId ===
                                      activity.activityId &&
                                    selectedActivity.ruleOrderId ===
                                      activity.ruleOrderId + "OnError"
                                    ? "1px solid #B42318"
                                    : " "
                                  : " ",
                            }}
                          >
                            <Grid item xs={4}>
                              <Grid
                                container
                                direction="row"
                                spacing={1}
                                justifyItems={"center"}
                                alignItems={"center"}
                              >
                                <Grid item>
                                  {/* <img
                                  src={getImage(activity.activityName,applyFontColor(activity.activityName))}
                                  className={classes.icons}
                                  alt={`${activity.activityName} Icon`}
                                /> */}
                                  <GetColorImage name={activity.activityName} />
                                </Grid>
                                <Grid item style={{ marginLeft: "2px" }} xs>
                                  <Typography
                                    className={getFontStyle(activity)}
                                    color={applyFontColor(
                                      activity.activityName
                                    )}
                                  >
                                    On Error:
                                  </Typography>
                                </Grid>
                              </Grid>
                            </Grid>
                            <Grid
                              item
                              className={classes.description}
                              xs
                              // title={showDescription(activity)}
                            >
                              {/*showDescription(activity).trim().length > 38
                            ? showDescription(activity).substring(0, 34) + ".."
                          : showDescription(activity)*/}
                            </Grid>
                          </Grid>

                          {activity.onError && activity.onError.length > 0 ? (
                            <Grid
                              item
                              container
                              style={{
                                paddingLeft: "15px",
                                borderLeft: "1px solid #D3D3D3",
                              }}
                            >
                              <Activity
                                id={id}
                                activitiesArr={activity.onError}
                                handleClipboardActions={handleClipboardActions}
                                handleCollapsedActivities={(
                                  selectedActivities
                                ) =>
                                  handleSubListActivities(
                                    activity.uid,
                                    selectedActivities
                                  )
                                }
                                collapsedActivities={
                                  collapsedActivities[`${activity.uid}`]
                                }
                                handleDrop={handleDrop}
                                handleDrag={handleDrag}
                                ref={ref}
                                addOrRemoveElseAct={addOrRemoveElseAct}
                              />
                            </Grid>
                          ) : (
                            <Grid item container direction="row">
                              {/* <Grid
                              item
                              xs
                              className={classes.thenActivity}
                              style={{
                                color: "#606060",
                                //paddingLeft: "12px",
                                border:'1px dashed black'
                              }}
                            >
                              <Typography variant="button">
                                Add Activities to be executed if encountered
                                error.
                              </Typography>
                            </Grid> */}
                              {/* <DragAndDropSpace /> */}
                            </Grid>
                          )}
                        </Grid>
                      )}
                  </Grid>
                  {/**CheckErrors logic ends */}

                  {/* {(activity.activityType === "G" ||
                    activity.activityType === "S") &&
                    activity.activityName !== "IfElse" && (
                      <Grid
                        item
                        container
                        direction="row"
                        style={{ marginLeft: "-2px" }}
                      >
                        <Grid
                          item
                          xs={4}
                          className={classes.endOfGroupActivity}
                          title={activity.displayName || ""}
                        >
                          End of{" "}
                          <span className={getFontStyle(activity)}>
                            {truncateString(activity.displayName || "")}
                          </span>
                        </Grid>
                      </Grid>
                    )} */}
                </Grid>
              </Grid>
            </Grid>
          );
        })}
    </>
  );
});

//Line Number of Activities component
const GetCount = (props) => {
  const {
    index,
    // handleBreakpoints,
    // breakpointsArray,
    type,
    size,
    isEnd,
    ruleOrderId,

    uid,
    id,
  } = props;

  const { breakpointsArray } = useSelector((state) => state.editorHomepage);
  const { collapsedActivities } = useSelector((state) => state.editorHomepage);

  const dispatch = useDispatch();
  const classes = useStyles();
  // const handleClickCollapse = (id) => {
  //   let collActs = [...collapsedActivities];
  //   if (collapsedActivities.includes(id)) {
  //     collActs = collActs.filter((uId) => uId !== id);
  //   } else {
  //     collActs.push(id);
  //   }
  //   dispatch(setCollapsedActivities(collActs));
  // };
  return (
    <>
      <Grid
        item
        //container
        //direction="column"
        //justifyContent="flex-end"
        //alignItems="flex-end"
        //spacing={1}
        style={
          {
            //paddingTop: type === "S" || type === "G" ? "29px" : "8px",
            //marginBottom: isEnd || type === "S" || type === "G" ? "8px" : "8px",
            //paddingTop: isEnd || type === "S" || type === "G" ? "5px" : "4px",
          }
        }
      >
        <Grid
          item
          container
          direction="row"
          //justify="flex-end"
          alignItems="center"
          style={{
            height: size,
            cursor: isEnd || ruleOrderId === null ? "auto" : "pointer",
          }}
          onDoubleClick={() =>
            isEnd || ruleOrderId === null
              ? console.log("not clickable")
              : dispatch(handleBreakpointsArray(ruleOrderId))
          }
        >
          <Grid item>
            <CustomTooltip
              title={
                ruleOrderId
                  ? breakpointsArray.indexOf(ruleOrderId) === -1
                    ? "Double Click to Enable Breakpoint"
                    : "Double Click to Disable Breakpoint"
                  : ""
              }
            >
              <Typography
                className={
                  breakpointsArray.indexOf(ruleOrderId) !== -1
                    ? "breakpoints" + " noselect"
                    : "noselect"
                }
              >
                {index}
              </Typography>
            </CustomTooltip>
          </Grid>
          {/* {(type === "G" || type === "S") && !isEnd ? (
            <Grid item style={{ marginLeft: "20px" }}>
              {collapsedActivities && !collapsedActivities.includes(uid) ? (
                <UniqueIDGenerator>
                  <WindowsPropertiesCollapseIcon
                    className={[
                      classes.dropdownIcon,
                      classes.focusVisible,
                    ].join(" ")}
                    onClick={() => handleClickCollapse(uid)}
                    //WCAG
                    tabIndex={0}
                    onKeyPress={(e) =>
                      e.key === "Enter" && handleClickCollapse(uid)
                    }
                    role="button"
                    id={`${id}_Collapse_${uid}`}
                    aria-expanded={false}
                    aria-label={`${id}`}
                  />
                </UniqueIDGenerator>
              ) : (
                <UniqueIDGenerator>
                  <WindowsPropertiesExpandIcon
                    className={[
                      classes.dropdownIcon,
                      classes.focusVisible,
                    ].join(" ")}
                    onClick={() => handleClickCollapse(uid)}
                    //WCAG
                    tabIndex={0}
                    onKeyPress={(e) =>
                      e.key === "Enter" && handleClickCollapse(uid)
                    }
                    role="button"
                    id={`${id}_Expand_${uid}`}
                    aria-expanded={true}
                    aria-label={`${id}`}
                  />
                </UniqueIDGenerator>
              )}
            </Grid>
          ) : null} */}
        </Grid>
      </Grid>
    </>
  );
};

const Activities = (props) => {
  console.log(props, "nodesssssss");
  const {
    activitiesList,

    handleCollapsedActivities,
    // collapsedActivities,
    handleDrop,
    handleDrag,

    dupList,
    // breakpointsArray,
    //handleBreakpoints,
    addOrRemoveElseAct,
    handleClipboardActions,
    id,
    nodes,
    activeTab,
  } = props;
  const windowInnerHeight = useSelector(
    (state) => state.appGlobalState.windowInnerHeight
  );

  const classes = useStyles({ windowInnerHeight });

  const debugStopRef = useRef(null);
  const [isVisible, setIsVisible] = useState(true);

  const runScriptModal = useSelector(
    (state) => state.editorHomepage.runScriptModal
  );
  const customActivitiesGroup = useSelector(
    (state) => state.editorLeftPanel.activitiesGroup
  );

  const debugDetails = useSelector(
    (state) => state.editorHomepage.debugDetails
  );
  const focusItemId = useSelector((state) => state.editorHomepage.focusItemId);
  const { collapsedActivities } = useSelector((state) => state.editorHomepage);

  const isInCurrentVersions = (cusAct) => {
    return customActivitiesGroup.some((grp) => {
      const currAct = grp?.activities.find(
        (item) =>
          item.activityId === cusAct.activityId &&
          item.dependency === cusAct.dependency
      );

      return currAct ? true : false;
    });
  };
  const isDeprecated = (cusAct) => {
    const isDep = false;

    for (const grp of customActivitiesGroup) {
      const currAct = grp?.activities.find(
        (item) =>
          item.activityId === cusAct.activityId &&
          item.dependency === cusAct.dependency
      );
      if (currAct) return grp.isDeprecated;
    }
    return isDep;
  };
  const getDeprectedAct = () => {
    let count = 0;
    const countActvities = (activities) => {
      activities.forEach((act) => {
        if (act.customActivity === 2) {
          if (isDeprecated(act)) {
            count++;
          }
        }
        if (act.activityName === "IfElse") {
          countActvities(act.thenActivities || []);
          countActvities(act.elseActivities || []);
        } else if (act.activityName === "CheckError") {
          countActvities(act.checkError || []);
          countActvities(act.onError || []);
        } else if (act.subActivities) {
          countActvities(act.subActivities);
        }
      });
    };
    countActvities(activitiesList);
    return count;
  };
  const getOlderVersionAct = () => {
    let count = 0;
    const countActvities = (activities) => {
      activities.forEach((act) => {
        if (act.customActivity === 2) {
          if (!isInCurrentVersions(act)) {
            count++;
          }
        }
        if (act.activityName === "IfElse") {
          countActvities(act.thenActivities || []);
          countActvities(act.elseActivities || []);
        } else if (act.activityName === "CheckError") {
          countActvities(act.checkError || []);
          countActvities(act.onError || []);
        } else if (act.subActivities) {
          countActvities(act.subActivities);
        }
      });
    };
    countActvities(activitiesList);
    return count;
  };

  const scrollEleIntoView = () => {
    let container = document.getElementById("ActivitiesContainer");
    if (debugStopRef.current?.offsetTop < container.offsetTop) {
      container.scrollTop = debugStopRef.current?.offsetTop;
    } else {
      const osb =
        debugStopRef.current?.offsetTop + debugStopRef.current?.offsetHeight;
      const sb = container.scrollTop + container.offsetHeight;
      if (osb > sb) {
        container.scrollTop = osb - 300;
      }
    }
  };
  useEffect(() => {
    if (debugDetails) {
      if (debugStopRef.current) {
        scrollEleIntoView();
      }
    }
  }, [debugStopRef.current, debugDetails]);
  useEffect(() => {
    if (focusItemId) {
      scrollEleIntoView();
    }
  }, [focusItemId]);

  const getLastOccurrenceByParentUid = (uid, cache = {}) => {
    if (cache[uid]) {
      return cache[uid];
    }
    const children = dupList.filter((listItem) => listItem.parentId === uid);
    if (children.length === 0) {
      return -1;
    }
    const maxIdx = Math.max(
      ...children.map((child) => (child.index !== undefined ? child.index : -1))
    );

    const nestedMaxIdx = children.reduce((max, child) => {
      if ((child.id === "G" || child.id === "S") && child.parentId != null) {
        const childMaxIdx = getLastOccurrenceByParentUid(child.uid, cache);
        return Math.max(max, childMaxIdx);
      }
      return max;
    }, maxIdx);
    cache[uid] = nestedMaxIdx;
    return nestedMaxIdx;
  };

  const getNewDupList = () => {
    const newDList = [...dupList];

    if (collapsedActivities.length > 0) {
      collapsedActivities.forEach((collapseActUid) => {
        const colAct = dupList.find((obj) => obj.uid === collapseActUid);
        /* const colActStartIndex = dupList.findIndex(
          (obj) => obj.uid === collapseActUid
        );*/
        //  console.log(colActStartIndex);
        if (colAct) {
          const colActLastIndex = getLastOccurrenceByParentUid(collapseActUid);
          if (colActLastIndex === -1) return;
          // const colLastAct = dupList[colActLastIndex]==undefined?dupList[dupList.length-1]:dupList[colActLastIndex];
          const colLastAct =
            dupList[colActLastIndex] || dupList[dupList.length - 1];
          // let totalRemoveables = newDList.slice(
          //   newDList.findIndex((item) => item.index === colAct.index),
          //   newDList.findIndex((item) => item.index === colLastAct.index)
          // ).length;
          const startIndex = newDList.findIndex(
            (item) => item.index === colAct.index
          );
          const endIndex = newDList.findIndex(
            (item) => item.index === colLastAct.index
          );

          if (startIndex !== -1 && endIndex !== -1 && startIndex < endIndex) {
            const totalRemoveables = endIndex - startIndex;
            const removeCount =
              colAct.name === "IfElse"
                ? totalRemoveables + 1
                : totalRemoveables;
            newDList.splice(startIndex + 1, removeCount - 1);
          }

          // if (colActLastIndex !== -1) {
          //   newDList.splice(
          //     newDList.findIndex((item) => item.index === colAct.index),
          //     colAct.name && colAct.name === "IfElse"
          //       ? totalRemoveables+1
          //       : totalRemoveables
          //   );
          // }
        }
      });
    }
    console.log(newDList, dupList, "NEWDLITATTS");
    return newDList;
  };

  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnter = () => {
    setIsDragging(true); // Show the new Grid item when drag starts
  };

  const handleDragLeave = () => {
    setIsDragging(false); // Revert to original items when drag ends
  };

  return activitiesList.length > 0 ? (
    <>
      {getDeprectedAct() > 0 && (
        <Grid container direction="row" spacing={1}>
          <Grid item xs>
            <Grid
              container
              className={classes.versionDeprecated}
              alignItems="center"
            >
              <Grid item xs={1}>
                <WarningIcon1
                  style={{
                    height: "16px",
                    width: "16px",
                    marginTop: "3px",
                  }}
                />
              </Grid>
              <Grid item xs>
                <Typography className={classes.text_white}>
                  {`You are using ${getDeprectedAct()} ${
                    getDeprectedAct() === 1 ? "activity" : "activities"
                  } with deprecated versions`}
                </Typography>
              </Grid>
              <Grid item style={{ marginRight: "24px", cursor: "pointer" }}>
                <Typography
                  className={classes.text_white}
                  onClick={() => handleClipboardActions("Set Activity Version")}
                  id={`${id}_Update`}
                >
                  Update
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      )}
      {getOlderVersionAct() > 0 && isVisible && (
        <Grid container direction="row">
          <Grid item xs>
            <Grid
              container
              className={classes.versionMismatch}
              alignItems="center"
            >
              <Grid item xs={1}>
                <InformationIcon1
                  style={{
                    height: "16px",
                    width: "16px",
                    marginTop: "3px",
                  }}
                />
              </Grid>
              <Grid item xs>
                <Typography>
                  {`You are using ${getOlderVersionAct()} ${
                    getOlderVersionAct() === 1 ? "activity" : "activities"
                  } with older versions`}
                </Typography>
              </Grid>
              <Grid item style={{ marginRight: "16px" }}>
                <Button
                  variant="contained"
                  size="small"
                  color="primary"
                  onClick={() => handleClipboardActions("Set Activity Version")}
                  style={{
                    fontWeight: 600,
                  }}
                  disableTouchRipple
                  disableRipple
                  className={classes.margin}
                  id={`${id}_Btn`}
                >
                  Update versions
                </Button>
                <CloseIcon
                  style={{
                    height: "10px",
                    width: "10px",
                    marginLeft: "10px",
                    cursor: "pointer",
                  }}
                  strokeWidth={3}
                  onClick={() => setIsVisible(false)}
                  id={`${id}_CloseIcon`}
                />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      )}

      {/*
       * @author sanya.mahajan Bug 156412 - UX Canvas getting deleted
       * Reason: When we were dropping the activity it was resetting the entire flow due to re rendering of entire structure
       * Resolution: Removed the grid
       * Date : 06/02/2025
       * */}
      <Grid
        container
        className={classes.root}
        style={{ height: debugDetails || runScriptModal ? "330px" : "" }}
        data-testid="activities"
        id="ActivitiesContainer"
        // onDrop={(e) => {
        //   e.preventDefault();

        //   handleDrop({ e });
        //   e.stopPropagation();
        // }}
        // onDragEnter={(e) => {
        //   e.preventDefault();

        //   e.currentTarget.style.border = '2px dashed "#0072c6"';
        //   // (e.currentTarget.style.borderWidth = "0 0 28px 0");
        //   //   (e.currentTarget.style.borderStyle = "solid");
        //   //   (e.currentTarget.style.borderImageSource = `url(${DropGrid})`);
        //   //   (e.currentTarget.style.borderImageSlice = 30);

        //   e.stopPropagation();
        // }}
        // onDragOver={(e) => {
        //   e.preventDefault();
        //   e.currentTarget.style.border = '2px dashed "#0072c6"';
        //   // (e.currentTarget.style.borderWidth = "0 0 28px 0");
        //   //   (e.currentTarget.style.borderStyle = "solid");
        //   //   (e.currentTarget.style.borderImageSource = `url(${DropGrid})`);
        //   //   (e.currentTarget.style.borderImageSlice = 30);

        //   e.stopPropagation();
        // }}
        // onDragLeave={(e) => {
        //   e.preventDefault();

        //   e.currentTarget.style.border = "none";
        //   e.stopPropagation();
        // }}
      >
        {/* <Grid container direction="row" spacing={1}>
          <Grid item>
            <Typography className={classes.text_light}>Line</Typography>
          </Grid>

          <Grid item xs>
            <Typography className={classes.text_light}>Activities</Typography>
          </Grid>
        </Grid> */}
        <Grid container direction="row" spacing={1}>
          <Grid item style={{ minWidth: "28px", paddingTop: "12px" }}>
            <Grid
              container
              spacing={1}
              direction={"column"}
              justifyContent="flex-end"
              alignItems="flex-end"
            >
              {getNewDupList().map((obj, index) => (
                <React.Fragment key={index}>
                  <GetCount
                    id={`${id}`}
                    type={obj.id}
                    uid={obj.uid}
                    size={obj.size}
                    isEnd={obj.isEnd}
                    index={obj.index}
                    ruleOrderId={obj.ruleOrderId}
                  />
                </React.Fragment>
              ))}
            </Grid>
          </Grid>
          <Grid item xs>
            <Activity
              id={`${id}`}
              activitiesArr={activitiesList}
              handleDrag={handleDrag}
              handleClipboardActions={handleClipboardActions}
              handleDrop={handleDrop}
              handleCollapsedActivities={handleCollapsedActivities}
              collapsedActivities={collapsedActivities}
              ref={debugStopRef}
              addOrRemoveElseAct={addOrRemoveElseAct}
              nodes={nodes}
              activeTab={activeTab}
            />
          </Grid>
        </Grid>
      </Grid>
    </>
  ) : (
    <Paper
      elevation={24}
      className={classes.root1}
      onDrop={(e) => {
        e.preventDefault();

        handleDrop({ e });
        e.stopPropagation();
      }}
      onDragEnter={(e) => {
        e.preventDefault();

        //e.currentTarget.style.border = '2px dashed "#0072c6"';
        e.currentTarget.style.borderWidth = "0 0 28px 0";
        e.currentTarget.style.borderStyle = "solid";
        e.currentTarget.style.borderImageSource = `url(${DropGrid})`;
        e.currentTarget.style.borderImageSlice = 30;

        e.stopPropagation();
      }}
      onDragOver={(e) => {
        e.preventDefault();
        //e.currentTarget.style.border = '2px dashed "#0072c6"';
        e.currentTarget.style.borderWidth = "0 0 28px 0";
        e.currentTarget.style.borderStyle = "solid";
        e.currentTarget.style.borderImageSource = `url(${DropGrid})`;
        e.currentTarget.style.borderImageSlice = 30;

        e.stopPropagation();
      }}
      onDragLeave={(e) => {
        e.preventDefault();

        e.currentTarget.style.border = "none";
        e.stopPropagation();
      }}
    >
      <Grid
        container
        direction={"column"}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDrop={handleDragLeave}
        //onDragOver={handleDragEnter}
        justifyContent={isDragging ? "" : "center"}
        alignItems={isDragging ? "" : "center"}
      >
        {isDragging ? (
          <Grid
            item
            sx={{
              border: "1px dashed #0072C6",
              height: 28,
              backgroundColor: "#F2F8FC",
              borderRadiu: "2px",
            }}
          >
            {/* <Typography variant="h6" color="primary">
              Drop Here to Add Activity
            </Typography> */}
          </Grid>
        ) : (
          <>
            <Grid item>
              <DragIndicator />
            </Grid>
            <Grid item>
              <Typography
                variant="h6"
                sx={{
                  color: "#3A3A3A",
                  fontWeight: "400",
                  fontSize: "12px",
                  textAlign: "center",
                }}
              >
                No activities are added. Drag and drop activities <br />
                from the left panel
              </Typography>
            </Grid>
          </>
        )}
      </Grid>
    </Paper>
  );
};

export default Activities;
