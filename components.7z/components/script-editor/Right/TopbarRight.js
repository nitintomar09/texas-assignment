import React from "react";
import makeStyles from "@mui/styles/makeStyles";
import { Grid, Typography, Divider, IconButton, Tabs, Tab, Paper } from "@mui/material";

import {
  CopyIcon,
  PasteIcon,
  CutIcon,
  DeleteIcon,
  RedoIcon,
  UndoIcon,
  SetActivityVersionIcon,
  IconsButton,
  MainScript,
  FlowChart,
} from "../../../utils/AllImages";
import { ExpandMore } from "@mui/icons-material";
import CustomTooltip from "../../../utils/CustomTooltip";
import { UniqueIDGenerator } from "../../../utils/UniqueIDGenerator";

const useStyles = makeStyles((theme) => ({
  root: {
    minHeight: "30px",
    //height: "32px",
    display: "flex",
    paddingLeft: "20px",
    paddingTop: "8px",
    paddingBottom: "8px",
    backgroundColor: "white",
    
    /**
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The elements were not aligned properly
     * Date : 05/02/2025             
     * */
    //boxShadow: "0px 3px 6px 0px #00000029",
    alignItems:"center",
  },
  textBold: {
    fontWeight: "400",
    fontSize: "12px",
    cursor: "pointer"

  },
  icon: {
    height: "18px",
    width: "18px",
    color: "#606060",
    cursor: "pointer",
    filter: `invert(0%) sepia(59%) saturate(0%) hue-rotate(65deg) brightness(99%) contrast(103%)`,
  },
  input: {
    height: "24px",
    width: "163px",
    border: `1px solid #c4c4c4`,
    backgroundColor: "#FFFFFF",
    fontSize: "12px",
  },
  items: {
    marginRight: "16px",
  },
  selectedView: {
    boxShadow: `0px 0px 2px 2px ${theme.palette.primary.main}`,
    background: `${theme.palette.primary.secondary} 0% 0% no-repeat padding-box`,
    color: `${theme.palette.primary.main}`,
    width: "70px",
    // height: "24px",
    alignItems: "center",
    zIndex: 1,
    cursor: "pointer",
  },
  normalView: {
    backgroundColor: "#FFFFFF",
    boxShadow: "0px 0px 2px 2px #d8d7d7",
    width: "70px",
    // height: "24px",
    alignItems: "center",
    cursor: "pointer",
  },
  divider: {
    color: "#000000",
    width: "2px",
    marginLeft: "8px",
    marginRight: "8px",
  },
  selectedTab: {
    borderBottom: `4px solid ${theme.palette.primary.main}`,
    borderLeft: "1px solid #d8d7d7",
    borderRight: "1px solid #d8d7d7",
  },
  tabIconSizes: {
    height: "16px",
    width: "16px",
    cursor: "pointer",
    marginRight:"5px",
  },
  selectedTabIcon:{
    filter:`invert(31%) sepia(98%) saturate(7494%) hue-rotate(195deg) brightness(105%) contrast(101%) `,
    height: "16px",
    width: "16px",
    cursor: "pointer",
    marginRight:"5px",
  },
  tabs: {},
  TopbarRightPaper: {
    /**
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The header height needed to be 40px
     * Date : 05/02/2025             
     * */
     height: "40px", 
     background: "#F8F8F8", 
     borderBottom: "1px solid #C4C4C4", 
     borderRadius: "0px", 
      /**
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The box shadow should not show on the left panel.
     * Date : 05/02/2025             
     * */
    // boxShadow: "0px 3px 6px 0px #00000029"  
       boxShadow: "0 3px 6px -2px rgba(0, 0, 0, 0.16)",
     }
}));
const TopbarRight = (props) => {
  console.log(props,"TopBarRight")
  const { handleClipboardActions, activeTab, handleTab } = props;
  const classes = useStyles();

  return (
    <Paper 
     /**
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The tertiary header was coming on top of the activity panel therefore removed elevation
     * Date : 05/02/2025             
     * */
    //elevation={24} 
    className={classes.TopbarRightPaper}>
      <Grid
        container
        direction="row"
        justifyContent="flex-start"
        spacing={1}
        style={{
          //paddingBottom: "10px",
          margin: "0",
          //paddingLeft:"10px"
          //height:"35px",
        }}
      >
        {/* <Grid item>
          <Grid container direction="row" spacing={1}>
            <Grid item>
              <Typography 
                className={classes.textBold} 
                style={{borderBottom:activeTab==="Script"?"3px solid #0072C6":""}}
                onClick={()=>handleTab("Script")}>
                  <IconButton className={classes.tabIconSizes}><MainScript/></IconButton>List View</Typography>
            </Grid>
            <Grid item>
              <Typography 
                className={classes.textBold} 
                style={{borderBottom:activeTab==="Flow Chart"?"3px solid #0072C6":""}} 
                onClick={()=>handleTab("Flow Chart")}>
                  <IconButton className={classes.tabIconSizes}><FlowChart/></IconButton>Flow FlowChart View</Typography>
            </Grid>
          </Grid>
        </Grid> */}
        <Tabs
          value={activeTab}
          onChange={(event, newValue) => handleTab(newValue)}
          indicatorColor="primary"
          textColor="primary"
           /**
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The indicator was coming below the border adjusted it's bottom
     * Date : 05/02/2025             
     * */
          sx={{
            "& .MuiTabs-indicator": {
              bottom: "1px", 
              height: "2px", 
            
            }
          }}
        >
          <Tab
            value="Script"
            label={
              <div style={{ display: 'flex', alignItems: 'center',cursor:'pointer' }}>
                <MainScript className={activeTab==="Script"?classes.selectedTabIcon:classes.tabIconSizes} />
                <Typography className={classes.textBold}>List View</Typography>
              </div>
            }
              /**
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The indicator was coming below the border because of this so removed it
     * Date : 05/02/2025             
     * */
            //style={{ borderBottom: activeTab === "Script" ? "2px solid #0072C6" : "" }}
          />
          <Tab
            value="Flow Chart"
            label={
              <div style={{ display: 'flex', alignItems: 'center',cursor:'pointer' }}>
                <FlowChart className={activeTab==="Flow Chart"?classes.selectedTabIcon:classes.tabIconSizes}  />
                <Typography className={classes.textBold}>Flow Chart View</Typography>
              </div>
            }
            /**
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The indicator was coming below the border because of this so removed it
     * Date : 05/02/2025             
     * */
            //style={{ borderBottom: activeTab === "Flow Chart" ? "2px solid #0072C6" : "" }}
          />
        </Tabs>
        {activeTab == "Script" && (
          <Grid item style={{ paddingRight: "25px", marginLeft: "auto" }}>
            <Grid container direction="row" alignItems="center" spacing={1}>
              {clipboardAction.map((item, index) => {
                                      /**
                      @author - akshat.pokhriyal
                      @Date - 10/01/2024
                      @Bug Id - 142502
                      @Bug Description - When we hover on icon we should get name icon name .
                      @Bug Reason of occurence - tooltip was missing
                      @Solution - added tooltip
                      **/ 
return (
                  <React.Fragment key={index}>
                    <CustomTooltip title={item.title}>
                      <Grid
                        item
                        onClick={() => handleClipboardActions(item.title)}
                        key={item.title || index}
                        //WCAG Keyboard Accessible : [19-06-2023] Added tabIndex and onKeyPress
                        tabIndex={0}
                        onKeyPress={(e) =>
                          e.key === "Enter" &&
                          handleClipboardActions(item.title)
                        }
                        role="button"
                        aria-label={`${item.title}`}
                        id={`${props.id}_${item.title}`}
                      >
                        <UniqueIDGenerator>
                          <item.icon className={classes.icon} />
                        </UniqueIDGenerator>
                      </Grid>
                    </CustomTooltip>

                    {index === 1 ? (
                      <Divider
                        orientation="vertical"
                        flexItem
                        className={classes.divider}
                      />
                    ) : null}
                  </React.Fragment>
                );
              })}
            </Grid>
          </Grid>
        )}
      </Grid>
      </Paper>
  );
};

export default TopbarRight;
const options = ["List View", "Flow Chart View"];

const clipboardAction = [
  {
    title: "Undo[Ctrl+Z]",
    icon: UndoIcon,
  },
  {
    title: "Redo[Ctrl+Y]",
    icon: RedoIcon,
  },
  {
    title: "Cut[Ctrl+X]",
    icon: CutIcon,
  },
  {
    title: "Copy[Ctrl+C]",
    icon: CopyIcon,
  },
  {
    title: "Paste[Ctrl+V]",
    icon: PasteIcon,
  },
  {
    title: "Delete[delete]",
    icon: DeleteIcon,
  },
  /* {
     title: "Set Activity Version",
     icon: SetActivityVersionIcon,
   },*/
];
