import React, { useState } from "react";

import makeStyles from "@mui/styles/makeStyles";
import { Brightness1 } from "@mui/icons-material";
import { Grid, Typography, Divider, Paper, IconButton } from "@mui/material";
import {
  // WebRec,
  // WindowsRec,
  VariableIcon,
  AddBreakpointIcon,
  DebugIcon,
  RunScriptIcon,
  CommitIcon,
  PublishIcon,
  StopDebugIcon,
  StepByStepIcon,
  OutputIcon,
  PauseIcon,
  SaveIcon,
  BotIcon,
  MenuIcon,
  SFIcon,
} from "../../../utils/AllImages";
import { useSelector, useDispatch } from "react-redux";

// import Buttons from "../../../utils/Buttons";
import CustomTooltip from "./../../../utils/CustomTooltip";
import { setIsSidebarVisible } from "./../../../redux/EditorHomepage/actions";
import { getCssFilterFromHex } from "../../../utils/HexToFilter";
// import BotPopupStatus from "./BotStatusPopup";
import { UniqueIDGenerator } from "../../../utils/UniqueIDGenerator";
import LoadingButton from "../../common/Button/index";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: "#FFFFFF",
    paddingLeft: "20px",
    paddingTop: "4px",
    //marginTop: "-14px",
    display: "flex",
    width: "100%",
    // [theme.breakpoints.up("lg")]: {
    //   height: "40px",
    // },
    borderBottom: "1px solid #E6E6E6",
    //position: "absolute",
    // boxShadow: "0px 2px 5px #d8d7d7",
    minHeight: "45px",
  },
  text_12: {
    fontSize: "12px",
  },
  title: {
    display: "none",
    fontSize: "16px",

    [theme.breakpoints.up("sm")]: {
      display: "block",

      fontWeight: 700,
    },
  },
  icon: {
    marginRight: "4px",
    width: "7px",
    height: "7px",

    cursor: "pointer",
  },

  actionIconBtn: {
    height: "16px",
    width: "16px",
    fontSize: "1rem",
    marginTop: "5px",

    marginRight: "4px",
    cursor: "pointer",
    // filter: `invert(0%) sepia(59%) saturate(0%) hue-rotate(65deg) brightness(99%) contrast(103%)`,
  },
  actionIconBtn1: {
    marginTop: "3px",
    width: "24px",
    height: "24px",
    cursor: "pointer",
    //filter: `invert(0%) sepia(59%) saturate(0%) hue-rotate(65deg) brightness(99%) contrast(103%)`,
  },

  divider: {
    color: "#000000",
    width: "2px",
    marginLeft: "8px",
    marginRight: "8px",
  },
  subtitle: {
    fontSize: "12px",
    fontWeight: "400",
  },
  icons: {
    width: "24px",
    height: "24px",
    color: "white",
  },
  icons1: {
    width: "28px",
    height: "28px",
    border: "1px solid #b9bdba",
    // borderRadius: "50px",
  },
  margin_right: {
    marginRight: "10px",
  },
  commonBtns: {
    paddingLeft: "8px",
    paddingRight: "8px",
    cursor: "pointer",
    background: "#FFFFFF 0% 0% no-repeat padding-box",
    border: "1px solid #C4C4C4",
    borderRadius: "2px",
  },
  publishBtn: {
    background: "#0D6F08 0% 0% no-repeat padding-box",
    // borderRadius: "2px",
    paddingLeft: "12px",
    paddingRight: "12px",
    // fontSize: "12px",
    cursor: "pointer",
    color: "#FFFFFF",
    "&:hover": {
      backgroundColor: "#026hbd",
      color: "#000000",
    },
  },
  item: {
    fontSize: "12px",
    cursor: "pointer",
    fontWeight: 600,
    marginInlineStart: "8px",
    marginTop: "-5px",
    color: (props)=>props.disabledColor?props.disabledColor:"#606060",
    fontFamily: "Open Sans",
  },
  botIconCss: {
    height: "20px",
    width: "20px",
    marginTop: "4px",
    filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  MenuIcon: {
    width: "16px",
    height: "16px",
    marginTop: "3px",

    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
      //background: "#add8e6 0% 0% no-repeat padding-box",
    },
  },
  // Bug 155879 - UX Breakpoint and Variable buttons in secondary header not correct
  toolHover: {
    "&:hover": {
      backgroundColor: (props) =>
        props.hoverBackgroundColor ? props.hoverBackgroundColor : "",
    },
  },
}));
const Tools = ({
  tools,
  handleOpenModal,
  isExecutionPause,
  status,
  hoverBackgroundColor = "",
  selectedActivity,
  disabledColor="",
}) => {
  const classes = useStyles({ hoverBackgroundColor,disabledColor });
  const getColor = (item) => {
    /* if (item.label == "Run Script") {
       return `invert(31%) sepia(98%) saturate(7494%) hue-rotate(195deg) brightness(105%) contrast(101%) `;
     } else if (item.label === "Stop Debug" || item.label === "Stop") {
       return `invert(32%) sepia(70%) saturate(1686%) hue-rotate(335deg) brightness(86%) contrast(92%)`;
     } else if (item.label === "Step by Step (F5)" || item.label === "Resume") {
       if (isExecutionPause) {
         return ` invert(57%) sepia(44%) saturate(5373%) hue-rotate(87deg) brightness(125%) contrast(119%)`;
       }
     } else {
       return "inherit";
     }*/
    return "inherit";
  };

  //   {BugId:Bug 143851 - Script Designer --> Unable to click on Play button + Finger tooltip not available on Play button (UI Issue, should be shown as disable if conditional based operational)
  // AuthorName:Dixita Ruhela
  // Date: 26 feb 2024
  //   }
  const getColorInDisable = (item) => {
    if (item.label == "Run Script") {
      return `invert(31%) sepia(98%) saturate(7494%) hue-rotate(195deg) brightness(105%) contrast(101%) opacity(40%)`;
    } else if (item.label === "Commit") {
      return `invert(32%) sepia(70%) saturate(1686%) hue-rotate(335deg) brightness(86%) contrast(92%) grayscale(100%) opacity(40%)`;
    } else if (item.label === "Stop Debug" || item.label === "Stop") {
      return `invert(32%) sepia(70%) saturate(1686%) hue-rotate(335deg) brightness(86%) contrast(92%) opacity(40%)`;
    } else if (item.label === "Step by Step (F5)" || item.label === "Resume") {
      if (isExecutionPause) {
        return ` invert(57%) sepia(44%) saturate(5373%) hue-rotate(87deg) brightness(125%) contrast(119%) opacity(40%)`;
      }
    } else {
      return "inherit";
    }
  };

  const IconWithClass = (item) => {
    if (item.img) {
      return (
        <img
          src={item.img}
          className={item.name ? classes.actionIconBtn : classes.actionIconBtn1}
          alt="icons"
        />
      );
    } else {
      let IconDefined = item.icon;
      return (
        <UniqueIDGenerator>
          <IconDefined
            /*  className={
                item.name ? classes.actionIconBtn : classes.actionIconBtn1
              }*/
            style={{
              filter: disableAction(item)
                ? getColorInDisable(item)
                : getColor(item),
              cursor: disableAction(item) ? "default" : "pointer",
              //color:disableAction(item)?"#D3D3D3":"#606060",
            }}
          />
        </UniqueIDGenerator>
      );
    }
  };

  const disableAction = (item) => {
    switch (item.name || item.label) {
      case "Run Script":
      case "Debug":
        if (status === "Design Mode") {
          return true;
        }
        break;
      case "Commit":
        if (status !== "Saved") {
          return true;
        }
        break;
      default:
        return false;
    }
    return false;
  };
  return (
    tools &&
    tools.map((item, index) => {
      return (
        <Grid item key={index}>
          <CustomTooltip
            title={disableAction(item) ? "" : item.label || ""}
            placement="bottom-start"
          >
            <Grid
              container
              alignItems="center"
              direction="row"
              onClick={
                disableAction(item)
                  ? null
                  : () => handleOpenModal(item.name || item.label)
              }
              //WCAG [Keyboard Accessible] : Provided tabIndex and onKeyPress
              tabIndex={0}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !disableAction(item)) {
                  handleOpenModal(item.name || item.label);
                }
              }}
              role="button"
              id={`RPA_ScriptEditor_${item.name || item.label}`}
              aria-label={`${item.name || item.label}`}
            >
              <Grid item>{IconWithClass(item)}</Grid>
              {item.name && (
                <Grid
                  item
                  sx={{disabledColor:selectedActivity && item.name=="Add Breakpoint"?
                    "red":""
                  }}
                  className={classes.item}
                  
                >
                  {item.name}
                </Grid>
              )}
            </Grid>
          </CustomTooltip>
        </Grid>
      );
    })
  );
};
const Topbar1 = ({
  handleOpenModal = () => console.log("please provide handleOpenModal()"),
  status = "Unknown",
  activeTab,
  selectedActivity,
}) => {
  const classes = useStyles();

  const dispatch = useDispatch();
  const [isVisible, setisVisible] = useState(false);

  const isExecutionPause = useSelector(
    (state) => state.editorHomepage.isExecutionPause
  );
  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const isRobotAvailable = useSelector((state) => state.robot.isRobotAvailable);

  const isDebuging = useSelector((state) => state.editorHomepage.isDebuging);
  const isSidebarVisible = useSelector(
    (state) => state.editorHomepage.isSidebarVisible
  );
  const isExecutingScript = useSelector(
    (state) => state.editorHomepage.isExecutingScript
  );

  const rightToolsWhenDebugging = [
    { label: "Output", icon: OutputIcon },
    { label: "Step by Step (F5)", icon: StepByStepIcon },
    {
      label: "Resume",
      icon: RunScriptIcon,
    },
    { label: "Stop Debug", icon: StopDebugIcon },
  ];
  const rightToolsWhenDebuggingAndExecuting = [
    { label: "Output", icon: OutputIcon },
    // { label: "Step by Step (F5)", icon: StepByStepIcon },
    { label: "Stop Debug", icon: StopDebugIcon },
  ];

  const publishBtn = {
    name: "Publish",
    startIcon: (
      <UniqueIDGenerator>
        <PublishIcon
          style={{
            height: "16px",
            width: "16px",
            filter: getCssFilterFromHex(
              status === "Saved" && scriptValues?.isCommited
                ? "#FFFFFF"
                : "#000000"
            ),
          }}
        />
      </UniqueIDGenerator>
    ),
  };
  const handleSidebar = () => {
    dispatch(setIsSidebarVisible(!isSidebarVisible));
  };
  const onMouseover = () => {
    setisVisible(true);
  };
  const onMouseout = () => {
    setisVisible(false);
  };
  const truncateString = (str) => {
    if (str && typeof str === "string") {
      return str.trim().length > 25 ? str.substring(0, 18) + ".." : str;
    } else if (str) {
      return str;
    }
    return "";
  };
  return (
    <Grid
      container
      direction="row"
      alignItems="center"
      justifyContent="space-between"
      className={classes.root}
      // style={{ width: isSidebarVisible ? "93%" : "100%" }}
    >
      <Grid item xs={4}>
        <Grid container spacing={2} alignItems="center">
          <Grid item>
            <UniqueIDGenerator>
              {/**
               * @author sanya.mahajan Bug 155454 - expand collapse option of the left panel should have the different icons else the tooltip
               * Description: Updated the icon as per the figma design and no expand collapse functionality is required
               * Date : 29/01/2025
               * */}
              {/* <MenuIcon
                className={classes.MenuIcon}
                onClick={() => handleSidebar()}
                //WCAG [Keyboard Accessible] : Provided tabIndex and onKeyPress
                role="button"
                tabIndex={0}
                onKeyPress={(e) => e.key === "Enter" && handleSidebar()}
                id="RPA_ScriptEditor_SideBarIcon"
              /> */}
              <SFIcon />
            </UniqueIDGenerator>
          </Grid>

          <Grid item>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <Typography
                  className={classes.title}
                  title={scriptValues && scriptValues.scriptName}
                >
                  {truncateString(
                    (scriptValues && scriptValues.scriptName) || ""
                  )}
                </Typography>
              </Grid>
              <Grid item>
                <Typography className={classes.subtitle}>
                  {scriptValues && scriptValues.versionName}
                </Typography>
              </Grid>
              <Divider
                orientation="vertical"
                flexItem
                className={classes.divider}
              />
              <Grid item>
                <Grid container alignItems="center">
                  <Grid item>
                    {/* {BugId:Bug 144059 - Connection status and design status should be in centre of name and publish button name should be centre and dark outline
                    AuthorName:Dixita Ruhela
                    Date:27 feb 2024
                    } */}
                    <IconButton>
                      <Brightness1
                        style={{
                          color: status === "Saved" ? "#00ff00" : "#FBCE0F",
                          marginTop: "-2px",
                          width: "7px",
                          height: "7px",
                        }}
                      />
                    </IconButton>
                  </Grid>
                  <Grid item>
                    <Typography
                      variant="subtitle2"
                      className={classes.subtitle}
                    >
                      {status}
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>

              {/* <Grid item>
                <Grid container alignItems="center">
                  <Grid
                    item
                    style={{ cursor: "pointer", position: "relative" }}
                    onClick={() => handleOpenModal("Robot")}
                    onMouseEnter={onMouseover}
                    onMouseLeave={onMouseout}
                    //WCAG [Keyboard Accessible] : Provided tabIndex and onKeyPress
                    role="button"
                    tabIndex={0}
                    onKeyPress={(e) =>
                      e.key === "Enter" && handleOpenModal("Robot")
                    }
                    id="RPA_ScriptEditor_BotIcon"
                    aria-label="Bot Icon"
                  >
                    <UniqueIDGenerator>
                      <BotIcon className={classes.botIconCss} />
                    </UniqueIDGenerator>
                    {isVisible && (
                      <Paper
                        style={{
                          backgroundColor: "#ffffff",
                          paddingLeft: 16,
                          paddingRight: 16,
                          paddingTop: 16,

                          position: "absolute",
                          zIndex: 2,
                          borderRadius: "2px",
                          width: "240px",
                          height: "150px",
                        }}
                        elevation={2}
                      >
                        <BotPopupStatus id="RPA_ScriptEditor" />
                      </Paper>
                    )}
                  </Grid>

                  <Grid item>
                    <IconButton>
                      <Brightness1
                      
                        style={{
                          color: isRobotAvailable ? "#00ff00" : "#ff0000",marginTop:"-1px",height:"7px",width:"7px"
                        }}
                      />
                    </IconButton>
                  </Grid>
                </Grid>
              </Grid> */}
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      {
        /*!isSidebarVisible && (*/
        activeTab === "Script" && (
          <Grid item>
            <Grid container direction="row" spacing={2} alignItems="center">
              {!isDebuging && !isExecutingScript && (
                <Tools
                  handleOpenModal={handleOpenModal}
                  isExecutionPause={isExecutionPause}
                  tools={LeftTools}
                  status={status}
                  hoverBackgroundColor="#F8F8F8"
                  selectedActivity={selectedActivity}
                 // disabledColor={!selectedActivity && LeftTools[0] === "Add Breakpoint"?"red":""}
                 
                />
              )}
            </Grid>
          </Grid>
        )
        /*)*/
      }

      {activeTab === "Script" && (
        <Grid item style={{ paddingRight: "10px" }}>
          <Grid container alignItems="center">
            {/* <Grid item>
            <MenuPopper
              MenuIcon={MoreIcon}
              items={["Set Activity Version"]}
              placement="bottom-end"
            />
         </Grid>*/}
            <Tools
              handleOpenModal={handleOpenModal}
              isExecutionPause={isExecutionPause}
              tools={
                isDebuging
                  ? rightToolsWhenDebugging
                  : isExecutingScript
                  ? rightToolsWhenRunningScript
                  : rightTools
              }
              status={status}
              hoverBackgroundColor="#F0F0F0"
            />
            {!isDebuging && !isExecutingScript && (
              <Grid item xs>
                <LoadingButton
                  btnType={
                    status === "Saved" ? "BUTTON-FILLED" : "BUTTON-BORDERLESS"
                  }
                  startIcon={
                    <UniqueIDGenerator>
                      <PublishIcon
                        style={{
                          height: "14px",
                          width: "14px",
                          color: "#FFFFFF",
                        }}
                      />
                    </UniqueIDGenerator>
                  }
                  title={"Publish"}
                  disabled={!(status === "Saved" && scriptValues?.isCommited)}
                  style={
                    // status === "Saved" ?
                    {
                      paddingLeft: "12px",
                      paddingRight: "12px",
                      marginBottom: 5,
                      marginTop: 5,
                      height: "28px",
                    }
                    // : null
                  }
                  onClick={() => {
                    handleOpenModal("Publish");
                  }}
                />
              </Grid>
            )}
          </Grid>
        </Grid>
      )}
    </Grid>
  );
};

export default Topbar1;

const LeftTools = [
  // { name: "Web Recorder", icon: WebRec },
  // { name: "Windows Recorder", icon: WindowsRec },
  { name: "Add Breakpoint", icon: AddBreakpointIcon },
  { name: "Variables", icon: VariableIcon },
];

const rightTools = [
  { label: "Output", icon: OutputIcon },
  { label: "Debug", icon: DebugIcon },
  { label: "Run Script", icon: RunScriptIcon },
  { label: "Save", icon: SaveIcon },
  { label: "Commit", icon: CommitIcon },
];
const rightToolsWhenRunningScript = [
  { label: "Output", icon: OutputIcon },
  // { label: "Pause", icon: PauseIcon },
  { label: "Stop", icon: StopDebugIcon },
];
// const rightToolsWhenDebugging = [
//   { label: "More", icon: MoreIcon },
//   { label: "Output", icon: OutputIcon },
//   { label: "Step by Step (F5)", icon: StepByStepIcon },
//   { label: "Resume", icon: RunScriptIcon },
//   { label: "Stop Debug", icon: StopDebugIcon },
// ];
/*const middleToolsWhenDebuging = [
  { name: "Resume", icon: PlayArrow },
  { name: "Step-by-step", icon: SkipNext },
  { name: "Stop Debug", icon: BugReport },
  { name: "Output", img: OutputIcon },
  { name: "Errors", img: ErrorsIcon },
  { name: "Logs", img: LogsIcon },
];*/
