import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "../../../../utils/CustomAppComp";
import Topbar1 from "../Topbar1";
import userEvent from "@testing-library/user-event";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  ReactDom.render(
    <CustomAppComp>
      <Topbar1 />
    </CustomAppComp>,
    div
  );
});

it("it shows script name,version name", () => {
  const handleOpenModal = jest.fn();
  const scriptValues = { scriptName: "Test Script", versionName: "V1.0" };

  render(
    <CustomAppComp>
      <Topbar1 handleOpenModal={handleOpenModal} scriptValues={scriptValues} />
    </CustomAppComp>
  );
  expect(screen.getByText("Test Script")).toBeInTheDocument();
  expect(screen.getByText("V1.0")).toBeInTheDocument();
});

it("clicking on any button", () => {
  const handleOpenModal = jest.fn();

  render(
    <CustomAppComp>
      <Topbar1 handleOpenModal={handleOpenModal} />
    </CustomAppComp>
  );
  userEvent.click(screen.getByText("Publish"));
  expect(handleOpenModal).toBeCalledTimes(1);
});

it("matches snapshot", () => {
  const handleOpenModal = jest.fn();

  const tree = renderer
    .create(
      <CustomAppComp>
        <Topbar1 handleOpenModal={handleOpenModal} />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
