import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "../../../../utils/CustomAppComp";
import Topbar from "../Topbar";
import userEvent from "@testing-library/user-event";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  ReactDom.render(
    <CustomAppComp>
      <Topbar />
    </CustomAppComp>,
    div
  );
});

it("clicking on any button", () => {
  const handleOpenModal = jest.fn();

  render(
    <CustomAppComp>
      <Topbar handleOpenModal={handleOpenModal} />
    </CustomAppComp>
  );
  userEvent.click(screen.getByText("Web Recorder"));
  expect(handleOpenModal).toBeCalledTimes(1);
});

it("matches snapshot", () => {
  const handleOpenModal = jest.fn();

  const tree = renderer
    .create(
      <CustomAppComp>
        <Topbar handleOpenModal={handleOpenModal} />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
