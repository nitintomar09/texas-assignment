// import React, { useState } from "react";
// import { Grid, Typography, IconButton, CircularProgress } from "@mui/material";
// import makeStyles from "@mui/styles/makeStyles";
// import { useSelector, useDispatch } from "react-redux";
// import { Brightness1, Check } from "@mui/icons-material";
// import { LaptopIcon } from "../../../utils/AllImages";
// import { connectToRobot } from "../../../redux/actions";

// const useStyles = makeStyles((theme) => ({
//   LaptopIcon: {
//     width: "24px",
//     height: "24px",
//     marginTop: "5px",
//   },
//   label: {
//     fontWeight: 600,
//     fontSize: "12px",
//     color: "#606060",
//   },
//   reconnect: {
//     color: `${theme.palette.primary.main}`,
//     fontSize: "10px",
//   },
// }));
// const BotPopupStatus = (props) => {
//   const isRobotAvailable = useSelector((state) => state.robot.isRobotAvailable);
//   const machineName = useSelector((state) => state.robot.machineName);
//   const [isConnecting, setIsConnecting] = useState(false);
//   const classes = useStyles();
//   const dispatch = useDispatch();

//   const getRoboStatus = (e) => {
//     setIsConnecting(true);
//     dispatch(
//       connectToRobot({
//         OnSuccess: () => {
//           setIsConnecting(false);
//         },
//         OnError: () => {
//           setIsConnecting(false);
//         },
//       })
//     );
//     e.stopPropagation();
//   };
//   return (
//     <div style={{ position: "absolute", paddingBottom: "20px" }}>
//       <Grid
//         container
//         direction="column"
//         spacing={1}
//         justifyContent="center"
//         alignItems="flex-start"
//         alignContent="center"
//       >
//         <Grid item>
//           <Typography className={classes.label}>Connection Status :</Typography>
//         </Grid>
//         <Grid item>
//           <Grid container spacing={1} alignItems="center">
//             <Grid item>
//               <Typography variant="h4" style={{ fontWeight: 600 }}>
//                 {isRobotAvailable ? "CONNECTED" : "Disconnected"}
//               </Typography>
//             </Grid>
//             <Grid item>
//               <IconButton
//                 style={{
//                   backgroundColor: isRobotAvailable ? "#619548" : "",
//                 }}
//                 size="small"
//                 disableRipple
//               >
//                 {isRobotAvailable ? (
//                   <Check htmlColor="#ffffff" />
//                 ) : (
//                   <Brightness1
//                     style={{
//                       color: "#ff0000",
//                       width: "12px",
//                       height: "12px",
//                     }}
//                   />
//                 )}
//               </IconButton>
//             </Grid>
//           </Grid>
//         </Grid>
//         {isRobotAvailable && (
//           <Grid item>
//             <Grid container spacing={1} alignItems="center">
//               <Grid item>
//                 <LaptopIcon className={classes.LaptopIcon} />
//               </Grid>
//               <Grid item xs>
//                 <Typography
//                   variant="h6"
//                   style={{ fontWeight: 600, color: "#606060" }}
//                 >
//                   {machineName || ""}
//                 </Typography>
//               </Grid>
//             </Grid>
//           </Grid>
//         )}
//       </Grid>
//       <div style={{ marginTop: "12px", paddingBottom: "16px" }}>

//         {/* {BugId:Bug 143955 - Connect Machine position changes on click
//         Author Name:Dixita Ruhela
//         Date: 26 feb 2024
//         } */}
//         {isConnecting ? (
//           <Typography className={classes.reconnect}>
//             {isRobotAvailable ? "Reconnect" : "Connect"} Machine
//             <CircularProgress
//               // color="#FFFFFF"
//               style={{
//                 height: "14px",
//                 width: "14px",
//                 marginLeft: "8px",
//                 //marginTop: "10px",
//                 color: "blue",
//               }}
//             ></CircularProgress>
//           </Typography>
//         ) : (
//           <Typography
//             className={classes.reconnect}
//             onClick={(e) => getRoboStatus(e)}
//             role="button"
//             aria-pressed="false"
//             aria-label={`${props.id}_ReconnectBtn`}
//             tabIndex={0}
//             onKeyPress={(e) => e.key === "Enter" && getRoboStatus(e)}
//           >
//             {isRobotAvailable ? "Reconnect" : "Connect"} Machine
//           </Typography>
//         )}
//       </div>
//     </div>
//   );
// };

// export default BotPopupStatus;
