import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import {
  CancelOutlined,
  TrendingUpOutlined,
  CloudUploadOutlined,
  Save,
  Brightness1,
  BugReport,
  Pause,
  SkipNext,
  Label,
  PlayArrow,
} from "@mui/icons-material";
import { Grid, Typography, Divider } from "@mui/material";
import WebRec from "../../../assets/images/Web Rec.svg";
import WindowsRec from "../../../assets/images/Windows Rec.svg";
import VariableIcon from "../../../assets/images/Variable.svg";
import RunScript from "../../../assets/images/Run Script.svg";
//import ValidateIcon from "../../../assets/images/Validate.svg";
import OutputIcon from "../../../assets/images/Output.svg";
import ErrorsIcon from "../../../assets/images/Errors.svg";
import { useSelector } from "react-redux";
//import BreakpointIcon from "../../../assets/images/Breakpoint.svg";

import LogsIcon from "../../../assets/images/Logs.svg";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: "#FFFFFF",
    paddingLeft: "20px",
    marginTop: "27px",
    display: "flex",
    width: "100%",
    [theme.breakpoints.up("lg")]: {
      height: "30px",
    },
    borderBottom: "1px solid #d8d7d7",

    position: "absolute",
  },
  item: {
    fontSize: "12px",
    cursor: "pointer",
    fontWeight: 600,
  },
  icon: {
    fontSize: "1rem",
    marginTop: "3px",

    marginRight: "4px",
    cursor: "pointer",
  },

  divider: {
    color: "#000000",
    width: "2px",
    marginLeft: "8px",
    marginRight: "8px",
  },
}));

const Tools = ({ tools, handleOpenModal }) => {
  const classes = useStyles();
  const getColor = (item) => {
    if (
      item.name == "Resume" ||
      item.name == "Step-by-step" ||
      item.name == "Stop Debug"
    ) {
      return "primary";
    } else {
      return "inherit";
    }
  };
  const IconWithClass = (item) => {
    if (item.img) {
      return <img src={item.img} className={classes.icon} alt="icons" />;
    } else {
      let IconDefined = item.icon;
      return <IconDefined className={classes.icon} color={getColor(item)} />;
    }
  };
  return (
    tools &&
    tools.map((item, index) => (
      <Grid item key={index}>
        <Grid
          container
          alignItems="center"
          direction="row"
          onClick={() => handleOpenModal(item.name)}
        >
          <Grid item>{IconWithClass(item)}</Grid>
          <Grid item className={classes.item}>
            {item.name}
          </Grid>
          {/* {index === 2 ? (
            <Typography variant="h5" className={classes.divider}>
              |
            </Typography>
          ) : null}
         */}
        </Grid>
      </Grid>
    ))
  );
};
const Topbar = (props) => {
  const {
    handleOpenModal = () => console.log("please provide handleOpenModal()"),
  } = props;

  const classes = useStyles();
  const debugDetails = useSelector(
    (state) => state.editorHomepage.debugDetails
  );
  return (
    <Grid
      container
      className={classes.root}
      alignItems="center"
      justifyContent="space-between"
    >
      <Grid item>
        <Grid container direction="row" spacing={2} alignItems="center">
          <Tools
            handleOpenModal={handleOpenModal}
            tools={debugDetails ? LeftToolsWhenDebuging : LeftTools}
          />
        </Grid>
      </Grid>
      <Grid item>
        <Grid container direction="row" spacing={2} alignItems="center">
          <Tools
            handleOpenModal={handleOpenModal}
            tools={debugDetails ? middleToolsWhenDebuging : middleTools}
          />
        </Grid>
      </Grid>
      <Grid item style={{ paddingRight: "20px" }}>
        <Grid container direction="row" spacing={2} alignItems="center">
          <Tools handleOpenModal={handleOpenModal} tools={RightTools} />
        </Grid>
      </Grid>
    </Grid>
  );
};

export default Topbar;
const LeftTools = [
  // { name: "Web Recorder", img: WebRec },
  // { name: "Windows Recorder", img: WindowsRec },
  { name: "Variable", img: VariableIcon },
];

const LeftToolsWhenDebuging = [{ name: "Add Breakpoint here", icon: Label }];
const middleTools = [
  { name: "Run Script", icon: PlayArrow },
  //{ name: "Validate", img: ValidateIcon },
  { name: "Debug", icon: BugReport },
  { name: "Output", img: OutputIcon },
  { name: "Errors", img: ErrorsIcon },
  // { name: "Breakpoint", img: BreakpointIcon },
  { name: "Logs", img: LogsIcon },
];
const middleToolsWhenDebuging = [
  { name: "Resume", icon: PlayArrow },
  { name: "Step-by-step", icon: SkipNext },
  { name: "Stop Debug", icon: BugReport },
  { name: "Output", img: OutputIcon },
  { name: "Errors", img: ErrorsIcon },
  { name: "Logs", img: LogsIcon },
];

const RightTools = [
  { name: "", icon: CancelOutlined },
  //{ name: "Commit", icon: TrendingUpOutlined },
  //{ name: "Save", icon: Save },
  // { name: "", icon: CloudUploadOutlined },
];
