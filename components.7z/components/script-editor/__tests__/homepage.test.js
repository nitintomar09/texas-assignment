import React from "react";
import ReactDom from "react-dom";
import {
  waitFor,
  screen,
  render,
  cleanup,
  getByTestId,
} from "@testing-library/react";
import { act } from "react-dom/test-utils";
import renderer from "react-test-renderer";
import { API_BASE_URL, RULES } from "../../../config/index";
import axiosMock from "axios";
import "@testing-library/jest-dom/extend-expect";
import EditorHomepage from "./../homepage";
import CustomAppComp from "./../../../utils/CustomAppComp";
afterEach(cleanup);

/*const scriptId = 123;
const versionName = "v1.0";
const userId = 4;
jest.mock("axios");
it("should load and display the data", async () => {
  const url = `${API_BASE_URL}${RULES}/${scriptId}/${versionName}/${userId}`;
  render(
    <CustomAppComp>
      <EditorHomepage />
    </CustomAppComp>
  );

  axiosMock.get.mockResolvedValueOnce({
    data: [
      {
        scriptName: "Test",
        rules: [
          {
            activityId: 2,
            activityName: "Test",
            activityType: "S",
            description: "null",
            displayName: "Test Act",
            params: [],
            subActivities: [],
          },
        ],
      },
    ],
  });

  expect(axiosMock.get).toHaveBeenCalledTimes(2);

  expect(screen).toHaveTextContent("Test Act");
});*/

it("renders without crashing", async () => {
  const div = document.createElement("div");
  const promise = Promise.resolve();
  act(() => {
    ReactDom.render(
      <CustomAppComp>
        <EditorHomepage />
      </CustomAppComp>,
      div
    );
  });

  await promise;
});

it("testing useeffect", async () => {
  const promise = Promise.resolve();

  act(() => {
    render(
      <CustomAppComp>
        <EditorHomepage />
      </CustomAppComp>
    );
  });

  expect(screen.getByTestId("loaderLeft")).toBeInTheDocument();

  await promise;
});

it("matches snapshot", async () => {
  const tree = renderer
    .create(
      <CustomAppComp>
        <EditorHomepage />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
