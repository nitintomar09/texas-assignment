import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "./../../../utils/CustomAppComp";
import Header from "./../Header";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(
    <CustomAppComp>
      <Header location={location} />
    </CustomAppComp>,
    div
  );
});

it("matches snapshot", () => {
  const tree = renderer
    .create(
      <CustomAppComp>
        <Header location={location} />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
const location = { pathname: "Test" };
