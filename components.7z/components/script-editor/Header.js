import React from "react";
import makeStyles from '@mui/styles/makeStyles';

import Typography from "@mui/material/Typography";

//import logo from "../../assets/img/NewgenLogoSvg.svg";
import {
  Grid,
  Button,
  Avatar,
  CircularProgress,
  Menu,
  MenuItem,
} from "@mui/material";

import {
  HelpIcon,
  NotificationIcon,
  ActivityIcon,
  NewgenLogoIcon,
  NewgenOneLogo
} from "../../utils/AllImages";

import { useHistory } from "react-router-dom";
import { userLogout } from "../../redux/actions";
import { getUser } from "../../utils/common";
import CustomTooltip from "../../utils/CustomTooltip";
import { useDispatch, useSelector } from "react-redux";
import { deepOrange, deepPurple } from "@mui/material/colors";
import UserProfile from "../ProfileMenu/UserProfile";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";

const useStyles = makeStyles((theme) => ({
  grow: {
    flexGrow: 1,
  },
  layout: {
    backgroundColor: "#f8f8f8",
    borderBottom: `1px solid #E6E6E6`,
    paddingLeft: "20px",
    paddingRight: "25px",
    color: "#000000",
    height: "40px",
    display: "flex",
    width: "100%",
    position: "absolute",
    zIndex: 1201,
  },
  menuButton: {
    // marginRight: theme.spacing(1),
  },
  icons: {
    height: "18px",
    width: "17px",
  },
  boldText: {
    fontSize: 12,
    color: "#1B1B1B",
    fontWeight: "bold",
  },
  title: {
    display: "none",
    fontSize: "12px",
    [theme.breakpoints.up("sm")]: {
      display: "block",
      color: "#01733a",
      fontWeight: 800,
    },
  },
  sectionDesktop: {
    display: "none",
    [theme.breakpoints.up("md")]: {
      display: "flex",
      alignItems: "center",
    },
  },
  sectionMobile: {
    display: "flex",
    [theme.breakpoints.up("md")]: {
      display: "none",
    },
  },
  normalText: {
    fontSize: "12px",
  },
  orange: {
    color: theme.palette.getContrastText(deepOrange[600]),
    backgroundColor: deepOrange[600],
  },
  purple: {
    color: theme.palette.getContrastText(deepPurple[600]),
    backgroundColor: deepPurple[600],
  },
  iconColor1: {
    filter: `invert(0%) sepia(59%) saturate(0%) hue-rotate(65deg) brightness(99%) contrast(103%)`,
    height: "17px",
    width: "17px",
  },
}));

const Header = (props) => {
  const classes = useStyles();
  const userArr = getUser();
  const dispatch = useDispatch();
  const history = useHistory();
  const [anchorEl, setAnchorEl] = React.useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleLogout = () => {
    dispatch(userLogout({ history }));
  };
  const isLogoutLoading = useSelector(
    (state) => state.userDetails.isLogoutLoading
  );

  return (
    <div className={classes.layout}>
      <Grid container alignItems="center" justifyContent="space-between">
        <Grid item>
          <Grid container spacing={2} alignItems="center">
            {/*<Grid item>
              <MenuIcon style={{ width: "24px", height: "24px" }} />
            </Grid>*/}

            <Grid item>
              {/* {BugId:Bug 144094 - In Designer : Logo should be NewgenONE
                    AuthorName:Dixita Ruhela
                    Date: 26 feb 2024
                    } */}
              <Grid container spacing={1}>
                <Grid item>
                  <img
                    src={NewgenOneLogo}
                    alt="Logo"
                    style={{ height: 24.11, width: 128 }}
                  />
                  {/*<NewgenLogoIcon />*/}
                </Grid>
                {/*<Grid item>
                  <Typography variant="h6" className={classes.title}>
                    NEWGEN
                  </Typography>
          </Grid>*/}
              </Grid>
            </Grid>

            <Grid item style={{ marginTop: "-5px" }}>
              <Typography>
                <span className={classes.normalText}>RPA</span>{" "}
                <span className={classes.boldText}>SCRIPT DESIGNER</span>
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        {/* user and notification */}
        {!["/Error"].includes(props.location.pathname) && (
          <Grid item>
            <Grid container alignItems="center" spacing={1}>
              <Grid item>
                <UniqueIDGenerator>
                  <HelpIcon className={classes.iconColor1} />
                </UniqueIDGenerator>
              </Grid>
              <Grid item>
                <UniqueIDGenerator>
                  <ActivityIcon className={classes.iconColor1} />
                </UniqueIDGenerator>
              </Grid>
              <Grid item>
                <UniqueIDGenerator>
                  <NotificationIcon className={classes.iconColor1} />
                </UniqueIDGenerator>
              </Grid>
              <Grid item>
                <UserProfile />
              </Grid>
              {/*<Grid item>
                {userArr && userArr[0]?.authUser?.fullName && (
                  <Button
                    aria-controls="simple-menu"
                    aria-haspopup="true"
                    onClick={handleClick}
                    style={{
                      paddingLeft: 0,
                      paddingRight: 0,
                      height: "20px",
                      width: "20px",
                    }}
                    disableRipple
                  >
                    <CustomTooltip title={`${userArr[0]?.authUser?.fullName}`}>
                      <Avatar
                        variant="circular"
                        className={classes.orange}
                        style={{
                          height: "18px",
                          width: "18px",
                          marginTop: "-2px",
                        }}
                      >
                        {userArr[0]?.authUser?.fullName
                          ?.charAt(0)
                          .toUpperCase()}
                      </Avatar>
                    </CustomTooltip>
                  </Button>
                )}
                        </Grid>*/}
            </Grid>
          </Grid>
        )}
      </Grid>
      <Menu
        id="simple-menu"
        anchorEl={anchorEl}
        keepMounted
        open={Boolean(anchorEl)}
        onClose={handleClose}
      >
        <MenuItem onClick={handleClose} id="simple-menu_Profile">
          Profile
        </MenuItem>
        <MenuItem onClick={handleClose} id="simple-menu_MyAccount">
          My account
        </MenuItem>
        <MenuItem onClick={handleLogout} id="simple-menu_Logout">
          {isLogoutLoading && (
            <CircularProgress
              // color="#606060"
              style={{
                height: "15px",
                width: "15px",
                marginRight: "8px",
                color:"#606060"
              }}
            ></CircularProgress>
          )}
          Logout
        </MenuItem>
      </Menu>
    </div>
  );
};
export default Header;
