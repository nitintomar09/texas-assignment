import React, { useState, useEffect, useContext, useCallback } from "react";
import Stomp from "stompjs";
import SockJS from "sockjs-client";
import makeStyles from "@mui/styles/makeStyles";
import { Box, Grid } from "@mui/material";
import { v4 as uuidv4 } from "uuid";
import MainLeft from "./Left/MainLeft";
import MainRight from "./Right/MainRight";
import VariableListModal from "./../modals/VariableListModalNew";
import RunScriptOutputModal from "./../modals/RunScriptOutputModal";
import ProcessVariablesModal from "./../modals/ProcessVariablesModal";
import MainScreen from "./PropertyWindow/MainScreen";
import Confirm from "../common/confirm/confirm";
import ModalForm from "../../utils/modalForm";

// import _ from "lodash";
import _, { constant } from "lodash";
import { useParams, useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {
  setOpenScriptDetails,
  setDebugDetails,
  setRunScriptModal,
  setIsDebuging,
  setIsSavingRules,
  setRedo,
  setUndo,
  setFocusItemId,
  setIsExecutingScript,
  setIsExecutionPause,
  setIsGettingRules,
  // connectToRobot,
  setRunScript,
  handleBreakpointsArray,
  setBreakpointsArray,
  setVariablesFunctionList,
  userLogout,
  setErrorActivity,
  handleSelectedActivity,
  setSelectedActivity,
  setActiveTab,
  setUuidRuleOrderid,
} from "../../redux/actions";
import {
  handleNetworkRequestError,
  unlockScript,
  getToken,
  createInstance,
  getUserId,
  doesUserHavePermission,
  getAuthKey,
} from "./../../utils/common";
import { VariablesContext } from "./../../contexts/VariablesListContext";

import {
  API_BASE_URL,
  RULES,
  SCRIPT,
  VARIABLES,
  DESIGNER_WEB_SOCKETS,
  SOCKET_GET_WEB_RULES,
  DISCARD_CHANGES,
  COMMIT,
  INVOKE,
  GET_EXECUTION_LOGS,
  RESUME_SCRIPT,
  GET_BREAKPOINTS_LOGS,
  // WINDOW_RECORDER,
  GET_WINDOWS_ACTIONS,
  PUBLISH_SCRIPT_INDEX,
  MODIFY_INDEX,
  API_BASE_URL_ADMIN,
  USERS,
  VALIDATE,
  COMMIT_SCRIPT_INDEX,
  DEPRECATE_MSG,
  VERSION_MISMATCH_MSG,
  STOP,
  ROBOT_API,
  // WEB_RECORDER,
} from "./../../config/index";
import { NotificationContext } from "./../../contexts/NotificationContext";
import Topbar1 from "./Top/Topbar1";
import DebugLeftPanel from "./Left/DebugLeftPanel";
import PublishScriptModal from "./../modals/PublishScriptModal";
import { getDecryptData } from "./../../utils/encryptions";
import RobotDownloadModal from "./../modals/RobotDownloadModal";
import DocumentVariablesModal from "./../modals/DocumentVariablesModal";
import UserProfileModal from "./../modals/UserProfileModal";
import SetActivityVersionModal from "./../modals/SetActivityVersionModal";
import { ChromeReaderMode } from "@mui/icons-material";
import ServiceFlowDetailsModal from "../modals/ServiceFlowDetailsModal";
import DebugServiceFlow from "../modals/DebugServiceFlowModal";

const useStyles = makeStyles((theme) => ({
  root: {
    backgroundColor: "#FFFFFF",
    display: "flex",
    flexDirection: "column",
    width: "100%",
    //marginTop: "15px",
    overflow: "hidden",
  },
  main: {
    display: "flex",
    //width: "100%",
    //paddingTop: "25px",
    //overflow: "hidden",
    overflowY: "auto",
    // [theme.breakpoints.down(860)]: {
    //   paddingTop: "50px",
    // },

    // [theme.breakpoints.between(860, 961)]: {
    //   paddingTop: "50px",
    // },
    // [theme.breakpoints.between(961, 1173)]: {
    //   paddingTop: "30px",
    // },
    // [theme.breakpoints.between(1173, 1280)]: {
    //   paddingTop: "30px",
    // },
    // [theme.breakpoints.up(1280, "xl")]: {
    //   paddingTop: "30px",
    // },
    outputDiv: {
      backgroundColor: "red",
      dispaly: "flex",
    },
  },
  secondaryMain: {
    overflowX: "auto",
    minWidth: "100%",
    display: "flex",
    flexDirection: "row",
  },
}));

const activitiesListDummy = [];

const EditorHomepage = () => {
  const classes = useStyles();
  const history = useHistory();
  const userId = getUserId();

  const dispatch = useDispatch();

  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const debugDetails = useSelector(
    (state) => state.editorHomepage.debugDetails
  );
  const runScriptModal = useSelector(
    (state) => state.editorHomepage.runScriptModal
  );
  const runScript = useSelector((state) => state.editorHomepage.runScript);

  const isDebuging = useSelector((state) => state.editorHomepage.isDebuging);

  const isExecutingScript = useSelector(
    (state) => state.editorHomepage.isExecutingScript
  );
  const openProfileModal = useSelector(
    (state) => state.userDetails.openProfileModal
  );
  const activeTab = useSelector((state) => state.editorHomepage.activeTab);
  const undoArray = useSelector((state) => state.editorHomepage.undoArray);

  const redoArray = useSelector((state) => state.editorHomepage.redoArray);
  const selectedActivity = useSelector(
    (state) => state.editorHomepage.selectedActivity
  );

  const currentCustomActivitiesGroups = useSelector(
    (state) => state.editorLeftPanel.currentCustomActivitiesGroups
  );

  const [leftPanelOpen, setLeftPanelOpen] = useState(true);
  const [openModalName, setOpenModalName] = useState(null);
  //"ServiceFlowDetails"
  //const [activeTab, setActiveTab] = useState("Script");
  const [openDialog, setOpenDialog] = useState(false);
  const [saveListViewDialog, setSaveListViewDialog] = useState(false);
  const [activitiesList, setActivitiesList] = useState(activitiesListDummy);
  const [activitiesListOrg, setActivitiesListOrg] = useState([]);

  const [recordedActivity, setRecorderActivity] = useState(null);
  const [windowRecordedActivity, setWindowRecorderActivity] = useState(null);

  const [recentActivities, setRecentActivities] = useState([]);
  const [dupList, setDupList] = useState([]);

  const [lastAction, setLastAction] = useState(null);
  const [selectedClipboardAct, setSelectedClipboardAct] = useState(null);
  const [scriptName, setScriptName] = useState([]);
  const { encodedStr } = useParams();
  const { versionId, scriptId, versionName } = scriptValues;

  const { value: allVariablesObj, setAllVariables } =
    useContext(VariablesContext);
  const { setValue: setNotification } = useContext(NotificationContext);
  const [outputObj, setOutputObj] = useState([]);
  const [endpointDetails, setEndpointDetails] = useState(null);
  const [defaultValue, setDefaultValue] = useState({});
  const { breakpointsArray } = useSelector((state) => state.editorHomepage);
  // const isRobotAvailable = useSelector((state) => state.robot.isRobotAvailable);

  const dataWebRecorder = {
    previousRecorded: "false",
    rpa: true,
    versionId,
    scriptId,
    serverUrl: `${API_BASE_URL}`,
    token: getToken(),
  };

  // function for updateNode

  const updateNodePosition = (nodes) => {
    const updateCoordinatesRecursively = (activities) => {
      
      return activities.map((activity) => {
        // Find the corresponding node by ruleOrderId
        const correspondingNode = nodes.find(
          (node) => node.data.ruleOrderId === activity.ruleOrderId
        );

        if (correspondingNode) {
          // Update the activity's coordinates based on the node's position
          activity.positionXCoordinate = Math.floor(
            correspondingNode.position.x
          );
          activity.positionYCoordinate = Math.floor(
            correspondingNode.position.y
          );
        } else {
          console.warn(
            `No node found for ruleOrderId: ${activity.ruleOrderId}`
          );
        }

        // Recursively update positions for sub-activities
        if (activity.subActivities && activity.subActivities.length > 0) {
          activity.subActivities = updateCoordinatesRecursively(
            activity.subActivities
          );
        }

        // Handle 'thenActivities' and 'elseActivities' if they exist
        if (activity.thenActivities && activity.thenActivities.length > 0) {
          activity.thenActivities = updateCoordinatesRecursively(
            activity.thenActivities
          );
        }
        if (activity.elseActivities && activity.elseActivities.length > 0) {
          activity.elseActivities = updateCoordinatesRecursively(
            activity.elseActivities
          );
        }
        if (activity.onError && activity.onError.length > 0) {
          activity.onError = updateCoordinatesRecursively(activity.onError);
        }
        if (activity.checkError && activity.checkError.length > 0) {
          activity.checkError = updateCoordinatesRecursively(
            activity.checkError
          );
        }
        return activity; // Return the updated activity
      });
    };

    // Start the recursive update from the root activities array
    const updatedActivities = updateCoordinatesRecursively(activitiesList);
    setActivitiesList(updatedActivities);
  };

  const changeTab = (tab) => {
    if (tab == "Script") {
      setOpenDialog(true);
    } else {
      dispatch(setActiveTab(tab));
    }
  };

  useEffect(() => {
    // getRoboStatus();
    dispatch(setSelectedActivity(null));

    dispatch(setVariablesFunctionList({ history }));
    const onUnload = (e) => {
      unlockScript({ versionId: scriptValues?.versionId });
    };
    window.addEventListener("beforeunload", onUnload);
    return () => {
      window.removeEventListener("beforeunload", onUnload);
    };
  }, []);
  useEffect(() => {
    getEncryption();
  }, [encodedStr]);
  const getEncryption = async () => {
    if (encodedStr) {
      const dec = getDecryptData(encodedStr);

      const { scriptId, versionName } = dec;
      dispatch(
        setOpenScriptDetails({
          scriptId,
          versionName,
          versionId: null,
          scriptName: null,
        })
      );
    }
  };

  useEffect(() => {
    if (versionId) {
      try {
        var subscriptionScriptExecution = {};
        subscriptionScriptExecution.unsubscribe = function () {
          console.log(
            "unsubscribed from websocket,Service Flow execution logs end point."
          );
        };
        var subscriptionDebugLogs = {};
        subscriptionDebugLogs.unsubscribe = function () {
          console.log("unsubscribed from websocket,debug logs end point .");
        };
        var subscriptionWebRecAct = {};
        subscriptionWebRecAct.unsubscribe = function () {
          console.log("unsubscribed from websocket web recorder end point.");
        };

        var subscriptionWindowsRecAct = {};
        subscriptionWindowsRecAct.unsubscribe = function () {
          console.log(
            "unsubscribed from websocket windows recorder end point."
          );
        };
        const socket = new SockJS(`${API_BASE_URL}${DESIGNER_WEB_SOCKETS}`);
        const stompClient = Stomp.over(socket);
        stompClient.connect({}, function (frame) {
          // console.log("Connected: " + frame);
          //subscribing to script execution logs
          subscriptionScriptExecution = stompClient.subscribe(
            `${GET_EXECUTION_LOGS}`,
            function (data) {
              const body = JSON.parse(data.body);
              if (body) {
                if (body.scriptId == scriptId && body.versionId == versionId) {
                  const message = body.message;
                  const messageType = body.messageType;
                  const activityId = body.activityId;
                  const ruleOrderId = body.ruleOrderId;

                  if (message && messageType) {
                    setOutputObj((prevState) => [
                      ...prevState,
                      {
                        activityName: "",
                        messageType: messageType,
                        message: message,
                      },
                    ]);
                    if (messageType === "Error" && activityId && ruleOrderId) {
                      dispatch(setErrorActivity({ activityId, ruleOrderId }));
                    }
                  }
                }
              }
            }
          );
          //subscribing to debug logs socket
          subscriptionDebugLogs = stompClient.subscribe(
            `${GET_BREAKPOINTS_LOGS}`,
            function (data) {
              const body = JSON.parse(data.body);
              if (body) {
                if (body.scriptId == scriptId && body.versionId == versionId) {
                  //setting redux state of debugDetails
                  dispatch(
                    setDebugDetails({
                      scriptId: body.scriptId,
                      versionId: body.versionId,
                      ruleOrderId: body.ruleOrderId,
                      variables: body.variables,
                      currentLineNo: body.currentLineNo,
                    })
                  );

                  dispatch(setIsExecutionPause(true));
                }
              }
            }
          );
          //subscribing to the web rules for web recorder activities

          subscriptionWebRecAct = stompClient.subscribe(
            `${SOCKET_GET_WEB_RULES}`,
            function (data) {
              const temp = JSON.parse(data.body);

              if (temp && temp.versionId === versionId) {
                const temparray1 = temp.list;

                const temparray = [];

                temparray1.map((obj, index) => {
                  obj.ruleOrderId = index + 1;
                  if (index === 0) {
                    obj.subActivities = [];
                    temparray.push(obj);
                  } else {
                    temparray[0].subActivities.push(obj);
                  }
                });

                //checking if recorded activity is present in state
                if (temparray.length > 0) {
                  const browserAct = temparray[0];
                  setRecorderActivity(browserAct);
                }
              }
            }
          );
          subscriptionWindowsRecAct = stompClient.subscribe(
            `${GET_WINDOWS_ACTIONS}`,
            function (data) {
              const temp = JSON.parse(data.body);

              if (
                temp &&
                temp.scriptId === scriptId &&
                temp.versionId === versionId
              ) {
                const temparray1 = temp.rules || [];

                const temparray = [];

                temparray1.map((obj, index) => {
                  obj.ruleOrderId = index + 1;

                  temparray.push(obj);
                });

                //checking if recorded activity is present in state

                if (temparray.length > 0) {
                  setWindowRecorderActivity(temparray);
                }
              }
            }
          );
        });
      } catch (error) {
        console.log(error);
      }
      //to cleanup the socket connections subscriptions
      return function () {
        subscriptionScriptExecution.unsubscribe();
        subscriptionDebugLogs.unsubscribe();
        subscriptionWebRecAct.unsubscribe();
      };
    } else {
      // history.push(`/Dashboard`);
    }
  }, [versionId]);

  useEffect(() => {
    if (lastAction) {
      const newArr = [
        ...redoArray,
        {
          focusItemId: lastAction.ruleOrderId,
          currentState: [...activitiesList],
        },
      ];
      dispatch(setRedo(newArr));
      dispatch(setUndo([]));
      dispatch(setFocusItemId(null));
      setLastAction(null);
    }
  }, [activitiesList]);

  const handleUndoRedoArrayValue = (pressedKey) => {
    let newUndoArr = [...undoArray];
    let newRedoArr = [...redoArray];
    if (pressedKey === "y") {
      const lastItem = newUndoArr.pop();
      if (lastItem) {
        const { focusItemId, currentState } = lastItem;

        setActivitiesList(_.cloneDeep(currentState));
        createDupArray(currentState);
        dispatch(setFocusItemId(focusItemId));
        newRedoArr = [...newRedoArr, lastItem];
        dispatch(setRedo(newRedoArr));
        dispatch(setUndo(newUndoArr));
      }
    } else if ("z") {
      const lastItem = newRedoArr.pop();
      if (lastItem) {
        if (newRedoArr.length > 0) {
          const { focusItemId, currentState } =
            newRedoArr[newRedoArr.length - 1];

          setActivitiesList(_.cloneDeep(currentState));
          createDupArray(currentState);
          dispatch(setFocusItemId(focusItemId));
        } else {
          setActivitiesList([...activitiesListOrg]);
          createDupArray(activitiesListOrg);
          dispatch(setFocusItemId(null));
        }
        newUndoArr = [...newUndoArr, lastItem];
        dispatch(setRedo(newRedoArr));
        dispatch(setUndo(newUndoArr));
      }
    }
  };

  const getActivityGroupName = (cusAct) => {
    let groupName = "";

    for (const grp of currentCustomActivitiesGroups) {
      const currAct = grp?.activities.find(
        (item) =>
          item.activityId === cusAct.activityId &&
          item.dependency === cusAct.dependency
      );
      if (currAct) {
        groupName = grp.groupName;
        return groupName;
      }
    }
    return groupName;
  };

  const allUsedCustomActivitiesGrps = () => {
    let cusActGrps = {};
    const getCustomActivities = (activities) => {
      activities.forEach((act) => {
        if (act.customActivity === 2) {
          if (getActivityGroupName(act)) {
            cusActGrps[`${getActivityGroupName(act)}`] = act.dependency;
          }
        }
        if (act.activityName === "IfElse") {
          getCustomActivities(act.thenActivities || []);
          getCustomActivities(act.elseActivities || []);
        } else if (act.activityName === "CheckError") {
          getCustomActivities(act.checkError || []);
          getCustomActivities(act.onError || []);
        } else if (act.subActivities) {
          getCustomActivities(act.subActivities);
        }
      });
    };
    getCustomActivities(activitiesList);
    return cusActGrps;
  };


  
  const updateInitialDataWithDefaults = () => {
    
    const updatedData = allVariablesObj?.allVariables?.map((row, index) => {
      
      if (defaultValue.hasOwnProperty(index)) {
        return {
            debugValue:defaultValue[index],
          ...row, 
       
        };
      }
      return row;
    });

    return updatedData;
  };
  const updatedData = updateInitialDataWithDefaults();
    


  const invokeScript = async (executionType) => {
    dispatch(setErrorActivity(null));

    const axiosInstance = createInstance();

    if (executionType === "normalExecution") {
      dispatch(setIsExecutingScript(true));
      dispatch(setRunScript(false));
    }
    const authenticationKey = getAuthKey();

    let scriptName = null;
    if (scriptValues) {
      scriptName = scriptValues.scriptName;
    }

    const arr = allVariablesObj?.allVariables?.map((v) => v.variableName) || [];
    const customActivities = allUsedCustomActivitiesGrps();
    let inputData = {
      scriptId: +scriptId,
      versionId: +versionId,
      scriptName: scriptName || "",
      breakpoints: executionType === "debugExecution" ? breakpointsArray : null,
      variables: executionType === "debugExecution" ? updatedData : [],
      customActivities,
      authenticationKey,
    };

    try {
      let res = await axiosInstance.post(`${INVOKE}`, {
        ...inputData,
      });

      if (res.status === 200) {
        dispatch(setDebugDetails(null));
        dispatch(setIsDebuging(false));
        dispatch(setIsExecutingScript(false));
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "Invoke failed.",
            title: "Script",
            notificationType: "ERROR",
          });
        },
      });
      dispatch(setDebugDetails(null));
      dispatch(setIsExecutingScript(false));
      dispatch(setIsDebuging(false));
    }
  };

  useEffect(() => {
    if (runScriptModal) {
      /*****************************************************************************************
       * @author asloob.ali BUG ID :100685 Description :  - Output window need to be closed to re-run the script
       *  Resolution : added runScript property which will track clicks of run script
       *  Date : 14/09/2021             ***************************************************************************************/
      if (runScript) {
        invokeScript("normalExecution");
      }else{
        //setOpenModalName("DebugAction");
      }
    }
  }, [runScriptModal, runScript]);
  useEffect(() => {
    if (isDebuging) {
      invokeScript("debugExecution");
    }
  }, [isDebuging]);

  //creating duplicate array by activities

  const addPlaceholders = (uid, count, countIncrement) => {
    const placeholders = [];
    for (let i = 0; i < countIncrement; i++) {
      placeholders.push({
        id: "N",
        size: "32px",
        ruleOrderId: null,
        uid,
        index: count++,
      });
    }
    return { placeholders, count };
  };
  
  const createDupArray = (allActivities) => {
    const newDupArrayOfAct = [];
    let count = 1;
  
    // Updated addActivity to include parentId
    const addActivity = (id, size, ruleOrderId, uid, parentId = null, isEnd = false) => ({
      id,
      size,
      ruleOrderId,
      uid,
      parentId, // Include parentId
      index: count++,
      isEnd,
    });
  
    const handleDupArray = (activities, parentId = null) => {
      activities.forEach((activity) => {
        switch (activity.activityName) {
          case "IfElse":
            newDupArrayOfAct.push(addActivity("S", "32px", activity.ruleOrderId, activity.uid, parentId));
  
            if (!activity.thenActivities?.length) {
              const { placeholders, count: updatedCount } = addPlaceholders(activity.uid, count, 1);
              newDupArrayOfAct.push(...placeholders);
              count = updatedCount;
            } else {
              newDupArrayOfAct.push(addActivity("N", "32px", null, activity.uid, parentId));
              handleDupArray(activity.thenActivities, activity.uid); // Pass current uid as parentId
            //  newDupArrayOfAct.push(addActivity("N", "32px", null, activity.uid, parentId));
            }
  
            if (!activity.elseActivities?.length) {
              const { placeholders, count: updatedCount } = addPlaceholders(activity.uid, count, 1);
              newDupArrayOfAct.push(...placeholders);
              count = updatedCount;
            } else {
              newDupArrayOfAct.push(addActivity("N", "32px", null, activity.uid, parentId));
              handleDupArray(activity.elseActivities, activity.uid); // Pass current uid as parentId
             // newDupArrayOfAct.push(addActivity("N", "32px", null, activity.uid, parentId));
            }
            break;
  
          case "CheckError":
            newDupArrayOfAct.push(addActivity("S", "32px", activity.ruleOrderId, activity.uid, parentId));
  
            if (activity.checkError) {
              handleDupArray(activity.checkError, activity.uid); // Pass current uid as parentId   
              //newDupArrayOfAct.push(addActivity("N", "32px", null, activity.uid, parentId));    
            } else {
              newDupArrayOfAct.push(addActivity("N", "32px", activity.ruleOrderId, null, parentId));
            }
  
            if (!activity.onError?.length) {
              const { placeholders, count: updatedCount } = addPlaceholders(activity.uid, count, 1);
              newDupArrayOfAct.push(...placeholders);
              count = updatedCount;
              
            } else {
              newDupArrayOfAct.push(addActivity("N", "32px", null, activity.uid, parentId));
              handleDupArray(activity.onError, activity.uid); // Pass current uid as parentId
            }
  
            //newDupArrayOfAct.push(addActivity("S", "32px", null, activity.uid, parentId, true));
            break;
  
          default:
            if (activity.activityType === "S" || activity.activityType === "G") {
              newDupArrayOfAct.push(addActivity("S", "32px", activity.ruleOrderId, activity.uid, parentId));
              if (activity.subActivities) {
                handleDupArray(activity.subActivities, activity.uid); // Pass current uid as parentId
              }
            } else {
              newDupArrayOfAct.push(addActivity("N", "32px", activity.ruleOrderId, null, parentId));
            }
            break;
        }
      });
    };
  
    handleDupArray(allActivities);
    setDupList(newDupArrayOfAct);
  };
  
  

  useEffect(() => {
    if (scriptId && getToken()) {
      dispatch(setIsGettingRules(true));
      //fetching saved rules for currently opened script

      getScriptRules();
    }
  }, [scriptId, getToken(), versionName]);
  useEffect(() => {
    if (versionId) {
      //fetching variables for currently opened script
      getVariables();
    }
  }, [versionId, versionName]);

  const giveUidToEveryRule = (allActivities) => {
    const updateUid = (activities) => {
      return activities.map((item, index) => {

        if (item.activityType === "G" || item.activityType === "S") {
          //item.uid = uuidv4();
          item.uid = updateUuidAgainstRuleOrderId(uuidv4(),item.ruleOrderId);
        }
        if(item.activityName==="CheckError"){
          
          item.checkError[0].uid=updateUuidAgainstRuleOrderId(uuidv4(),item.checkError[0].ruleOrderId);

        }
        if (item.subActivities) {
         
          let res2 = updateUid(item.subActivities);
          item.subActivities = res2;
          return item;
        } else if (item.activityName === "IfElse") {
          let res2 = updateUid(item.thenActivities || []);
          let res4 = item.elseActivities
            ? updateUid(item.elseActivities)
            : null;
          item.thenActivities = res2;
          item.elseActivities = res4;
          return item;
        } else if (item.activityName === "CheckError") {
         
         
         
         let res2 = updateUid(item.checkError || []);
         let res4 = updateUid(item.onError || []);

          item.checkError = res2;
          item.onError = res4;
          return item;
        } else {
          return item;
        }
      });
    };
    return updateUid(allActivities);
  };

  const getScriptRules = async () => {
    const axiosInstance = createInstance();
    try {
      let response = await axiosInstance.get(
        `${RULES}/${scriptId}/${versionName}`
      );

      if (response.status === 200) {
        const data = response.data.data ? response.data.data[0] : {};
        const activities = data["rules"] || [];
        let { scriptName, versionId, projectName, isCommited, createdBy } =
          data;
        dispatch(setIsGettingRules(false));
        dispatch(
          setOpenScriptDetails({
            scriptName,
            scriptId,
            versionName,
            versionId,
            projectName,
            isCommited,
            createdBy,
          })
        );

        //giving uids to every group activity
        const allActs = giveUidToEveryRule(activities);
        //for our line counts of activities
        createDupArray(allActs);

        setScriptName(data);
        setActivitiesList(allActs);
        setActivitiesListOrg(allActs);
        dispatch(setRedo([]));
        dispatch(setUndo([]));
        dispatch(setFocusItemId(null));
        setLastAction(null);
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message:
              errMsg || "could not fetch rules.something went wrong on server.",
            title: "Script",
            notificationType: "ERROR",
            onClose: () => {
              if (error?.response?.status === 423) {
                history.push("/Dashboard");
              }
            },
          });
        },
      });
    }
    dispatch(setIsGettingRules(false));
  };

  // useEffect(() => {
  //   if (recordedActivity) {
  //     const recordIdObj =
  //       recordedActivity.params &&
  //       recordedActivity.params.find((obj) => obj.paramName === "RecordId");

  //     if (recordIdObj && recordIdObj.paramValue) {
  //       updateRecorderActivities(recordIdObj.paramValue, recordedActivity);
  //     }
  //   }
  // }, [recordedActivity]);
  // useEffect(() => {
  //   if (windowRecordedActivity) {
  //     if (activitiesList.length > 0) {
  //       const newActList = [...activitiesList, ...windowRecordedActivity];
  //       updateRulesOrder(newActList);
  //       createDupArray(newActList);

  //       setActivitiesList(newActList);
  //       setActivitiesList([...activitiesList, ...windowRecordedActivity]);
  //     } else {
  //       setActivitiesList(windowRecordedActivity);
  //       createDupArray(windowRecordedActivity);
  //     }
  //   }
  // }, [windowRecordedActivity]);

  const getVariables = async () => {
    const axiosInstance = createInstance();

    try {
      let res = await axiosInstance.get(`${VARIABLES}/${versionId}`);

      if (res.status === 200) {
        setAllVariables({ allVariables: res.data.data || [] });
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "",
            title: "",
            notificationType: "ERROR",
          });
        },
      });
    }
  };
  //hitting api to start windows recorder
  // const InvokeWindowsRecorder = async () => {
  //   try {
  //     const axiosInstance = createInstance();
  //     const authenticationKey = getAuthKey();
  //     const config = {
  //       headers: {
  //         RobotAuthorization: authenticationKey,
  //       },
  //     };

  //     const res = await axiosInstance.get(
  //       `${WINDOW_RECORDER}/${scriptId}/${versionId}`,
  //       config
  //     );
  //   } catch (error) {
  //     handleNetworkRequestError({
  //       error,
  //       history,
  //       onError: (errMsg) => {
  //         setNotification({
  //           isOpen: true,
  //           message: errMsg || "",
  //           title: "",
  //           notificationType: "ERROR",
  //         });
  //       },
  //     });
  //   }
  // };

  //checking if saved rules contain any custom activity which is not of current selected version
  const isSavedRulesContainMismatchCustomActivity = () => {
    let isMismatchFlag = false;

    const checkIfMismatch = (list) => {
      list.some((act) => {
        if (act.customActivity === 2) {
          const isBelong = currentCustomActivitiesGroups.some((grp) => {
            const objAct = grp?.activities?.find(
              (cusAct) => cusAct.activityId === act.activityId
            );

            if (objAct) {
              return true;
            }
          });
          if (isBelong && act?.subActivities) {
            checkIfMismatch(act.subActivities);
          } else if (!isBelong) {
            isMismatchFlag = true;
            return true;
          }
          return false;
        }
        if (act.activityName === "IfElse") {
          checkIfMismatch(act.thenActivities || []);
          checkIfMismatch(act.elseActivities || []);
        } else if (act.activityName === "CheckError") {
          checkIfMismatch(act.checkError || []);
          checkIfMismatch(act.onError || []);
        } else if (act.subActivities) {
          checkIfMismatch(act.subActivities);
        }
        return false;
      });
    };
    checkIfMismatch(activitiesList);
    return isMismatchFlag;
  };

  //checking if saved rules contain any custom activity which is not of current selected version
  const isSavedRulesContainDeprecatedCustomActivity = () => {
    let isDeprecatedFlag = false;
    const checkIfDeprecated = (list) => {
      list.some((act) => {
        if (act.customActivity === 2) {
          return currentCustomActivitiesGroups.some((grp) => {
            const objAct = grp.activities?.find(
              (cusAct) => cusAct.activityId === act.activityId
            );

            if (objAct && grp.isDeprecated) {
              isDeprecatedFlag = true;
              return true;
            }
          });
        }
        if (!isDeprecatedFlag && act.activityName === "IfElse") {
          checkIfDeprecated(act.thenActivities || []);
          checkIfDeprecated(act.elseActivities || []);
        } else if (!isDeprecatedFlag && act.activityName === "CheckError") {
          checkIfDeprecated(act.checkError || []);
          checkIfDeprecated(act.onError || []);
        } else if (!isDeprecatedFlag && act.subActivities) {
          checkIfDeprecated(act.subActivities);
        }
        return false;
      });
    };
    checkIfDeprecated(activitiesList);
    return isDeprecatedFlag;
  };

  /*****************************************************************************************
   * @author asloob_ali BUG ID : 100695 Description :  Stop Debug button is not working
   *  Reason:to stop script execution, api was not integrated .
   * Resolution : integrated api to stop the execution of script.
   *  Date : 10/03/2022             ***************************************************************************************/

  const stopExecution = async () => {
    const axiosInstance = createInstance();
    const authenticationKey = getAuthKey();
    const config = {
      headers: {
        RobotAuthorization: authenticationKey,
      },
    };
    try {
      let res = await axiosInstance.get(`${ROBOT_API}${STOP}`, config);

      if (res.status === 200) {
        dispatch(setIsExecutionPause(false));
        dispatch(setDebugDetails(null));
        dispatch(setIsDebuging(false));
        dispatch(setIsExecutingScript(false));
      }
    } catch (error) {
      console.log(error);
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "",
            title: "",
            notificationType: "ERROR",
          });
        },
      });
    }
  };

  var isWebRecorderInstalled = false;

  window.addEventListener("message", function (event) {
    const allowedOrigins = [`${window?.location?.origin}`];

    if (
      allowedOrigins.includes(event.origin) &&
      event.source == window &&
      event.data.direction &&
      event.data.direction == "from-content-script-NewgenWebRecorder"
    ) {
      if (event.data.message == "Installed") {
        isWebRecorderInstalled = true;
      } else {
        setNotification({
          isOpen: true,
          message: "Kindly refresh the page",
          notificationType: "ERROR",
          title: "",
        });
      }
    }
  });

  // function InvokeWebRecorder() {
  //   isWebRecorderInstalled = false;

  //   document.dispatchEvent(
  //     new CustomEvent("yourCustomEvent", {
  //       detail: { invoke: false },
  //     })
  //   );
  //   setTimeout(() => {
  //     if (isWebRecorderInstalled) {
  //       document.dispatchEvent(
  //         new CustomEvent("yourCustomEvent", {
  //           detail: dataWebRecorder,
  //         })
  //       );
  //     } else {
  //       setNotification({
  //         isOpen: true,
  //         message:
  //           "Please check if WebRecorder Extension is installed and enabled.",
  //         notificationType: "ERROR",
  //         title: "",
  //       });
  //     }
  //   }, 1000);
  // }
  // const InvokeWebRecorder = async () =>  {
  //   // isWebRecorderInstalled = false;

  //   // document.dispatchEvent(
  //   //   new CustomEvent("yourCustomEvent", {
  //   //     detail: { invoke: false },
  //   //   })
  //   // );
  //   // setTimeout(() => {
  //   //   if (isWebRecorderInstalled) {
  //   //     document.dispatchEvent(
  //   //       new CustomEvent("yourCustomEvent", {
  //   //         detail: dataWebRecorder,
  //   //       })
  //   //     );
  //   //   } else {
  //   //     setNotification({
  //   //       isOpen: true,
  //   //       message:
  //   //         "Please check if WebRecorder Extension is installed and enabled.",
  //   //       notificationType: "ERROR",
  //   //       title: "",
  //   //     });
  //   //   }
  //   // }, 1000);
  //   try {
  //     const axiosInstance = createInstance();
  //     const authenticationKey = getAuthKey();
  //     const config = {
  //       headers: {
  //         RobotAuthorization: authenticationKey,
  //       },
  //     };

  //     const res = await axiosInstance.get(
  //       `${WEB_RECORDER}/${scriptId}/${versionId}`,
  //       config
  //     );
  //   } catch (error) {
  //     handleNetworkRequestError({
  //       error,
  //       history,
  //       onError: (errMsg) => {
  //         setNotification({
  //           isOpen: true,
  //           message: errMsg || "",
  //           title: "",
  //           notificationType: "ERROR",
  //         });
  //       },
  //     });
  //   }
  // }
  const handleOpenModal = async (name) => {
    /*****************************************************************************************
     * @author asloob_ali BUG ID : 103127 Description : 103127  Designer: Recorder is working fine during session time out in designer application
     *  Reason:after certain time without activity the user session expires on server.we can not know if the session ended without making an api call to server.
     so user was able to open windows/web recorder and perform recording, but while saving because of session expiration user was not able to save those changes.
     * Resolution : now before opening modal/recorders,we are validating session by hitting below api.
     *  Date : 03/01/2022    
     * Enhanced-> terminating function when getting session timeout error
     * Date : 13/01/2022
     * 
     *          ****************************************/

    //checking if session of currently logged in user is valid via api call
    /*   const axiosInstance = createInstance(`${API_BASE_URL_ADMIN}`);
       const config = {
         headers: {
           Authorization: "Bearer " + getToken(),
         },
       };
   
       try {
         let res = await axiosInstance.post(`${USERS}${VALIDATE}`, config);
         if (res.status === 200) {
           //if user session expired returned data will be null
           if (res.data == null) {
             dispatch(userLogout({ history }));
             return;
           }
         }
       } catch (error) {
         handleNetworkRequestError({
           error,
           history,
           onError: (errMsg) => {
             setNotification({
               isOpen: true,
               message: errMsg || "Error in token validation.",
               title: "",
               notificationType: "ERROR",
             });
           },
         });
         return;
       }*/

    switch (name) {
      // case "Web Recorder":
      //   if (
      //     doesUserHavePermission({
      //       isShared: scriptValues?.createdBy !== +userId,
      //       permissionNum: MODIFY_INDEX,
      //     })
      //   ) {
      //     InvokeWebRecorder();
      //   } else {
      //     setNotification({
      //       isOpen: true,
      //       message: "You Don't have permission to modify a script.",
      //       notificationType: "ERROR",
      //       title: "",
      //     });
      //   }
      //   break;
      // case "Windows Recorder":
      //   if (
      //     doesUserHavePermission({
      //       isShared: scriptValues?.createdBy !== +userId,
      //       permissionNum: MODIFY_INDEX,
      //     })
      //   ) {
      //     if (isRobotAvailable) {
      //       InvokeWindowsRecorder();
      //     } else {
      //       setNotification({
      //         isOpen: true,
      //         message: "Kindly Connect Robot",
      //         title: "",
      //         notificationType: "ERROR",
      //       });
      //     }
      //   } else {
      //     setNotification({
      //       isOpen: true,
      //       message: "You Don't have permission to modify a script.",
      //       notificationType: "ERROR",
      //       title: "",
      //     });
      //   }
      //   break;
      case "Run Script":
        if (isSavedRulesContainMismatchCustomActivity()) {
          setNotification({
            isOpen: true,
            message: `${VERSION_MISMATCH_MSG}`,
            title: "",
            notificationType: "ERROR",
          });
          return;
        }
        if (isSavedRulesContainDeprecatedCustomActivity()) {
          setNotification({
            isOpen: true,
            message: `${DEPRECATE_MSG}`,
            title: "",
            notificationType: "ERROR",
          });
          return;
        }
        dispatch(setRunScriptModal("All"));
        dispatch(setRunScript(true));
        break;
      case "Debug":
        if (isSavedRulesContainMismatchCustomActivity()) {
          setNotification({
            isOpen: true,
            message: `${VERSION_MISMATCH_MSG}`,
            title: "",
            notificationType: "ERROR",
          });
          return;
        }
        if (isSavedRulesContainDeprecatedCustomActivity()) {
          setNotification({
            isOpen: true,
            message: `${DEPRECATE_MSG}`,
            title: "",
            notificationType: "ERROR",
          });
          return;
        }
        //dispatch(setIsDebuging(true));
        setOpenModalName(name);
       
        break;
      case "Add Breakpoint":
        if (selectedActivity) {
          dispatch(handleBreakpointsArray(selectedActivity.ruleOrderId));
        }
        break;
      case "Errors":
        dispatch(setRunScriptModal(name));
        break;
      case "Output":
        dispatch(setRunScriptModal(name));
        break;
      case "Logs":
        dispatch(setRunScriptModal(name));
        break;
      case "Discard Changes":
        discardScriptChanges();
        break;
      case "Commit":
        if (
          doesUserHavePermission({
            isShared: scriptValues?.createdBy !== +userId,
            permissionNum: COMMIT_SCRIPT_INDEX,
          })
        ) {
          if (isSavedRulesContainMismatchCustomActivity()) {
            setNotification({
              isOpen: true,
              message: `${VERSION_MISMATCH_MSG}`,
              title: "",
              notificationType: "ERROR",
            });
            return;
          }
          if (isSavedRulesContainDeprecatedCustomActivity()) {
            setNotification({
              isOpen: true,
              message: `${DEPRECATE_MSG}`,
              title: "",
              notificationType: "ERROR",
            });
            return;
          }
          commitScript();
        } else {
          setNotification({
            isOpen: true,
            message: "You Don't have permission to commit a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        break;

      case "Save":
        if (
          doesUserHavePermission({
            isShared: scriptValues?.createdBy !== +userId,
            permissionNum: MODIFY_INDEX,
          })
        ) {
          if (isSavedRulesContainMismatchCustomActivity()) {
            setNotification({
              isOpen: true,
              message: `${VERSION_MISMATCH_MSG}`,
              title: "",
              notificationType: "ERROR",
            });
            return;
          }
          if (isSavedRulesContainDeprecatedCustomActivity()) {
            setNotification({
              isOpen: true,
              message: `${DEPRECATE_MSG}`,
              title: "",
              notificationType: "ERROR",
            });
            return;
          }
          saveScriptRules();
        } else {
          setNotification({
            isOpen: true,
            message: "You Don't have permission to modify a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
        }
        break;
      case "Resume":
        //to resume  debuging
        resumeDebugScript(0);
        break;
      case "Step by Step (F5)":
        //to resume debuging in step by step mode
        resumeDebugScript(1);
        break;
      case "Stop Debug":
        stopExecution();
        break;
      case "Stop":
        stopExecution();
        break;
      case "Refresh":
        refreshScriptData();
        break;
      default:
        setOpenModalName(name);
        break;
    }
  };

  // callback for update nodes

  const handleCloseModal = () => {
    setOpenModalName(null);
  };

  const saveScriptRules = async (onSuccess) => {
    const axiosInstance = createInstance();

    dispatch(setIsSavingRules(true));
    let updatedNodes = [...activitiesList];

    const inputBody = {
      versionId: +versionId,
      rules: updatedNodes,
    };

    try {
      let res = await axiosInstance.post(`${RULES}`, { ...inputBody });

      if (res.status === 200) {
        setActivitiesListOrg(_.cloneDeep(activitiesList));
        dispatch(setIsSavingRules(false));
        dispatch(setRedo([]));
        dispatch(setUndo([]));
        dispatch(setFocusItemId(null));
       // dispatch(setUuidRuleOrderid(uuid,updatedNodes[0].ruleOrderId))
        // setActiveTab("Script");
        // setOpenDialog(false);
        // setActiveTab('Script')
        setLastAction(null);
        setNotification({
          isOpen: true,
          message: res.data?.message || "rules saved.",
          title: "Service Flow",
          notificationType: "SUCCESS",
        });

        /* if (res.data.data) {
          const rules = res.data.data[0]["rules"];

          if (rules) {
            //for our line counts of activities
            createDupArray(rules);
            setActivitiesList(rules);
            setActivitiesListOrg(rules);
          }
        }*/
      }
      if (typeof onSuccess === "function") {
        onSuccess();
      }
    } catch (error) {
      dispatch(setIsSavingRules(false));
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "Rules not saved.",
            title: "Service Flow",
            notificationType: "ERROR",
          });
        },
      });
    }
  };

  //   const saveScriptRules = async () => {
  //     const axiosInstance = createInstance();
  //     dispatch(setIsSavingRules(true));

  //     // Make a copy of the activities list
  //     let updatedNodes = [...activitiesList];

  //     // Update positions for each activity in the list
  //     updatedNodes.forEach((activity) => {
  //         if (activity) {
  //             updatedNodes = updateActivityPositionsRecursively(activity, updatedNodes);
  //         } else {
  //             console.warn('Found an undefined activity in updatedNodes');
  //         }
  //     });

  //     console.log(updatedNodes, "Updated nodes after processing");

  //     const inputBody = {
  //         versionId: +versionId,
  //         rules: updatedNodes,
  //     };

  //     try {
  //         let res = await axiosInstance.post(`${RULES}`, { ...inputBody });

  //         if (res.status === 200) {
  //             // Assuming you want to reset or set the original activities list
  //             setActivitiesListOrg(_.cloneDeep(updatedNodes));
  //             dispatch(setIsSavingRules(false));
  //             dispatch(setRedo([]));
  //             dispatch(setUndo([]));
  //             dispatch(setFocusItemId(null));
  //             setLastAction(null);
  //             setNotification({
  //                 isOpen: true,
  //                 message: res.data?.message || "Rules saved.",
  //                 title: "Service Flow",
  //                 notificationType: "SUCCESS",
  //             });

  //             /* Uncomment if you want to handle received rules from the response
  //             if (res.data.data) {
  //                 const rules = res.data.data[0]["rules"];
  //                 if (rules) {
  //                     createDupArray(rules);
  //                     setActivitiesList(rules);
  //                     setActivitiesListOrg(rules);
  //                 }
  //             } */
  //         }
  //     } catch (error) {
  //         dispatch(setIsSavingRules(false));
  //         handleNetworkRequestError({
  //             error,
  //             history,
  //             onError: (errMsg) => {
  //                 setNotification({
  //                     isOpen: true,
  //                     message: errMsg || "Rules not saved.",
  //                     title: "Service Flow",
  //                     notificationType: "ERROR",
  //                 });
  //             },
  //         });
  //     }
  // };

  const discardScriptChanges = async () => {
    const axiosInstance = createInstance();

    const inputBody = {
      scriptId: +scriptId,
      versionId: +versionId,
    };

    try {
      let res = await axiosInstance.put(`${DISCARD_CHANGES}${SCRIPT}`, {
        ...inputBody,
      });

      if (res.status === 200) {
        const rules = res.data?.data?.rules;

        setActivitiesList(rules || []);
        createDupArray(rules || []);
        dispatch(setBreakpointsArray([]));
        dispatch(setDebugDetails(null));
        dispatch(setRedo([]));
        dispatch(setUndo([]));
        dispatch(setFocusItemId(null));

        setNotification({
          isOpen: true,
          message: res.data.message || "changes discarded.",
          title: scriptValues.scriptName || "",
          notificationType: "SUCCESS",
        });
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "changes not discarded.",
            title: "Service Flow",
            notificationType: "ERROR",
          });
        },
      });
    }
  };

  const commitScript = async () => {
    const axiosInstance = createInstance();

    const inputBody = {
      scriptId: +scriptId,
      versionId: +versionId,
    };

    try {
      let res = await axiosInstance.post(`${COMMIT}${SCRIPT}`, {
        ...inputBody,
      });

      if (res.status === 200) {
        setNotification({
          isOpen: true,
          message: res.data.message || "commited",
          title: scriptValues.scriptName || "",
          notificationType: "SUCCESS",
        });

        const versionName = res.data.data[0]["versionName"] || "";
        const isCommited = res.data.data[0]["isCommited"] || false;
        //updating the current version of the script
        if (versionName) {
          dispatch(
            setOpenScriptDetails({ ...scriptValues, versionName, isCommited })
          );
        }
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "Rules not commited.",
            title: "Service Flow",
            notificationType: "ERROR",
          });
        },
      });
    }
    return true;
  };

  const resumeDebugScript = async (type) => {
    const axiosInstance = createInstance();
    const authenticationKey = getAuthKey();
    const config = {
      headers: {
        RobotAuthorization: authenticationKey,
      },
    };
    const id = debugDetails && debugDetails.ruleOrderId;

    if (id) {
      try {
        let res = await axiosInstance.put(
          `${RESUME_SCRIPT}/${id}/${type}`,
          null,
          config
        );

        if (res.status === 200) {
          dispatch(setIsExecutionPause(false));
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setNotification({
              isOpen: true,
              message: errMsg || "",
              title: "",
              notificationType: "ERROR",
            });
          },
        });
      }
    } else {
      console.log("dont have breakpoint ruleOrderId to continue");
    }
  };

  const refreshScriptData = () => {
    setActivitiesList(activitiesListOrg);
    createDupArray(activitiesListOrg);
    dispatch(setBreakpointsArray([]));

    dispatch(setDebugDetails(null));
    dispatch(setRedo([]));
    dispatch(setUndo([]));
    dispatch(setFocusItemId(null));
    setLastAction(null);
  };

  const handleEndpointDetails = (endpointDetails) => {
    setEndpointDetails(endpointDetails);
    console.log(endpointDetails);
    setOpenModalName("ServiceFlowDetails");
  };
  const showModal = () => {
    let modalToOpen = null;

    switch (openModalName) {
      case "Variables":
        modalToOpen = (
          <VariableListModal
            id="RPA_ScriptEditor_VariableList"
            handleClose={handleCloseModal}
            isOpen={true}
          />
        );
        break;
      case "ProcessVariables":
        modalToOpen = (
          <ProcessVariablesModal
            id="RPA_ScriptEditor_ProcessVariable"
            handleClose={handleCloseModal}
            isOpen={true}
            handleOpenModal={handleOpenModal}
          />
        );
        break;
      case "DocumentsVariables":
        modalToOpen = (
          <DocumentVariablesModal
            id="RPA_ScriptEditor_DocumentVariable"
            handleClose={handleCloseModal}
            isOpen={true}
            handleOpenModal={handleOpenModal}
          />
        );
        break;
      case "Publish":
        if (
          doesUserHavePermission({
            isShared: scriptValues?.createdBy !== +userId,
            permissionNum: PUBLISH_SCRIPT_INDEX,
          })
        ) {
          modalToOpen = (
            <PublishScriptModal
              id="RPA_ScriptEditor_PublishScript"
              handleClose={handleCloseModal}
              isOpen={true}
              selectedScript={scriptValues}
              handleEndpointDetails={handleEndpointDetails}
            />
          );
        } else {
          setNotification({
            isOpen: true,
            message: "You Don't have permission to publish a Service Flow.",
            notificationType: "ERROR",
            title: "",
          });
          //Bug 156174 - If publish serviceflow rights not given then user is getting the error of blank error page
          //Author:nitin_tomar
          //Date: 12 FEB 2025
          //Description: If user is not having rights then setting the modal to null;
          setOpenModalName(null);
        }
        
        break;
      case "ServiceFlowDetails":
        modalToOpen = (
          <ServiceFlowDetailsModal
            id="RPA_ScriptEditor_PublishScript"
            handleClose={handleCloseModal}
            isOpen={true}
            selectedScript={scriptValues}
            endpointDetails={endpointDetails}
          />
        );
        break;
      case "Debug":
        modalToOpen = (
          <DebugServiceFlow
            id="RPA_ScriptEditor_DebugServiceFlow"
            handleClose={handleCloseModal}
            isOpen={true}
            isDebuging={isDebuging}
            setIsDebuging={setIsDebuging}
            invokeScript={invokeScript}
            debugValue={defaultValue}
            updatedData={updatedData}
            setDefaultValue={setDefaultValue}

          />
        );
        break;
      // case "Robot":
      //   modalToOpen = (
      //     <RobotDownloadModal
      //       id="RPA_ScriptEditor_BotDownload"
      //       handleClose={handleCloseModal}
      //       isOpen={true}
      //     />
      //   );
      //   break;
      case "Set Activity Version":
        modalToOpen = (
          <SetActivityVersionModal
            id="RPA_ScriptEditor_SetActivityVersion"
            handleClose={handleCloseModal}
            isOpen={true}
          />
        );
        break;
      default:
        break;
    }
    return modalToOpen;
  };

  const handleLeftPanel = () => {
    setLeftPanelOpen(!leftPanelOpen);
  };

  const handleClipboardActions = (action) => {
    switch (action) {
      case "Cut[Ctrl+X]":
      case "Cut":
        if (selectedActivity) {
          setSelectedClipboardAct(selectedActivity);
          const result = RemoveActivity(selectedActivity, activitiesList);
          let result1 = [];
          if (result.length > 0) {
            result1 = updateRulesOrder(_.cloneDeep(result));
          }

          setActivitiesList(result1);
          createDupArray(result1);
          setLastAction(selectedActivity);
          dispatch(handleSelectedActivity(null));
        }
        break;
      case "Copy[Ctrl+C]":
      case "Copy":
        if (selectedActivity) {
          setSelectedClipboardAct(selectedActivity);
          dispatch(handleSelectedActivity(null));
        }

        break;
      case "Paste[Ctrl+V]":
        if (selectedActivity && selectedClipboardAct) {
          let newActivity = {
            ...selectedClipboardAct,
            ruleOrderId: selectedActivity.ruleOrderId + 1,
          };

          if (
            newActivity.activityType === "G" ||
            newActivity.activityType === "S"
          ) {
            // newActivity["uid"] = uuidv4();
            newActivity["uid"]= updateUuidAgainstRuleOrderId(uuidv4(),newActivity.ruleOrderId);
            const newActArr = giveUidToEveryRule([_.cloneDeep(newActivity)]);
            newActivity = newActArr[0];
          }
          const result = addActivity(
            newActivity,
            selectedActivity,
            activitiesList
          );
          const result1 = updateRulesOrder(_.cloneDeep(result));

          setActivitiesList(result1);
          createDupArray(result1);

          setLastAction(newActivity);
        }

        break;
      case "Paste in Next Line":
        if (selectedActivity) {
          const newActivity = {
            ..._.cloneDeep(selectedActivity),
            ruleOrderId: selectedActivity.ruleOrderId + 1,
          };
         
          if (
            newActivity.activityType === "G" ||
            newActivity.activityType === "S"
          ) {
            //newActivity["uid"] = uuidv4();
            newActivity["uid"] = updateUuidAgainstRuleOrderId(
              uuidv4(),
              newActivity.ruleOrderId
            );
          }
          const result = addActivity(
            newActivity,
            selectedActivity,
            activitiesList
          );

          const result1 = updateRulesOrder(_.cloneDeep(result));

          setActivitiesList(result1);
          createDupArray(result1);
          setLastAction(newActivity);
        }
        break;
      case "Disable Activity":
        if (selectedActivity) {
          const newActivity = {
            ...selectedActivity,
            isDisabled: 1,
          };

          const result = disableOrEnableActivity(newActivity);

          setActivitiesList(result);

          setLastAction(newActivity);
        }
        break;
      case "Enable Activity":
        if (selectedActivity) {
          const newActivity = {
            ...selectedActivity,
            isDisabled: 0,
          };

          const result = disableOrEnableActivity(newActivity);

          setActivitiesList(result);

          setLastAction(newActivity);
        }
        break;

      case "Delete[delete]":
        if (selectedActivity) {
          const result = RemoveActivity(selectedActivity, activitiesList);
          let result1 = [];
          if (result.length > 0) {
            result1 = updateRulesOrder(_.cloneDeep(result));
          }

          setActivitiesList(result1);
          createDupArray(result1);
          setLastAction(selectedActivity);

          dispatch(handleSelectedActivity(null));
        }
        break;
      case "Undo[Ctrl+Z]":
        handleUndoRedoArrayValue("z");
        break;
      case "Redo[Ctrl+Y]":
        handleUndoRedoArrayValue("y");
        break;
      case "Enable Breakpoint":
      case "Disable Breakpoint":
        if (selectedActivity) {
          dispatch(handleBreakpointsArray(selectedActivity.ruleOrderId));
        }
        break;
      default:
        setOpenModalName(action);
        break;
    }
  };

  const RemoveActivity = (actvityToRemove, allActivities) => {
    let activityIndex = null;
    let countFlag = false;
    const updateActivities = (activities) => {
      let newActivities = _.map(activities, (activity, index) => {
        if (
          actvityToRemove.ruleOrderId === activity.ruleOrderId &&
          actvityToRemove.activityId === activity.activityId
        ) {
          activityIndex = index;
          countFlag = true;
        }
        if (activity.activityName === "IfElse" && !countFlag) {
          let arr = updateActivities(activity.thenActivities || []);
          let arr1 = activity.elseActivities
            ? updateActivities(activity.elseActivities)
            : null;
          activity.thenActivities = _.cloneDeep(arr);
          activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
          return activity;
        } else if (activity.activityName === "CheckError" && !countFlag) {
          let arr = updateActivities(activity.checkError || []);
          let arr1 = updateActivities(activity.onError || []);

          activity.checkError = _.cloneDeep(arr);
          activity.onError = _.cloneDeep(arr1);
          return activity;
        } else if (activity.subActivities && !countFlag) {
          let arr = updateActivities(_.cloneDeep(activity.subActivities));
          activity.subActivities = _.cloneDeep(arr);
          return activity;
        } else {
          return activity;
        }
      });

      if (activityIndex !== null && activityIndex !== -1) {
        newActivities.splice(activityIndex, 1);
        activityIndex = null;
      }

      return newActivities;
    };

    return updateActivities(_.cloneDeep(allActivities));
  };

  //updating the rule order ids of activities in design area
  const updateRulesOrder = (allActivities) => {
    let newRuleId = 0;

    const updateRuleOrderId = (activities) => {
      return activities.map((item, index) => {
        newRuleId++;
        item.ruleOrderId = newRuleId;
        if (item.subActivities) {
          let res2 = updateRuleOrderId(item.subActivities);
          item.subActivities = res2;
          return item;
        } else if (item.activityName === "IfElse") {
          let res2 = updateRuleOrderId(item.thenActivities || []);
          let res4 = item.elseActivities
            ? updateRuleOrderId(item.elseActivities)
            : null;
          item.thenActivities = res2;
          item.elseActivities = res4;
          return item;
        } else if (item.activityName === "CheckError") {
          let res2 = updateRuleOrderId(item.checkError || []);
          let res4 = updateRuleOrderId(item.onError || []);

          item.checkError = res2;
          item.onError = res4;
          return item;
        } else {
          return item;
        }
      });
    };
    return updateRuleOrderId(allActivities);
  };

  const addActivity = (newActivity, activitySelected, allActivities) => {
    let IdWhereAdding = null;
    let countFlag = false;

    const updateActivities = (activities) => {
      let newActivities = _.map(activities, (activity, index) => {
        if (
          activitySelected.ruleOrderId === activity.ruleOrderId &&
          activity.activityId === activitySelected.activityId
        ) {
          IdWhereAdding = index + 1;
          countFlag = true;
        }
        if (activity.activityName === "IfElse" && !countFlag) {
          let arr = updateActivities(activity.thenActivities || []);
          let arr1 = activity.elseActivities
            ? updateActivities(activity.elseActivities)
            : null;
          activity.thenActivities = _.cloneDeep(arr);
          activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
          return activity;
        } else if (activity.activityName === "CheckError" && !countFlag) {
          let arr = updateActivities(activity.checkError || []);
          let arr1 = updateActivities(activity.onError);

          activity.checkError = _.cloneDeep(arr);
          activity.onError = _.cloneDeep(arr1);
          return activity;
        } else if (activity.subActivities && !countFlag) {
          let arr = updateActivities(activity.subActivities);
          activity.subActivities = _.cloneDeep(arr);
          return activity;
        } else {
          return activity;
        }
      });
      if (IdWhereAdding) {
        if (activitySelected.activityName === "IfElse") {
          if (
            newActivities[IdWhereAdding - 1] &&
            newActivities[IdWhereAdding - 1].thenActivities
          ) {
            newActivities[IdWhereAdding - 1].thenActivities.unshift(
              newActivity
            );
          } else {
            newActivities[IdWhereAdding - 1].thenActivities = [
              { ...newActivity },
            ];
          }
        } else if (activitySelected.activityName === "CheckError") {
          if (
            newActivities[IdWhereAdding - 1] &&
            newActivities[IdWhereAdding - 1].checkError
          ) {
            newActivities[IdWhereAdding - 1].checkError.unshift(newActivity);
          } else {
            newActivities[IdWhereAdding - 1].checkError = [{ ...newActivity }];
          }
        } else if (
          activitySelected.activityType === "G" ||
          activitySelected.activityType === "S"
        ) {
          if (
            newActivities[IdWhereAdding - 1] &&
            newActivities[IdWhereAdding - 1].subActivities
          ) {
            newActivities[IdWhereAdding - 1].subActivities.unshift(newActivity);
          } else {
            newActivities[IdWhereAdding - 1].subActivities = [
              { ...newActivity },
            ];
          }
        } else {
          newActivities.splice(IdWhereAdding, 0, newActivity);
        }
        IdWhereAdding = null;
      }
      return newActivities;
    };

    return updateActivities(allActivities);
  };

  const addOrRemoveElseAct = (activitySelected, action) => {
    let countFlag = false;

    const updateActivities = (activities) => {
      return _.map(activities, (activity, index) => {
        if (
          activitySelected.ruleOrderId === activity.ruleOrderId &&
          activity.activityId === activitySelected.activityId
        ) {
          countFlag = true;
          if (action === "Add") {
            activity.elseActivities = [];
          } else if (action === "Remove") {
            activity.elseActivities = null;
          }
        }
        if (activity.activityName === "IfElse" && !countFlag) {
          let arr = updateActivities(activity.thenActivities || []);
          let arr1 = activity.elseActivities
            ? updateActivities(activity.elseActivities)
            : null;
          activity.thenActivities = _.cloneDeep(arr);
          activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
          return activity;
        } else if (activity.activityName === "CheckError" && !countFlag) {
          let arr = updateActivities(activity.checkError || []);
          let arr1 = updateActivities(activity.onError);

          activity.checkError = _.cloneDeep(arr);
          activity.onError = _.cloneDeep(arr1);
          return activity;
        } else if (activity.subActivities && !countFlag) {
          let arr = updateActivities(activity.subActivities);
          activity.subActivities = _.cloneDeep(arr);
          return activity;
        } else {
          return activity;
        }
      });
    };

    const newActList = updateActivities(_.cloneDeep(activitiesList));
    createDupArray(newActList);

    setActivitiesList(newActList);
  };

  // const updateRecorderActivities = (recordId, activityToUpdate) => {
  //   const activities = [...activitiesList];

  //   let IndexOfEditedActivity = null;
  //   let countFlag = false;

  //   const updateActivities = (allActivities) => {
  //     let newActivities = _.map(allActivities, (activity, index) => {
  //       const recordIdObj =
  //         activity.params &&
  //         activity.params.find((obj) => obj.paramName === "RecordId");

  //       if (recordIdObj) {
  //         if (recordIdObj.paramValue === recordId) {
  //           IndexOfEditedActivity = index;
  //           countFlag = true;
  //         }
  //       }
  //       if (activity.activityName === "IfElse" && !countFlag) {
  //         let arr = updateActivities(activity.thenActivities || []);
  //         let arr1 = activity.elseActivities
  //           ? updateActivities(activity.elseActivities)
  //           : null;
  //         activity.thenActivities = _.cloneDeep(arr);
  //         activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
  //         return activity;
  //       } else if (activity.activityName === "CheckError" && !countFlag) {
  //         let arr = updateActivities(activity.checkError || []);
  //         let arr1 = updateActivities(activity.onError);

  //         activity.checkError = _.cloneDeep(arr);
  //         activity.onError = _.cloneDeep(arr1);
  //         return activity;
  //       } else if (activity.subActivities && !countFlag) {
  //         let arr = updateActivities(activity.subActivities);
  //         activity.subActivities = _.cloneDeep(arr);
  //         return activity;
  //       } else {
  //         return activity;
  //       }
  //     });
  //     if (IndexOfEditedActivity !== null) {
  //       newActivities.splice(IndexOfEditedActivity, 1, activityToUpdate);
  //       IndexOfEditedActivity = null;
  //     }

  //     return newActivities;
  //   };

  //   const result = updateActivities(activities);
  //   if (countFlag) {
  //     createDupArray(result);
  //     //updated activities with updated Rule Order Id
  //     let newResult = updateRulesOrder(_.cloneDeep(result));

  //     setActivitiesList(newResult);
  //   } else {
  //     const newResult = [...activities, activityToUpdate];
  //     let newResult2 = updateRulesOrder(_.cloneDeep(newResult));

  //     createDupArray(newResult2);
  //     setActivitiesList(newResult2);
  //   }
  // };

  const checkIfActvityInsideDropedActivity = (
    actDroped,
    activityWhereDroped
  ) => {
    let isChild = false;
    const checkIsChild = (activities) => {
      _.forEach(activities, (activity, index) => {
        if (
          activityWhereDroped.ruleOrderId === activity.ruleOrderId &&
          activityWhereDroped.activityId === activity.activityId
        ) {
          isChild = true;
        }
        if (activity.activityName === "IfElse" && !isChild) {
          checkIsChild(activity.thenActivities || []);
          checkIsChild(activity.elseActivities || []);
        } else if (activity.activityName === "CheckError" && !isChild) {
          checkIsChild(activity.checkError || []);
          checkIsChild(activity.onError || []);
        } else if (activity.subActivities && !isChild) {
          checkIsChild(_.cloneDeep(activity.subActivities));
        }
      });
    };
    if (actDroped.activityName === "IfElse") {
      checkIsChild(actDroped.thenActivities || []);
      checkIsChild(actDroped.elseActivities || []);
    } else if (actDroped.activityName === "CheckError") {
      checkIsChild(actDroped.checkError || []);
      checkIsChild(actDroped.onError || []);
    } else if (actDroped.subActivities) {
      checkIsChild(_.cloneDeep(actDroped.subActivities));
    }

    return isChild;
  };

  const handleDrop = ({
    e,
    activityWhereDroped,
    AddParallelToGroupActivity,
    insideIf,
    insideError,
  }) => {
    const draggedActivity = JSON.parse(e.dataTransfer.getData("activityObj"));

    let newActivity = { ...draggedActivity };

    if (
      !draggedActivity.ruleOrderId &&
      (draggedActivity.activityType === "G" ||
        draggedActivity.activityType === "S")
    ) {
      // newActivity["uid"] = uuidv4();

      newActivity["uid"] = updateUuidAgainstRuleOrderId(
        uuidv4(),
        newActivity.ruleOrderId
      );
    }
    if (activityWhereDroped) {
     
      const IdWhereDropped = activityWhereDroped.ruleOrderId;
      const IdWhichDropped = draggedActivity.ruleOrderId;

      if (
        IdWhichDropped &&
        IdWhereDropped === IdWhichDropped &&
        activityWhereDroped.activityId === draggedActivity.activityId
      ) {
        return;
      }

      if (
        IdWhichDropped &&
        (draggedActivity.activityType === "G" ||
          draggedActivity.activityType === "S")
      ) {
        const isTrue = checkIfActvityInsideDropedActivity(
          draggedActivity,
          activityWhereDroped
        );

        /*****************************************************************************************
         * @author asloob_ali BUG ID : 106190 Description : 106190 -Activities gets blank when I move Server Connect activity inside Check Error activity
         *  Reason:Parent activity was dragged inside child activity.
         * Resolution : fixed, user will get a notification that parent activity can't be moved inside child activity.
         *  Date : 11/03/2022             ****************************************/

        if (isTrue) {
          setNotification({
            isOpen: true,
            message: "You can't move parent activity inside child activity",
            title: "",
            notificationType: "ERROR",
          });
          return;
        }
      }

      let IdWhereAdding = null;
      let countFlag = false;

      const updateActivities = (activities) => {
        let newActivities = _.map(activities, (activity, index) => {
          if (
            IdWhereDropped === activity.ruleOrderId &&
            activity.activityId === activityWhereDroped.activityId
          ) {
            IdWhereAdding = index + 1;
            countFlag = true;
          }
          if (activity.activityName === "IfElse" && !countFlag) {
            let arr = updateActivities(activity.thenActivities || []);
            let arr1 = activity.elseActivities
              ? updateActivities(activity.elseActivities)
              : null;
            activity.thenActivities = _.cloneDeep(arr);
            activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
            return activity;
          } else if (activity.activityName === "CheckError" && !countFlag) {
            let arr = updateActivities(activity.checkError || []);
            let arr1 = updateActivities(activity.onError);

            activity.checkError = _.cloneDeep(arr);
            activity.onError = _.cloneDeep(arr1);
            return activity;
          } else if (activity.subActivities && !countFlag) {
            let arr = updateActivities(activity.subActivities);
            activity.subActivities = _.cloneDeep(arr);
            return activity;
          } else {
            return activity;
          }
        });
        if (IdWhereAdding) {
          if (IdWhichDropped) {
            newActivity.ruleOrderId = IdWhereDropped + 1;
          } else {
            if (
              (activityWhereDroped.activityType === "G" ||
                activityWhereDroped.activityType === "S") &&
              !AddParallelToGroupActivity
            ) {
              newActivity.ruleOrderId = IdWhereDropped + 1;
            } else if (
              activityWhereDroped.activityType === "G" ||
              (activityWhereDroped.activityType === "S" &&
                AddParallelToGroupActivity)
            ) {
              newActivity.ruleOrderId = activityWhereDroped.subActivities
                ? activityWhereDroped.subActivities.length + 1 + IdWhereDropped
                : 1 + IdWhereDropped;
            } else {
              newActivity.ruleOrderId = IdWhereDropped + 1;
            }
          }

          if (
            activityWhereDroped.activityName === "IfElse" &&
            insideIf &&
            !AddParallelToGroupActivity
          ) {
            if (insideIf === "THEN") {
              if (
                newActivities[IdWhereAdding - 1] &&
                newActivities[IdWhereAdding - 1].thenActivities
              ) {
                newActivities[IdWhereAdding - 1].thenActivities.unshift(
                  newActivity
                );
              } else {
                newActivities[IdWhereAdding - 1].thenActivities = [
                  { ...newActivity },
                ];
              }
            } else if (insideIf === "ELSE") {
              if (
                newActivities[IdWhereAdding - 1] &&
                newActivities[IdWhereAdding - 1].elseActivities
              ) {
                newActivities[IdWhereAdding - 1].elseActivities.unshift(
                  newActivity
                );
              } else {
                newActivities[IdWhereAdding - 1].elseActivities = [
                  { ...newActivity },
                ];
              }
            }
          } else if (
            activityWhereDroped.activityName === "CheckError" &&
            insideError &&
            !AddParallelToGroupActivity
          ) {
            if (insideError === "CheckError") {
              if (
                newActivities[IdWhereAdding - 1] &&
                newActivities[IdWhereAdding - 1].checkError
              ) {
                newActivities[IdWhereAdding - 1].checkError.unshift(
                  newActivity
                );
              } else {
                newActivities[IdWhereAdding - 1].checkError = [
                  { ...newActivity },
                ];
              }
            } else if (insideError === "OnError") {
              if (
                newActivities[IdWhereAdding - 1] &&
                newActivities[IdWhereAdding - 1].onError
              ) {
                newActivities[IdWhereAdding - 1].onError.unshift(newActivity);
              } else {
                newActivities[IdWhereAdding - 1].onError = [{ ...newActivity }];
              }
            }
          } else if (
            (activityWhereDroped.activityType === "G" ||
              activityWhereDroped.activityType === "S") &&
            !AddParallelToGroupActivity
          ) {
            if (
              newActivities[IdWhereAdding - 1] &&
              newActivities[IdWhereAdding - 1].subActivities
            ) {
              newActivities[IdWhereAdding - 1].subActivities.unshift(
                newActivity
              );
            } else {
              newActivities[IdWhereAdding - 1].subActivities = [
                { ...newActivity },
              ];
            }
          } else {
            newActivities.splice(IdWhereAdding, 0, newActivity);
          }
          IdWhereAdding = null;
        }
        return newActivities;
      };

      //updated activities
      //if dragged activity is from the rules defination

      let result1 = [...activitiesList];
      if (IdWhichDropped) {
        result1 = RemoveActivity(draggedActivity, _.cloneDeep(activitiesList));
      }
      let result = updateActivities(_.cloneDeep(result1));

      //updated activities with updated Rule Order Id
      let newResult = updateRulesOrder(_.cloneDeep(result));

      setActivitiesList(newResult);
      //for our line counts of activities
      createDupArray(newResult);

      setLastAction(newActivity);
    } else {
      let activities = [{ ...newActivity, ruleOrderId: 1 }];

      setActivitiesList(activities);
      //for our line counts of activities
      createDupArray(activities);

      setLastAction({ ...newActivity, ruleOrderId: 1 });
    }
    let newRecentAct = [...recentActivities];
    const draggedActPresent = newRecentAct.find(
      (actObj) => actObj.activityId === draggedActivity.activityId
    );
    //to remove duplicate activities if present in recents
    if (draggedActPresent) {
      newRecentAct = newRecentAct.filter(
        (actObj) => actObj.activityId !== draggedActivity.activityId
      );
    }
    newRecentAct = [draggedActivity, ...newRecentAct];
    if (newRecentAct.length > 10) {
      setRecentActivities(newRecentAct.splice(0, 10));
    } else {
      setRecentActivities(newRecentAct);
    }
    e.stopPropagation();
  };
  const handleDrag = (e, activity) => {
    e.dataTransfer.setData("activityObj", JSON.stringify(activity));
  };

  const handleCloseRunScript = () => {
    dispatch(setRunScriptModal(null));
  };

  const handleKeyDown = (e) => {
    /*****************************************************************************************
     * @author asloob_ali BUG ID : 102526 Description :  Publish Package: Not able to delete data in comment section using backspace key if large data is entered
     *  Reason: we were preventing the default actions for certain keys like [ctrl+c,ctrl+v...etc] because of our functionalities of copy/paste/delete.. etc in activities.so user was not able to use these keys/commands in inputs/textareas.
     * Resolution : now for inputs and textareas the functionalities will remain Default as usualy in browser.
     *  Date : 17/11/2021             ***************************************************************************************/
    if (e.repeat === false) {
      if (
        e.keyCode === 83 &&
        (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
      ) {
        e.preventDefault();
        saveScriptRules();
      } else if (
        (!navigator.platform.match("Mac") && e.keyCode === 46) ||
        (navigator.platform.match("Mac") && e.keyCode === 8)
      ) {
        if (
          e.target.localName !== "input" &&
          e.target.localName !== "textarea" &&
          e.target.localName !== "div"
        ) {
          if (selectedActivity) {
            e.preventDefault();
            handleClipboardActions("Delete[delete]");
          }
        }
      } else if (
        e.keyCode === 67 &&
        (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
      ) {
        if (
          e.target.localName !== "input" &&
          e.target.localName !== "textarea" &&
          e.target.localName !== "div"
        ) {
          if (selectedActivity) {
            e.preventDefault();

            handleClipboardActions("Copy[Ctrl+C]");
          }
        }
      } else if (
        e.keyCode === 86 &&
        (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
      ) {
        if (
          e.target.localName !== "input" &&
          e.target.localName !== "textarea"
        ) {
          e.preventDefault();
          handleClipboardActions("Paste[Ctrl+V]");
        }
      } else if (
        e.keyCode === 88 &&
        (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
      ) {
        if (
          e.target.localName !== "input" &&
          e.target.localName !== "textarea"
        ) {
          e.preventDefault();
          handleClipboardActions("Cut[Ctrl+X]");
        }
      } else if (
        e.keyCode === 89 &&
        (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
      ) {
        e.preventDefault();
        handleUndoRedoArrayValue("y");
      } else if (
        e.keyCode === 90 &&
        (navigator.platform.match("Mac") ? e.metaKey : e.ctrlKey)
      ) {
        e.preventDefault();
        handleUndoRedoArrayValue("z");
      } else if (e.keyCode === 116 && isDebuging) {
        e.preventDefault();

        resumeDebugScript(1);
      }
    }
  };

  useEffect(() => {
    //saving rules by ctrl/cmd + s,and other actions on key press
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  //to add the params into selected activity
  const addParamsToSelAct = (params) => {
    let countFlag = false;

    const updateActivities = (activities) => {
      return _.map(activities, (activity, index) => {
        if (
          activity.activityId === selectedActivity.activityId &&
          activity.ruleOrderId === selectedActivity.ruleOrderId
        ) {
          activity.params = [...params];
          countFlag = true;
        }
        if (activity.activityName === "IfElse" && !countFlag) {
          let arr = updateActivities(activity.thenActivities || []);
          let arr1 = activity.elseActivities
            ? updateActivities(activity.elseActivities)
            : null;
          activity.thenActivities = _.cloneDeep(arr);
          activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
          return activity;
        } else if (activity.activityName === "CheckError" && !countFlag) {
          let arr = updateActivities(activity.checkError || []);
          let arr1 = updateActivities(activity.onError || []);

          activity.checkError = _.cloneDeep(arr);
          activity.onError = _.cloneDeep(arr1);
          return activity;
        } else if (activity.subActivities && !countFlag) {
          let arr = updateActivities(activity.subActivities);
          activity.subActivities = _.cloneDeep(arr);
          return activity;
        } else {
          return activity;
        }
      });
    };

    //updated activities
    let result = updateActivities(_.cloneDeep(activitiesList));

    setActivitiesList(result);
    setLastAction(selectedActivity);
  };

  //updating is Disabled flag

  const makeAllSubActEnableOrDisable = (allSubAct, isDisable) => {
    const updateIsDisabledFlag = (activities) => {
      return activities.map((item, index) => {
        item.isDisabled = isDisable;
        if (item.subActivities) {
          let res2 = updateIsDisabledFlag(item.subActivities);
          item.subActivities = res2;
          return item;
        } else if (item.activityName === "IfElse") {
          let res2 = updateIsDisabledFlag(item.thenActivities || []);
          let res4 = item.elseActivities
            ? updateIsDisabledFlag(item.elseActivities)
            : null;
          item.thenActivities = res2;
          item.elseActivities = res4;
          return item;
        } else if (item.activityName === "CheckError") {
          let res2 = updateIsDisabledFlag(item.checkError || []);
          let res4 = updateIsDisabledFlag(item.onError || []);

          item.checkError = res2;
          item.onError = res4;
          return item;
        } else {
          return item;
        }
      });
    };
    return updateIsDisabledFlag(allSubAct);
  };
  //to disable/enable selected activity
  const disableOrEnableActivity = (newActivity) => {
    let countFlag = false;

    const updateActivities = (activities) => {
      return _.map(activities, (activity) => {
        if (
          activity.activityId === selectedActivity.activityId &&
          activity.ruleOrderId === selectedActivity.ruleOrderId
        ) {
          activity = { ...newActivity };
          countFlag = true;
          if (activity.activityName === "IfElse" && countFlag) {
            let arr = makeAllSubActEnableOrDisable(
              activity.thenActivities || [],
              newActivity.isDisabled
            );
            let arr1 = activity.elseActivities
              ? makeAllSubActEnableOrDisable(
                  activity.elseActivities,
                  newActivity.isDisabled
                )
              : null;
            activity.thenActivities = _.cloneDeep(arr);
            activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
            // return activity;
          } else if (activity.activityName === "CheckError" && countFlag) {
            let arr = makeAllSubActEnableOrDisable(
              activity.checkError || [],
              newActivity.isDisabled
            );
            let arr1 = makeAllSubActEnableOrDisable(
              activity.onError || [],
              newActivity.isDisabled
            );

            activity.checkError = _.cloneDeep(arr);
            activity.onError = _.cloneDeep(arr1);
            // return activity;
          } else if (activity.subActivities && countFlag) {
            let arr = makeAllSubActEnableOrDisable(
              activity.subActivities,
              newActivity.isDisabled
            );
            activity.subActivities = _.cloneDeep(arr);
            //return activity;
          }
        }
        if (activity.activityName === "IfElse" && !countFlag) {
          let arr = updateActivities(activity.thenActivities || []);
          let arr1 = activity.elseActivities
            ? updateActivities(activity.elseActivities)
            : null;
          activity.thenActivities = _.cloneDeep(arr);
          activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
          return activity;
        } else if (activity.activityName === "CheckError" && !countFlag) {
          let arr = updateActivities(activity.checkError || []);
          let arr1 = updateActivities(activity.onError || []);

          activity.checkError = _.cloneDeep(arr);
          activity.onError = _.cloneDeep(arr1);
          return activity;
        } else if (activity.subActivities && !countFlag) {
          let arr = updateActivities(activity.subActivities);
          activity.subActivities = _.cloneDeep(arr);
          return activity;
        } else {
          return activity;
        }
      });
    };

    return updateActivities(_.cloneDeep(activitiesList));
  };

  //to add the condition Array into selected if activity
  const addCondArrToSelAct = (conditionArray) => {
    let countFlag = false;

    const updateActivities = (activities) => {
      return _.map(activities, (activity, index) => {
        if (
          activity.activityId === selectedActivity.activityId &&
          activity.ruleOrderId === selectedActivity.ruleOrderId
        ) {
          activity.conditionArray = [...conditionArray];
          countFlag = true;
        }
        if (activity.activityName === "IfElse" && !countFlag) {
          let arr = updateActivities(activity.thenActivities || []);
          let arr1 = activity.elseActivities
            ? updateActivities(activity.elseActivities)
            : null;
          activity.thenActivities = _.cloneDeep(arr);
          activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
          return activity;
        } else if (activity.activityName === "CheckError" && !countFlag) {
          let arr = updateActivities(activity.checkError || []);
          let arr1 = updateActivities(activity.onError || []);

          activity.checkError = _.cloneDeep(arr);
          activity.onError = _.cloneDeep(arr1);
          return activity;
        } else if (activity.subActivities && !countFlag) {
          let arr = updateActivities(activity.subActivities);
          activity.subActivities = _.cloneDeep(arr);
          return activity;
        } else {
          return activity;
        }
      });
    };

    //updated activities
    let result = updateActivities(_.cloneDeep(activitiesList));

    setActivitiesList(result);
    setLastAction(selectedActivity);
  };
 // const uuid = uuidv4();
  const updateUuidAgainstRuleOrderId = (uuid,ruleOrderId) => {
    //const uuid = uuidv4();
    dispatch(setUuidRuleOrderid(uuid, ruleOrderId));
    return uuid;
  };

  //to update display name of selected activity
  const updateDisplayNameSelAct = (name) => {
    let countFlag = false;

    if (name) {
      const updateActivities = (activities) => {
        return _.map(activities, (activity, index) => {
          if (
            activity.activityId === selectedActivity.activityId &&
            activity.ruleOrderId === selectedActivity.ruleOrderId
          ) {
            activity.displayName = name;
            countFlag = true;
          }
          if (activity.activityName === "IfElse" && !countFlag) {
            let arr = updateActivities(activity.thenActivities || []);
            let arr1 = activity.elseActivities
              ? updateActivities(activity.elseActivities)
              : null;
            activity.thenActivities = _.cloneDeep(arr);
            activity.elseActivities = arr1 ? _.cloneDeep(arr1) : arr1;
            return activity;
          } else if (activity.activityName === "CheckError" && !countFlag) {
            let arr = updateActivities(activity.checkError || []);
            let arr1 = updateActivities(activity.onError || []);

            activity.checkError = _.cloneDeep(arr);
            activity.onError = _.cloneDeep(arr1);
            return activity;
          } else if (activity.subActivities && !countFlag) {
            let arr = updateActivities(activity.subActivities);
            activity.subActivities = _.cloneDeep(arr);
            return activity;
          } else {
            return activity;
          }
        });
      };

      //updated activities
      let result = updateActivities(_.cloneDeep(activitiesList));

      setActivitiesList(result);
      setLastAction(selectedActivity);
    }
  };

  const handleOutputObj = (item) => {
    setOutputObj(item);
  };

  const getStatus = () => {
    if (isExecutingScript) {
      return "Running Mode";
    } else if (isDebuging) {
      return "Debugging Mode";
    } else if (_.isEqual(activitiesList, activitiesListOrg)) {
      return "Saved";
    } else {
      return "Design Mode";
    }
  };

  return (
    <>
      <div className={classes.root}>
        <Topbar1
          handleOpenModal={handleOpenModal}
          status={getStatus()}
          activeTab={activeTab}
          selectedActivity={selectedActivity}
        />

        {/*<div> <Topbar handleOpenModal={handleOpenModal} /></div>*/}

        <div className={classes.main}>
          {/* <Grid container direction="row"> */}
          <Grid className={classes.secondaryMain}>
          {/* 
     * @author sanya.mahajan for Bug 155880 - UX Tertiary header not correct
     * Reason:The header needed to be below the activity panel
     * Date : 05/02/2025             
     * */ }
            <Grid item sx={{zIndex:"10"}}>
              {debugDetails ? (
                <DebugLeftPanel
                  leftPanelOpen={leftPanelOpen}
                  handleLeftPanel={handleLeftPanel}
                />
              ) : (
                <MainLeft
                  id="RPA_ScriptEditor"
                  leftPanelOpen={leftPanelOpen}
                  activeTab={activeTab}
                  selectedActivity={selectedActivity}
                  handleLeftPanel={handleLeftPanel}
                  handleDrag={handleDrag}
                  recentActivities={recentActivities}
                />
              )}
            </Grid>
            <Grid
              item
              xs
              style={{
                backgroundColor: "#F8F8F8",
                minWidth: "490px",
              }}
            >
              <MainRight
                id="RPA_ScriptEditor"
                activitiesList={activitiesList}
                handleDrop={handleDrop}
                handleDrag={handleDrag}
                handleClipboardActions={handleClipboardActions}
                dupList={dupList}
                addOrRemoveElseAct={addOrRemoveElseAct}
                changeTab={changeTab}
                activeTab={activeTab}
                selectedActivity={selectedActivity}
                script={scriptName}
                openDialog={openDialog}
                setOpenDialog={setOpenDialog}
                updateNodePosition={updateNodePosition}
                saveListViewDialog={saveListViewDialog}
                setSaveListViewDialog={setSaveListViewDialog}
                saveScriptRules={saveScriptRules}
                status={getStatus()}
              />
            </Grid>
            {selectedActivity ? (
              <Grid item style={{ display: "flex" }}>
                <MainScreen
                  id={`RPA_ScriptEditor_${selectedActivity.activityName}_${
                    selectedActivity.uid
                      ? selectedActivity.uid
                      : selectedActivity.ruleOrderId
                  }`}
                  handleOpenModal={handleOpenModal}
                  addParamsToSelAct={addParamsToSelAct}
                  addCondArrToSelAct={addCondArrToSelAct}
                  updateDisplayNameSelAct={updateDisplayNameSelAct}
                />
              </Grid>
            ) : null}
          </Grid>
        </div>
        {openModalName ? showModal() : null}
        {openProfileModal ? <UserProfileModal isOpen={true} /> : null}
      </div>
      {runScriptModal && (
        <div>
          <RunScriptOutputModal
            id={`RPA_ScriptEditor_OutputModal`}
            handleClose={handleCloseRunScript}
            scriptValues={scriptValues}
            isOpen={runScriptModal ? true : false}
            outputObj={outputObj}
            openTab={runScriptModal}
            isExecutingScript={isExecutingScript}
            isPropertyWindowOpen={selectedActivity ? true : false}
            handleOutputObj={handleOutputObj}
          />
        </div>
      )}
      {/* {openDialog && (
          <>
          <ModalForm
          containerWidth ={"600px"}
          containerHeight ={"200px"}
          isOpen={openDialog}
          title="Save Changes"
          description="Please ensure you save the flow before switching to 'Flow Chart' View."
          headerCloseBtn
          onClick2={saveScriptRules}
          onClick1={handleClose}
          btn1Title='Cancel'
          btn2Title='Save'
          onClickHeaderCloseBtn={()=>setOpenDialog(false)}
          />
          </>
        )} */}
    </>
  );
};

export default EditorHomepage;
