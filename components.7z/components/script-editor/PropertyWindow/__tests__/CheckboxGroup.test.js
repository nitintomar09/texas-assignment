import React from "react";
import ReactDom from "react-dom";
import { cleanup, render, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/extend-expect";
import CheckboxGroup from "../PropertyFields/CheckboxGroup";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  const handleChange = jest.fn();

  const items = checkboxArray.map((item) => {
    return { ...item, onChange: handleChange };
  });
  ReactDom.render(<CheckboxGroup checkboxArray={items} />, div);
});

test("handles click correctly for checkbox Group", () => {
  const handleChange = jest.fn();

  const items = checkboxArray.map((item) => {
    return { ...item, onChange: handleChange };
  });
  render(<CheckboxGroup checkboxArray={items} />);

  userEvent.click(screen.getByText("Second Checkbox"));
  expect(screen.getByLabelText("Second Checkbox")).toBeChecked();
});

it("matches snapshot", () => {
  const handleChange = jest.fn();

  const items = checkboxArray.map((item) => {
    return { ...item, onChange: handleChange };
  });
  const tree = renderer
    .create(<CheckboxGroup checkboxArray={items} />)
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const checkboxArray = [
  {
    name: "First",
    value: "First",
    label: "First Checkbox",
  },
  {
    name: "Second",
    value: "Second",
    label: "Second Checkbox",
  },
  {
    name: "Third",
    value: "Third",
    label: "Third Checkbox",
  },
];
