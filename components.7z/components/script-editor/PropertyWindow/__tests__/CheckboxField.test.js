import React from "react";
import ReactDom from "react-dom";
import { cleanup, render, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/extend-expect";
import CheckboxField from "../PropertyFields/CheckboxField";

test("handles click correctly for checkbox field", () => {
  render(<CheckboxField name="Test" label="Testing Checkbox" />);

  userEvent.click(screen.getByText("Testing Checkbox"));
  expect(screen.getByLabelText("Testing Checkbox")).toBeChecked();
});

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  ReactDom.render(<CheckboxField name="Test" label="Testing Checkbox" />, div);
});

it("matches snapshot", () => {
  const tree = renderer
    .create(<CheckboxField name="Test" label="Testing Checkbox" />)
    .toJSON();
  expect(tree).toMatchSnapshot();
});
