import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "../../../../utils/CustomAppComp";
import MainScreen from "./../MainScreen";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  const addParamsToSelAct = jest.fn();
  const handleOpenModal = jest.fn();
  ReactDom.render(
    <CustomAppComp>
      <MainScreen
        selectedActivity={selectedActivity}
        handleOpenModal={handleOpenModal}
        addParamsToSelAct={addParamsToSelAct}
      />
    </CustomAppComp>,
    div
  );
});

it("matches snapshot", () => {
  const addParamsToSelAct = jest.fn();
  const handleOpenModal = jest.fn();
  const tree = renderer
    .create(
      <CustomAppComp>
        <MainScreen
          selectedActivity={selectedActivity}
          handleOpenModal={handleOpenModal}
          addParamsToSelAct={addParamsToSelAct}
        />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const selectedActivity = {
  activityId: 26,
  activityName: "SetWindowSize",
  activityType: "N",
  description: "null",
  displayName: "SetWindowSize",
};
const activitiesList = [
  {
    activityId: 52,
    activityName: "ServerConnect",
    activityType: "S",
    description: "null",
    displayName: "Server Connect",

    params: [
      {
        paramName: "ServerUrl",
        paramObjectTypeId: 1,
        paramState: 0,
        paramType: "C",
        paramValue: "http://52.187.37.117:8080",
        paramrId: 698,
      },
    ],
    subActivities: [],
  },
];
