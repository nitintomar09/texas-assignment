import React from "react";
import ReactDom from "react-dom";
import { cleanup, render, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/extend-expect";
import PropertyField from "../PropertyFields/PropertyField";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  const handleChange = jest.fn();
  const handleType = jest.fn();
  const itemObj = { paramType: "C", paramValue: "" };

  ReactDom.render(
    <PropertyField
      ActivityTitle={true}
      ActivityName="Test Activity"
      labelBtn1={true}
      labelBtn2={true}
      dropdown={itemObj.paramType === "V"}
      paramObj={itemObj}
      labelBtn1OnClick={handleType}
      labelBtn2OnClick={handleType}
      name="Test"
      label="Test"
      value={itemObj.paramValue}
      options={[]}
      onChange={handleChange}
    />,
    div
  );
});

test("handles change correctly for input", () => {
  const handleChange = jest.fn();
  const handleType = jest.fn();
  const itemObj = { paramType: "C", paramValue: "" };

  render(
    <PropertyField
      ActivityTitle={true}
      ActivityName="Test Activity"
      labelBtn1={true}
      labelBtn2={true}
      dropdown={itemObj.paramType === "V"}
      paramObj={itemObj}
      labelBtn1OnClick={handleType}
      labelBtn2OnClick={handleType}
      name="Test"
      label="Test"
      value={itemObj.paramValue}
      options={[]}
      onChange={handleChange}
    />
  );
  userEvent.type(screen.getByRole("textbox"), "Testing input");
  expect(handleChange).toBeCalledTimes(13);
});

test("handles checbox correctly", () => {
  const handleChange = jest.fn();

  render(
    <PropertyField
      ActivityTitle={true}
      ActivityName="Test Activity"
      checkbox={true}
      name="Test"
      label="Test Checkbox"
      onChange={handleChange}
    />
  );
  userEvent.click(screen.getByLabelText("Test Checkbox"));

  expect(screen.getByLabelText("Test Checkbox")).toBeChecked();
});

it("matches snapshot", () => {
  const handleChange = jest.fn();

  const tree = renderer
    .create(
      <PropertyField
        ActivityTitle={true}
        ActivityName="Test Activity"
        makeLogsPrivate={false}
        helperText="description of the test activity."
        radio={true}
        ButtonsArray={ButtonsArray}
        name="TestRadioButtonGroup"
        value=""
        label="Testing Radios"
        onChange={handleChange}
      />
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const ButtonsArray = [
  {
    label: "First",
    value: "First",
  },
  {
    label: "Second",
    value: "Second",
  },
  {
    label: "Third",
    value: "Third",
  },
];
