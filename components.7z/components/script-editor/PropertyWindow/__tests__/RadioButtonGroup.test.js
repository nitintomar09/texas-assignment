import React from "react";
import ReactDom from "react-dom";
import { cleanup, render, screen } from "@testing-library/react";
import renderer from "react-test-renderer";
import userEvent from "@testing-library/user-event";
import "@testing-library/jest-dom/extend-expect";
import RadioButtonGroup from "../PropertyFields/RadioButtonGroup";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  const handleChange = jest.fn();

  ReactDom.render(
    <RadioButtonGroup
      ButtonsArray={ButtonsArray}
      name="TestRadioButtonGroup"
      value=""
      label="Testing Radios"
      onChange={handleChange}
    />,
    div
  );
});

test("handles click correctly for Radio Group", () => {
  const handleChange = jest.fn();

  render(
    <RadioButtonGroup
      ButtonsArray={ButtonsArray}
      name="TestRadioButtonGroup"
      value=""
      label="Testing Radios"
      onChange={handleChange}
    />
  );

  userEvent.click(screen.getByText("Second"));
  expect(handleChange).toBeCalledTimes(1);
});

it("matches snapshot", () => {
  const handleChange = jest.fn();

  const tree = renderer
    .create(
      <RadioButtonGroup
        ButtonsArray={ButtonsArray}
        name="TestRadioButtonGroup"
        value=""
        label="Testing Radios"
        onChange={handleChange}
      />
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});

const ButtonsArray = [
  {
    label: "First",
    value: "First",
  },
  {
    label: "Second",
    value: "Second",
  },
  {
    label: "Third",
    value: "Third",
  },
];
