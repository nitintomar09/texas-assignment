import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";

import "@testing-library/jest-dom/extend-expect";
import * as components from "../AllComponetsWindows";
import CustomAppComp from "../../../../../utils/CustomAppComp";
afterEach(cleanup);
const selectedActivity = { params: [], activityName: "Test" };
const addParamsToSelAct = jest.fn();
Object.keys(components).forEach((componentName) => {
  const Component = components[componentName];
  const div = document.createElement("div");

  describe(`Component: ${componentName}`, () => {
    test(`${componentName} renders with default props`, () => {
      ReactDom.render(
        <CustomAppComp>
          <Component
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
          />
        </CustomAppComp>,
        div
      );
    });
  });
});
