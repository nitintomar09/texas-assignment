import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
    mapFieldObjWithValueByName,
    logsState,
    getOptionsForVariable,
    getVariableTypeById,
    getDefaultOfDefinedVariableByName,
    getAllVariables
} from "./../Common/CommonMethods";

import { setSelectedTab, setErrorType, setDatabaseNameGlobaly } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import { createInstance } from "../../../../../utils/common";
import { DATABASE, DATABASE_CONNECT, GET_DATABASE_TYPE } from "../../../../../config";



const ConnectDatabaseWindow = (props) => {
    const classes = useStyles();

    const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
        props;

    const { params } = selectedActivity;
    const allVariables = getAllVariables();

    const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
    const dispatch = useDispatch();
    const { setValue: setNotification } = useContext(NotificationContext);
    const axiosInstance = createInstance()

    const [activityName, setActivityName] = useState(
        (selectedActivity && selectedActivity.displayName) || ""
    );

    const [databaseTypeOptions, setDatabaseTypeOptions] = useState([])
    const [databaseVersionOptions, setDatabaseVersionOptions] = useState([])


    const [typeValue, setTypeValue] = useState(
        mapFieldObjWithValueByName(params, "DatabaseType", "mssql")
    );
    const [invisibleInLogs, setInvisibleInLogs] = useState(
        logsState(params, false)
    );

    const [hostName, setHostname] = useState(
        mapFieldObjWithValueByName(params, "HostName", "")
    );
    const [databaseName, setDatabaseName] = useState(
        mapFieldObjWithValueByName(params, "DatabaseName", "")
    );
    const [username, setUsername] = useState(
        mapFieldObjWithValueByName(params, "UserName", "")
    );
    const [serviceName, setServiceName] = useState(
        mapFieldObjWithValueByName(params, "ServiceName", "")
    );

    const [password, setPassword] = useState(
        mapFieldObjWithValueByName(params, "Password", "")
    );
    const [port, setPort] = useState(
        mapFieldObjWithValueByName(params, "Port", "")
    );

    const [connectionStatus, setConnectionStatus] = useState(
        mapFieldObjWithValueByName(params, "ConnectionStatus", false)
    );
    const [isConnecting, setIsConnecting] = useState(
        false
    );
    const [timeoutField, setTimeoutField] = useState(
        mapFieldObjWithValueByName(params, "ConnectionTimeOut", "")
    );
    const [databaseVersion, setDatabaseVersion] = useState("");
    useEffect(() => {
        setActivityName(selectedActivity ? selectedActivity.displayName : "");
        setInvisibleInLogs(logsState(params, false));

        setPassword(mapFieldObjWithValueByName(params, "Password", ""));
        setHostname(mapFieldObjWithValueByName(params, "HostName", ""));
        setUsername(mapFieldObjWithValueByName(params, "UserName", ""));
        setServiceName(mapFieldObjWithValueByName(params, "ServiceName", ""));

        setPort(mapFieldObjWithValueByName(params, "Port", ""));
        setConnectionStatus(mapFieldObjWithValueByName(params, "ConnectionStatus", ""));
        setTypeValue(
            mapFieldObjWithValueByName(params, "DatabaseType", "mssql")
        )
        setDatabaseName(
            mapFieldObjWithValueByName(params, "DatabaseName", "")
        )
        setTimeoutField(mapFieldObjWithValueByName(params, "ConnectionTimeOut", ""));



        dispatch(setErrorType("Throw"));
        dispatch(setSelectedTab("input"));
    }, [selectedActivity]);


    useEffect(async () => {

        try {
            const res = await axiosInstance.get(`${DATABASE}${GET_DATABASE_TYPE}`);

            const objOfOptionsInRes = res?.data?.data[0];

            if (objOfOptionsInRes) {
                const arrayOfOptions = Object.keys(objOfOptionsInRes).map(opt => ({ name: opt, value: objOfOptionsInRes[opt]?.databaseType, defaultTimeout: objOfOptionsInRes[opt]?.connectionTimeOut, version: objOfOptionsInRes[opt]?.version }))
                setDatabaseTypeOptions(arrayOfOptions)

            }
        } catch (error) {
            console.log(error)
        }
    }, [JSON.stringify(selectedActivity)])


    useEffect(() => {

        if (typeValue.paramValue) {
            const typeOption = databaseTypeOptions.find(item => item.value === typeValue.paramValue);
            if (typeOption) {
                setTimeoutField((prev) => ({ ...prev, paramValue: +typeOption.defaultTimeout }))
                setDatabaseVersionOptions(typeOption?.version?.map(item => ({ name: item, value: item })))
                setDatabaseVersion("")
            }
        }
    }, [typeValue, databaseTypeOptions])
    const handleChange = (e) => {
        const { name, value } = e.target;
        switch (name) {
            case "ActivityName":
                setActivityName(value);
                updateDisplayNameSelAct(value);
                break;
            case "MakeLogsPrivate":
                setInvisibleInLogs({
                    ...invisibleInLogs,
                    paramValue: !invisibleInLogs.paramValue,
                });
                break;

            case "Hostname":
                setHostname((prevState) => ({ ...prevState, paramValue: value }));
                break;

            case "Port":
                setPort((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "Username":
                setUsername((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "ServiceName":
                setServiceName((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "DatabaseName":
                setDatabaseName((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "Password":
                setPassword((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "Type":
                setTypeValue((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "DatabaseVersion":
                setDatabaseVersion(value);
                break;
            case "ConnectionStatus":
                setConnectionStatus((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "Timeout":
                setTimeoutField((prevState) => ({ ...prevState, paramValue: value }));
                break;

            default:
                break;
        }
    };

    const getDefaultOfDefinedVariableByName = (varName) => {
        const variable = allVariables.find(item => item.variableName === varName)
        if (variable) {
            return variable.varDefaultValue;
        }
        return ""
    }
    const getValueOfParam = (param) => {
        let valOfParam = param.paramValue;
        if (param.paramType === "V") {
            valOfParam = getDefaultOfDefinedVariableByName(param.paramValue)
        }
        return valOfParam
    }
    const handleConnect = async () => {
        setIsConnecting(true)
        try {
            const inputPayload = {
                databaseName: getValueOfParam(databaseName),
                "databaseType": getValueOfParam(typeValue),
                "hostName": getValueOfParam(hostName),
                "port": getValueOfParam(port),
                "userName": getValueOfParam(username),
                "password": getValueOfParam(password),
                version: databaseVersion

            }
            if (typeValue.paramValue === 'oracle') {
                inputPayload['serviceName'] = getValueOfParam(serviceName)
            }

            const res = await axiosInstance.post(`${DATABASE_CONNECT}`, inputPayload);
            if (res.status === 200 && res.data && res.data.data && res.data.data[0]?.databaseConnection) {
                setIsConnecting(false)
                setNotification({
                    isOpen: true,
                    title: "Connect Database",
                    message: "Database Server connected successfully.",
                    notificationType: "SUCCESS",
                });
                dispatch(setDatabaseNameGlobaly(getValueOfParam(databaseName)))
            } else {
                setIsConnecting(false)

                setNotification({
                    isOpen: true,
                    title: "Connect Database",
                    message: "Not able to connect with Database Server.",
                    notificationType: "ERROR",
                });
            }

        } catch (error) {
            setIsConnecting(false)

            setNotification({
                isOpen: true,
                title: "Connect Database",
                message: "Not able to connect with Database Server.",
                notificationType: "ERROR",
            });
        }


    }
    useEffect(() => {
        updateParams();
    }, [
        invisibleInLogs,
        password,
        hostName,
        username,
        port,
        serviceName,
        databaseName,
        connectionStatus,
        typeValue,
        timeoutField
    ]);

    const updateParams = () => {

        let newParams = [
            invisibleInLogs,
            password,
            hostName,
            username,
            typeValue,
            port,
            databaseName,
            connectionStatus,
            timeoutField
        ];
        if (typeValue?.paramValue !== 'oracle') {
            const newServiceName = { ...serviceName, paramValue: "" }
            newParams = [...newParams, newServiceName]
        } else {
            newParams = [...newParams, serviceName]
        }
        addParamsToSelAct(newParams);
    };

    const changeParamTypeToVorC = (paramName, changeToValue) => {
        switch (paramName) {
            case "Hostname":
                setHostname({ ...hostName, paramType: changeToValue });
                break;
            case "Port":
                setPort({ ...port, paramType: changeToValue });
                break;
            case "Username":
                setUsername({ ...username, paramType: changeToValue });
                break;
            case "ServiceName":
                setUsername({ ...serviceName, paramType: changeToValue });
                break;
            case "DatabaseName":
                setDatabaseName({ ...databaseName, paramType: changeToValue });
                break;
            case "Password":
                setPassword({ ...password, paramType: changeToValue });
                break;
            case "ConnectionStatus":
                setConnectionStatus({ ...connectionStatus, paramType: changeToValue });
                break;
            case "Timeout":
                setTimeoutField({ ...timeoutField, paramType: changeToValue });
                break;
            default:
                break;
        }
    };
    return (
        <>
            <CommonFields
                id={props.id}
                selectedActivity={selectedActivity}
                ScopeActivity={selectedActivity.activityType === "S"}
                activityName={activityName}
                handleChange={handleChange}
                makeLogsPrivate={invisibleInLogs.paramValue}
                ActivityIcon={Email}
                helperText={selectedActivity.description || "Connect to a Database Server"}
            />
            <div
                className={classes.scrollDiv + " " + classes.focusVisible}
                tabIndex={0}
            >
                {selectedTab === "input" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                INPUT
                            </Typography>
                        </Grid>
                        <Grid item>

                            <PropertyField
                                id={`${props.id}_DatabaseType`}
                                combo={true}
                                dropdown={true}
                                name="Type"
                                label="Database Type"
                                value={typeValue?.paramValue}

                                onChange={handleChange}
                                options={databaseTypeOptions}
                                helperText={`Supported versions: ${databaseVersionOptions?.length == 1 ? databaseVersionOptions[0]?.name : databaseVersionOptions[0]?.name + " to " + databaseVersionOptions[databaseVersionOptions.length - 1]?.name}`}
                                helperTextColor="#0072C6"
                            />
                        </Grid>

                        <Grid item>
                            <PropertyField
                                id={`${props.id}_DatabaseName`}
                                combo={true}
                                dropdown={databaseName.paramType === "V"}
                                paramObj={databaseName}
                                labelBtn1OnClick={changeParamTypeToVorC}
                                labelBtn2OnClick={changeParamTypeToVorC}
                                options={getOptionsForVariable(databaseName)}
                                labelBtn1={true}
                                labelBtn2={true}
                                name="DatabaseName"
                                label="Database Name"
                                value={databaseName.paramValue}
                                onChange={handleChange}
                                error={vaildateParamValue(databaseName.paramValue).errorStatus}
                                helperText={vaildateParamValue(databaseName.paramValue).msg}
                            />
                        </Grid>
                        <Grid item container justifyContent={'space-between'}>
                            <Grid item >
                                <PropertyField
                                    id={`${props.id}_Hostname`}
                                    combo={true}
                                    dropdown={hostName.paramType === "V"}
                                    paramObj={hostName}
                                    labelBtn1OnClick={changeParamTypeToVorC}
                                    labelBtn2OnClick={changeParamTypeToVorC}
                                    options={getOptionsForVariable(hostName)}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    name="Hostname"
                                    label="Host Name"
                                    value={hostName.paramValue}
                                    onChange={handleChange}
                                    error={vaildateParamValue(hostName.paramValue).errorStatus}
                                    helperText={vaildateParamValue(hostName.paramValue).msg}
                                    width={160}
                                />
                            </Grid>


                            <Grid item >

                                <PropertyField
                                    id={`${props.id}_Port`}
                                    combo={true}
                                    dropdown={port.paramType === "V"}
                                    paramObj={port}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    labelBtn1OnClick={changeParamTypeToVorC}
                                    labelBtn2OnClick={changeParamTypeToVorC}
                                    name="Port"
                                    label="Port"
                                    value={port.paramValue}
                                    options={getOptionsForVariable(port)}
                                    onChange={handleChange}
                                    width={160}

                                //error={vaildateParamValue(port).errorStatus}
                                //helperText={vaildateParamValue(port).msg}
                                />

                            </Grid>
                        </Grid>


                        {typeValue?.paramValue === "oracle" &&
                            <Grid item>
                                <PropertyField
                                    id={`${props.id}_ServiceName`}
                                    combo={true}
                                    dropdown={serviceName.paramType === "V"}
                                    paramObj={serviceName}
                                    labelBtn1OnClick={changeParamTypeToVorC}
                                    labelBtn2OnClick={changeParamTypeToVorC}
                                    options={getOptionsForVariable(serviceName)}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    name="ServiceName"
                                    label="Service Name"
                                    value={serviceName.paramValue}
                                    onChange={handleChange}
                                    error={vaildateParamValue(serviceName.paramValue).errorStatus}
                                    helperText={vaildateParamValue(serviceName.paramValue).msg}
                                />
                            </Grid>
                        }

                        <Grid item>
                            <PropertyField
                                id={`${props.id}_UserName`}
                                combo={true}
                                dropdown={username.paramType === "V"}
                                paramObj={username}
                                labelBtn1OnClick={changeParamTypeToVorC}
                                labelBtn2OnClick={changeParamTypeToVorC}
                                options={getOptionsForVariable(username)}
                                labelBtn1={true}
                                labelBtn2={true}
                                name="Username"
                                label="Username"
                                value={username.paramValue}
                                onChange={handleChange}
                                error={vaildateParamValue(username.paramValue).errorStatus}
                                helperText={vaildateParamValue(username.paramValue).msg}
                            />
                        </Grid>
                        <Grid item>
                            <PropertyField
                                id={`${props.id}_Pass`}
                                combo={true}
                                dropdown={password.paramType === "V"}
                                paramObj={password}
                                secret={true}
                                labelBtn1OnClick={changeParamTypeToVorC}
                                labelBtn2OnClick={changeParamTypeToVorC}
                                options={getOptionsForVariable(password)}
                                labelBtn1={true}
                                labelBtn2={true}
                                name="Password"
                                label="Password"
                                value={password.paramValue}
                                onChange={handleChange}
                                error={vaildateParamValue(password.paramValue).errorStatus}
                                helperText={vaildateParamValue(password.paramValue).msg}
                            />
                        </Grid>
                        <Grid item>
                            <PropertyField
                                id={`${props.id}_Timeout`}
                                type="number"
                                combo={true}
                                labelBtn1={true}
                                labelBtn2={true}
                                dropdown={timeoutField.paramType === "V"}
                                paramObj={timeoutField}
                                labelBtn1OnClick={changeParamTypeToVorC}
                                labelBtn2OnClick={changeParamTypeToVorC}
                                name="Timeout"
                                label="Connection Timeout (sec)"
                                value={timeoutField.paramValue}
                                options={getOptionsForVariable(timeoutField)}
                                onChange={handleChange}
                            />
                        </Grid>


                        <Grid item>
                            {isConnecting ? (
                                <Button
                                    variant="outlined"
                                >
                                    <CircularProgress
                                        size={14}
                                        className={classes.secondary_btn_circular_progress}
                                    />
                                    <Typography className={classes.secondary_btn_title}>
                                        Connecting...
                                    </Typography>
                                </Button>
                            ) : (
                                <Button
                                    variant="outlined"
                                    onClick={() => handleConnect()}
                                >
                                    <Typography className={classes.secondary_btn_title}>Test Connection</Typography>
                                </Button>
                            )}
                        </Grid>
                    </Grid>
                ) : selectedTab === "output" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                OUTPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <PropertyField
                                id={`${props.id}_ConnectionStatus`}
                                combo={true}
                                dropdown={true}
                                paramObj={connectionStatus}
                                btnIcon={
                                    <AddVariableIcon
                                        className={classes.btnIcon + " " + classes.colorPrimary}
                                    />
                                }
                                name="ConnectionStatus"
                                label={`Connection Status (${getVariableTypeById(
                                    connectionStatus.paramObjectTypeId
                                )})`}
                                value={connectionStatus.paramValue}
                                options={getOptionsForVariable(connectionStatus)}
                                onChange={handleChange}
                                error={
                                    vaildateParamValue(connectionStatus.paramValue.toString())
                                        .errorStatus
                                }
                                helperText={
                                    vaildateParamValue(connectionStatus.paramValue.toString()).msg
                                }
                            />
                        </Grid>
                    </Grid>
                )
                    :

                    selectedTab === "error" ? (
                        <ErrorsWindow />
                    ) : null}
            </div>
        </>
    );
};

export default ConnectDatabaseWindow;
