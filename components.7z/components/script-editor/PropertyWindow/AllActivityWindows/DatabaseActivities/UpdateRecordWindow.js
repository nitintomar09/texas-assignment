import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email, ExpandMore, Remove } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress, Avatar } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
    mapFieldObjWithValueByName,
    logsState,
    getOptionsForVariable,
    getVariableTypeById,
    getDefaultOfDefinedVariableByName,
    getAllVariables,
    handleParseValuesForDatabaseColumnValues,
    getAllOptionsForWhereClause
} from "./../Common/CommonMethods";

import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { AddIcon, AddVariableIcon, CloseIcon, DeleteIcon } from "../../../../../utils/AllImages";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import { createInstance, generateUniqueId } from "../../../../../utils/common";
import { DATABASE, DATABASE_CONNECT, GET_COLUMNS, GET_DATABASE_TYPE, GET_TABLES } from "../../../../../config";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";
import MenuPopper from "../../../../../utils/MenuPopper";



const UpdateRecordWindow = (props) => {
    const classes = useStyles();

    const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
        props;

    const { params } = selectedActivity;
    //const allOptions = getAllOptionsForWhereClause();
    const allVariables = getAllVariables();

    const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
    const databaseName = useSelector((state) => state.editorHomepage.databaseName);

    const dispatch = useDispatch();
    const { setValue: setNotification } = useContext(NotificationContext);
    const axiosInstance = createInstance()

    const [activityName, setActivityName] = useState(
        (selectedActivity && selectedActivity.displayName) || ""
    );

    const [tableOptions, setTableOptions] = useState([])
    const [columnOptions, setColumnOptions] = useState([])
    const [isFetchingTables, setIsFetchingTables] = useState(
        false
    );

    const [arrOfFieldVals, setArrOfFieldVals] = useState([

    ])


    const [tableName, setTableName] = useState(
        mapFieldObjWithValueByName(params, "TableName", "")
    );
    const [invisibleInLogs, setInvisibleInLogs] = useState(
        logsState(params, false)
    );


    const [fieldValues, setFieldValues] = useState(
        mapFieldObjWithValueByName(params, "FieldValues", "")
    );

    const [rowUpdated, setRowUpdated] = useState(
        mapFieldObjWithValueByName(params, "RowUpdated", "")
    );

    const [condition, setCondtion] = useState(
        mapFieldObjWithValueByName(params, "Condition", "")
    );
    const [conditionArray, setCondtionArray] = useState(
        []
    );

    const [whereCheckbox, setWhereCheckbox] = useState(
        false
    );



    useEffect(() => {
        setActivityName(selectedActivity ? selectedActivity.displayName : "");
        setInvisibleInLogs(logsState(params, false));
        setRowUpdated(mapFieldObjWithValueByName(params, "RowUpdated", ""));
        setTableName(
            mapFieldObjWithValueByName(params, "TableName", "")
        )

        const fieldValuesObj = mapFieldObjWithValueByName(params, "FieldValues", "")
        if (fieldValuesObj.paramValue) {
            try {
                const arrOfFieldVals = JSON.parse(fieldValues.paramValue);
                if (Array.isArray(arrOfFieldVals)) {
                    const newArrOfFieldVals = arrOfFieldVals.map((item) => {
                        return handleParseValuesForDatabaseColumnValues({
                            stringyfiedObject: JSON.stringify(item),
                        });
                    });
                    setArrOfFieldVals(newArrOfFieldVals);
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            setArrOfFieldVals([])
        }
        setFieldValues(fieldValuesObj)

        const conditions = mapFieldObjWithValueByName(params, "Condition", "")
        if (conditions.paramValue) {
            try {
                const arrOfConditions = JSON.parse(conditions.paramValue);
                if (Array.isArray(arrOfConditions)) {
                    setCondtionArray(arrOfConditions);
                    if (arrOfConditions.length > 0) {
                        setWhereCheckbox(true)
                    }
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            setCondtionArray([
                {
                    conditionID: 1,
                    conditionType: 1,
                    param1: "",
                    paramType1: "V",
                    operator: "",
                    paramType2: "C",
                    // param2: "",
                    param2: null,
                    dataType: null,
                    dataTypeLength: null,
                    expression: 0,
                },
            ])
        }
        setCondtion(conditions)

        dispatch(setErrorType("Throw"));
        dispatch(setSelectedTab("input"));
    }, [JSON.stringify(selectedActivity)]);

    useEffect(() => {
        setCondtion({ ...condition, paramValue: JSON.stringify(conditionArray) })
    }, [conditionArray])


    const getTables = async () => {
        if (databaseName) {
            setIsFetchingTables(true)
            try {
                const res = await axiosInstance.get(`${DATABASE}${GET_TABLES}/${databaseName}`);
                if (res.status === 200) {
                    setIsFetchingTables(false)

                    const arrOfOptionsInRes = res?.data?.data;
                    if (arrOfOptionsInRes) {
                        const arrayOfOptions = arrOfOptionsInRes.map(opt => ({ name: opt, value: opt }))
                        setTableOptions(arrayOfOptions)
                    }
                }
            } catch (error) {
                setIsFetchingTables(false)

                console.log(error)
            }
        } else {
            setNotification({
                isOpen: true,
                title: "Update Records",
                message: "Kindly first connect with Database Server.",
                notificationType: "ERROR",
            });
        }
    }

    const getColumnsOfTable = async () => {
        try {
            const res = await axiosInstance.get(`${DATABASE}${GET_COLUMNS}/${databaseName}/${tableName.paramValue}`);

            const arrOfOptionsInRes = res?.data?.data && res?.data?.data[0]?.columnList;
            if (arrOfOptionsInRes) {
                const arrayOfOptions = arrOfOptionsInRes.map(opt => ({
                    name: opt.columnName, value: opt.columnName, type: opt.columnType, dataType: opt.dataType,
                    rpaDataType: opt.rpaDataType, description: opt.columnType, isPrimaryKey: opt.isPrimaryKey, //disabled: opt.isPrimaryKey,
                    dataTypeLength: opt.dataTypeLength

                }))
                setColumnOptions(arrayOfOptions)

            }


        } catch (error) {
            console.log(error)
        }
    }






    useEffect(() => {
        if (arrOfFieldVals.length > 0 && columnOptions.length > 0) {
            const getColumnObj = (param) => {
                return columnOptions.find(item => item.name === param.key)
            }
            const newParamObj = arrOfFieldVals.map((param) => {

                return {
                    [param.key]: {
                        columnValue: param.paramType === "C"
                            ? param.value
                            : "${" + `${param.value}` + "}",
                        columnType: getColumnObj(param) ? getColumnObj(param).type : "",
                        dataType: getColumnObj(param) ? getColumnObj(param).dataType : "",
                        isPrimaryKey: getColumnObj(param) ? getColumnObj(param).isPrimaryKey : false,
                        dataTypeLength: getColumnObj(param) ? getColumnObj(param).dataTypeLength : "",
                        rpaDataType: getColumnObj(param) ? getColumnObj(param).rpaDataType : "",

                    }


                };
            });

            if (newParamObj) {
                setFieldValues({
                    ...fieldValues,
                    paramValue: JSON.stringify(newParamObj),
                });
            }
        }
    }, [arrOfFieldVals]);
    useEffect(() => {
        if (tableName?.paramValue && databaseName) {
            getColumnsOfTable()
        }
    }, [tableName])


    const handleChange = (e, index) => {

        const { name, value, checked } = e.target;
        switch (name) {
            case "ActivityName":
                setActivityName(value);
                updateDisplayNameSelAct(value);
                break;
            case "MakeLogsPrivate":
                setInvisibleInLogs({
                    ...invisibleInLogs,
                    paramValue: !invisibleInLogs.paramValue,
                });
                break;

            case "RowUpdated":
                setRowUpdated((prevState) => ({ ...prevState, paramValue: value }));
                break;


            case "TableName":
                setTableName((prevState) => ({ ...prevState, paramValue: value }));
                setArrOfFieldVals([])

                break;
            case "FieldValues":
                setFieldValues((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "Where":
                setWhereCheckbox(checked);
                break;
            default:
                break;
        }

    };

    const handleChangeConditionVals = (e, index) => {
        const { name, value } = e.target;
        if (typeof index === 'number') {
            const item = conditionArray[index];
            const colObj = columnOptions.find(item => item.name === value);


            switch (name) {
                case "Operand1":
                    item.param1 = value;
                    item.rpaDataType = colObj?.rpaDataType || "";
                    item.dataType = colObj?.dataType || null;
                    item.dataTypeLength = colObj?.dataTypeLength || null;
                    item.rpaDataType = colObj?.rpaDataType || null;


                    break;
                case "Operand2":
                    item.param2 = value;
                    break;
                case "OperatorType":
                    item.operator = value;
                    //in these operators case we dont need value of second param
                    if (["9", "10", "11"].includes(value)) {
                        item.param2 = "";
                    }
                    break;
                default:
                    break;
            }

            const newArr = [...conditionArray];
            newArr.splice(index, 1, item);
            setCondtionArray(newArr);
        }
    }
    useEffect(() => {
        updateParams();
    }, [
        invisibleInLogs,

        rowUpdated,
        fieldValues,
        tableName,
        condition,
        //  whereCheckbox

    ]);

    const updateParams = () => {
        let allParams = [
            invisibleInLogs,

            rowUpdated,
            fieldValues,
            tableName,

        ];
        if (whereCheckbox) {
            allParams = [...allParams, condition]
        } else {
            allParams = [...allParams, { ...condition, paramValue: "" }]
        }
        addParamsToSelAct(allParams);
    };




    const handleFieldValsValueChange = (e, index) => {

        const newArr = handleArrObjsValuesChange(e, index, arrOfFieldVals);
        setArrOfFieldVals(newArr);
    };

    const handleArrObjsValuesChange = (e, index, arr) => {
        const { name, value } = e.target;

        const newArr = [...arr];
        const obj = arr[index];
        if (name === "Key") {
            obj.key = value;
        } else if (name === "Value") {
            obj.value = value;
        }
        newArr.splice(index, 1, obj);
        return newArr;
    };
    const handleArrObjsValuesDelete = (index, arr) => {
        const newArr = [...arr];
        newArr.splice(index, 1);
        return newArr;
    };

    const addFieldValue = () => {
        const newObj = { key: "", value: "", paramType: "C", type: "", dataType: "", dataTypeLength: "" };
        const newArr = [...arrOfFieldVals, newObj];
        setArrOfFieldVals(newArr);
    };

    const handleFieldValueDelete = (index) => {
        const newArr = handleArrObjsValuesDelete(index, arrOfFieldVals);
        setArrOfFieldVals(newArr);
    };
    const changeValueTypeToVorC = (
        paramName,
        changeToValue,
        index,
        nameOfField
    ) => {
        let obj = null;
        switch (nameOfField) {

            case "FieldValues":
                obj = arrOfFieldVals[index];
                obj.paramType = changeToValue;
                obj.value = "";
                const newParamValues = [...arrOfFieldVals];
                newParamValues.splice(index, 1, obj);
                setArrOfFieldVals(newParamValues);
                break;
            default:
                break;
        }
    };


    const changeParamTypeToVorC = (paramName, changeToValue, index) => {
        switch (paramName) {
            case "Operand2":
                const item = conditionArray[index];
                item.paramType2 = changeToValue;
                item.param2 = "";
                const newArr = [...conditionArray];
                newArr.splice(index, 1, item);
                setCondtionArray(newArr);
                break;

            default:
                break;
        }
    };

    const removeCondition = () => {
        const newConditionArr = [...conditionArray];
        if (newConditionArr.length > 1) {
            let last = newConditionArr[conditionArray.length - 2];
            last.expression = 0;
            newConditionArr.splice(newConditionArr.length - 2, 2);

            setCondtionArray([...newConditionArr, last]);
        } else if (newConditionArr.length === 1) {
            setCondtionArray([]);
        }
    };

    const addNewCondition = () => {
        const newConditionArr = [...conditionArray];
        let last = conditionArray[conditionArray.length - 1];
        if (last) {
            last.expression = 1;
            newConditionArr.splice(newConditionArr.length - 1, 1);

            const newCond = {
                conditionID: conditionArray.length + 1,
                conditionType: 1,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                dataTypeLength: null,
                expression: 0,
            };
            setCondtionArray([...newConditionArr, last, newCond]);
        } else {
            const newCond = {
                conditionID: conditionArray.length + 1,
                conditionType: 1,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                dataTypeLength: null,
                expression: 0,
            };
            setCondtionArray([newCond]);
        }
    };
    
    const handleCond = (e, index) => {
       
        const { value } = e.target;
        const itemCon = conditionArray[index - 1];
        if (itemCon) {
            itemCon.expression = value === "OR" ? 2 : 1;
            const newArr = [...conditionArray];
            newArr.splice(index - 1, 1, itemCon);
            setCondtionArray(newArr);
        }
    };


    const getOperatorsOptions = (cond) => {
        const param1 = cond.param1;

        if (param1) {
            const varType = cond?.rpaDataType || 1;
            switch (varType) {
                case 1:
                    return allOperators.filter((opr) =>
                        availableOperators["textValue"].includes(opr.value)
                    );
                case 2:
                case 8:
                    return allOperators.filter((opr) =>
                        availableOperators["integerValue"].includes(opr.value)
                    );
                case 3:
                    return allOperators.filter((opr) =>
                        availableOperators["booleanValue"].includes(opr.value)
                    );
                case 4:
                case 9:
                    return allOperators.filter((opr) =>
                        availableOperators["dateTime"].includes(opr.value)
                    );
            }
        }
    };

    const getOptionsForVar = (cond) => {
        const param1 = cond.param1;
        if (param1) {

            const varType = cond?.rpaDataType || 1;
            if (varType) {
                return allVariables
                    .filter((obj) => obj.variableObjType === varType)
                    .map((item) => {
                        return { name: item.variableName, value: item.variableName };
                    });
            } else {
                return [];
            }
        }
    };
    const getVarType = (cond) => {
        const param1 = cond?.param1;


        if (param1) {
            return cond?.rpaDataType || 1;
        }

    };
    const getFieldType = (cond) => {
        const param1 = cond.param1;
        let fieldType = "text";
        if (param1) {

            const varType = cond?.rpaDataType;

            switch (varType) {
                case 2:
                case 8:
                    fieldType = "number";
                    break;
                case 4:
                    fieldType = "date";
                    break;
                case 9:
                    fieldType = "datetime-local";
                    break;
                default:
                    break;
            }
        }
        return fieldType;
    };
    const getColumnObj = (columnName) => {
        return columnOptions.find(col => col.name === columnName)
    }
    return (
        <>
            <CommonFields
                id={props.id}
                selectedActivity={selectedActivity}
                ScopeActivity={selectedActivity.activityType === "S"}
                activityName={activityName}
                handleChange={handleChange}
                makeLogsPrivate={invisibleInLogs.paramValue}
                ActivityIcon={Email}
                helperText={selectedActivity.description || "Update Records"}
            />
            <div
                className={classes.scrollDiv + " " + classes.focusVisible}
                tabIndex={0}
            >
                {selectedTab === "input" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                INPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <Typography component="h5" className={classes.text_light}>
                                Table
                            </Typography>
                        </Grid>
                        <Grid item container spacing={1}>
                            <Grid item>
                                {isFetchingTables ? (
                                    <Button
                                        variant="outlined"

                                        style={{ height: '32px' }}

                                    >
                                        <CircularProgress

                                            size={14}
                                            className={classes.secondary_btn_circular_progress}

                                        />
                                        <Typography className={classes.secondary_btn_title}>
                                            Fetching...
                                        </Typography>
                                    </Button>
                                ) : (
                                    <Button
                                        variant="outlined"

                                        onClick={() => getTables()}
                                        style={{ height: '32px' }}
                                    >
                                        <Typography className={classes.secondary_btn_title}>Fetch</Typography>
                                    </Button>
                                )}
                            </Grid>
                            <Grid item xs={8}>
                                <PropertyField
                                    id={`${props.id}_TableName`}
                                    combo={true}
                                    dropdown={true}
                                    name="TableName"
                                    // label="Table Name"
                                    value={tableName?.paramValue}
                                    onChange={handleChange}
                                    options={tableOptions}
                                    width={isFetchingTables ? 220 : 270}
                                    placeholder="Select Table"


                                />
                            </Grid>
                          

                        </Grid>
                        <Grid
                            item
                            container
                            direction="column"
                            spacing={1}
                            style={{ marginBottom: "5px" }}
                        >
                            <Grid item>
                                <Typography className={classes.GroupTitle}>
                                    Field Values
                                </Typography>
                            </Grid>
                            {arrOfFieldVals.length > 0 && (
                                <Grid item>
                                    <Grid container spacing={3} alignItems="flex-end">
                                        <Grid item xs={5}>
                                            <Typography className={classes.text_light}>Column</Typography>
                                        </Grid>
                                        <Grid item xs={5}>
                                            <Typography className={classes.text_light}>Value</Typography>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            )}
                            {arrOfFieldVals.map((item, index) => (
                                <Grid item key={index}>
                                    <Grid container spacing={3} alignItems="center">
                                        <Grid
                                            item
                                            xs={5}
                                        >
                                            <PropertyField
                                                id={`${props.id}_Key_${generateUniqueId()}`}
                                                name="Key"
                                                //  label="Key"
                                                combo={true}
                                                dropdown={true}
                                                readOnly={item.readOnly}
                                                value={item.key}

                                                onChange={(e) => handleFieldValsValueChange(e, index)}
                                                //  height={28}
                                                options={columnOptions.map(item => ({ ...item, disabled: item.isPrimaryKey }))}

                                                width={139}

                                            />
                                        </Grid>
                                        <Grid item xs={5}>
                                            <PropertyField
                                                id={`${props.id}_Value_${generateUniqueId()}`}
                                                combo={true}
                                                width={139}
                                                varType={1}
                                                name="Value"
                                                //  label="Value"
                                                paramObj={item}
                                                labelBtn1={true}
                                                labelBtn2={true}
                                                dropdown={item.paramType === "V"}
                                                labelBtn1OnClick={(paramName, changeToValue) =>
                                                    changeValueTypeToVorC(
                                                        paramName,
                                                        changeToValue,
                                                        index,
                                                        "FieldValues"
                                                    )
                                                }
                                                labelBtn2OnClick={(paramName, changeToValue) =>
                                                    changeValueTypeToVorC(
                                                        paramName,
                                                        changeToValue,
                                                        index,
                                                        "FieldValues"
                                                    )
                                                }
                                                value={item.value}
                                                onChange={(e) => handleFieldValsValueChange(e, index)}
                                                readOnly={item.readOnly}
                                                options={getOptionsForVariable({
                                                    paramObjectTypeId: getColumnObj(item.key)?.rpaDataType,
                                                })}
                                            />
                                        </Grid>


                                        <Grid item>
                                            <UniqueIDGenerator>
                                                <CloseIcon
                                                    id={`${props.id
                                                        }_DeleteIcon_${generateUniqueId()}`}
                                                    className={classes.deleteCrossIcon}
                                                    onClick={() => handleFieldValueDelete(index)}
                                                    tabIndex={0}
                                                    onKeyPress={(e) =>
                                                        e.key === "Enter" && handleFieldValueDelete(index)
                                                    }
                                                    role="button"
                                                    aria-label="Delete"
                                                />
                                            </UniqueIDGenerator>
                                        </Grid>


                                    </Grid>
                                    {index === arrOfFieldVals.length - 1 && <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                                        <Grid container spacing={1}
                                            onClick={() => addFieldValue()}
                                            onKeyPress={(e) =>
                                                e.key === "Enter" && addFieldValue()
                                            }
                                            tabIndex={0}

                                            role="button"
                                            aria-label="Add"
                                            >
                                            <Grid item>
                                                <AddIcon
                                                    className={classes.addColumnBtn}

                                                />
                                            </Grid>
                                            <Grid item>
                                                <Typography className={classes.tertiary_add_btn_title}>
                                                    Add Column
                                                </Typography>
                                            </Grid>
                                        </Grid>
                                    </Grid>}
                                </Grid>
                            ))}
                            {arrOfFieldVals.length === 0 &&
                                <Grid item>
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        onClick={() => addFieldValue()}
                                    >
                                        <Typography className={classes.btn_title}>Add Column</Typography>
                                    </Button></Grid>
                            }

                            {arrOfFieldVals.length > 0 &&
                                <Grid item>
                                    <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                        <Grid container direction='column' spacing={1}>
                                            <Grid item>
                                                <PropertyField
                                                    checkbox={true}
                                                    id={`${props.id}_Where`}
                                                    name="Where"
                                                    label="Where"
                                                    value={whereCheckbox}
                                                    onChange={handleChange}
                                                />

                                            </Grid>


                                            {whereCheckbox &&
                                                conditionArray.map((cond, index) => {

                                                    return (
                                                        <React.Fragment key={index}>
                                                            {index > 0 ? (
                                                                <Grid item container alignItems="center">

                                                                    <Grid item xs={12}>
                                                                        <PropertyField
                                                                            id={`${props.id}_${generateUniqueId()}`}
                                                                            width={310}
                                                                            // combo={true}
                                                                            dropdown={true}
                                                                            name="AndOrCondition"

                                                                            value={conditionArray[index - 1]?.expression === 1
                                                                                ? "AND"
                                                                                : "OR"}
                                                                            options={
                                                                                andOrOROptions || []
                                                                            }
                                                                            onChange={(e) => handleCond(e, index)}
                                                                        />
                                                                    </Grid>
                                                                </Grid>
                                                            ) : null}



                                                            <Grid item
                                                                style={{
                                                                    marginTop: "4px",
                                                                    paddingLeft: '16px',
                                                                    maxWidth: '320px'
                                                                }}
                                                            >
                                                                <Grid
                                                                    // item
                                                                    container
                                                                    direction="row"
                                                                    spacing={1}
                                                                    alignItems="flex-start"
                                                                    style={{
                                                                        backgroundColor: '#F8F8F8',
                                                                        borderRadius: '4px',
                                                                        paddingRight: '8px'
                                                                    }}
                                                                >
                                                                    {index === conditionArray.length - 1 && <Grid item xs={12}>
                                                                        <Grid container alignItems='flex-end'>

                                                                            <Grid item style={{ marginLeft: "auto" }}>

                                                                                <UniqueIDGenerator>
                                                                                    <CloseIcon
                                                                                        id={`${props.id
                                                                                            }_RemoveCndBtn_${generateUniqueId()}`}
                                                                                        className={classes.deleteCrossIcon}
                                                                                        onClick={() => removeCondition()}
                                                                                        tabIndex={0}
                                                                                        onKeyPress={(e) => e.key === "Enter" && removeCondition()}
                                                                                        role="button"
                                                                                        aria-label="Delete"
                                                                                        style={{ marginBottom: '-8px' }}
                                                                                    />
                                                                                </UniqueIDGenerator>



                                                                            </Grid>
                                                                        </Grid>
                                                                    </Grid>}
                                                                    <Grid item xs={8}>
                                                                        <PropertyField
                                                                            id={`${props.id}_${cond.param1
                                                                                }_${generateUniqueId()}`}
                                                                            width={200}
                                                                            combo={true}
                                                                            label={"Column"}
                                                                            dropdown={true}
                                                                            name="Operand1"
                                                                            value={cond.param1}
                                                                            options={
                                                                                columnOptions || []
                                                                            }
                                                                            onChange={(e) => handleChangeConditionVals(e, index)}
                                                                        />
                                                                    </Grid>
                                                                    <Grid item xs={4}>
                                                                        <PropertyField
                                                                            id={`${props.id}_${cond.operator
                                                                                }_${generateUniqueId()}`}
                                                                            //  combo={true}
                                                                            dropdown={true}
                                                                            label={"Operator"}
                                                                            name="OperatorType"
                                                                            value={cond.operator}
                                                                            onChange={(e) => handleChangeConditionVals(e, index)}
                                                                            options={getOperatorsOptions(cond) || []}
                                                                        // height={28}
                                                                        />
                                                                    </Grid>
                                                                    {cond.operator == "9" ||
                                                                        cond.operator == "10" ||
                                                                        cond.operator == "11" ? null : (
                                                                        <Grid item xs={12}>
                                                                            <PropertyField
                                                                                id={`${props.id}_${cond.param2
                                                                                    }_${generateUniqueId()}`}
                                                                                combo={true}
                                                                                dropdown={true}
                                                                                canType={true}

                                                                                type={getFieldType(cond)}
                                                                                labelBtn1={true}
                                                                                labelBtn2={true}
                                                                                paramObj={{ paramType: cond.paramType2 }}
                                                                                labelBtn1OnClick={(paramName, changeToValue) =>
                                                                                    changeParamTypeToVorC(
                                                                                        paramName,
                                                                                        changeToValue,
                                                                                        index
                                                                                    )
                                                                                }
                                                                                labelBtn2OnClick={(paramName, changeToValue) =>
                                                                                    changeParamTypeToVorC(
                                                                                        paramName,
                                                                                        changeToValue,
                                                                                        index
                                                                                    )
                                                                                }
                                                                                name="Operand2"
                                                                                label={"Value"}
                                                                                value={cond.param2}
                                                                                onChange={(e) => handleChangeConditionVals(e, index)}
                                                                                varType={getVarType(cond)}
                                                                                options={getOptionsForVar(cond) || []}
                                                                                error={
                                                                                    vaildateParamValue(cond?.param2?.toString() || "")
                                                                                        .errorStatus
                                                                                }
                                                                                helperText={
                                                                                    vaildateParamValue(cond?.param2?.toString() || "")
                                                                                        .msg
                                                                                }
                                                                                width={310}

                                                                            />
                                                                        </Grid>
                                                                    )}

                                                                </Grid>
                                                            </Grid>
                                                           
                                                        </React.Fragment>
                                                    );
                                                })}

                                            {whereCheckbox &&
                                                <Grid item container>
                                                    <Grid item xs={5} style={{ marginLeft: 'auto', cursor: 'pointer', marginRight: '-30px' }}>
                                                        <Grid container
                                                            onClick={() => addNewCondition()}
                                                            tabIndex={0}
                                                            onKeyPress={(e) => e.key === "Enter" && addNewCondition()}
                                                            role="button"
                                                            id={`${props.id}_AddNewCndBtn`}
                                                        >
                                                            <Grid item>
                                                                <AddIcon
                                                                    className={classes.addColumnBtn}

                                                                />
                                                            </Grid>
                                                            <Grid item>
                                                                <Typography className={classes.tertiary_add_btn_title}>
                                                                    Add Condition
                                                                </Typography>
                                                            </Grid>
                                                        </Grid>
                                                    </Grid>

                                                </Grid>
                                            }
                                        </Grid>
                                    </div>
                                </Grid>
                            }
                        </Grid>




                    </Grid>
                ) : selectedTab === "output" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                OUTPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <PropertyField
                                id={`${props.id}_RecordAdded`}
                                combo={true}
                                dropdown={true}
                                paramObj={rowUpdated}
                                btnIcon={
                                    <AddVariableIcon
                                        className={classes.btnIcon + " " + classes.colorPrimary}
                                    />
                                }
                                name="RowUpdated"
                                label={`Updated Record (${getVariableTypeById(
                                    rowUpdated.paramObjectTypeId
                                )})`}
                                value={rowUpdated.paramValue}
                                options={getOptionsForVariable(rowUpdated)}
                                onChange={handleChange}
                                error={
                                    vaildateParamValue(rowUpdated.paramValue.toString())
                                        .errorStatus
                                }
                                helperText={
                                    vaildateParamValue(rowUpdated.paramValue.toString()).msg
                                }
                            />
                        </Grid>
                    </Grid>
                )
                    :

                    selectedTab === "error" ? (
                        <ErrorsWindow />
                    ) : null}
            </div>
        </>
    );
};

export default UpdateRecordWindow;
const allOperators = [
    { name: "==(Equals)", value: 1, strName: "Equals" },
    { name: ">", value: 2, strName: "GreaterThan" },
    { name: ">=", value: 3, strName: "GreaterThanOrEqual" },
    { name: "<", value: 4, strName: "LessThan" },
    { name: "<=", value: 5, strName: "LessThanOrEqual" },
    { name: "!=", value: 6, strName: "NotEqual" },
    // { name: "EqualsIgnoreCase", value: 7, strName: "EqualsIgnoreCase" },
    { name: "Contains", value: 8, strName: "Contains" },
    { name: "isNull", value: 9, strName: "isNull" },
    { name: "isNotNull", value: 10, strName: "isNotNull" },
    { name: "isEmpty", value: 11, strName: "isEmpty" },
    { name: "Before", value: 12, strName: "Before" },
    { name: "After", value: 13, strName: "After" },
];

const andOrOROptions = [
    { name: "AND", value: "AND" },
    { name: "OR", value: "OR" }
]
const availableOperators = {
    integerValue: [1, 2, 3, 4, 5, 6],
    // floatValue: [1, 2, 3, 4, 5, 6],
    textValue: [1, 7, 9, 10, 11, 6],
    dateTime: [12, 13, 1, 6, 9, 10],
    booleanValue: [1, 6, 9, 10],
};