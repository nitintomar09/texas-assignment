import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress, Avatar } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
    mapFieldObjWithValueByName,
    logsState,
    getOptionsForVariable,
    getVariableTypeById,
    getDefaultOfDefinedVariableByName,
    getAllVariables,
    handleParseValuesForDatabaseColumnValues
} from "./../Common/CommonMethods";

import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { AddIcon, AddVariableIcon, DeleteIcon, CloseIcon } from "../../../../../utils/AllImages";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import { createInstance, generateUniqueId } from "../../../../../utils/common";
import { DATABASE, DATABASE_CONNECT, GET_COLUMNS, GET_DATABASE_TYPE, GET_TABLES } from "../../../../../config";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";



const AddRecordWindow = (props) => {
    const classes = useStyles();

    const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
        props;

    const { params } = selectedActivity;
    const allVariables = getAllVariables();

    const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
    const databaseName = useSelector((state) => state.editorHomepage.databaseName);

    const dispatch = useDispatch();
    const { setValue: setNotification } = useContext(NotificationContext);
    const axiosInstance = createInstance()

    const [activityName, setActivityName] = useState(
        (selectedActivity && selectedActivity.displayName) || ""
    );

    const [tableOptions, setTableOptions] = useState([])
    const [columnOptions, setColumnOptions] = useState([])
    const [isFetchingTables, setIsFetchingTables] = useState(
        false
    );

    // const [arrOfFieldVals, setArrOfFieldVals] = useState([
    // { key: "", value: "", paramType: "C"}

    // ])
    const [arrOfFieldVals, setArrOfFieldVals] = useState([

    ])


    const [tableName, setTableName] = useState(
        mapFieldObjWithValueByName(params, "TableName", "")
    );
    const [invisibleInLogs, setInvisibleInLogs] = useState(
        logsState(params, false)
    );


    const [fieldValues, setFieldValues] = useState(
        mapFieldObjWithValueByName(params, "FieldValues", "")
    );

    const [recordAdded, setRecordAdded] = useState(
        mapFieldObjWithValueByName(params, "Records", "")
    );

    const [primaryKey, setPrimaryKey] = useState(
        mapFieldObjWithValueByName(params, "primaryKey", "")
    );


    useEffect(() => {
        setActivityName(selectedActivity ? selectedActivity.displayName : "");
        setInvisibleInLogs(logsState(params, false));
        setRecordAdded(mapFieldObjWithValueByName(params, "Records", ""));
        setTableName(
            mapFieldObjWithValueByName(params, "TableName", "")
        )
        setPrimaryKey(
            mapFieldObjWithValueByName(params, "primaryKey", "")
        )
        const fieldValuesObj = mapFieldObjWithValueByName(params, "FieldValues", "")
        if (fieldValuesObj.paramValue) {
            try {
                const arrOfFieldVals = JSON.parse(fieldValues.paramValue);
                if (Array.isArray(arrOfFieldVals)) {
                    const newArrOfFieldVals = arrOfFieldVals.map((item) => {
                        return handleParseValuesForDatabaseColumnValues({
                            stringyfiedObject: JSON.stringify(item),
                        });
                    });
                    setArrOfFieldVals(newArrOfFieldVals);
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            setArrOfFieldVals([])
        }
        setFieldValues(fieldValuesObj)

        dispatch(setErrorType("Throw"));
        dispatch(setSelectedTab("input"));
    }, [JSON.stringify(selectedActivity)]);


    const getTables = async () => {
        if (databaseName) {
            setIsFetchingTables(true)
            try {
                const res = await axiosInstance.get(`${DATABASE}${GET_TABLES}/${databaseName}`);
                if (res.status === 200) {
                    setIsFetchingTables(false)

                    const arrOfOptionsInRes = res?.data?.data;
                    if (arrOfOptionsInRes) {
                        const arrayOfOptions = arrOfOptionsInRes.map(opt => ({ name: opt, value: opt }))
                        setTableOptions(arrayOfOptions)
                    }
                }
            } catch (error) {
                setIsFetchingTables(false)

                console.log(error)
            }
        } else {
            setNotification({
                isOpen: true,
                title: "Add Records",
                message: "Kindly first connect with Database Server.",
                notificationType: "ERROR",
            });
        }
    }

    const getColumnsOfTable = async () => {
        try {
            const res = await axiosInstance.get(`${DATABASE}${GET_COLUMNS}/${databaseName}/${tableName.paramValue}`);

            const arrOfOptionsInRes = res?.data?.data && res?.data?.data[0]?.columnList;
            const primeKey = res?.data?.data && res?.data?.data[0]?.primaryKey || ""
            if (arrOfOptionsInRes) {
                const arrayOfOptions = arrOfOptionsInRes.map(opt => ({
                    name: opt.columnName, value: opt.columnName, type: opt.columnType, dataType: opt.dataType, description: opt.columnType, isPrimaryKey: opt.isPrimaryKey, //disabled: opt.isPrimaryKey,
                    rpaDataType: opt.rpaDataType,
                    dataTypeLength: opt.dataTypeLength
                }))
                setColumnOptions(arrayOfOptions)

            }

            setPrimaryKey({ ...primaryKey, paramValue: primeKey })

        } catch (error) {
            console.log(error)
        }
    }

    useEffect(() => {
        if (arrOfFieldVals.length > 0 && columnOptions.length > 0) {
            const getColumnObj = (param) => {

                return columnOptions.find(item => item.name === param.key)
            }
            const newParamObj = arrOfFieldVals.map((param) => {

                return {
                    [param.key]: {
                        columnValue: param.paramType === "C"
                            ? param.value
                            : "${" + `${param.value}` + "}",
                        columnType: getColumnObj(param) ? getColumnObj(param).type : "",
                        dataType: getColumnObj(param) ? getColumnObj(param).dataType : "",
                        isPrimaryKey: getColumnObj(param) ? getColumnObj(param).isPrimaryKey : false,
                        dataTypeLength: getColumnObj(param) ? getColumnObj(param).dataTypeLength : "",
                        rpaDataType: getColumnObj(param) ? getColumnObj(param).rpaDataType : "",

                    }

                };
            });

            if (newParamObj) {
                setFieldValues({
                    ...fieldValues,
                    paramValue: JSON.stringify(newParamObj),
                });
            }
        }
    }, [arrOfFieldVals]);
    useEffect(() => {
        if (tableName?.paramValue && databaseName) {
            getColumnsOfTable()
        }
    }, [tableName, databaseName])
    const handleChange = (e) => {
        const { name, value } = e.target;
        switch (name) {
            case "ActivityName":
                setActivityName(value);
                updateDisplayNameSelAct(value);
                break;
            case "MakeLogsPrivate":
                setInvisibleInLogs({
                    ...invisibleInLogs,
                    paramValue: !invisibleInLogs.paramValue,
                });
                break;

            case "Records":
                setRecordAdded((prevState) => ({ ...prevState, paramValue: value }));
                break;


            case "TableName":
                setTableName((prevState) => ({ ...prevState, paramValue: value }));
                setArrOfFieldVals([])

                break;
            case "FieldValues":
                setFieldValues((prevState) => ({ ...prevState, paramValue: value }));
                break;

            default:
                break;
        }
    };


    useEffect(() => {
        updateParams();
    }, [
        invisibleInLogs,

        recordAdded,
        fieldValues,
        tableName,
        primaryKey

    ]);

    const updateParams = () => {
        const allParams = [
            invisibleInLogs,

            recordAdded,
            fieldValues,
            tableName,
            primaryKey

        ];

        addParamsToSelAct(allParams);
    };




    const handleFieldValsValueChange = (e, index) => {

        const newArr = handleArrObjsValuesChange(e, index, arrOfFieldVals);
        setArrOfFieldVals(newArr);
    };

    const handleArrObjsValuesChange = (e, index, arr) => {
        const { name, value } = e.target;

        const newArr = [...arr];
        const obj = arr[index];
        if (name === "Key") {
            obj.key = value;
        } else if (name === "Value") {
            obj.value = value;
        }
        newArr.splice(index, 1, obj);
        return newArr;
    };
    const handleArrObjsValuesDelete = (index, arr) => {
        const newArr = [...arr];
        newArr.splice(index, 1);
        return newArr;
    };

    const addFieldValue = () => {
        const newObj = { key: "", value: "", paramType: "C", type: "", dataType: "" };
        const newArr = [...arrOfFieldVals, newObj];
        setArrOfFieldVals(newArr);
    };

    const handleFieldValueDelete = (index) => {
        const newArr = handleArrObjsValuesDelete(index, arrOfFieldVals);
        setArrOfFieldVals(newArr);
    };
    const changeValueTypeToVorC = (
        paramName,
        changeToValue,
        index,
        nameOfField
    ) => {
        let obj = null;
        switch (nameOfField) {

            case "FieldValues":
                obj = arrOfFieldVals[index];
                obj.paramType = changeToValue;
                obj.value = "";
                const newParamValues = [...arrOfFieldVals];
                newParamValues.splice(index, 1, obj);
                setArrOfFieldVals(newParamValues);
                break;
            default:
                break;
        }
    };
    const getColumnObj = (columnName) => {
        return columnOptions.find(col => col.name === columnName)
    }
    return (
        <>
            <CommonFields
                id={props.id}
                selectedActivity={selectedActivity}
                ScopeActivity={selectedActivity.activityType === "S"}
                activityName={activityName}
                handleChange={handleChange}
                makeLogsPrivate={invisibleInLogs.paramValue}
                ActivityIcon={Email}
                helperText={selectedActivity.description || "Add a Record"}
            />
            <div
                className={classes.scrollDiv + " " + classes.focusVisible}
                tabIndex={0}
            >
                {selectedTab === "input" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                INPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <Typography component="h5" className={classes.text_light}>
                                Table
                            </Typography>
                        </Grid>
                        <Grid item container spacing={1}>

                            <Grid item>
                                {isFetchingTables ? (
                                    <Button
                                        variant="outlined"

                                        style={{ height: '32px' }}

                                    >
                                        <CircularProgress

                                            size={14}
                                            className={classes.secondary_btn_circular_progress}

                                        />
                                        <Typography className={classes.secondary_btn_title}>
                                            Fetching...
                                        </Typography>
                                    </Button>
                                ) : (
                                    <Button
                                        variant="outlined"

                                        onClick={() => getTables()}
                                        style={{ height: '32px' }}
                                    >
                                        <Typography className={classes.secondary_btn_title}>Fetch</Typography>
                                    </Button>
                                )}
                            </Grid>
                            <Grid item >
                                <PropertyField
                                    id={`${props.id}_TableName`}
                                    combo={true}
                                    dropdown={true}
                                    name="TableName"
                                    // label="Table Name"
                                    value={tableName?.paramValue}
                                    onChange={handleChange}
                                    options={tableOptions}
                                    width={isFetchingTables ? 220 : 270}
                                    placeholder="Select Table"

                                />
                            </Grid>


                        </Grid>
                        <Grid
                            item
                            container
                            direction="column"
                            // spacing={1}
                            style={{ marginBottom: "5px" }}
                        >
                            <Grid item>
                                <Typography className={classes.GroupTitle}>
                                    Field Values
                                </Typography>
                            </Grid>
                            {arrOfFieldVals.length > 0 && (
                                <Grid item>
                                    <Grid container spacing={3} alignItems="flex-end">
                                        <Grid item xs={5}>
                                            <Typography className={classes.text_light}>Column</Typography>
                                        </Grid>
                                        <Grid item xs={5}>
                                            <Typography className={classes.text_light}>Value</Typography>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            )}
                            {arrOfFieldVals.map((item, index) => (
                                <Grid item key={index}>
                                    <Grid container spacing={3} alignItems="center">
                                        <Grid
                                            item
                                            xs={5} //style={{ paddingTop: "24px" }}
                                        >
                                            <PropertyField
                                                id={`${props.id}_Key_${generateUniqueId()}`}
                                                name="Key"
                                                //  label="Key"
                                                combo={true}
                                                dropdown={true}
                                                value={item.key}
                                                onChange={(e) => handleFieldValsValueChange(e, index)}
                                                readOnly={item.readOnly}
                                                //  height={28}
                                                options={columnOptions.map(item => ({ ...item, disabled: item.isPrimaryKey }))}
                                                disablePrimaryKey={true}
                                                width={139}

                                            />
                                        </Grid>
                                        <Grid item xs={5}>
                                            <PropertyField
                                                id={`${props.id}_Value_${generateUniqueId()}`}
                                                combo={true}
                                                width={139}
                                                varType={1}
                                                name="Value"
                                                //  label="Value"
                                                paramObj={item}
                                                labelBtn1={true}
                                                labelBtn2={true}
                                                dropdown={item.paramType === "V"}
                                                labelBtn1OnClick={(paramName, changeToValue) =>
                                                    changeValueTypeToVorC(
                                                        paramName,
                                                        changeToValue,
                                                        index,
                                                        "FieldValues"
                                                    )
                                                }
                                                labelBtn2OnClick={(paramName, changeToValue) =>
                                                    changeValueTypeToVorC(
                                                        paramName,
                                                        changeToValue,
                                                        index,
                                                        "FieldValues"
                                                    )
                                                }
                                                value={item.value}
                                                onChange={(e) => handleFieldValsValueChange(e, index)}
                                                readOnly={item.readOnly}
                                                options={getOptionsForVariable({
                                                    paramObjectTypeId: getColumnObj(item.key)?.rpaDataType,
                                                })}
                                            />
                                        </Grid>


                                        <Grid item >
                                            <UniqueIDGenerator>
                                                <CloseIcon
                                                    id={`${props.id
                                                        }_DeleteIcon_${generateUniqueId()}`}
                                                    className={classes.deleteCrossIcon}
                                                    onClick={() => handleFieldValueDelete(index)}
                                                    tabIndex={0}
                                                    onKeyPress={(e) =>
                                                        e.key === "Enter" && handleFieldValueDelete(index)
                                                    }
                                                    role="button"
                                                    aria-label="Delete"
                                                />
                                            </UniqueIDGenerator>
                                        </Grid>
                                    </Grid>

                                    {index === arrOfFieldVals.length - 1 && <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>

                                        <Grid container spacing={1}
                                            onClick={() => addFieldValue()}>
                                            <Grid item>
                                                <AddIcon
                                                    className={classes.addColumnBtn}

                                                // style={{
                                                //     height: "18px",
                                                //     width: "18px",
                                                //     color: "#0072C6",

                                                // }}
                                                />
                                            </Grid>
                                            <Grid item>
                                                <Typography className={classes.tertiary_add_btn_title}>
                                                    Add Column
                                                </Typography>
                                            </Grid>
                                        </Grid>
                                    </Grid>}
                                </Grid>
                            ))}
                            {arrOfFieldVals.length === 0 &&
                                <Grid item>
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        onClick={() => addFieldValue()}
                                    >
                                        <Typography className={classes.btn_title}>Add Column</Typography>
                                    </Button></Grid>}
                        </Grid>





                    </Grid>
                ) : selectedTab === "output" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                OUTPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <PropertyField
                                id={`${props.id}_RecordAdded`}
                                combo={true}
                                dropdown={true}
                                paramObj={recordAdded}
                                btnIcon={
                                    <AddVariableIcon
                                        className={classes.btnIcon + " " + classes.colorPrimary}
                                    />
                                }
                                name="Records"
                                label={`Added Record (${getVariableTypeById(
                                    recordAdded.paramObjectTypeId
                                )})`}
                                value={recordAdded.paramValue}
                                options={getOptionsForVariable(recordAdded)}
                                onChange={handleChange}
                                error={
                                    vaildateParamValue(recordAdded.paramValue.toString())
                                        .errorStatus
                                }
                                helperText={
                                    vaildateParamValue(recordAdded.paramValue.toString()).msg
                                }
                            />
                        </Grid>
                    </Grid>
                )
                    :

                    selectedTab === "error" ? (
                        <ErrorsWindow />
                    ) : null}
            </div>
        </>
    );
};

export default AddRecordWindow;
