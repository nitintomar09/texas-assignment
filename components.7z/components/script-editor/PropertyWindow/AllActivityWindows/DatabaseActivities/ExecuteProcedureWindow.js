import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email, ExpandMore, Remove } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress, Avatar } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
    mapFieldObjWithValueByName,
    logsState,
    getOptionsForVariable,
    getVariableTypeById,
    getDefaultOfDefinedVariableByName,
    getAllVariables,
    handleParseValuesForDatabaseColumnValues,
    getAllOptionsForWhereClause
} from "./../Common/CommonMethods";

import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { AddIcon, AddVariableIcon, DeleteIcon } from "../../../../../utils/AllImages";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import { createInstance, generateUniqueId } from "../../../../../utils/common";
import { DATABASE, DATABASE_CONNECT, GET_COLUMNS, GET_DATABASE_TYPE, GET_PROCEDURES, GET_PROCEDURE_PARAMS, GET_TABLES } from "../../../../../config";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";
import MenuPopper from "../../../../../utils/MenuPopper";



const ExecuteProcedureWindow = (props) => {
    const classes = useStyles();

    const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
        props;

    const { params } = selectedActivity;
    const allVariables = getAllVariables();

    const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
    const databaseName = useSelector((state) => state.editorHomepage.databaseName);

    const dispatch = useDispatch();
    const { setValue: setNotification } = useContext(NotificationContext);
    const axiosInstance = createInstance()

    const [activityName, setActivityName] = useState(
        (selectedActivity && selectedActivity.displayName) || ""
    );

    const [procedureOptions, setProcesdureOptions] = useState([])
    const [inputParams, setInputParams] = useState(
        mapFieldObjWithValueByName(params, "InputParams", [])
    )
    /*   const [inoutParams, setInOutParams] = useState(
           mapFieldObjWithValueByName(params, "InOutParams", [])
       )*/
    const [inputParamsArray, setInputParamsArray] = useState([])
    const [outputParamsArray, setOutputParamsArray] = useState([])
    //   const [inoutParamsArray, setInOutParamsArray] = useState([])


    const [inputOutputParams, setInputOutputParams] = useState([])
    const [outputParams, setOutputParams] = useState(
        mapFieldObjWithValueByName(params, "OutputParams", [])
    )
    const [isFetchingProcesdures, setIsFetchingProcesdures] = useState(
        false
    );


    const [procedureName, setProcedureName] = useState(
        mapFieldObjWithValueByName(params, "ProcedureName", "")
    );
    const [invisibleInLogs, setInvisibleInLogs] = useState(
        logsState(params, false)
    );




    const [status, setStatus] = useState(
        mapFieldObjWithValueByName(params, "Status", "")
    );
    const [onceRendered, setOnceRendered] = useState(false);



    useEffect(() => {
        setActivityName(selectedActivity ? selectedActivity.displayName : "");
        setInvisibleInLogs(logsState(params, false));
        setOnceRendered(false)
        setStatus(mapFieldObjWithValueByName(params, "Status", ""));
        setProcedureName(
            mapFieldObjWithValueByName(params, "ProcedureName", "")
        )
        const inputParamsValue = mapFieldObjWithValueByName(params, "InputParams", [])
        if (inputParamsValue.paramValue) {
            try {
                const arrOfValues = JSON.parse(inputParamsValue.paramValue);
                if (Array.isArray(arrOfValues)) {
                    setInputParamsArray(arrOfValues);
                }
            } catch (error) {
                console.log(error);
            }
        }
        setInputParams(inputParamsValue)

        /*   const inoutParamsValue = mapFieldObjWithValueByName(params, "InOutParams", [])
           if (inoutParamsValue.paramValue) {
               try {
                   const arrOfValues = JSON.parse(inoutParamsValue.paramValue);
                   if (Array.isArray(arrOfValues)) {
                       setInOutParamsArray(arrOfValues);
                   }
               } catch (error) {
                   console.log(error);
               }
           }
           setInOutParams(inoutParamsValue)*/

        const outputParamsValue = mapFieldObjWithValueByName(params, "OutputParams", [])
        if (outputParamsValue.paramValue) {
            try {
                const arrOfValues = JSON.parse(outputParamsValue.paramValue);
                if (Array.isArray(arrOfValues)) {
                    setOutputParamsArray(arrOfValues);
                }
            } catch (error) {
                console.log(error);
            }
        }
        setOutputParams(outputParamsValue)
        dispatch(setErrorType("Throw"));
        dispatch(setSelectedTab("input"));
    }, [selectedActivity]);


    const getProcedures = async () => {
        if (databaseName) {
            setIsFetchingProcesdures(true)

            try {
                const res = await axiosInstance.get(`${DATABASE}${GET_PROCEDURES}/${databaseName}`);
                if (res.status === 200) {
                    setIsFetchingProcesdures(false)

                    const arrOfOptionsInRes = res?.data?.data;
                    if (arrOfOptionsInRes) {
                        const arrayOfOptions = arrOfOptionsInRes.map(opt => ({ name: opt, value: opt }))
                        setProcesdureOptions(arrayOfOptions)
                    }
                }
            } catch (error) {
                setIsFetchingProcesdures(false)

                console.log(error)
            }
        } else {
            setNotification({
                isOpen: true,
                title: "Execute Procedure",
                message: "Kindly first connect with Database Server.",
                notificationType: "ERROR",
            });
        }
    }

    const getInputOutputVariablesOfProcesdure = async () => {

        try {
            const res = await axiosInstance.get(`${DATABASE}${GET_PROCEDURE_PARAMS}/${databaseName}/${procedureName.paramValue}`);

            const arrOfOptionsInRes = res?.data?.data || [];
            if (arrOfOptionsInRes) {
                const arrayOfOptions = arrOfOptionsInRes.map(opt => ({
                    ...opt,
                    name: opt.paramName, value: opt.paramName,
                }))

                setInputOutputParams(arrayOfOptions)
                if (onceRendered) {
                    setInputParamsArray([...arrOfOptionsInRes].filter(item => item.paramType === 'IN'))
                    setOutputParamsArray([...arrOfOptionsInRes].filter(item => item.paramType === 'OUT'))
                    //  setInOutParamsArray([...arrOfOptionsInRes].filter(item => item.paramType === 'INOUT'))

                    setOnceRendered(true);
                } else if (((!inputParams.paramValue || (Array.isArray(inputParams.paramValue) && inputParams.paramValue.length === 0)) && (!outputParams.paramValue || (Array.isArray(outputParams.paramValue) && outputParams.paramValue.length === 0)))) {
                    setInputParamsArray([...arrOfOptionsInRes].filter(item => item.paramType === 'IN'))
                    setOutputParamsArray([...arrOfOptionsInRes].filter(item => item.paramType === 'OUT'))
                    //setInOutParamsArray([...arrOfOptionsInRes].filter(item => item.paramType === 'INOUT'))

                    setOnceRendered(true);
                } else {
                    setOnceRendered(true)
                }
            }
        } catch (error) {
            console.log(error)
        }
    }


    useEffect(() => {
        if (procedureName?.paramValue && databaseName) {
            getInputOutputVariablesOfProcesdure()
        }
    }, [procedureName])


    const handleChange = (e, index) => {

        const { name, value, checked } = e.target;
        switch (name) {
            case "ActivityName":
                setActivityName(value);
                updateDisplayNameSelAct(value);
                break;
            case "MakeLogsPrivate":
                setInvisibleInLogs({
                    ...invisibleInLogs,
                    paramValue: !invisibleInLogs.paramValue,
                });
                break;

            case "Status":
                setStatus((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "ProcedureName":
                setProcedureName((prevState) => ({ ...prevState, paramValue: value }));
                break;

            default:
                break;
        }

    };


    useEffect(() => {
        updateParams();
    }, [
        invisibleInLogs,
        status,
        inputParams,
        outputParams,
        procedureName,
        //  inoutParams
    ]);

    const updateParams = () => {
        let allParams = [
            invisibleInLogs,
            status,
            // inputParams,
            //outputParams,
            procedureName,
            // inoutParams
        ];
        const stringyfiedArr = JSON.stringify([])

        //  let newInoutParams = { ...inoutParams }
        let newInputParams = { ...inputParams }
        let newOutputParams = { ...outputParams }



        /* if (!inoutParams.paramValue) {
             newInoutParams = { ...inoutParams, paramValue: stringyfiedArr }
         }*/
        if (!inputParams.paramValue) {
            newInputParams = { ...inputParams, paramValue: stringyfiedArr }

        }
        if (!outputParams.paramValue) {
            newOutputParams = { ...outputParams, paramValue: stringyfiedArr }
        }
        //  allParams.push(newInoutParams)
        allParams.push(newInputParams)
        allParams.push(newOutputParams)
        addParamsToSelAct(allParams);
    };

    useEffect(() => {
        if (inputParamsArray.length > 0) {
            setInputParams({
                ...inputParams,
                paramValue: JSON.stringify(inputParamsArray),
            });

        }
    }, [JSON.stringify(inputParamsArray)]);
    /*useEffect(() => {
        if (inoutParamsArray.length > 0) {
            setInOutParams({
                ...inoutParams,
                paramValue: JSON.stringify(inoutParamsArray),
            });

        }
    }, [inoutParamsArray]);*/
    useEffect(() => {
        if (outputParamsArray.length > 0) {
            setOutputParams({
                ...outputParams,
                paramValue: JSON.stringify(outputParamsArray),
            });

        }
    }, [JSON.stringify(outputParamsArray)]);


    const handleChangeInputParamsValue = (e, index) => {
        const { name, value } = e.target;
        if (typeof index === 'number') {
            const item = inputParamsArray[index];

            switch (name) {
                case "Operand2":
                    item.paramValue = value;
                    if (!value) {
                        item.paramVariableType = "C"
                    }
                    break;
                default:
                    break;
            }
            const newArr = [...inputParamsArray];
            newArr.splice(index, 1, item);
            setInputParamsArray(newArr);
        }
    }

    /* const handleChangeInoutParamsValue = (e, index) => {
         const { name, value } = e.target;
         if (typeof index === 'number') {
             const item = inoutParamsArray[index];
 
             switch (name) {
                 case "Operand2":
                     item.paramValue = value;
                     if (!value) {
                         item.paramVariableType = "C"
                     }
                     break;
                 default:
                     break;
             }
             const newArr = [...inoutParamsArray];
             newArr.splice(index, 1, item);
             setInOutParamsArray(newArr);
         }
     }
 */


    const handleChangeOutputParamsValue = (e, index) => {
        const { name, value } = e.target;
        if (typeof index === 'number') {
            const item = outputParamsArray[index];

            switch (name) {
                case "Operand2":
                    item.paramValue = value;
                    if (!value) {
                        item.paramVariableType = "C"
                    }
                    break;
                default:
                    break;
            }
            const newArr = [...outputParamsArray];
            newArr.splice(index, 1, item);
            setOutputParamsArray(newArr);
        }
    }
    const changeParamTypeToVorCForInputParams = (paramName, changeToValue, index) => {
        switch (paramName) {
            case "Operand2":
                const item = inputParamsArray[index];
                item.paramVariableType = changeToValue;
                item.paramValue = ""
                const newArr = [...inputParamsArray];
                newArr.splice(index, 1, item);
                setInputParamsArray(newArr);
                break;

            default:
                break;
        }
    };

    /* const changeParamTypeToVorCForInoutParams = (paramName, changeToValue, index) => {
         switch (paramName) {
             case "Operand2":
                 const item = inoutParamsArray[index];
                 item.paramVariableType = changeToValue;
                 item.paramValue = ""
                 const newArr = [...inoutParamsArray];
                 newArr.splice(index, 1, item);
                 setInOutParamsArray(newArr);
                 break;
 
             default:
                 break;
         }
     };*/
    const changeParamTypeToVorCForOutputParams = (paramName, changeToValue, index) => {
        switch (paramName) {
            case "Operand2":
                const item = outputParamsArray[index];
                item.paramVariableType = changeToValue;
                item.paramValue = "";
                const newArr = [...outputParamsArray];
                newArr.splice(index, 1, item);
                setOutputParamsArray(newArr);
                break;

            default:
                break;
        }
    };
    const getOptionsForVar = (param) => {
        const varType = param?.rpaDataType || 1;
        if (varType) {
            return allVariables
                .filter((obj) => obj.variableObjType === varType)
                .map((item) => {
                    return { name: item.variableName, value: item.variableName };
                });
        } else {
            return [];
        }
    };
    const getVarType = (cond) => {
        const param1 = cond?.param1;
        if (param1) {
            return cond?.rpaDataType || 1;
        }

    };
    const handleReset = () => {
        setInputParamsArray((prev) => ([...inputOutputParams].filter(item => item.paramType === 'IN')))
        setOutputParamsArray((prev) => ([...inputOutputParams].filter(item => item.paramType === 'OUT')))
        // setInOutParamsArray([...inputOutputParams].filter(item => item.paramType === 'INOUT'))

    }
    return (
        <>
            <CommonFields
                id={props.id}
                selectedActivity={selectedActivity}
                ScopeActivity={selectedActivity.activityType === "S"}
                activityName={activityName}
                handleChange={handleChange}
                makeLogsPrivate={invisibleInLogs.paramValue}
                ActivityIcon={Email}
                helperText={selectedActivity.description || "Execute Procedure"}
            />
            <div
                className={classes.scrollDiv + " " + classes.focusVisible}
                tabIndex={0}
            >
                {selectedTab === "input" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                INPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <Typography component="h5" className={classes.text_light}>
                                Procedure
                            </Typography>
                        </Grid>
                        <Grid item container spacing={1}>
                            <Grid item>
                                {isFetchingProcesdures ? (
                                    <Button
                                        variant="outlined"

                                        style={{ height: '32px' }}

                                    >
                                        <CircularProgress

                                            size={14}
                                            className={classes.secondary_btn_circular_progress}

                                        />
                                        <Typography className={classes.secondary_btn_title}>
                                            Fetching...
                                        </Typography>
                                    </Button>
                                ) : (
                                    <Button
                                        variant="outlined"

                                        onClick={() => getProcedures()}
                                        style={{ height: '32px' }}
                                    >
                                        <Typography className={classes.secondary_btn_title}>Fetch</Typography>
                                    </Button>
                                )}
                            </Grid>
                            <Grid item xs={8}>
                                <PropertyField
                                    id={`${props.id}_ProcedureName`}
                                    combo={true}
                                    dropdown={true}
                                    name="ProcedureName"

                                    value={procedureName?.paramValue}
                                    onChange={handleChange}
                                    options={procedureOptions}
                                    width={isFetchingProcesdures ? 220 : 270}
                                    placeholder="Select Procedure"


                                />
                            </Grid>
                        </Grid>

                        <Grid item>
                            <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                <Grid container direction='column' spacing={1}>
                                    <Grid item>
                                        <Typography component="h5" className={classes.listSubTitle}>
                                            Input Parameters
                                        </Typography>
                                    </Grid>
                                    {
                                        inputParamsArray.map((cond, index) => {

                                            return (
                                                <Grid item key={index}>

                                                    <Grid container spacing={1} alignItems="center">
                                                        <Grid item xs={6}>


                                                            <PropertyField
                                                                id={`${props.id}_${cond.paramName
                                                                    }_${generateUniqueId()}`}
                                                                width={159}
                                                                combo={true}
                                                                // dropdown={true}
                                                                readOnly={true}
                                                                name="Operand1"
                                                                label="Parameter"
                                                                value={cond.paramName}

                                                            />
                                                        </Grid>


                                                        <Grid item xs={5}>
                                                            <PropertyField
                                                                id={`${props.id}_${cond.paramValue
                                                                    }_${generateUniqueId()}`}
                                                                width={139}
                                                                combo={true}
                                                                dropdown={cond.paramVariableType === 'V'}

                                                                name="Operand2"
                                                                label="Value"

                                                                labelBtn1={true}
                                                                labelBtn2={true}
                                                                value={cond.paramValue}
                                                                varType={getVarType(cond)}
                                                                paramObj={{ paramType: cond.paramVariableType || "C", paramValue: cond.paramValue, paramObjectTypeId: getVarType(cond) }}
                                                                options={
                                                                    getOptionsForVar(cond)
                                                                }
                                                                labelBtn1OnClick={(paramName, changeToValue) =>
                                                                    changeParamTypeToVorCForInputParams(
                                                                        paramName,
                                                                        changeToValue,
                                                                        index
                                                                    )
                                                                }
                                                                labelBtn2OnClick={(paramName, changeToValue) =>
                                                                    changeParamTypeToVorCForInputParams(
                                                                        paramName,
                                                                        changeToValue,
                                                                        index
                                                                    )
                                                                }
                                                                onChange={(e) => handleChangeInputParamsValue(e, index)}
                                                            />
                                                        </Grid>
                                                    </Grid>

                                                </Grid>
                                            );
                                        })}

                                </Grid>
                            </div>
                        </Grid>
                        <Grid item>
                            <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                <Grid container direction='column' spacing={1}>
                                    <Grid item>
                                        <Typography component="h5" className={classes.listSubTitle}>
                                            Output Parameters
                                        </Typography>
                                    </Grid>
                                    {
                                        outputParamsArray.map((cond, index) => {

                                            return (
                                                <Grid item key={index}>

                                                    <Grid container spacing={1} alignItems="center">
                                                        <Grid item xs={6}>


                                                            <PropertyField
                                                                id={`${props.id}_${cond.paramName
                                                                    }_${generateUniqueId()}`}
                                                                width={159}
                                                                combo={true}
                                                                // dropdown={true}
                                                                readOnly={true}
                                                                name="Operand1"
                                                                label="Parameter"
                                                                value={cond.paramName}

                                                            />
                                                        </Grid>


                                                        <Grid item xs={5}>
                                                            <PropertyField
                                                                id={`${props.id}_${cond.paramValue
                                                                    }_${generateUniqueId()}`}
                                                                width={139}

                                                                combo={true}
                                                                dropdown={true}
                                                                paramObj={cond}
                                                                name="Operand2"
                                                                label="Value"
                                                                value={cond.paramValue}
                                                                varType={getVarType(cond)}
                                                                options={
                                                                    getOptionsForVar(cond)
                                                                }
                                                                labelBtn1OnClick={(paramName, changeToValue) =>
                                                                    changeParamTypeToVorCForOutputParams(
                                                                        paramName,
                                                                        changeToValue,
                                                                        index
                                                                    )
                                                                }
                                                                labelBtn2OnClick={(paramName, changeToValue) =>
                                                                    changeParamTypeToVorCForOutputParams(
                                                                        paramName,
                                                                        changeToValue,
                                                                        index
                                                                    )
                                                                }
                                                                onChange={(e) => handleChangeOutputParamsValue(e, index)}
                                                            />
                                                        </Grid>
                                                    </Grid>

                                                </Grid>
                                            );
                                        })}

                                </Grid>
                            </div>
                        </Grid>
                        {inputOutputParams.length > 0 && <Grid item>

                            <Button
                                variant="outlined"
                                onClick={() => handleReset()}
                            >
                                <Typography
                                    className={classes.secondary_btn_title}>Refresh</Typography>
                            </Button>

                        </Grid>}

                    </Grid>
                ) : selectedTab === "output" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                OUTPUT
                            </Typography>
                        </Grid>
                        <Grid item>

                            <PropertyField
                                id={`${props.id}_Status`}
                                combo={true}
                                dropdown={true}
                                paramObj={status}
                                btnIcon={
                                    <AddVariableIcon
                                        className={classes.btnIcon + " " + classes.colorPrimary}
                                    />
                                }
                                name="Status"
                                label={`Status (${getVariableTypeById(
                                    status.paramObjectTypeId
                                )})`}
                                value={status.paramValue}
                                options={getOptionsForVariable(status)}
                                onChange={handleChange}
                                error={
                                    vaildateParamValue(status.paramValue.toString())
                                        .errorStatus
                                }
                                helperText={
                                    vaildateParamValue(status.paramValue.toString()).msg
                                }
                            />
                        </Grid>
                    </Grid>
                )
                    :

                    selectedTab === "error" ? (
                        <ErrorsWindow />
                    ) : null}
            </div>
        </>
    );
};

export default ExecuteProcedureWindow;

