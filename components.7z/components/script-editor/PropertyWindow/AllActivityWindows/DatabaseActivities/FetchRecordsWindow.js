import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email, ExpandMore, Remove } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress, Avatar, IconButton } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
    mapFieldObjWithValueByName,
    logsState,
    getOptionsForVariable,
    getVariableTypeById,
    getDefaultOfDefinedVariableByName,
    getAllVariables,
    handleParseValuesForDatabaseColumnValues,
    getAllOptionsForWhereClause
} from "./../Common/CommonMethods";

import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { AddIcon, AddVariableIcon, CloseIcon, DeleteIcon } from "../../../../../utils/AllImages";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import { createInstance, generateUniqueId } from "../../../../../utils/common";
import { DATABASE, DATABASE_CONNECT, GET_COLUMNS, GET_DATABASE_TYPE, GET_TABLES } from "../../../../../config";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";
import MenuPopper from "../../../../../utils/MenuPopper";
import MultiSelectWithSearch from "../../../../../utils/MultiSelectWithSearchInput";
import _ from "lodash";
import HelpLabel from "../Common/HelpLabel";


const FetchRecordWindow = (props) => {
    const classes = useStyles();

    const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
        props;

    const { params } = selectedActivity;
    //const allOptions = getAllOptionsForWhereClause();
    const allVariables = getAllVariables();

    const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
    const databaseName = useSelector((state) => state.editorHomepage.databaseName);

    const dispatch = useDispatch();
    const { setValue: setNotification } = useContext(NotificationContext);
    const axiosInstance = createInstance()

    const [activityName, setActivityName] = useState(
        (selectedActivity && selectedActivity.displayName) || ""
    );

    const [tableOptions, setTableOptions] = useState([])
    const [columnOptions, setColumnOptions] = useState([])
    const [isFetchingTables, setIsFetchingTables] = useState(
        false
    );

    const [arrOfJoinFieldVals, setArrOfJoinFieldVals] = useState([
        { tableName: "", columnNames: [] }
    ])

    const radioButtonsArray = [
        { label: "Single Table", value: 1 },
        { label: "Multiple Tables", value: 2 },
    ];

    const [tableName, setTableName] = useState(
        mapFieldObjWithValueByName(params, "TableName", "")
    );
    const [invisibleInLogs, setInvisibleInLogs] = useState(
        logsState(params, false)
    );


    const [fieldValues, setFieldValues] = useState(
        mapFieldObjWithValueByName(params, "FieldValues", "")
    );

    const [fetchFromTableMode, setFetchFromTableMode] = useState(
        mapFieldObjWithValueByName(params, "FetchFromTableMode", 1)
    );

    const [selectedFetchFromTableType, setSelectedFetchFromTableType] = useState(1);

    const [fieldValuesForJoin, setFieldValuesForJoin] = useState(
        mapFieldObjWithValueByName(params, "MultipleTableValues", "")
    );
    const [records, setRecords] = useState(
        mapFieldObjWithValueByName(params, "Records", "")
    );

    const [joinCondition, setJoinCondtion] = useState(
        mapFieldObjWithValueByName(params, "JoinCondition", "")
    );
    const [wherecondition, setWhereCondition] = useState(
        mapFieldObjWithValueByName(params, "WhereCondition", [])
    );
    const [orderByCondition, setOrderByCondtion] = useState(
        mapFieldObjWithValueByName(params, "OrderByCondition", [])
    );
    const [limitCondition, setLimitCondtion] = useState(
        mapFieldObjWithValueByName(params, "LimitCondition", "")
    );
    const [offsetCondition, setOffsetCondtion] = useState(
        mapFieldObjWithValueByName(params, "OffsetCondition", "")
    );
    const [havingCondition, setHavingCondition] = useState(
        mapFieldObjWithValueByName(params, "HavingCondition", [])
    );
    const [groupByCondition, setGroupByCondtion] = useState(
        mapFieldObjWithValueByName(params, "GroupByCondition", [])
    );


    const [whereConditionArray, setWhereConditionArray] = useState(
        []
    );
    const [orderByConditionArray, setOrderByConditionArray] = useState(
        []
    );
    const [groupByConditionArrayForParam2, setGroupByConditionArrayForParam2] = useState(
        [
            {
                key: "",
                type: "",
                dataType: "",
                value: ""
            },
        ]
    );
    const [havingConditionArray, setHavingConditionArray] = useState(
        []
    );
    const [groupByConditionArray, setGroupByConditionArray] = useState(
        []
    );
    const [joinConditionArray, setJoinConditionArray] = useState(
        [
            {
                conditionID: 1,
                conditionType: 1,
                param1: "",
                paramType1: "V",
                d: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
                onJoinTableName: "",
                rpaDataType: ''
            }
        ]
    );
    const [whereCheckbox, setWhereCheckbox] = useState(
        false
    );
    const [limitCheckbox, setLimitCheckbox] = useState(
        false
    );
    const [offsetCheckbox, setOffsetCheckbox] = useState(
        false
    );
    const [orderByCheckbox, setOrderByCheckbox] = useState(
        false
    );
    const [groupByCheckbox, setGroupByCheckbox] = useState(
        false
    );
    const [havingCheckbox, setHavingCheckbox] = useState(
        false
    );
    const [selectedColumns, setSelectedColumns] = useState([]);
    const [tableColumnsOption, setTableColumnsOption] = useState({});




    useEffect(() => {
        setActivityName(selectedActivity ? selectedActivity.displayName : "");
        setInvisibleInLogs(logsState(params, false));
        setRecords(mapFieldObjWithValueByName(params, "Records", ""));
        setHavingCondition(
            mapFieldObjWithValueByName(params, "HavingCondition", [])
        )
        setFetchFromTableMode(
            mapFieldObjWithValueByName(params, "FetchFromTableMode", 1)
        )
        setGroupByCondtion(
            mapFieldObjWithValueByName(params, "GroupByCondition", [])
        )
        const limitCond = mapFieldObjWithValueByName(params, "LimitCondition", "")
        if (limitCond.paramValue) {
            setLimitCheckbox(true)
        }
        const offsetCond = mapFieldObjWithValueByName(params, "OffsetCondition", "")
        if (offsetCond.paramValue) {
            setOffsetCheckbox(true)
        }
        setLimitCondtion(limitCond);
        setOffsetCondtion(offsetCond);


        setTableName(
            mapFieldObjWithValueByName(params, "TableName", "")
        )

        const fieldValuesObj = mapFieldObjWithValueByName(params, "FieldValues", "")

        if (fieldValuesObj.paramValue) {
            try {
                const arrOfFieldVals = JSON.parse(fieldValuesObj.paramValue);
                if (Array.isArray(arrOfFieldVals)) {
                    setSelectedColumns(arrOfFieldVals)
                }
                else {
                    setSelectedColumns([])
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            setSelectedColumns([])
        }
        setFieldValues(fieldValuesObj)
        const joinFieldValuesObj = mapFieldObjWithValueByName(params, "MultipleTableValues", "")

        if (joinFieldValuesObj.paramValue) {
            try {
                const arrOfFieldVals = JSON.parse(joinFieldValuesObj.paramValue);
                if (Array.isArray(arrOfFieldVals)) {
                    setArrOfJoinFieldVals(arrOfFieldVals)
                    if (arrOfFieldVals.length > 0) {

                        if (databaseName) {
                            arrOfFieldVals.forEach(item => {
                                getColumnsOfSelectedTable(item.tableName)
                            })
                        }
                        /* try {
                             const fetchPromises = items.map(item => 
                               axios.get(`https://api.example.com/data?item=${item}`)
                                 .then(response => ({ item, result: response.data }))
                                 .catch(error => ({ item, error }))
                             );
                     
                             const results = await Promise.all(fetchPromises);
                             const dataObject = results.reduce((acc, { item, result, error }) => {
                               if (error) {
                                 console.error(`Error fetching data for ${item}:`, error);
                               } else {
                                 acc[item] = result;
                               }
                               return acc;
                             }, {});
                     
                             setData(dataObject);
                           } catch (error) {
                             console.error('Error during fetching:', error);
                             setError(error);
                           }*/
                    }
                }
                else {
                    setArrOfJoinFieldVals([
                        {
                            tableName: "",
                            columnNames: [],
                        },
                    ])
                }
            } catch (error) {
                console.log(error);
            }
        } else {
            setArrOfJoinFieldVals([
                {
                    tableName: "",
                    columnNames: [],
                },
            ])
        }
        setFieldValuesForJoin(joinFieldValuesObj)

        const joinConditions = mapFieldObjWithValueByName(params, "JoinCondition", []);
        if (joinConditions.paramValue) {
            try {
                const arrOfJoinConditions = JSON.parse(joinConditions.paramValue);
                if (Array.isArray(arrOfJoinConditions) && arrOfJoinConditions.length > 0) {
                    setJoinConditionArray(arrOfJoinConditions)
                }
                else {
                    setJoinConditionArray([
                        {
                            conditionID: 1,
                            conditionType: 1,
                            param1: "",
                            paramType1: "V",
                            d: "",
                            paramType2: "C",
                            // param2: "",
                            param2: null,
                            dataType: null,
                            expression: 0,
                        },
                    ])
                }
            } catch (error) {
                console.log(error);
                setJoinConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 1,
                        param1: "",
                        paramType1: "V",
                        d: "",
                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },
                ])
            }
        } else {
            setJoinConditionArray([
                {
                    conditionID: 1,
                    conditionType: 1,
                    param1: "",
                    paramType1: "V",
                    d: "",
                    paramType2: "C",
                    // param2: "",
                    param2: null,
                    dataType: null,
                    expression: 0,
                },
            ])
        }

        setJoinCondtion(joinConditions)
        const whereConditions = mapFieldObjWithValueByName(params, "WhereCondition", [])

        if (whereConditions.paramValue) {
            try {
                const arrOfConditions = JSON.parse(whereConditions.paramValue);
                if (Array.isArray(arrOfConditions)) {
                    setWhereConditionArray(arrOfConditions);
                    if (arrOfConditions.length > 0) {
                        setWhereCheckbox(true)
                    }
                }
                else {
                    setWhereConditionArray([
                        {
                            conditionID: 1,
                            conditionType: 1,
                            param1: "",
                            paramType1: "V",
                            d: "",
                            paramType2: "C",
                            // param2: "",
                            param2: null,
                            dataType: null,
                            expression: 0,
                        },
                    ])
                }
            } catch (error) {
                console.log(error);
                setWhereConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 1,
                        param1: "",
                        paramType1: "V",
                        d: "",
                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },
                ])
            }
        } else {
            setWhereConditionArray([
                {
                    conditionID: 1,
                    conditionType: 1,
                    param1: "",
                    paramType1: "V",
                    d: "",
                    paramType2: "C",
                    // param2: "",
                    param2: null,
                    dataType: null,
                    expression: 0,
                },
            ])
        }
        setWhereCondition(whereConditions)

        const groupByConditions = mapFieldObjWithValueByName(params, "GroupByCondition", [])
        if (groupByConditions.paramValue) {
            try {
                const arrOfConditions = JSON.parse(groupByConditions.paramValue);
                if (Array.isArray(arrOfConditions)) {
                    setGroupByConditionArray(arrOfConditions);
                    if (arrOfConditions.length > 0) {
                        setGroupByCheckbox(true)
                    }
                    const conditionObj = arrOfConditions[0];
                    //  const param1Values = conditionObj?.param1 || [];
                    const param2Values = conditionObj?.param2 || [];
                    //  setSelectedColumnsForGroupBy([...param1Values])
                    const appropriateArrayStructureForParam2 = param2Values.map(item => ({ key: item.columnName, value: item.aggregateFunction, dataType: item.dataType, type: item.columnType }));
                    if (appropriateArrayStructureForParam2.length) {
                        setGroupByConditionArrayForParam2([...appropriateArrayStructureForParam2])
                    } else {
                        setGroupByConditionArrayForParam2([
                            {
                                key: "",
                                type: "",
                                dataType: "",
                                value: ""
                            },
                        ])
                    }


                } else {
                    setGroupByConditionArray([
                        {
                            conditionID: 1,
                            conditionType: 2,
                            param1: [],
                            paramType1: "V",
                            d: "",
                            paramType2: "C",
                            // param2: "",
                            param2: null,
                            dataType: null,
                            expression: 0,
                        },
                    ])
                }
            } catch (error) {
                console.log(error);
                setGroupByConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 2,
                        param1: [],
                        paramType1: "V",
                        d: "",
                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },
                ])
            }
        } else {
            setGroupByConditionArray([
                {
                    conditionID: 1,
                    conditionType: 2,
                    param1: [],
                    paramType1: "V",
                    d: "",
                    paramType2: "C",
                    // param2: "",
                    param2: null,
                    dataType: null,
                    expression: 0,
                },
            ])
        }
        setGroupByCondtion(groupByConditions)


        const orderByConditions = mapFieldObjWithValueByName(params, "OrderByCondition", [])
        if (orderByConditions.paramValue) {
            try {
                const arrOfConditions = JSON.parse(orderByConditions.paramValue);
                if (Array.isArray(arrOfConditions)) {
                    setOrderByConditionArray(arrOfConditions);
                    if (arrOfConditions.length > 0) {
                        setOrderByCheckbox(true)
                    }
                } else {
                    setOrderByConditionArray([
                        {
                            conditionID: 1,
                            conditionType: 2,
                            param1: "",
                            paramType1: "V",
                            operator: "",
                            paramType2: "C",
                            // param2: "",
                            param2: null,
                            dataType: null,
                            expression: 0,
                        },
                    ])
                }
            } catch (error) {
                console.log(error);
                setOrderByConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 2,
                        param1: "",
                        paramType1: "V",
                        operator: "",

                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },
                ])
            }
        } else {
            setOrderByConditionArray([
                {
                    conditionID: 1,
                    conditionType: 2,
                    param1: "",
                    paramType1: "V",
                    operator: "",

                    paramType2: "C",
                    // param2: "",
                    param2: null,
                    dataType: null,
                    expression: 0,
                },
            ])
        }
        setOrderByCondtion(orderByConditions)

        const havingConditions = mapFieldObjWithValueByName(params, "HavingCondition", [])

        if (havingConditions.paramValue) {
            try {
                const arrOfConditions = JSON.parse(havingConditions.paramValue);
                if (Array.isArray(arrOfConditions)) {
                    setHavingConditionArray(arrOfConditions);
                    if (arrOfConditions.length > 0) {
                        setHavingCheckbox(true)
                    }
                } else {
                    setHavingConditionArray([
                        {
                            conditionID: 1,
                            conditionType: 7,
                            param1: "",
                            paramType1: "V",
                            d: "",
                            paramType2: "C",
                            // param2: "",
                            param2: null,
                            dataType: null,
                            expression: 0,
                        },
                    ])
                }
            } catch (error) {

                setHavingConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 7,
                        param1: "",
                        paramType1: "V",
                        d: "",
                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },
                ])
            }
        } else {
            setHavingConditionArray([
                {
                    conditionID: 1,
                    conditionType: 7,
                    param1: "",
                    paramType1: "V",
                    d: "",
                    paramType2: "C",
                    // param2: "",
                    param2: null,
                    dataType: null,
                    expression: 0,
                },
            ])
        }
        setHavingCondition(havingConditions)

        dispatch(setErrorType("Throw"));
        dispatch(setSelectedTab("input"));
    }, [JSON.stringify(selectedActivity)]);

    useEffect(() => {
        if (fetchFromTableMode.paramValue) {
            setSelectedFetchFromTableType(fetchFromTableMode.paramValue);
        }
    }, [fetchFromTableMode]);
    useEffect(() => {
        if (databaseName) {
            if (fieldValuesForJoin?.length > 0) {
                fieldValuesForJoin.forEach(item => {
                    getColumnsOfSelectedTable(item.tableName)
                })
            }
        }
    }, [databaseName])
    useEffect(() => {
        setWhereCondition({ ...wherecondition, paramValue: JSON.stringify(whereConditionArray) })
    }, [whereConditionArray])

    useEffect(() => {
        setOrderByCondtion({ ...orderByCondition, paramValue: JSON.stringify(orderByConditionArray) })
    }, [orderByConditionArray])
    useEffect(() => {
        setGroupByCondtion({ ...groupByCondition, paramValue: JSON.stringify(groupByConditionArray) })
    }, [groupByConditionArray])
    useEffect(() => {
        setHavingCondition({ ...havingCondition, paramValue: JSON.stringify(havingConditionArray) })
    }, [havingConditionArray])
    useEffect(() => {
        setFieldValuesForJoin({ ...fieldValuesForJoin, paramValue: JSON.stringify(arrOfJoinFieldVals) })
    }, [arrOfJoinFieldVals])
    useEffect(() => {
        setJoinCondtion({ ...joinCondition, paramValue: JSON.stringify(joinConditionArray) })
    }, [joinConditionArray])
    const getTables = async () => {
        if (databaseName) {
            setIsFetchingTables(true)
            try {
                const res = await axiosInstance.get(`${DATABASE}${GET_TABLES}/${databaseName}`);
                if (res.status === 200) {
                    setIsFetchingTables(false)

                    const arrOfOptionsInRes = res?.data?.data;
                    if (arrOfOptionsInRes) {
                        const arrayOfOptions = arrOfOptionsInRes.map(opt => ({ name: opt, value: opt }))
                        setTableOptions(arrayOfOptions)
                    }
                }
            } catch (error) {
                setIsFetchingTables(false)

                console.log(error)
            }
        } else {
            setNotification({
                isOpen: true,
                title: "Update Records",
                message: "Kindly first connect with Database Server.",
                notificationType: "ERROR",
            });
        }
    }

    const getColumnsOfTable = async () => {
        try {
            const res = await axiosInstance.get(`${DATABASE}${GET_COLUMNS}/${databaseName}/${tableName.paramValue}`);

            const arrOfOptionsInRes = res?.data?.data && res?.data?.data[0]?.columnList;
            if (arrOfOptionsInRes) {
                const arrayOfOptions = arrOfOptionsInRes.map(opt => ({
                    name: opt.columnName, value: opt.columnName, type: opt.columnType, dataType: opt.dataType,
                    rpaDataType: opt.rpaDataType, description: opt.columnType, isPrimaryKey: opt.isPrimaryKey,
                    dataTypeLength: opt.dataTypeLength,
                    tableName: tableName.paramValue,
                    subDescription: tableName.paramValue
                }))
                setColumnOptions(arrayOfOptions)

                setTableColumnsOption((prev) => ({ ...prev, [tableName.paramValue]: [...arrayOfOptions] }))
            }


        } catch (error) {
            console.log(error)
        }
    }


    const getColumnsOfSelectedTable = async (tableName) => {
        if (tableName && !tableColumnsOption[tableName]) {
            try {
                const res = await axiosInstance.get(`${DATABASE}${GET_COLUMNS}/${databaseName}/${tableName}`);

                const arrOfOptionsInRes = res?.data?.data && res?.data?.data[0]?.columnList;
                if (arrOfOptionsInRes) {
                    const arrayOfOptions = arrOfOptionsInRes.map(opt => ({
                        name: opt.columnName, value: opt.columnName, type: opt.columnType, dataType: opt.dataType,
                        rpaDataType: opt.rpaDataType, description: opt.columnType, isPrimaryKey: opt.isPrimaryKey,
                        tableName,
                        subDescription: tableName
                    }))
                    setTableColumnsOption((prev) => ({ ...prev, [tableName]: arrayOfOptions }))
                }

                return res

            } catch (error) {
                console.log(error)
            }
        }
        return;
    }

    useEffect(() => {

        if (selectedColumns.length) {
            setFieldValues({
                ...fieldValues,
                paramValue: JSON.stringify(selectedColumns),
            });
        }

    }, [selectedColumns]);
    useEffect(() => {
        if (tableName?.paramValue && databaseName) {
            getColumnsOfTable()
        }
    }, [tableName, databaseName])


    const handleChange = (e, index) => {

        const { name, value, checked } = e.target;
        switch (name) {
            case "ActivityName":
                setActivityName(value);
                updateDisplayNameSelAct(value);
                break;
            case "MakeLogsPrivate":
                setInvisibleInLogs({
                    ...invisibleInLogs,
                    paramValue: !invisibleInLogs.paramValue,
                });
                break;
            case "FetchFromTableType":
                setSelectedFetchFromTableType(value);
                setFetchFromTableMode({ ...fetchFromTableMode, paramValue: value });
                setArrOfJoinFieldVals([{ tableName: "", columnNames: [] }]);
                setSelectedColumns([])
                break;
            case "Records":
                setRecords((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "LimitCondition":
                setLimitCondtion((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "OffsetCondition":
                setOffsetCondtion((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "HavingCondition":
                setHavingCondition((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "GroupByCondition":
                setGroupByCondtion((prevState) => ({ ...prevState, paramValue: value }));
                break;

            case "TableName":
                setTableName((prevState) => ({ ...prevState, paramValue: value }));
                setSelectedColumns([])

                break;
            case "FieldValues":
                setFieldValues((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "MultipleTableValues":
                setFieldValuesForJoin((prevState) => ({ ...prevState, paramValue: value }));
                break;
            case "Where":
                setWhereCheckbox(checked);
                if (!checked) {
                    setWhereConditionArray(
                        [
                            {
                                conditionID: 1,
                                conditionType: 1,
                                param1: "",
                                paramType1: "V",
                                operator: '',
                                paramType2: "C",
                                // param2: "",
                                param2: null,
                                dataType: null,
                                expression: 0,
                            },

                        ]
                    )
                }
                break;
            case "Limit":
                setLimitCheckbox(checked);
                if (!checked) {

                    setLimitCondtion((prevState) => ({ ...prevState, paramValue: "" }));
                    setOffsetCheckbox(false)
                    setOffsetCondtion((prevState) => ({ ...prevState, paramValue: "" }));

                }
                break;
            case "Offset":
                setOffsetCheckbox(checked);
                if (!checked) {
                    setOffsetCondtion((prevState) => ({ ...prevState, paramValue: "" }));
                }
                break;
            case "OrderBy":
                setOrderByCheckbox(checked);
                setOrderByConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 2,
                        param1: "",
                        paramType1: "V",
                        operator: "",

                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },

                ])
                break;
            case "GroupBy":
                setGroupByCheckbox(checked);
                setGroupByConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 3,
                        param1: "",
                        paramType1: "V",
                        d: "",
                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },

                ])
                if (!checked) {
                    setHavingCheckbox(false);
                    setHavingConditionArray([
                        {
                            conditionID: 1,
                            conditionType: 7,
                            param1: "",
                            paramType1: "V",
                            d: "",
                            paramType2: "C",
                            // param2: "",
                            param2: null,
                            dataType: null,
                            expression: 0,
                        },

                    ])
                }
                break;
            case "Having":
                setHavingCheckbox(checked);
                setHavingConditionArray([
                    {
                        conditionID: 1,
                        conditionType: 7,
                        param1: "",
                        paramType1: "V",
                        d: "",
                        paramType2: "C",
                        // param2: "",
                        param2: null,
                        dataType: null,
                        expression: 0,
                    },

                ])
                break;
            default:
                break;
        }

    };

    const handleChangeWhereConditionVals = (e, index) => {
        const { name, value } = e.target;
        if (typeof index === 'number') {
            const item = whereConditionArray[index];

            switch (name) {
                case "Operand1":
                    item.param1 = value;
                    item.rpaDataType = getColumnObj(value)?.rpaDataType || "";
                    item.dataType = getColumnObj(value)?.dataType || null;
                    item.dataTypeLength = getColumnObj(value)?.dataTypeLength || null;
                    item.rpaDataType = getColumnObj(value)?.rpaDataType || null;
                    item.tableName = getColumnObj(value)?.tableName || ""

                    break;
                case "Operand2":
                    item.param2 = value;
                    break;
                case "OperatorType":
                    item.operator = value;
                    //in these operators case we dont need value of second param
                    if (["9", "10", "11"].includes(value)) {
                        item.param2 = "";
                    }
                    break;
                default:
                    break;
            }

            const newArr = [...whereConditionArray];
            newArr.splice(index, 1, item);
            setWhereConditionArray(newArr);
        }
    }

    const handleChangeOrderByConditionVals = (e, index) => {
        const { name, value } = e.target;
        if (typeof index === 'number') {
            const item = orderByConditionArray[index];

            switch (name) {
                case "Operand1":
                    item.param1 = value;
                    item.tableName = getColumnObj(value) ? getColumnObj(value).tableName : ""
                    break;
                case "Operand2":
                    item.param2 = value;
                    break;

                default:
                    break;
            }
            const newArr = [...orderByConditionArray];
            newArr.splice(index, 1, item);
            setOrderByConditionArray(newArr);
        }
    }
    useEffect(() => {
        updateParams();
    }, [
        invisibleInLogs,

        records,
        fieldValues,
        fieldValuesForJoin,
        tableName,
        wherecondition,
        limitCondition,
        orderByCondition,
        havingCondition,
        groupByCondition,
        whereCheckbox,
        limitCheckbox,
        orderByCheckbox,
        offsetCheckbox,
        fetchFromTableMode,
        joinCondition,
        offsetCondition

    ]);

    const updateParams = () => {
        let allParams = [
            invisibleInLogs,

            records,
            tableName,
            fetchFromTableMode
            // havingCondition,
        ];


        const stringyfiedArr = JSON.stringify([])
        if (whereCheckbox) {
            allParams = [...allParams, wherecondition]
        } else {
            allParams = [...allParams, { ...wherecondition, paramValue: stringyfiedArr }]
        }


        if (orderByCheckbox) {
            allParams = [...allParams, orderByCondition]
        } else {
            allParams = [...allParams, { ...orderByCondition, paramValue: stringyfiedArr }]
        }


        if (limitCheckbox) {
            allParams = [...allParams, limitCondition]
        } else {
            allParams = [...allParams, { ...limitCondition, paramValue: "" }]
        }
        if (offsetCheckbox && limitCheckbox) {
            allParams = [...allParams, offsetCondition]
        } else {
            allParams = [...allParams, { ...offsetCondition, paramValue: "" }]
        }
        if (groupByCheckbox) {
            allParams = [...allParams, groupByCondition]
        } else {
            allParams = [...allParams, { ...groupByCondition, paramValue: stringyfiedArr }]
        }
        if (groupByCheckbox && havingCheckbox) {
            allParams = [...allParams, havingCondition]
        } else {
            allParams = [...allParams, { ...havingCondition, paramValue: stringyfiedArr }]
        }

        if (fetchFromTableMode.paramValue == 2) {
            allParams = [...allParams, fieldValuesForJoin]
            allParams = [...allParams, { ...fieldValues, paramValue: stringyfiedArr }]
            allParams = [...allParams, joinCondition]

        } else if (fetchFromTableMode.paramValue == 1) {
            allParams = [...allParams, fieldValues]
            allParams = [...allParams, { ...fieldValuesForJoin, paramValue: stringyfiedArr }]
            allParams = [...allParams, { ...joinCondition, paramValue: stringyfiedArr }]

        }

        addParamsToSelAct(allParams);
    };

    const changeParamTypeToVorCForWhere = (paramName, changeToValue, index) => {
        switch (paramName) {
            case "Operand2":
                const item = whereConditionArray[index];
                item.paramType2 = changeToValue;
                item.param2 = "";
                const newArr = [...whereConditionArray];
                newArr.splice(index, 1, item);
                setWhereConditionArray(newArr);
                break;

            default:
                break;
        }
    };



    const changeParamTypeToVorC = (paramName, changeToValue) => {
        switch (paramName) {
            case "LimitCondition":
                setLimitCondtion({ ...limitCondition, paramType: changeToValue });
                break;
            case "OffsetCondition":
                setOffsetCondtion({ ...offsetCondition, paramType: changeToValue });
                break;

            default:
                break;
        }
    };
    const removeWhereCondition = () => {
        const newConditionArr = [...whereConditionArray];
        if (newConditionArr.length > 1) {
            let last = newConditionArr[whereConditionArray.length - 2];
            last.expression = 0;
            newConditionArr.splice(newConditionArr.length - 2, 2);

            setWhereConditionArray([...newConditionArr, last]);
        } else if (newConditionArr.length === 1) {
            setWhereConditionArray([]);
        }
    };

    const addNewWhereCondition = () => {
        const newConditionArr = [...whereConditionArray];
        let last = whereConditionArray[whereConditionArray.length - 1];
        if (last) {
            last.expression = 1;
            newConditionArr.splice(newConditionArr.length - 1, 1);

            const newCond = {
                conditionID: whereConditionArray.length + 1,
                conditionType: 0,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
            };
            setWhereConditionArray([...newConditionArr, last, newCond]);
        } else {
            const newCond = {
                conditionID: whereConditionArray.length + 1,
                conditionType: 1,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
            };
            setWhereConditionArray([newCond]);
        }
    };

    const removeHavingCondition = () => {
        const newConditionArr = [...havingConditionArray];
        if (newConditionArr.length > 1) {
            let last = newConditionArr[havingConditionArray.length - 2];
            last.expression = 0;
            newConditionArr.splice(newConditionArr.length - 2, 2);

            setHavingConditionArray([...newConditionArr, last]);
        } else if (newConditionArr.length === 1) {
            setHavingConditionArray([]);
        }
    };

    const addNewHavingCondition = () => {
        const newConditionArr = [...havingConditionArray];
        let last = havingConditionArray[havingConditionArray.length - 1];
        if (last) {
            last.expression = 1;
            newConditionArr.splice(newConditionArr.length - 1, 1);

            const newCond = {
                conditionID: havingConditionArray.length + 1,
                conditionType: 0,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
            };
            setHavingConditionArray([...newConditionArr, last, newCond]);
        } else {
            const newCond = {
                conditionID: havingConditionArray.length + 1,
                conditionType: 7,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
            };
            setHavingConditionArray([newCond]);
        }
    };

    const getColumnObj = (value) => {
        return getAllColumnOptionsForConditions(tableColumnsOption).find(item => item.name === value)
    }
    const handleChangeHavingConditionVals = (e, index) => {
        const { name, value } = e.target;
        if (typeof index === 'number') {
            let item = havingConditionArray[index];



            switch (name) {
                case "ColumnName":

                    item.param1 = {
                        ...item.param1, columnName: value,
                        columnType: getColumnObj(value) ? getColumnObj(value).type : "",
                        dataType: getColumnObj(value) ? getColumnObj(value).dataType : "",
                        dataTypeLength: getColumnObj(value)?.dataTypeLength || null,
                        rpaDataType: getColumnObj(value)?.rpaDataType || null

                    }
                    item.dataType = getColumnObj(value) ? getColumnObj(value).dataType : ""
                    item.dataTypeLength = getColumnObj(value)?.dataTypeLength || null;
                    item.rpaDataType = getColumnObj(value)?.rpaDataType || null;
                    item.tableName = getColumnObj(value) ? getColumnObj(value).tableName : ""
                    break;
                case "AggregateFunc":
                    item.param1 = { ...item.param1, aggregateFunction: value }
                    break;
                case "Operand2":
                    item.param2 = value;
                    break;
                case "OperatorType":
                    item.operator = value;
                    //in these operators case we dont need value of second param
                    if (["9", "10", "11"].includes(value)) {
                        item.param2 = "";
                    }
                    break;
                default:
                    break;
            }

            const newArr = _.cloneDeep(havingConditionArray);
            newArr.splice(index, 1, item);
            setHavingConditionArray(newArr);
        }
    }
    /* const handleCondHaving = (e, item, selCond) => {
         const itemConIndex = havingConditionArray.findIndex(
             (con) => con.conditionID === selCond.conditionID
         );
 
         const itemCon = havingConditionArray[itemConIndex - 1];
         if (itemCon) {
             itemCon.expression = item === "OR" ? 2 : 1;
             const newArr = [...havingConditionArray];
             newArr.splice(itemConIndex - 1, 1, itemCon);
             setHavingConditionArray(newArr);
         }
     };*/
    const handleCondHaving = (e, index) => {

        const { value } = e.target;
        const itemCon = havingConditionArray[index - 1];
        if (itemCon) {
            itemCon.expression = value === "OR" ? 2 : 1;
            const newArr = [...havingConditionArray];
            newArr.splice(index - 1, 1, itemCon);
            setHavingConditionArray(newArr);
        }
    };


    const changeParamTypeToVorCForHaving = (paramName, changeToValue, index) => {
        switch (paramName) {
            case "Operand2":
                const item = havingConditionArray[index];
                item.paramType2 = changeToValue;
                item.param2 = "";
                const newArr = [...havingConditionArray];
                newArr.splice(index, 1, item);
                setHavingConditionArray(newArr);
                break;

            default:
                break;
        }
    };

    const removeOrderByCondition = () => {
        const newConditionArr = [...orderByConditionArray];
        if (newConditionArr.length > 1) {
            let last = newConditionArr[orderByConditionArray.length - 2];
            last.expression = 0;
            newConditionArr.splice(newConditionArr.length - 2, 2);

            setOrderByConditionArray([...newConditionArr, last]);
        } else if (newConditionArr.length === 1) {
            setOrderByConditionArray([
                {
                    conditionID: 1,
                    conditionType: 2,
                    param1: "",
                    paramType1: "V",
                    operator: "",
                    paramType2: "C",
                    param2: "",
                    dataType: null,
                    expression: 0,
                }
            ]);
        }
    };

    const addNewOrderByCondition = () => {
        const newConditionArr = [...orderByConditionArray];
        let last = orderByConditionArray[orderByConditionArray.length - 1];
        if (last) {
            last.expression = 1;
            newConditionArr.splice(newConditionArr.length - 1, 1);

            const newCond = {
                conditionID: orderByConditionArray.length + 1,
                conditionType: 0,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
            };
            setOrderByConditionArray([...newConditionArr, last, newCond]);
        } else {
            const newCond = {
                conditionID: orderByConditionArray.length + 1,
                conditionType: 2,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
            };
            setOrderByConditionArray([newCond]);
        }
    };



    const handleGroupByParam2ValsValueChange = (e, index) => {

        const newArr = handleArrObjsValuesChange(e, index, groupByConditionArrayForParam2);
        setGroupByConditionArrayForParam2(newArr);
    };

    const handleArrObjsValuesChange = (e, index, arr) => {
        const { name, value } = e.target;

        const newArr = [...arr];
        const obj = arr[index];
        if (name === "Key") {
            obj.key = value;
        } else if (name === "Value") {
            obj.value = value;
        }
        newArr.splice(index, 1, obj);
        return newArr;
    };
    const handleArrObjsValuesDelete = (index, arr) => {
        const newArr = [...arr];
        newArr.splice(index, 1);
        return newArr;
    };

    const addGroupByParam2Value = () => {
        const newObj = { key: "", value: "", paramType: "C", type: "", dataType: "" };
        const newArr = [...groupByConditionArrayForParam2, newObj];
        setGroupByConditionArrayForParam2(newArr);
    };

    const handleGroupByParam2ValueDelete = (index) => {
        const newArr = handleArrObjsValuesDelete(index, groupByConditionArrayForParam2);
        if (newArr.length) {
            setGroupByConditionArrayForParam2(newArr);
        } else {
            setGroupByConditionArrayForParam2([
                {
                    key: "",
                    type: "",
                    dataType: "",
                    value: ""
                },
            ])
        }
    };

    useEffect(() => {
        if (groupByConditionArrayForParam2.length > 0 && groupByConditionArrayForParam2.every(item => item.key && item.value)) {
            const getColumnObj = (param) => {
                return getAllColumnOptionsForConditions(tableColumnsOption).find(item => item.name === param.key)
            }
            const newParamObjArr = groupByConditionArrayForParam2.map((param) => ({
                columnName: param.key,
                columnType: getColumnObj(param) ? getColumnObj(param).type : "",
                dataType: getColumnObj(param) ? getColumnObj(param).dataType : "",
                aggregateFunction: param.value,
                tableName: getColumnObj(param) ? getColumnObj(param).tableName : ""
            }));

            if (newParamObjArr) {
                const mainObj = groupByConditionArray[0];
                mainObj.param2 = [...newParamObjArr];
                setGroupByConditionArray([{ ...mainObj }]);
            }
        }
    }, [groupByConditionArrayForParam2]);



    const handleCondWhere = (e, index) => {

        const { value } = e.target;
        const itemCon = whereConditionArray[index - 1];
        if (itemCon) {
            itemCon.expression = value === "OR" ? 2 : 1;
            const newArr = [...whereConditionArray];
            newArr.splice(index - 1, 1, itemCon);
            setWhereConditionArray(newArr);
        }
    };

    const getOperatorsOptions = (cond) => {
        const param1 = cond.param1;

        if (param1) {
            const varType = cond?.rpaDataType || 1;
            switch (varType) {
                case 1:
                    return allOperators.filter((opr) =>
                        availableOperators["textValue"].includes(opr.value)
                    );
                case 2:
                case 8:
                    return allOperators.filter((opr) =>
                        availableOperators["integerValue"].includes(opr.value)
                    );
                case 3:
                    return allOperators.filter((opr) =>
                        availableOperators["booleanValue"].includes(opr.value)
                    );
                case 4:
                case 9:
                    return allOperators.filter((opr) =>
                        availableOperators["dateTime"].includes(opr.value)
                    );
            }
        }
    };

    const getOptionsForVar = (cond) => {
        const param1 = cond.param1;
        if (param1) {

            const varType = cond?.rpaDataType || 1;
            if (varType) {
                return allVariables
                    .filter((obj) => obj.variableObjType === varType)
                    .map((item) => {
                        return { name: item.variableName, value: item.variableName };
                    });
            } else {
                return [];
            }
        }
    };
    const getVarType = (cond) => {
        const param1 = cond?.param1;


        if (param1) {
            return cond?.rpaDataType || 1;
        }

    };
    const getFieldType = (cond) => {
        const param1 = cond.param1;
        let fieldType = "text";
        if (param1) {

            const varType = cond?.rpaDataType;

            switch (varType) {
                case 2:
                case 8:
                    fieldType = "number";
                    break;
                case 4:
                    fieldType = "date";
                    break;
                case 9:
                    fieldType = "datetime-local";
                    break;
                default:
                    break;
            }
        }
        return fieldType;
    };

    const setSelectedColumnFunc = (list) => {
        let newArr = [];
        list?.forEach((el) => {
            newArr.push(el.name);
        });
        setSelectedColumns(newArr);
    };


    const setSelectedColumnsForGroupByFunc = (list) => {
        let newArr = [];
        list?.forEach((el) => {
            const tableName = getAllColumnOptionsForConditions(tableColumnsOption).find(item => item.name === el.name)?.tableName || ""
            newArr.push({ columnName: el.name, tableName });
        });
        const item = { ...groupByConditionArray[0] }
        item.param1 = [...newArr]
        const newArrOfGroupByConditions = [item];
        setGroupByConditionArray(newArrOfGroupByConditions);
    };


    const addMultipleTableArrFieldsValue = () => {
        const newObj = { tableName: "", columnNames: [] };
        const newArr = [...arrOfJoinFieldVals, newObj];
        setArrOfJoinFieldVals(newArr);
    };

    const handleMultipleTableArrFieldsValueDelete = (index) => {
        const newArr = handleArrObjsValuesDelete(index, arrOfJoinFieldVals);
        if (newArr.length) {
            setArrOfJoinFieldVals(newArr);
        } else {
            setArrOfJoinFieldVals([
                {
                    tableName: "",
                    columnNames: [],
                },
            ])
        }
    };

    useEffect(() => {
        if (arrOfJoinFieldVals.length > 0 && arrOfJoinFieldVals.every(item => item.tableName && item.columnNames)) {

            setFieldValuesForJoin({ ...fieldValuesForJoin, paramValue: JSON.stringify(arrOfJoinFieldVals) })
        }
    }, [arrOfJoinFieldVals]);


    const handleMultipleTableArrFieldsValueChange = async (e, index) => {
        const tempArrOfJoinFieldVals = [...arrOfJoinFieldVals]
        const { name, value } = e.target;

        const res = await getColumnsOfSelectedTable(value)
        const item = _.cloneDeep(tempArrOfJoinFieldVals[index])
        item.tableName = value
        item.columnNames = []
        tempArrOfJoinFieldVals.splice(index, 1, item);
        setArrOfJoinFieldVals(_.cloneDeep(tempArrOfJoinFieldVals))

    };


    const setSelectedColumnForMultipleTableFunc = (list, index) => {
        const tempArrOfJoinFieldVals = [...arrOfJoinFieldVals]
        let newArr = [];
        list?.forEach((el) => {
            newArr.push(el.name);
        });
        const item = _.cloneDeep(tempArrOfJoinFieldVals[index])
        item.columnNames = [...newArr]
        tempArrOfJoinFieldVals.splice(index, 1, item);
        setArrOfJoinFieldVals(_.cloneDeep(tempArrOfJoinFieldVals))
    };

    const removeJoinCondition = () => {
        const newConditionArr = [...joinConditionArray];
        if (newConditionArr.length > 1) {
            let last = newConditionArr[joinConditionArray.length - 2];
            last.expression = 0;
            newConditionArr.splice(newConditionArr.length - 2, 2);

            setJoinConditionArray([...newConditionArr, last]);
        } else if (newConditionArr.length === 1) {
            setJoinConditionArray([{
                conditionID: 1,
                conditionType: 1,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
                onJoinTableName: "",
                rpaDataType: ''
            }
            ]);
        }
    };

    const addNewJoinCondition = () => {
        const newConditionArr = [...joinConditionArray];
        let last = joinConditionArray[joinConditionArray.length - 1];
        if (last) {
            last.expression = 1;
            newConditionArr.splice(newConditionArr.length - 1, 1);

            const newCond = {
                conditionID: joinConditionArray.length + 1,
                conditionType: 1,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
                rpaDataType: ''
            };
            setJoinConditionArray([...newConditionArr, last, newCond]);
        } else {
            const newCond = {
                conditionID: joinConditionArray.length + 1,
                conditionType: 1,
                param1: "",
                paramType1: "V",
                operator: "",
                paramType2: "C",
                param2: "",
                dataType: null,
                expression: 0,
                rpaDataType: ''
            };
            setJoinConditionArray([newCond]);
        }
    };


    const handleChangeJoinConditionVals = (e, index) => {
        const { name, value } = e.target;
        if (typeof index === 'number') {
            let item = joinConditionArray[index];



            switch (name) {
                case "Param1TableName":

                    item.param1 = {
                        ...item.param1, tableName: value, columnName: ""
                    }
                    getColumnsOfSelectedTable(value)
                    break;
                case "OnJoinTableName":
                    item.onJoinTableName = value
                    break;
                case "Param1ColumnName":
                    item.param1 = {
                        ...item.param1,
                        columnName: value,
                        columnType: getColumnObj() ? getColumnObj().type : "",
                        dataType: getColumnObj() ? getColumnObj().dataType : "",
                        rpaDataType: getColumnObj() ? getColumnObj().rpaDataType : "",

                    }
                    break;
                case "Param2TableName":

                    item.param2 = {
                        ...item.param2, tableName: value, columnName: ""
                    }
                    getColumnsOfSelectedTable(value)
                    break;
                case "Param2ColumnName":
                    item.param2 = {
                        ...item.param2,
                        columnName: value,
                        columnType: getColumnObj() ? getColumnObj().type : "",
                        dataType: getColumnObj() ? getColumnObj().dataType : "",
                        rpaDataType: getColumnObj() ? getColumnObj().rpaDataType : ""
                    }
                    break;

                default:
                    break;
            }

            const newArr = _.cloneDeep(joinConditionArray);
            newArr.splice(index, 1, item);
            setJoinConditionArray(newArr);
        }
    }

    const getJoinType = (joinName) => {
        switch (joinName) {
            case "Inner Join":
                return 1;
            case "Left Outer Join":
                return 2;
            case "Right Outer Join":
                return 3;
            case "Full Outer Join":
                return 4;
        }
    }
    const getJoinTypeName = (joinType) => {
        switch (joinType) {
            case 1:
                return "Inner Join";
            case 2:
                return "Left Outer Join";
            case 3:
                return "Right Outer Join";
            case 4:
                return "Full Outer Join";
        }
    }
    /* const handleCondJoin = (e, item, selCond) => {
         const itemConIndex = joinConditionArray.findIndex(
             (con) => con.conditionID === selCond.conditionID
         );
 
         const itemCon = joinConditionArray[itemConIndex];
         if (itemCon) {
             itemCon.conditionType = getJoinType(item);
             const newArr = [...joinConditionArray];
             newArr.splice(itemConIndex, 1, itemCon);
             setJoinConditionArray(newArr);
         }
     };*/
    const handleCondJoin = (e, index) => {
        const { value } = e.target;

        const itemCon = joinConditionArray[index];
        if (itemCon) {
            itemCon.conditionType = getJoinType(value);
            const newArr = [...joinConditionArray];
            newArr.splice(index, 1, itemCon);
            setJoinConditionArray(newArr);
        }
    };


    const getAllTableOptionsForConditions = (includeFirstTableName) => {
        console.log(arrOfJoinFieldVals)
        if (includeFirstTableName && arrOfJoinFieldVals.findIndex(item => item.tableName === tableName.paramValue) == -1) {
            return [...arrOfJoinFieldVals.map(item => ({ name: item.tableName, value: item.tableName })), { name: tableName.paramValue, value: tableName.paramValue }]

        }
        return [...arrOfJoinFieldVals.map(item => ({ name: item.tableName, value: item.tableName }))]


    }
    const getAllColumnOptionsForConditions = (tableColumnsOption) => {
        let allTables = arrOfJoinFieldVals.filter(item => item.tableName).map(item => item.tableName)
        if (allTables.length === 0 && tableName.paramValue && columnOptions.length > 0) {
            return columnOptions
        } else {
            if (!allTables.includes(tableName.paramValue)) {
                //including the primary table as well
                allTables = [...allTables, tableName.paramValue]
            }
            let allColumns = []
            Object.keys(tableColumnsOption).forEach(tableName => {
                if (allTables.includes(tableName)) {
                    allColumns = [...allColumns, ...tableColumnsOption[tableName]]
                }
            })

            return allColumns

        }
    }
    return (
        <>
            <CommonFields
                id={props.id}
                selectedActivity={selectedActivity}
                ScopeActivity={selectedActivity.activityType === "S"}
                activityName={activityName}
                handleChange={handleChange}
                makeLogsPrivate={invisibleInLogs.paramValue}
                ActivityIcon={Email}
                helperText={selectedActivity.description || "Fetch Records"}
            />
            <div
                className={classes.scrollDiv + " " + classes.focusVisible}
                tabIndex={0}
            >
                {selectedTab === "input" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                INPUT
                            </Typography>
                        </Grid>
                        <Grid item container spacing={1}>
                            <Grid item>
                                <PropertyField
                                    id={`${props.id}_FetchMode`}
                                    radio={true}
                                    ButtonsArray={radioButtonsArray}
                                    name="FetchFromTableType"
                                    label="Fetch From"
                                    value={selectedFetchFromTableType}
                                    onChange={handleChange}
                                // column={true}
                                />
                            </Grid>
                            <Grid item xs={12}>
                                <Typography component="h5" className={classes.text_light}>
                                    Table
                                </Typography>
                            </Grid>
                            <Grid item container spacing={1}>
                                <Grid item>
                                    {isFetchingTables ? (
                                        <Button
                                            variant="outlined"

                                            style={{ height: '32px' }}

                                        >
                                            <CircularProgress

                                                size={14}
                                                className={classes.secondary_btn_circular_progress}

                                            />
                                            <Typography className={classes.secondary_btn_title}>
                                                Fetching...
                                            </Typography>
                                        </Button>
                                    ) : (
                                        <Button
                                            variant="outlined"

                                            onClick={() => getTables()}
                                            style={{ height: '32px' }}
                                        >
                                            <Typography className={classes.secondary_btn_title}>Fetch</Typography>
                                        </Button>
                                    )}
                                </Grid>
                                <Grid item xs={8}>
                                    <PropertyField
                                        id={`${props.id}_TableName`}
                                        combo={true}
                                        dropdown={true}
                                        name="TableName"
                                        // label="Table Name"
                                        value={tableName?.paramValue}
                                        onChange={handleChange}
                                        options={tableOptions}
                                        width={isFetchingTables ? 220 : 270}
                                        placeholder="Select Table"


                                    />
                                </Grid>


                            </Grid>
                        </Grid>


                        <Grid
                            item
                            container
                            direction="column"
                            spacing={1}
                            style={{ marginBottom: "5px" }}
                        >
                            <Grid item>


                                {selectedFetchFromTableType == 1 &&
                                    <div>
                                        <label>
                                            <Typography >
                                                Column(s)
                                            </Typography>
                                        </label>
                                        <MultiSelectWithSearch
                                            optionList={columnOptions}
                                            selectedOptionList={selectedColumns}
                                            optionRenderKey="name"
                                            showTags={true}
                                            getSelectedItems={setSelectedColumnFunc}
                                            id="column_List"
                                            style={{ width: '315px', marginBottom: '8px' }}

                                        />
                                    </div>}
                            </Grid>

                            {selectedFetchFromTableType == 2
                                &&
                                <>
                                    <Grid item>
                                        <Typography >
                                            Fields
                                        </Typography>
                                    </Grid>

                                    <Grid item>
                                        <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                            <Grid container direction='column' spacing={1}>
                                                <Grid item>

                                                    <Grid container spacing={1} alignItems="center">


                                                        {arrOfJoinFieldVals.map((item, i) => (
                                                            <Grid item
                                                                key={i}
                                                                style={{
                                                                    marginTop: "12px",
                                                                    paddingLeft: '16px',
                                                                    maxWidth: '320px'
                                                                }}>

                                                                <Grid
                                                                    container
                                                                    direction="row"
                                                                    spacing={1}
                                                                    alignItems="flex-start"
                                                                    style={{
                                                                        backgroundColor: '#F8F8F8',
                                                                        borderRadius: '4px',
                                                                        paddingRight: '8px',
                                                                        paddingBottom: '8px',

                                                                    }}>

                                                                    {i === arrOfJoinFieldVals.length - 1 && <Grid item xs={12}>
                                                                        <Grid container alignItems='flex-end'>

                                                                            <Grid item style={{ marginLeft: "auto" }}>

                                                                                <UniqueIDGenerator>
                                                                                    <CloseIcon
                                                                                        id={`${props.id
                                                                                            }_RemoveCndBtn_${generateUniqueId()}`}
                                                                                        className={classes.deleteCrossIcon}
                                                                                        onClick={() => handleMultipleTableArrFieldsValueDelete(i)}
                                                                                        tabIndex={0}
                                                                                        onKeyPress={(e) =>
                                                                                            e.key === "Enter" && handleMultipleTableArrFieldsValueDelete(i)
                                                                                        }
                                                                                        role="button"
                                                                                        aria-label="Delete"
                                                                                        style={{ marginBottom: '-8px' }}
                                                                                    />
                                                                                </UniqueIDGenerator>



                                                                            </Grid>
                                                                        </Grid>
                                                                    </Grid>}
                                                                    <Grid
                                                                        item
                                                                        xs={12}
                                                                    >
                                                                        <PropertyField
                                                                            id={`${props.id}_Key_${generateUniqueId()}`}
                                                                            name="Key"
                                                                            label="Table"
                                                                            combo={true}
                                                                            dropdown={true}
                                                                            readOnly={item.readOnly}
                                                                            value={item.tableName || ""}

                                                                            onChange={(e) => handleMultipleTableArrFieldsValueChange(e, i)}
                                                                            //  height={28}
                                                                            options={tableOptions}
                                                                            width={310}

                                                                        />
                                                                    </Grid>
                                                                    <Grid item xs={12}>
                                                                        <Grid container spacing={1}>
                                                                            <Grid item xs={9}>

                                                                                <div>
                                                                                    <label for={`column_List_multipleTable+${i}`} class={classes.label}>
                                                                                        Column(s)
                                                                                    </label>
                                                                                    <MultiSelectWithSearch


                                                                                        optionList={tableColumnsOption[item.tableName] || []}
                                                                                        selectedOptionList={item.columnNames || []}
                                                                                        optionRenderKey="name"
                                                                                        showTags={true}
                                                                                        getSelectedItems={(list) => setSelectedColumnForMultipleTableFunc(list, i)}
                                                                                        id={`column_List_multipleTable+${i}`}
                                                                                        maxTagsToShow={2}
                                                                                        style={{ width: '295px' }}


                                                                                    />
                                                                                </div>
                                                                            </Grid>



                                                                            {/*i === arrOfJoinFieldVals.length - 1 && <Grid item xs={1} style={{ marginTop: '28px' }}>
                                                                                <Avatar variant="circular" className={classes.addIcon}
                                                                                    style={{ marginTop: '-13px' }}
                                                                                    onClick={() => addMultipleTableArrFieldsValue()}
                                                                                    onKeyPress={(e) =>
                                                                                        e.key === "Enter" && addMultipleTableArrFieldsValue()
                                                                                    }
                                                                                    tabIndex={0}

                                                                                    role="button"
                                                                                    aria-label="Add"
                                                                                >
                                                                                    <AddIcon
                                                                                        style={{
                                                                                            height: "16px",
                                                                                            width: "16px",
                                                                                            color: "#0072C6",
                                                                                        }}
                                                                                    />
                                                                                </Avatar>
                                                                                    </Grid>*/}
                                                                        </Grid>
                                                                    </Grid>

                                                                </Grid>
                                                                {i === arrOfJoinFieldVals.length - 1 && <Grid item xs={4} style={{ marginLeft: 'auto', marginTop: '8px', cursor: 'pointer', marginRight: '-15px' }}>
                                                                    <Grid container spacing={1}
                                                                        onClick={() => addMultipleTableArrFieldsValue()}
                                                                        onKeyPress={(e) =>
                                                                            e.key === "Enter" && addMultipleTableArrFieldsValue()
                                                                        }
                                                                    >
                                                                        <Grid item>
                                                                            <AddIcon
                                                                                className={classes.addColumnBtn}

                                                                            />
                                                                        </Grid>
                                                                        <Grid item>
                                                                            <Typography className={classes.tertiary_add_btn_title}>
                                                                                Add Fields
                                                                            </Typography>
                                                                        </Grid>
                                                                    </Grid>
                                                                </Grid>}



                                                            </Grid>
                                                        ))}





                                                    </Grid>

                                                </Grid>
                                            </Grid>
                                        </div>
                                    </Grid>



                                    <Grid item>
                                        <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                            <Grid container direction='column' spacing={1}>
                                                {
                                                    joinConditionArray.map((cond, index) => {

                                                        return (
                                                            <React.Fragment key={index + "Join"}>

                                                                {/*   <Grid item container alignItems="center">

                                                                    <Grid item xs={12}>
                                                                        <PropertyField
                                                                            id={`${props.id}_${generateUniqueId()}`}
                                                                            width={305}
                                                                            // combo={true}
                                                                            dropdown={true}
                                                                            name="JoinConditionType"
                                                                            label="Join"

                                                                            value={getJoinTypeName(joinConditionArray[index]?.conditionType
                                                                            )}
                                                                            options={
                                                                                joinOptions || []
                                                                            }
                                                                            onChange={(e) => handleCondJoin(e, index)}
                                                                        />
                                                                    </Grid>
                                                                </Grid>

                                                                <Grid item>
                                                                    <Grid
                                                                        item
                                                                        xs={12}
                                                                    >
                                                                        <PropertyField
                                                                            id={`${props.id}_OnJoinTableNameJoin_${generateUniqueId()}`}
                                                                            name="OnJoinTableName"
                                                                            label="On Table"
                                                                            combo={true}
                                                                            dropdown={true}
                                                                            value={cond?.onJoinTableName}
                                                                            options={getAllTableOptionsForConditions()}
                                                                            onChange={(e) => handleChangeJoinConditionVals(e, index)}
                                                                            width={316}

                                                                        />
                                                                    </Grid>
                                                                        </Grid>*/}
                                                                <Grid item

                                                                    style={{
                                                                        marginTop: "12px",
                                                                        paddingLeft: '16px',
                                                                        maxWidth: '320px'
                                                                    }}>

                                                                    <Grid
                                                                        container
                                                                        direction="row"
                                                                        spacing={1}
                                                                        alignItems="flex-start"
                                                                        style={{
                                                                            backgroundColor: '#F8F8F8',
                                                                            borderRadius: '4px',
                                                                            paddingRight: '8px',
                                                                            paddingBottom: '8px',

                                                                        }}>
                                                                        <Grid item container alignItems="center">
                                                                            {index === joinConditionArray.length - 1 && <Grid item xs={12}>
                                                                                <Grid container alignItems='flex-end'>

                                                                                    <Grid item style={{ marginLeft: "auto" }}>

                                                                                        <UniqueIDGenerator>
                                                                                            <CloseIcon
                                                                                                id={`${props.id
                                                                                                    }_RemoveJoinCndBtn_${generateUniqueId()}`}
                                                                                                className={classes.deleteCrossIcon}
                                                                                                onClick={() => removeJoinCondition()}
                                                                                                tabIndex={0}
                                                                                                onKeyPress={(e) => e.key === "Enter" && removeJoinCondition()}

                                                                                                role="button"
                                                                                                aria-label="Delete"
                                                                                                style={{ marginBottom: '-8px' }}
                                                                                            />
                                                                                        </UniqueIDGenerator>



                                                                                    </Grid>
                                                                                </Grid>
                                                                            </Grid>}


                                                                            <Grid item xs={12}>
                                                                                <PropertyField
                                                                                    id={`${props.id}_${generateUniqueId()}`}
                                                                                    width={295}
                                                                                    // combo={true}
                                                                                    dropdown={true}
                                                                                    name="JoinConditionType"
                                                                                    label="Join"

                                                                                    value={getJoinTypeName(joinConditionArray[index]?.conditionType
                                                                                    )}
                                                                                    options={
                                                                                        joinOptions || []
                                                                                    }
                                                                                    onChange={(e) => handleCondJoin(e, index)}
                                                                                />
                                                                            </Grid>
                                                                        </Grid>

                                                                        <Grid item>
                                                                            <Grid
                                                                                item
                                                                                xs={12}
                                                                            >
                                                                                <PropertyField
                                                                                    id={`${props.id}_OnJoinTableNameJoin_${generateUniqueId()}`}
                                                                                    name="OnJoinTableName"
                                                                                    label="On Table"
                                                                                    combo={true}
                                                                                    dropdown={true}
                                                                                    value={cond?.onJoinTableName}
                                                                                    options={getAllTableOptionsForConditions()}
                                                                                    onChange={(e) => handleChangeJoinConditionVals(e, index)}
                                                                                    width={305}

                                                                                />
                                                                            </Grid>
                                                                        </Grid>
                                                                        <Grid item xs={4}>
                                                                            <Typography>
                                                                                ON
                                                                            </Typography>
                                                                        </Grid>

                                                                        <Grid
                                                                            item
                                                                            container
                                                                            direction="row"
                                                                            spacing={2}
                                                                            alignItems="flex-start"
                                                                            style={{
                                                                                marginTop: "-10px",
                                                                            }}
                                                                        >
                                                                            <Grid item xs={12}>

                                                                                <Grid container spacing={3} alignItems="center">
                                                                                    <Grid
                                                                                        item
                                                                                        xs={6}
                                                                                    >
                                                                                        <PropertyField
                                                                                            id={`${props.id}_Param1TableNameJoin_${generateUniqueId()}`}
                                                                                            name="Param1TableName"
                                                                                            label="Table Name"
                                                                                            combo={true}
                                                                                            dropdown={true}
                                                                                            value={cond?.param1?.tableName || ""}
                                                                                            options={getAllTableOptionsForConditions(true)}
                                                                                            onChange={(e) => handleChangeJoinConditionVals(e, index)}
                                                                                            width={145}

                                                                                        />
                                                                                    </Grid>
                                                                                    <Grid item xs={6}>
                                                                                        <PropertyField
                                                                                            id={`${props.id}_Param1ColumnName_${generateUniqueId()}`}
                                                                                            name="Param1ColumnName"
                                                                                            label='Column Name'
                                                                                            combo={true}
                                                                                            dropdown={true}
                                                                                            hideSubDescription={true}
                                                                                            value={cond?.param1?.columnName || ""}
                                                                                            options={tableColumnsOption[cond?.param1?.tableName] || []}
                                                                                            onChange={(e) => handleChangeJoinConditionVals(e, index)}
                                                                                            width={145}

                                                                                        />
                                                                                    </Grid>

                                                                                </Grid>
                                                                                <Grid item xs={4} style={{ marginBottom: '12px' }}>

                                                                                    <PropertyField
                                                                                        id={`${props.id}_operator_${generateUniqueId()}`}
                                                                                        name="equaloperator"

                                                                                        // combo={true}
                                                                                        //dropdown={true}
                                                                                        disabled={true}
                                                                                        label="Operator"
                                                                                        value={"=="}
                                                                                        options={[]}

                                                                                        width={293}

                                                                                    />
                                                                                </Grid>

                                                                                <Grid item xs={12} >
                                                                                    <Grid container spacing={3} alignItems="flex-end">
                                                                                        <Grid
                                                                                            item
                                                                                            xs={6}
                                                                                        >
                                                                                            <PropertyField
                                                                                                id={`${props.id}_Param2TableNameJoin_${generateUniqueId()}`}
                                                                                                name="Param2TableName"
                                                                                                label="Table Name"
                                                                                                combo={true}
                                                                                                dropdown={true}
                                                                                                value={cond?.param2?.tableName || ""}
                                                                                                options={getAllTableOptionsForConditions(true)}
                                                                                                onChange={(e) => handleChangeJoinConditionVals(e, index)}
                                                                                                width={145}

                                                                                            />
                                                                                        </Grid>
                                                                                        <Grid item xs={6}>
                                                                                            <PropertyField
                                                                                                id={`${props.id}_Param2ColumnName_${generateUniqueId()}`}
                                                                                                name="Param2ColumnName"
                                                                                                label='Column Name'
                                                                                                combo={true}
                                                                                                dropdown={true}
                                                                                                hideSubDescription={true}
                                                                                                value={cond?.param2?.columnName || ""}
                                                                                                options={tableColumnsOption[cond?.param2?.tableName] || []}
                                                                                                onChange={(e) => handleChangeJoinConditionVals(e, index)}
                                                                                                width={145}

                                                                                            />
                                                                                        </Grid>

                                                                                    </Grid>
                                                                                </Grid>

                                                                            </Grid>
                                                                        </Grid>
                                                                    </Grid>
                                                                    {joinConditionArray.length < arrOfJoinFieldVals.length - 1 && <Grid item xs={5} style={{ marginLeft: 'auto', marginTop: '8px', cursor: 'pointer', marginRight: '-16px' }}>
                                                                        <Grid container spacing={1}
                                                                            onClick={() => addNewJoinCondition()}
                                                                            tabIndex={0}
                                                                            onKeyPress={(e) => e.key === "Enter" && addNewJoinCondition()}
                                                                            role="button"
                                                                            id={`${props.id}_AddNewJoinCndBtn`}
                                                                        >
                                                                            <Grid item>
                                                                                <AddIcon
                                                                                    className={classes.addColumnBtn}

                                                                                />
                                                                            </Grid>
                                                                            <Grid item>
                                                                                <Typography className={classes.tertiary_add_btn_title}>
                                                                                    Add Condition
                                                                                </Typography>
                                                                            </Grid>
                                                                        </Grid>
                                                                    </Grid>}
                                                                </Grid>

                                                                {/*joinConditionArray.length < arrOfJoinFieldVals.length - 1 &&
                                                                    <Grid item container style={{ cursor: "pointer" }}>
                                                                        <Grid item>
                                                                            <Grid
                                                                                container
                                                                                spacing={1}
                                                                                onClick={() => addNewJoinCondition()}
                                                                                tabIndex={0}
                                                                                onKeyPress={(e) => e.key === "Enter" && addNewJoinCondition()}
                                                                                role="button"
                                                                                id={`${props.id}_AddNewJoinCndBtn`}
                                                                            >
                                                                                <Grid item>
                                                                                    <Avatar variant="circular" className={classes.addIcon}>
                                                                                        <AddIcon
                                                                                            style={{
                                                                                                height: "16px",
                                                                                                width: "16px",
                                                                                                color: "#0072C6",
                                                                                            }}
                                                                                        />
                                                                                    </Avatar>
                                                                                </Grid>
                                                                                <Grid item>
                                                                                    <Typography style={{ color: "#0072C6" }}>
                                                                                        Add Join Condition
                                                                                    </Typography>
                                                                                </Grid>
                                                                            </Grid>
                                                                        </Grid>
                                                                        <Grid item style={{ marginLeft: "auto" }}>
                                                                            <Grid
                                                                                container
                                                                                spacing={1}
                                                                                onClick={() => removeJoinCondition()}
                                                                                tabIndex={0}
                                                                                onKeyPress={(e) => e.key === "Enter" && removeJoinCondition()}
                                                                                role="button"
                                                                                id={`${props.id}_RemoveJoinCndBtn`}
                                                                            >
                                                                                <Grid item>
                                                                                    <Avatar variant="circular" className={classes.removeIcon}>
                                                                                        <Remove
                                                                                            style={{
                                                                                                height: "16px",
                                                                                                width: "16px",
                                                                                                color: "#FF0000",
                                                                                            }}
                                                                                        />
                                                                                    </Avatar>
                                                                                </Grid>
                                                                                <Grid item>
                                                                                    <Typography style={{ color: "#FF0000" }}>
                                                                                        Remove
                                                                                    </Typography>
                                                                                </Grid>
                                                                            </Grid>
                                                                        </Grid>
                                                                    </Grid>
                                                                                        */}
                                                            </React.Fragment>
                                                        );
                                                    })}
                                            </Grid>
                                        </div>
                                    </Grid>

                                </>
                            }






                            {(selectedColumns.length > 0 || arrOfJoinFieldVals.length > 0)
                                &&
                                <>
                                    <Grid item>
                                        <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                            <Grid container direction='column' spacing={1}>
                                                <Grid item>
                                                    <PropertyField
                                                        checkbox={true}
                                                        id={`${props.id}_Where`}
                                                        name="Where"
                                                        label="Where"
                                                        value={whereCheckbox}
                                                        onChange={handleChange}
                                                    />

                                                </Grid>


                                                {whereCheckbox &&
                                                    whereConditionArray.map((cond, index) => {

                                                        return (
                                                            <React.Fragment key={index}>
                                                                {/*index > 0 ? (
                                                        <Grid item container alignItems="center">
                                                            <Grid item>
                                                                <Typography
                                                                    component="h5"
                                                                    className={classes.GroupTitle}
                                                                >
                                                                    {whereConditionArray[index - 1]?.expression === 1
                                                                        ? "AND"
                                                                        : "OR"}
                                                                </Typography>
                                                            </Grid>
                                                            <Grid item style={{ marginTop: "10px" }}>
                                                                <MenuPopper
                                                                    id={`${props.id}_MenuPopper_${generateUniqueId()}`}
                                                                    MenuIcon={ExpandMore}
                                                                    selfClicked={cond}
                                                                    handleSelectedItem={handleCondWhere}
                                                                    items={["AND", "OR"]}
                                                                />
                                                            </Grid>
                                                        </Grid>
                                                    ) : null*/}
                                                                {index > 0 ? (
                                                                    <Grid item container alignItems="center">

                                                                        <Grid item xs={12}>
                                                                            <PropertyField
                                                                                id={`${props.id}_${generateUniqueId()}`}
                                                                                width={310}
                                                                                // combo={true}
                                                                                dropdown={true}
                                                                                name="AndOrCondition"

                                                                                value={whereConditionArray[index - 1]?.expression === 1
                                                                                    ? "AND"
                                                                                    : "OR"}
                                                                                options={
                                                                                    andOrOROptions || []
                                                                                }
                                                                                onChange={(e) => handleCondWhere(e, index)}
                                                                            />
                                                                        </Grid>
                                                                    </Grid>
                                                                ) : null}
                                                                <Grid item
                                                                    style={{
                                                                        marginTop: "4px",
                                                                        paddingLeft: '16px',
                                                                        maxWidth: '320px'
                                                                    }}
                                                                >
                                                                    <Grid
                                                                        item
                                                                        container
                                                                        direction="row"
                                                                        spacing={1}
                                                                        alignItems="flex-start"
                                                                        style={{
                                                                            backgroundColor: '#F8F8F8',
                                                                            borderRadius: '4px',
                                                                            paddingRight: '8px'
                                                                        }}
                                                                    >
                                                                        {index === whereConditionArray.length - 1 && <Grid item xs={12}>
                                                                            <Grid container alignItems='flex-end'>

                                                                                <Grid item style={{ marginLeft: "auto" }}>

                                                                                    <UniqueIDGenerator>
                                                                                        <CloseIcon
                                                                                            id={`${props.id
                                                                                                }_RemoveCndBtn_${generateUniqueId()}`}
                                                                                            className={classes.deleteCrossIcon}
                                                                                            onClick={() => removeWhereCondition()}
                                                                                            tabIndex={0}
                                                                                            onKeyPress={(e) => e.key === "Enter" && removeWhereCondition()}
                                                                                            role="button"
                                                                                            aria-label="Delete"
                                                                                            style={{ marginBottom: '-8px' }}
                                                                                        />
                                                                                    </UniqueIDGenerator>



                                                                                </Grid>
                                                                            </Grid>
                                                                        </Grid>}
                                                                        <Grid item xs={8}>
                                                                            <PropertyField
                                                                                id={`${props.id}_${cond.param1
                                                                                    }_${generateUniqueId()}`}
                                                                                width={200}
                                                                                combo={true}
                                                                                dropdown={true}
                                                                                name="Operand1"
                                                                                label='Column'
                                                                                value={cond.param1}
                                                                                options={
                                                                                    fetchFromTableMode?.paramValue == 1 ? columnOptions :
                                                                                        getAllColumnOptionsForConditions(tableColumnsOption) || []
                                                                                }
                                                                                onChange={(e) => handleChangeWhereConditionVals(e, index)}
                                                                            />
                                                                        </Grid>
                                                                        <Grid item xs={4}>
                                                                            <PropertyField
                                                                                id={`${props.id}_${cond.operator
                                                                                    }_${generateUniqueId()}`}
                                                                                //  combo={true}
                                                                                dropdown={true}
                                                                                label='Operator'
                                                                                name="OperatorType"
                                                                                value={cond.operator}
                                                                                onChange={(e) => handleChangeWhereConditionVals(e, index)}
                                                                                options={getOperatorsOptions(cond) || []}
                                                                                height={32}

                                                                            />
                                                                        </Grid>
                                                                        {cond.operator == "9" ||
                                                                            cond.operator == "10" ||
                                                                            cond.operator == "11" ? null : (
                                                                            <Grid item xs={12}>
                                                                                <PropertyField
                                                                                    id={`${props.id}_${cond.param2
                                                                                        }_${generateUniqueId()}`}
                                                                                    combo={true}
                                                                                    dropdown={true}
                                                                                    canType={true}
                                                                                    type={getFieldType(cond)}
                                                                                    labelBtn1={true}
                                                                                    labelBtn2={true}
                                                                                    paramObj={{ paramType: cond.paramType2 }}
                                                                                    labelBtn1OnClick={(paramName, changeToValue) =>
                                                                                        changeParamTypeToVorCForWhere(
                                                                                            paramName,
                                                                                            changeToValue,
                                                                                            index
                                                                                        )
                                                                                    }
                                                                                    labelBtn2OnClick={(paramName, changeToValue) =>
                                                                                        changeParamTypeToVorCForWhere(
                                                                                            paramName,
                                                                                            changeToValue,
                                                                                            index
                                                                                        )
                                                                                    }
                                                                                    name="Operand2"
                                                                                    label={"Value"}
                                                                                    value={cond.param2}
                                                                                    onChange={(e) => handleChangeWhereConditionVals(e, index)}
                                                                                    varType={getVarType(cond)}
                                                                                    options={getOptionsForVar(cond) || []}
                                                                                    error={
                                                                                        vaildateParamValue(cond?.param2?.toString() || "")
                                                                                            .errorStatus
                                                                                    }
                                                                                    helperText={
                                                                                        vaildateParamValue(cond?.param2?.toString() || "")
                                                                                            .msg
                                                                                    }
                                                                                    width={310}
                                                                                />
                                                                            </Grid>
                                                                        )}
                                                                    </Grid>
                                                                </Grid>

                                                            </React.Fragment>
                                                        );
                                                    })}

                                                {/*whereCheckbox &&
                                        <Grid item container style={{ cursor: "pointer" }}>
                                            <Grid item>
                                                <Grid
                                                    container
                                                    spacing={1}
                                                    onClick={() => addNewWhereCondition()}
                                                    tabIndex={0}
                                                    onKeyPress={(e) => e.key === "Enter" && addNewWhereCondition()}
                                                    role="button"
                                                    id={`${props.id}_AddNewCndBtn`}
                                                >
                                                    <Grid item>
                                                        <Avatar variant="circular" className={classes.addIcon}>
                                                            <AddIcon
                                                                style={{
                                                                    height: "16px",
                                                                    width: "16px",
                                                                    color: "#0072C6",
                                                                }}
                                                            />
                                                        </Avatar>
                                                    </Grid>
                                                    <Grid item>
                                                        <Typography style={{ color: "#0072C6" }}>
                                                            Add Condition
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                            <Grid item style={{ marginLeft: "auto" }}>
                                                <Grid
                                                    container
                                                    spacing={1}
                                                    onClick={() => removeWhereCondition()}
                                                    tabIndex={0}
                                                    onKeyPress={(e) => e.key === "Enter" && removeWhereCondition()}
                                                    role="button"
                                                    id={`${props.id}_RemoveCndBtn`}
                                                >
                                                    <Grid item>
                                                        <Avatar variant="circular" className={classes.removeIcon}>
                                                            <Remove
                                                                style={{
                                                                    height: "16px",
                                                                    width: "16px",
                                                                    color: "#FF0000",
                                                                }}
                                                            />
                                                        </Avatar>
                                                    </Grid>
                                                    <Grid item>
                                                        <Typography style={{ color: "#FF0000" }}>
                                                            Remove
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                                            */}
                                                {whereCheckbox &&
                                                    <Grid item container>
                                                        <Grid item xs={5} style={{ marginLeft: 'auto', cursor: 'pointer', marginRight: '-30px' }}>
                                                            <Grid container
                                                                onClick={() => addNewWhereCondition()}
                                                                tabIndex={0}
                                                                onKeyPress={(e) => e.key === "Enter" && addNewWhereCondition()}
                                                                role="button"
                                                                id={`${props.id}_AddNewCndBtn`}
                                                            >
                                                                <Grid item>
                                                                    <AddIcon
                                                                        className={classes.addColumnBtn}
                                                                    />
                                                                </Grid>
                                                                <Grid item>
                                                                    <Typography className={classes.tertiary_add_btn_title}>
                                                                        Add Condition
                                                                    </Typography>
                                                                </Grid>
                                                            </Grid>
                                                        </Grid>

                                                    </Grid>
                                                }
                                            </Grid>
                                        </div>
                                    </Grid>

                                    <Grid item>
                                        <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                            <Grid container direction='column' spacing={1}>
                                                <Grid item container direction={'row'} alignItems={'flex-start'}>
                                                    <Grid item>
                                                        <PropertyField
                                                            checkbox={true}
                                                            id={`${props.id}_Group_By`}
                                                            name="GroupBy"
                                                            label="GroupBy"
                                                            value={groupByCheckbox}
                                                            onChange={handleChange}
                                                        />
                                                    </Grid>
                                                    <Grid item>
                                                        <HelpLabel label="Group Together" />
                                                    </Grid>
                                                </Grid>


                                                {groupByCheckbox &&
                                                    groupByConditionArray.map((cond, index) => {

                                                        return (
                                                            <Grid item key={index}>

                                                                <Grid container spacing={1} alignItems="center">
                                                                    <Grid item xs={12}>


                                                                        <MultiSelectWithSearch
                                                                            optionList={
                                                                                fetchFromTableMode?.paramValue == 1 ? columnOptions :
                                                                                    getAllColumnOptionsForConditions(tableColumnsOption) || []
                                                                            }
                                                                            selectedOptionList={(cond.param1 || []).map(item => item.columnName)}
                                                                            optionRenderKey="name"
                                                                            showTags={true}
                                                                            getSelectedItems={setSelectedColumnsForGroupByFunc}
                                                                            id="column_List_groupBy"
                                                                            style={{ width: '305px', marginBottom: '8px' }}


                                                                        />

                                                                    </Grid>

                                                                    {groupByConditionArrayForParam2.map((item, i) => (
                                                                        <Grid item xs={12} key={i}>
                                                                            <Grid container spacing={1} alignItems="center">
                                                                                <Grid
                                                                                    item
                                                                                    xs={5}
                                                                                >
                                                                                    <PropertyField
                                                                                        id={`${props.id}_Key_${generateUniqueId()}`}
                                                                                        name="Key"
                                                                                        label="Column"
                                                                                        combo={true}
                                                                                        dropdown={true}
                                                                                        readOnly={item.readOnly}
                                                                                        value={item.key}

                                                                                        onChange={(e) => handleGroupByParam2ValsValueChange(e, i)}
                                                                                        //  height={28}
                                                                                        options={fetchFromTableMode?.paramValue == 1 ? columnOptions :
                                                                                            getAllColumnOptionsForConditions(tableColumnsOption) || []}
                                                                                        width={139}

                                                                                    />
                                                                                </Grid>
                                                                                <Grid item xs={5}>
                                                                                    <PropertyField
                                                                                        id={`${props.id}_value_${generateUniqueId()}`}
                                                                                        name="Value"
                                                                                        label="Function"
                                                                                        combo={true}
                                                                                        dropdown={true}
                                                                                        readOnly={item.readOnly}
                                                                                        value={item.value}

                                                                                        onChange={(e) => handleGroupByParam2ValsValueChange(e, i)}
                                                                                        options={aggregateFnOptions}
                                                                                        width={139}

                                                                                    />
                                                                                </Grid>


                                                                                <Grid item>
                                                                                    <IconButton
                                                                                        id={`${props.id
                                                                                            }_DeleteIcon_${generateUniqueId()}`}
                                                                                        className={classes.iconBtnMediumSize}
                                                                                        onClick={() => handleGroupByParam2ValueDelete(index)}
                                                                                        size='small'
                                                                                    >


                                                                                        <CloseIcon

                                                                                        />
                                                                                    </IconButton>

                                                                                </Grid>

                                                                            </Grid>
                                                                            {/*i === groupByConditionArrayForParam2.length - 1 && <Grid item xs={1}>
                                                                        <Avatar variant="circular" className={classes.addIcon}
                                                                            style={{ marginTop: '-13px' }}
                                                                            onClick={() => addGroupByParam2Value()}
                                                                        >
                                                                            <AddIcon
                                                                                style={{
                                                                                    height: "16px",
                                                                                    width: "16px",
                                                                                    color: "#0072C6",
                                                                                }}
                                                                            />
                                                                        </Avatar>
                                                                            </Grid>*/}
                                                                            {i === groupByConditionArrayForParam2.length - 1 && <Grid item container>
                                                                                <Grid item xs={5} style={{ marginLeft: 'auto', cursor: 'pointer', marginRight: '-30px' }}>
                                                                                    <Grid container
                                                                                        onClick={() => addGroupByParam2Value()}
                                                                                        tabIndex={0}
                                                                                        onKeyPress={(e) => e.key === "Enter" && addGroupByParam2Value()}
                                                                                        role="button"
                                                                                        id={`${props.id}_AddNewGrpByCndBtn`}
                                                                                    >
                                                                                        <Grid item>
                                                                                            <AddIcon
                                                                                                className={classes.addColumnBtn}
                                                                                            />
                                                                                        </Grid>
                                                                                        <Grid item>
                                                                                            <Typography className={classes.tertiary_add_btn_title}>
                                                                                                Add Condition
                                                                                            </Typography>
                                                                                        </Grid>
                                                                                    </Grid>
                                                                                </Grid>

                                                                            </Grid>}
                                                                        </Grid>
                                                                    ))}





                                                                </Grid>

                                                            </Grid>
                                                        );
                                                    })}
                                            </Grid>
                                        </div>
                                    </Grid>
                                    {groupByCheckbox &&
                                        <Grid item>
                                            <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                                <Grid container direction='column' spacing={1}>
                                                    <Grid item container alignItems={'center'}>

                                                        <Grid item>
                                                            <PropertyField
                                                                checkbox={true}
                                                                id={`${props.id}_Having`}
                                                                name="Having"
                                                                label="Having"
                                                                value={havingCheckbox}
                                                                onChange={handleChange}
                                                            />

                                                        </Grid>
                                                        <Grid item>
                                                            <HelpLabel label="Group Condition" />
                                                        </Grid>
                                                    </Grid>


                                                    {havingCheckbox &&
                                                        havingConditionArray.map((cond, index) => {

                                                            return (
                                                                <React.Fragment key={index + "having"}>
                                                                    {/*index > 0 ? (
                                                        <Grid item container alignItems="center">
                                                            <Grid item>
                                                                <Typography
                                                                    component="h5"
                                                                    className={classes.GroupTitle}
                                                                >
                                                                    {havingConditionArray[index - 1]?.expression === 1
                                                                        ? "AND"
                                                                        : "OR"}
                                                                </Typography>
                                                            </Grid>
                                                            <Grid item style={{ marginTop: "10px" }}>
                                                                <MenuPopper
                                                                    id={`${props.id}_MenuPopper_${generateUniqueId()}`}
                                                                    MenuIcon={ExpandMore}
                                                                    selfClicked={cond}
                                                                    handleSelectedItem={handleCondHaving}
                                                                    items={["AND", "OR"]}
                                                                />
                                                            </Grid>
                                                        </Grid>
                                                    ) : null*/}

                                                                    {index > 0 ? (
                                                                        <Grid item container alignItems="center">

                                                                            <Grid item xs={12}>
                                                                                <PropertyField
                                                                                    id={`${props.id}_${generateUniqueId()}`}
                                                                                    width={310}
                                                                                    // combo={true}
                                                                                    dropdown={true}
                                                                                    name="AndOrCondition"

                                                                                    value={havingConditionArray[index - 1]?.expression === 1
                                                                                        ? "AND"
                                                                                        : "OR"}
                                                                                    options={
                                                                                        andOrOROptions || []
                                                                                    }
                                                                                    onChange={(e) => handleCondHaving(e, index)}
                                                                                />
                                                                            </Grid>
                                                                        </Grid>
                                                                    ) : null}

                                                                    <Grid item
                                                                        style={{
                                                                            marginTop: "4px",
                                                                            paddingLeft: '16px',
                                                                            maxWidth: '320px'
                                                                        }}
                                                                    >
                                                                        <Grid
                                                                            item
                                                                            container
                                                                            direction="row"
                                                                            spacing={1}
                                                                            alignItems="flex-start"
                                                                            style={{
                                                                                backgroundColor: '#F8F8F8',
                                                                                borderRadius: '4px',
                                                                                paddingRight: '8px'
                                                                            }}
                                                                        >
                                                                            {index === havingConditionArray.length - 1 && <Grid item xs={12}>
                                                                                <Grid container alignItems='flex-end'>

                                                                                    <Grid item style={{ marginLeft: "auto" }}>

                                                                                        <UniqueIDGenerator>
                                                                                            <CloseIcon
                                                                                                id={`${props.id
                                                                                                    }_RemoveCndBtn_${generateUniqueId()}`}
                                                                                                className={classes.deleteCrossIcon}
                                                                                                onClick={() => removeHavingCondition()}
                                                                                                tabIndex={0}
                                                                                                onKeyPress={(e) => e.key === "Enter" && removeHavingCondition()}
                                                                                                role="button"
                                                                                                aria-label="Delete"
                                                                                                style={{ marginBottom: '-8px' }}
                                                                                            />
                                                                                        </UniqueIDGenerator>
                                                                                    </Grid>
                                                                                </Grid>
                                                                            </Grid>}
                                                                            <Grid item xs={12}>

                                                                                <Grid container justifyContent={'space-between'} alignItems="flex-end" style={{ paddingInlineEnd: '12px' }}>
                                                                                    <Grid
                                                                                        item
                                                                                        xs={6}
                                                                                    >
                                                                                        <PropertyField
                                                                                            id={`${props.id}_ColumnNameHaving_${generateUniqueId()}`}
                                                                                            name="ColumnName"
                                                                                            label="Column"
                                                                                            combo={true}
                                                                                            dropdown={true}
                                                                                            value={cond?.param1?.columnName || ""}
                                                                                            options={fetchFromTableMode?.paramValue == 1 ? columnOptions :
                                                                                                getAllColumnOptionsForConditions(tableColumnsOption) || []}


                                                                                            onChange={(e) => handleChangeHavingConditionVals(e, index)}

                                                                                            width={139}

                                                                                        />
                                                                                    </Grid>
                                                                                    <Grid item xs={6}>


                                                                                        <PropertyField
                                                                                            id={`${props.id}_AggregateFunc_${generateUniqueId()}`}
                                                                                            name="AggregateFunc"
                                                                                            label='Function'
                                                                                            combo={true}
                                                                                            dropdown={true}
                                                                                            readOnly={cond?.param1?.readOnly}

                                                                                            value={cond?.param1?.aggregateFunction}
                                                                                            options={aggregateFnOptions}


                                                                                            onChange={(e) => handleChangeHavingConditionVals(e, index)}
                                                                                            width={139}

                                                                                        />
                                                                                    </Grid>


                                                                                </Grid>
                                                                                <Grid container justifyContent={'space-between'} alignItems="flex-start" style={{ paddingInlineEnd: '12px' }}>

                                                                                    <Grid item xs={6}>
                                                                                        <PropertyField
                                                                                            id={`${props.id}_${cond.operator
                                                                                                }_${generateUniqueId()}`}
                                                                                            //  combo={true}
                                                                                            dropdown={true}
                                                                                            name="OperatorType"
                                                                                            label='Operator'
                                                                                            value={cond.d}
                                                                                            onChange={(e) => handleChangeHavingConditionVals(e, index)}
                                                                                            //Having conditions result with aggregate functions will be a number
                                                                                            options={getOperatorsOptions({ param1: true, rpaDataType: 8 }) || []}
                                                                                            height={32}
                                                                                            width={129}

                                                                                        />
                                                                                    </Grid>
                                                                                    {cond.d == "9" ||
                                                                                        cond.d == "10" ||
                                                                                        cond.d == "11" ? null : (
                                                                                        <Grid item xs={6}>
                                                                                            <PropertyField
                                                                                                width={139}
                                                                                                id={`${props.id}_${cond.param2
                                                                                                    }_${generateUniqueId()}`}
                                                                                                combo={true}
                                                                                                dropdown={true}
                                                                                                canType={true}
                                                                                                type={getFieldType(cond)}
                                                                                                labelBtn1={true}
                                                                                                labelBtn2={true}
                                                                                                paramObj={{ paramType: cond.paramType2 }}
                                                                                                labelBtn1OnClick={(paramName, changeToValue) =>
                                                                                                    changeParamTypeToVorCForHaving(
                                                                                                        paramName,
                                                                                                        changeToValue,
                                                                                                        index
                                                                                                    )
                                                                                                }
                                                                                                labelBtn2OnClick={(paramName, changeToValue) =>
                                                                                                    changeParamTypeToVorCForHaving(
                                                                                                        paramName,
                                                                                                        changeToValue,
                                                                                                        index
                                                                                                    )
                                                                                                }
                                                                                                name="Operand2"
                                                                                                label={"Value"}
                                                                                                value={cond.param2}
                                                                                                onChange={(e) => handleChangeHavingConditionVals(e, index)}
                                                                                                varType={getVarType(cond)}
                                                                                                options={getOptionsForVar(cond) || []}
                                                                                                error={
                                                                                                    vaildateParamValue(cond?.param2?.toString() || "")
                                                                                                        .errorStatus
                                                                                                }
                                                                                                helperText={
                                                                                                    vaildateParamValue(cond?.param2?.toString() || "")
                                                                                                        .msg
                                                                                                }
                                                                                            />
                                                                                        </Grid>
                                                                                    )}
                                                                                </Grid>
                                                                            </Grid>
                                                                        </Grid>
                                                                    </Grid>

                                                                </React.Fragment>
                                                            );
                                                        })}

                                                    {/*havingCheckbox &&
                                        <Grid item container style={{ cursor: "pointer" }}>
                                            <Grid item>
                                                <Grid
                                                    container
                                                    spacing={1}
                                                    onClick={() => addNewHavingCondition()}
                                                    tabIndex={0}
                                                    onKeyPress={(e) => e.key === "Enter" && addNewHavingCondition()}
                                                    role="button"
                                                    id={`${props.id}_AddNewHavingCndBtn`}
                                                >
                                                    <Grid item>
                                                        <Avatar variant="circular" className={classes.addIcon}>
                                                            <AddIcon
                                                                style={{
                                                                    height: "16px",
                                                                    width: "16px",
                                                                    color: "#0072C6",
                                                                }}
                                                            />
                                                        </Avatar>
                                                    </Grid>
                                                    <Grid item>
                                                        <Typography style={{ color: "#0072C6" }}>
                                                            Add Having Condition
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                                            </Grid>*/}
                                                    {havingCheckbox &&
                                                        <Grid item container>
                                                            <Grid item xs={5} style={{ marginLeft: 'auto', cursor: 'pointer', marginRight: '-30px' }}>
                                                                <Grid container
                                                                    onClick={() => addNewHavingCondition()}
                                                                    tabIndex={0}
                                                                    onKeyPress={(e) => e.key === "Enter" && addNewHavingCondition()}
                                                                    role="button"
                                                                    id={`${props.id}_AddNewHavingCndBtn`}
                                                                >
                                                                    <Grid item>
                                                                        <AddIcon
                                                                            className={classes.addColumnBtn}
                                                                        />
                                                                    </Grid>
                                                                    <Grid item>
                                                                        <Typography className={classes.tertiary_add_btn_title}>
                                                                            Add Condition
                                                                        </Typography>
                                                                    </Grid>
                                                                </Grid>
                                                            </Grid>

                                                        </Grid>
                                                    }
                                                    {/* <Grid item style={{ marginLeft: "auto" }}>
                                                <Grid
                                                    container
                                                    spacing={1}
                                                    onClick={() => removeHavingCondition()}
                                                    tabIndex={0}
                                                    onKeyPress={(e) => e.key === "Enter" && removeHavingCondition()}
                                                    role="button"
                                                    id={`${props.id}_RemoveHavingCndBtn`}
                                                >
                                                    <Grid item>
                                                        <Avatar variant="circular" className={classes.removeIcon}>
                                                            <Remove
                                                                style={{
                                                                    height: "16px",
                                                                    width: "16px",
                                                                    color: "#FF0000",
                                                                }}
                                                            />
                                                        </Avatar>
                                                    </Grid>
                                                    <Grid item>
                                                        <Typography style={{ color: "#FF0000" }}>
                                                            Remove
                                                        </Typography>
                                                    </Grid>
                                                </Grid>
                                                            </Grid>*/}

                                                </Grid>
                                            </div>
                                        </Grid>}



                                    <Grid item>
                                        <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                            <Grid container direction='column' spacing={1}>
                                                <Grid item container spacing={1} >
                                                    <Grid item>
                                                        <PropertyField
                                                            checkbox={true}
                                                            id={`${props.id}_Order_By`}
                                                            name="OrderBy"
                                                            label="OrderBy"
                                                            value={orderByCheckbox}
                                                            onChange={handleChange}
                                                        />
                                                    </Grid>
                                                    <Grid item>
                                                        <HelpLabel label="Sorting" />
                                                    </Grid>
                                                </Grid>



                                                {orderByCheckbox &&
                                                    orderByConditionArray.map((cond, index) => {

                                                        return (
                                                            <Grid item key={index}>

                                                                <Grid container spacing={3} alignItems="center">
                                                                    <Grid item xs={5}>


                                                                        <PropertyField
                                                                            id={`${props.id}_${cond.param1
                                                                                }_${generateUniqueId()}`}
                                                                            width={139}
                                                                            combo={true}
                                                                            dropdown={true}
                                                                            name="Operand1"
                                                                            label="Column"
                                                                            value={cond.param1}
                                                                            options={
                                                                                fetchFromTableMode?.paramValue == 1 ? columnOptions :
                                                                                    getAllColumnOptionsForConditions(tableColumnsOption) || []
                                                                            }
                                                                            onChange={(e) => handleChangeOrderByConditionVals(e, index)}
                                                                        />
                                                                    </Grid>


                                                                    <Grid item xs={5}>
                                                                        <PropertyField
                                                                            id={`${props.id}_${cond.param1
                                                                                }_${generateUniqueId()}`}
                                                                            width={139}
                                                                            combo={true}
                                                                            dropdown={true}
                                                                            name="Operand2"
                                                                            label="Order"
                                                                            value={cond.param2}
                                                                            options={
                                                                                orderByOptions || []
                                                                            }
                                                                            onChange={(e) => handleChangeOrderByConditionVals(e, index)}
                                                                        />
                                                                    </Grid>
                                                                    <Grid item >
                                                                        <UniqueIDGenerator>
                                                                            <CloseIcon
                                                                                id={`${props.id
                                                                                    }_DeleteIcon_${generateUniqueId()}`}
                                                                                className={classes.deleteCrossIcon}

                                                                                onClick={() => removeOrderByCondition(index)}
                                                                                tabIndex={0}
                                                                                onKeyPress={(e) =>
                                                                                    e.key === "Enter" && removeOrderByCondition(index)
                                                                                }
                                                                                role="button"
                                                                                aria-label="Delete"
                                                                            />
                                                                        </UniqueIDGenerator>
                                                                    </Grid>


                                                                </Grid>

                                                                {index === orderByConditionArray.length - 1 &&
                                                                    <Grid item container>
                                                                        <Grid item xs={5} style={{ marginLeft: 'auto', cursor: 'pointer', marginRight: '-30px' }}>
                                                                            <Grid container
                                                                                onClick={() => addNewOrderByCondition()}
                                                                                tabIndex={0}
                                                                                onKeyPress={(e) => e.key === "Enter" && addNewOrderByCondition()}
                                                                                role="button"
                                                                                id={`${props.id}_AddNewOrderByCndBtn`}
                                                                            >
                                                                                <Grid item>
                                                                                    <AddIcon
                                                                                        className={classes.addColumnBtn}
                                                                                    />
                                                                                </Grid>
                                                                                <Grid item>
                                                                                    <Typography className={classes.tertiary_add_btn_title}>
                                                                                        Add Condition
                                                                                    </Typography>
                                                                                </Grid>
                                                                            </Grid>
                                                                        </Grid>

                                                                    </Grid>
                                                                }
                                                            </Grid>
                                                        );
                                                    })}
                                            </Grid>
                                        </div>
                                    </Grid>
                                    <Grid item>
                                        <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                            <Grid container direction='column' spacing={1}>

                                                <Grid item container alignItems={'center'}>
                                                    <Grid item>
                                                        <PropertyField
                                                            checkbox={true}
                                                            id={`${props.id}_Limit`}
                                                            name="Limit"
                                                            label="Limit"
                                                            value={limitCheckbox}
                                                            onChange={handleChange}
                                                        />
                                                    </Grid>
                                                    <Grid item>
                                                        <HelpLabel label="Fetch Rows from Top" />
                                                    </Grid>
                                                </Grid>


                                                {limitCheckbox &&
                                                    <Grid item>
                                                        <PropertyField
                                                            id={`${props.id}_LimitCondition`}
                                                            combo={true}
                                                            labelBtn1={true}
                                                            labelBtn2={true}
                                                            dropdown={limitCondition.paramType === "V"}
                                                            paramObj={limitCondition}
                                                            labelBtn1OnClick={changeParamTypeToVorC}
                                                            labelBtn2OnClick={changeParamTypeToVorC}
                                                            // btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                                                            name="LimitCondition"
                                                            label="Value"
                                                            value={limitCondition.paramValue}
                                                            options={getOptionsForVariable(limitCondition)}
                                                            onChange={handleChange}
                                                            error={
                                                                vaildateParamValue(limitCondition.paramValue.toString())
                                                                    .errorStatus
                                                            }
                                                            helperText={
                                                                vaildateParamValue(limitCondition.paramValue.toString()).msg
                                                            }
                                                            width={310}
                                                        />
                                                    </Grid>
                                                }
                                            </Grid>
                                        </div>
                                    </Grid>

                                    <Grid item>
                                        {limitCheckbox && <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px' }}>
                                            <Grid container direction='column' spacing={1}>
                                                <Grid item container alignItems={'center'}>
                                                    <Grid item>
                                                        <PropertyField
                                                            checkbox={true}
                                                            id={`${props.id}_Offset`}
                                                            name="Offset"
                                                            label="Offset"
                                                            value={offsetCheckbox}
                                                            onChange={handleChange}
                                                        />
                                                    </Grid>
                                                    <Grid item>
                                                        <HelpLabel label="Start Row From" />
                                                    </Grid>
                                                </Grid>
                                                {limitCheckbox && offsetCheckbox &&
                                                    <Grid item>
                                                        <PropertyField
                                                            id={`${props.id}_OffsetCondition`}
                                                            combo={true}
                                                            labelBtn1={true}
                                                            labelBtn2={true}
                                                            dropdown={offsetCondition.paramType === "V"}
                                                            paramObj={offsetCondition}
                                                            labelBtn1OnClick={changeParamTypeToVorC}
                                                            labelBtn2OnClick={changeParamTypeToVorC}
                                                            // btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                                                            name="OffsetCondition"
                                                            label="Value"
                                                            value={offsetCondition.paramValue}
                                                            options={getOptionsForVariable(offsetCondition)}
                                                            onChange={handleChange}
                                                            error={
                                                                vaildateParamValue(offsetCondition.paramValue.toString())
                                                                    .errorStatus
                                                            }
                                                            helperText={
                                                                vaildateParamValue(offsetCondition.paramValue.toString()).msg
                                                            }
                                                            width={310}
                                                        />
                                                    </Grid>
                                                }
                                            </Grid>
                                        </div>}
                                    </Grid>
                                </>

                            }
                        </Grid>




                    </Grid>
                ) : selectedTab === "output" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                OUTPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <PropertyField
                                id={`${props.id}_Records`}
                                combo={true}
                                dropdown={true}
                                paramObj={records}
                                btnIcon={
                                    <AddVariableIcon
                                        className={classes.btnIcon + " " + classes.colorPrimary}
                                    />
                                }
                                name="Records"
                                label={`Records (${getVariableTypeById(
                                    records.paramObjectTypeId
                                )})`}
                                value={records.paramValue}
                                options={getOptionsForVariable(records)}
                                onChange={handleChange}
                                error={
                                    vaildateParamValue(records.paramValue.toString())
                                        .errorStatus
                                }
                                helperText={
                                    vaildateParamValue(records.paramValue.toString()).msg
                                }
                            />
                        </Grid>
                    </Grid>
                )
                    :

                    selectedTab === "error" ? (
                        <ErrorsWindow />
                    ) : null}
            </div>
        </>
    );
};

export default FetchRecordWindow;
const allOperators = [
    { name: "==(Equals)", value: 1, strName: "Equals" },
    { name: ">", value: 2, strName: "GreaterThan" },
    { name: ">=", value: 3, strName: "GreaterThanOrEqual" },
    { name: "<", value: 4, strName: "LessThan" },
    { name: "<=", value: 5, strName: "LessThanOrEqual" },
    { name: "!=", value: 6, strName: "NotEqual" },
    // { name: "EqualsIgnoreCase", value: 7, strName: "EqualsIgnoreCase" },
    { name: "Contains", value: 8, strName: "Contains" },
    { name: "isNull", value: 9, strName: "isNull" },
    { name: "isNotNull", value: 10, strName: "isNotNull" },
    { name: "isEmpty", value: 11, strName: "isEmpty" },
    { name: "Before", value: 12, strName: "Before" },
    { name: "After", value: 13, strName: "After" },
];

const availableOperators = {
    integerValue: [1, 2, 3, 4, 5, 6],
    // floatValue: [1, 2, 3, 4, 5, 6],
    textValue: [1, 7, 9, 10, 11, 6],
    dateTime: [12, 13, 1, 6, 9, 10],
    booleanValue: [1, 6, 9, 10],
};
const andOrOROptions = [
    { name: "AND", value: "AND" },
    { name: "OR", value: "OR" }
]

const joinOptions = [
    { name: "Inner Join", value: "Inner Join" },
    { name: "Left Outer Join", value: "Left Outer Join" },
    { name: "Right Outer Join", value: "Right Outer Join" },
    { name: "Full Outer Join", value: "Full Outer Join" }

]
const orderByOptions = [
    { name: "Ascending", value: "ASC" },
    { name: "Descending", value: "DESC" }
]

const aggregateFnOptions = [
    { name: "AVG", value: "AVG" },
    { name: "MAX", value: "MAX" },
    { name: "MIN", value: "MIN" },
    { name: "SUM", value: "SUM" },
    { name: "COUNT", value: "COUNT" }

]