import React, { useState } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";

const CompressFileWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, updateDisplayNameSelAct } = props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [makeLogsPrivate, setMakeLogsPrivate] = useState(false);

  const [archiveTypeValue, setArchiveTypeValue] = useState("Zip");
  const radioButtonsArray = [
    { label: "RAR", value: "RAR" },
    { label: "Zip", value: "Zip" },
  ];

  const [folderSelection, setFolderSelection] = useState("C://Documents");
  const [zipFileDestination, setZipFileDestination] = useState("C://Documents");
  const [zipFileName, setZipFileName] = useState("");
  const [encryptionMethod, setEncryptionMethod] = useState("");
  const [applyPassword, setApplyPassword] = useState("");
  const [applyPasswordCheckbox, setApplyPasswordCheckbox] = useState(false);

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setMakeLogsPrivate(!makeLogsPrivate);
        break;
      case "ArchiveType":
        setArchiveTypeValue(value);
        break;
      case "ApplyPassword":
        setApplyPassword(value);
        break;
      case "ApplyPasswordCheckbox":
        setApplyPasswordCheckbox(!applyPasswordCheckbox);
        break;
      case "ZipFileDestination":
        setZipFileDestination(value);
        break;
      case "ZipFileName":
        setZipFileName(value);
        break;
      case "FolderSelection":
        setFolderSelection(value);
        break;
      case "EncryptionMethod":
        setEncryptionMethod(value);
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={makeLogsPrivate}
        ActivityIcon={WebAsset}
        helperText="Compresses files"
      />
      <div className={classes.scrollDiv}>
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              INPUT
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              radio={true}
              ButtonsArray={radioButtonsArray}
              name="ArchiveType"
              label="Archive Type"
              value={archiveTypeValue}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              dropdown={true}
              btnIcon={
                <FolderOpen
                  className={classes.btnIcon + " " + classes.colorPrimary}
                />
              }
              name="FolderSelection"
              label="Folder Selection"
              value={folderSelection}
              options={ExcelFilePathOptions}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              dropdown={true}
              btnIcon={
                <FolderOpen
                  className={classes.btnIcon + " " + classes.colorPrimary}
                />
              }
              name="ZipFileDestination"
              label="Zip File Destination"
              value={zipFileDestination}
              options={ExcelFilePathOptions}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="ZipFileName"
              label="Zip File Name"
              value={zipFileName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              labelBtnDisabled={true}
              labelWithCheckbox={true}
              labelCheckboxName="ApplyPasswordCheckbox"
              labelCheckboxValue={applyPasswordCheckbox}
              name="ApplyPassword"
              label="Apply Password"
              value={applyPassword}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              dropdown={true}
              name="EncryptionMethod"
              label="Encryption Method"
              value={encryptionMethod}
              options={EncryptionMethodOptions}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
      </div>
    </div>
  );
};

export default CompressFileWindow;
const ExcelFilePathOptions = [
  { name: "C://Documents/Excel", value: "C://Documents/Excel" },
  { name: "Sheetlist", value: "Sheetlist" },
  { name: "C://Documents", value: "C://Documents" },
  { name: "D://Documents/Excel", value: "D://Documents/Excel" },
];

const EncryptionMethodOptions = [
  { name: "ENC_Method_AES(default)", value: "ENC_Method_AES(default)" },
  { name: "ENC_Method2_AES", value: "ENC_Method2_AES" },
];
