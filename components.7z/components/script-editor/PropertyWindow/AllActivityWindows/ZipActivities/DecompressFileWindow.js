import React, { useState } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";

const DecompressFileWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity } = props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [makeLogsPrivate, setMakeLogsPrivate] = useState(false);

  const [archiveTypeValue, setArchiveTypeValue] = useState("Zip");
  const radioButtonsArray = [
    { label: "RAR", value: "RAR" },
    { label: "Zip", value: "Zip" },
  ];

  const [zipFileSelection, setZipFileSelection] = useState("C://Documents");
  const [extractFolderLocation, setExtractFolderLocation] = useState(
    "C://Documents/Decompress"
  );
  const [password, setPassword] = useState("");
  const [passwordCheckbox, setApplyPasswordCheckbox] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setMakeLogsPrivate(!makeLogsPrivate);
        break;
      case "ArchiveType":
        setArchiveTypeValue(value);
        break;
      case "Password":
        setPassword(value);
        break;
      case "PasswordCheckbox":
        setApplyPasswordCheckbox(!passwordCheckbox);
        break;
      case "ZipFileSelection":
        setZipFileSelection(value);
        break;

      case "ExtractFolderLocation":
        setExtractFolderLocation(value);
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={makeLogsPrivate}
        ActivityIcon={WebAsset}
        helperText="Decompresses files"
      />
      <div className={classes.scrollDiv}>
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              INPUT
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              radio={true}
              ButtonsArray={radioButtonsArray}
              name="ArchiveType"
              label="Archive Type"
              value={archiveTypeValue}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              dropdown={true}
              btnIcon={
                <FolderOpen
                  className={classes.btnIcon + " " + classes.colorPrimary}
                />
              }
              name="ZipFileSelection"
              label="Zip File Selection"
              value={zipFileSelection}
              options={ExcelFilePathOptions}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              dropdown={true}
              btnIcon={
                <FolderOpen
                  className={classes.btnIcon + " " + classes.colorPrimary}
                />
              }
              name="ExtractFolderLocation"
              label="Extract Folder Location"
              value={extractFolderLocation}
              options={ExcelFilePathOptions}
              onChange={handleChange}
            />
          </Grid>

          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              labelBtnDisabled={true}
              labelWithCheckbox={true}
              labelCheckboxName="passwordCheckbox"
              labelCheckboxValue={passwordCheckbox}
              name="Password"
              label="Password(If given in zip file)"
              value={password}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
      </div>
    </div>
  );
};

export default DecompressFileWindow;
const ExcelFilePathOptions = [
  { name: "C://Documents/Excel", value: "C://Documents/Excel" },
  { name: "C://Documents/Decompress", value: "C://Documents/Decompress" },
  { name: "C://Documents", value: "C://Documents" },
  { name: "D://Documents/Excel", value: "D://Documents/Excel" },
];
