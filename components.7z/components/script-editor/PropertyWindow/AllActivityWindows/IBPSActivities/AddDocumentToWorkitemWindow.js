import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { AddBox, Folder, Email } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const AddDocumentToWorkitemWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;

  const [activityName, setActivityName] = useState(
    selectedActivity ? selectedActivity.displayName : ""
  );

  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [documentIndex, setDocumentIndex] = useState(
    mapFieldObjWithValueByName(params, "DocumentIndex", "")
  );
  const [documentName, setDocumentName] = useState(
    mapFieldObjWithValueByName(params, "DocumentName", "")
  );
  const [sessionId, setSessionId] = useState(
    mapFieldObjWithValueByName(params, "SessionId", "")
  );
  const [volumeId, setVolumeId] = useState(
    mapFieldObjWithValueByName(params, "VolumeId", "")
  );
  const [documentPath, setDocumentPath] = useState(
    mapFieldObjWithValueByName(params, "DocumentPath", "")
  );
  const [parentFolderIndex, setParentFolderIndex] = useState(
    mapFieldObjWithValueByName(params, "ParentFolderIndex", "")
  );
  const [statusCode, setStatusCode] = useState(
    mapFieldObjWithValueByName(params, "StatusCode", "")
  );
  const [statusMessage, setStatusMessage] = useState(
    mapFieldObjWithValueByName(params, "StatusMessage", "")
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setDocumentIndex(mapFieldObjWithValueByName(params, "DocumentIndex", ""));
    setDocumentName(mapFieldObjWithValueByName(params, "DocumentName", ""));

    setSessionId(mapFieldObjWithValueByName(params, "SessionId", ""));
    setVolumeId(mapFieldObjWithValueByName(params, "VolumeId", ""));
    setDocumentPath(mapFieldObjWithValueByName(params, "DocumentPath", ""));
    setParentFolderIndex(
      mapFieldObjWithValueByName(params, "ParentFolderIndex", "")
    );

    setStatusCode(mapFieldObjWithValueByName(params, "StatusCode", ""));
    setStatusMessage(mapFieldObjWithValueByName(params, "StatusMessage", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    documentIndex,
    documentName,
    sessionId,
    volumeId,
    documentPath,
    parentFolderIndex,
    statusCode,
    statusMessage,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      documentIndex,
      documentName,
      sessionId,
      volumeId,
      documentPath,
      parentFolderIndex,
      statusCode,
      statusMessage,
    ];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "DocumentPath":
        setDocumentPath((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ParentFolderIndex":
        setParentFolderIndex((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;

      case "VolumeId":
        setVolumeId((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "SessionId":
        setSessionId((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "DocumentIndex":
        setDocumentIndex((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "DocumentName":
        setDocumentName((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusCode":
        setStatusCode((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusMessage":
        setStatusMessage((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "DocumentPath":
        setDocumentPath({ ...documentPath, paramType: changeToValue });
        break;
      case "ParentFolderIndex":
        setParentFolderIndex({
          ...parentFolderIndex,
          paramType: changeToValue,
        });
        break;

      case "VolumeId":
        setVolumeId({ ...volumeId, paramType: changeToValue });
        break;
      case "SessionId":
        setSessionId({ ...sessionId, paramType: changeToValue });
        break;
      case "DocumentIndex":
        setDocumentIndex({ ...documentIndex, paramType: changeToValue });
        break;

      case "DocumentName":
        setDocumentName({ ...documentName, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || "Add Documents"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DocumentPath`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={documentPath.paramType === "V"}
                paramObj={documentPath}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                btnIcon={
                  <Folder
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="DocumentPath"
                label="Document Path"
                value={documentPath.paramValue}
                options={getOptionsForVariable(documentPath)}
                onChange={handleChange}
                error={
                  vaildateParamValue(documentPath.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(documentPath.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={documentName.paramType === "V"}
                paramObj={documentName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="DocumentName"
                label="Document Name"
                value={documentName.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(documentName)}
                error={
                  vaildateParamValue(documentName.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(documentName.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DocumentIndex`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={documentIndex.paramType === "V"}
                paramObj={documentIndex}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="DocumentIndex"
                label="Document Index"
                value={documentIndex.paramValue}
                options={getOptionsForVariable(documentIndex)}
                onChange={handleChange}
                error={
                  vaildateParamValue(documentIndex.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(documentIndex.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_ParentFolderIndex`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={parentFolderIndex.paramType === "V"}
                paramObj={parentFolderIndex}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                btnIcon={
                  <Folder
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="ParentFolderIndex"
                label="Parent Folder Index"
                value={parentFolderIndex.paramValue}
                options={getOptionsForVariable(parentFolderIndex)}
                onChange={handleChange}
                error={
                  vaildateParamValue(parentFolderIndex.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(parentFolderIndex.paramValue.toString())
                    .msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SessionId`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={sessionId.paramType === "V"}
                paramObj={sessionId}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="SessionId"
                label="Session Id"
                value={sessionId.paramValue}
                options={getOptionsForVariable(sessionId)}
                onChange={handleChange}
                error={
                  vaildateParamValue(sessionId.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(sessionId.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_VolumeId`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={volumeId.paramType === "V"}
                paramObj={volumeId}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="VolumeId"
                label="Volume Id"
                value={volumeId.paramValue}
                options={getOptionsForVariable(volumeId)}
                onChange={handleChange}
                error={
                  vaildateParamValue(volumeId.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(volumeId.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusCode`}
                combo={true}
                dropdown={true}
                paramObj={statusCode}
                btnIcon={
                  <AddBox
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                //label="Status Code"
                label={`Status Code (${getVariableTypeById(
                  statusCode.paramObjectTypeId
                )})`}
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                error={
                  vaildateParamValue(statusCode.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusCode.paramValue.toString()).msg
                }
                //helperText="Select or add a int type variable"
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusMsg`}
                combo={true}
                dropdown={true}
                paramObj={statusMessage}
                btnIcon={
                  <AddBox
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusMessage"
                label={`Status Message (${getVariableTypeById(
                  statusMessage.paramObjectTypeId
                )})`}
                value={statusMessage.paramValue}
                options={getOptionsForVariable(statusMessage)}
                onChange={handleChange}
                // helperText="Select or add a char type variable"
                error={
                  vaildateParamValue(statusMessage.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusMessage.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default AddDocumentToWorkitemWindow;
