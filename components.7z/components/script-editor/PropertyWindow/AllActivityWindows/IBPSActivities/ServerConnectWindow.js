import React, { useState, useContext, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import { iBPSContext } from "./../../../../../contexts/iBPSContext";
import { createInstance } from "../../../../../utils/common";
import { OMNIFLOW, CONNECT } from "./../../../../../config/index";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { getEncryptedString } from "../../../../../utils/encryptions";

const ServerConnectWindow = (props) => {
  const classes = useStyles();

  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;

  const { params } = selectedActivity;
  console.log(params);

  const { setValue: setNotification } = useContext(NotificationContext);

  const { iBPSValues, setAlliBPSValues } = useContext(iBPSContext);

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [serverURL, setServerURL] = useState(
    mapFieldObjWithValueByName(params, "ServerUrl", "")
  );
  const [cabinetName, setCabinetName] = useState(
    mapFieldObjWithValueByName(params, "CabinetName", "")
  );

  const [username, setUsername] = useState(
    mapFieldObjWithValueByName(params, "UserName", "")
  );

  const [pwd, setPwd] = useState(
    mapFieldObjWithValueByName(params, "Password", "")
  );

  const [sessionId, setSessionId] = useState(
    mapFieldObjWithValueByName(params, "SessionId", "")
  );

  const [volumeId, setVolumeId] = useState(
    mapFieldObjWithValueByName(params, "VolumeId", "")
  );

  const [statusCode, setStatusCode] = useState(
    mapFieldObjWithValueByName(params, "StatusCode", "")
  );

  const [statusMessage, setStatusMessage] = useState(
    mapFieldObjWithValueByName(params, "StatusMessage", "")
  );

  const [isConnecting, setIsConnecting] = useState(false);
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));

    setPwd(mapFieldObjWithValueByName(params, "Password", ""));
    setServerURL(mapFieldObjWithValueByName(params, "ServerUrl", ""));
    setCabinetName(mapFieldObjWithValueByName(params, "CabinetName", ""));
    setUsername(mapFieldObjWithValueByName(params, "UserName", ""));
    setSessionId(mapFieldObjWithValueByName(params, "SessionId", ""));
    setVolumeId(mapFieldObjWithValueByName(params, "VolumeId", ""));
    setStatusCode(mapFieldObjWithValueByName(params, "StatusCode", ""));
    setStatusMessage(mapFieldObjWithValueByName(params, "StatusMessage", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "ServerURL":
        setServerURL((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "CabinetName":
        setCabinetName((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "SessionId":
        setSessionId((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "VolumeId":
        setVolumeId((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Username":
        setUsername((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Password":
        setPwd((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "StatusCode":
        setStatusCode((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusMessage":
        setStatusMessage((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const handleConnect = async () => {
    setIsConnecting(true);
    const axiosInstance = createInstance();

    try {
      let inputBody = {
        serverUrl: serverURL.paramValue,
        userName: username.paramValue,
        userAuthKey: pwd.paramValue,
        cabinetName: cabinetName.paramValue,
      };
      let response = await axiosInstance.post(`${OMNIFLOW}${CONNECT}`, {
        ...inputBody,
      });

      if (response.status === 200) {
        setIsConnecting(false);
        const ibpsKey =
          response.data && response.data.NGOConnectCabinet_Output?.UserDBId;
        //   const encryptedK = getEncryptedString("" + ibpsKey);
        // sessionStorage.setItem("iBPS-key", encryptedK);
        setNotification({
          isOpen: true,
          title: "iBPS",
          message: "server connected successfully.",
          notificationType: "SUCCESS",
        });
        setAlliBPSValues({
          ...iBPSValues,
          serverUrl: serverURL.paramValue,
          cabinetName: cabinetName.paramValue,
          sessionId: ibpsKey,
        });
      }
    } catch (error) {
      setIsConnecting(false);
      if (error.response && error.response.status === 500) {
        setNotification({
          isOpen: true,
          title: "iBPS",
          message: error.response.data,
          notificationType: "ERROR",
        });
        /*
        Bug 144111 - Unable to connect to OmniDocs Server + Wrong Error message displayed(JSONObject["NGOConnectCabinet_Output"] not found.)
        @nitin_tomar
        Date: 27 FEB 2024
        added one more conditon to display correct error message
        */
      } else if(error.response && error.response.status === 400){
        setNotification({
          isOpen: true,
          title: "iBPS",
          message: error.response.data,
          notificationType: "ERROR",
        });
      }else if (
        error.response &&
        error.response.data &&
        error.response.data.NGOConnectCabinet_Output
      ) {
        /*  const { Exception } =
          error.response.data.NGOConnectCabinet_Output.Error;
        const errorMessage = Exception.Description
          ? Exception.Description
          : Exception.Subject;*/
        const errorMessage = error.response.data.NGOConnectCabinet_Output.Error;
        setNotification({
          isOpen: true,
          title: "iBPS",
          message: errorMessage,
          notificationType: "ERROR",
        });
      } else if (error.response && error.response.data) {
        const errorMessage = error.response.data.errorMessage;
        setNotification({
          isOpen: true,
          title: "iBPS",
          message: errorMessage,
          notificationType: "ERROR",
        });
      } else {
        setNotification({
          isOpen: true,
          title: "iBPS",
          message: "Network error",
          notificationType: "ERROR",
        });
      }
    }
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    pwd,
    serverURL,
    username,
    cabinetName,
    statusCode,
    statusMessage,
    volumeId,
    sessionId,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,

      pwd,
      serverURL,
      username,
      cabinetName,
      statusCode,
      statusMessage,
      volumeId,
      sessionId,
    ];
    addParamsToSelAct(allParams);
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ServerURL":
        setServerURL({ ...serverURL, paramType: changeToValue });
        break;
      case "CabinetName":
        setCabinetName({ ...cabinetName, paramType: changeToValue });
        break;
      case "Username":
        setUsername({ ...username, paramType: changeToValue });
        break;
      case "Password":
        setPwd({ ...pwd, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || "Connect to Newgen Server"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_ServerURL`}
                combo={true}
                dropdown={serverURL.paramType === "V"}
                paramObj={serverURL}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(serverURL)}
                labelBtn1={true}
                labelBtn2={true}
                name="ServerURL"
                label="Server URL"
                value={serverURL.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(serverURL.paramValue).errorStatus}
                helperText={vaildateParamValue(serverURL.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_CabinetName`}
                combo={true}
                dropdown={cabinetName.paramType === "V"}
                paramObj={cabinetName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(cabinetName)}
                labelBtn1={true}
                labelBtn2={true}
                name="CabinetName"
                label="Cabinet Name"
                value={cabinetName.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(cabinetName.paramValue).errorStatus}
                helperText={vaildateParamValue(cabinetName.paramValue).msg}
              />
            </Grid>
            {/* <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Port"
              label="Port"
              value={port}
              onChange={handleChange}
            />
         </Grid>*/}
            <Grid item>
              <PropertyField
                id={`${props.id}_Username`}
                combo={true}
                dropdown={username.paramType === "V"}
                paramObj={username}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(username)}
                labelBtn1={true}
                labelBtn2={true}
                name="Username"
                label="Username"
                value={username.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(username.paramValue).errorStatus}
                helperText={vaildateParamValue(username.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Password`}
                combo={true}
                dropdown={pwd.paramType === "V"}
                paramObj={pwd}
                secret={true}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(pwd)}
                labelBtn1={true}
                labelBtn2={true}
                name="Password"
                label="Password"
                value={pwd.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(pwd.paramValue).errorStatus}
                helperText={vaildateParamValue(pwd.paramValue).msg}
              />
            </Grid>
            {/*<Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Process"
              label="Process"
              value={process}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Queue"
              label="Queue"
              value={queue}
              onChange={handleChange}
            />
          </Grid>*/}

            <Grid item>
              {isConnecting ? (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleConnect()}
                  id={`${props.id}_ConnectingBtn`}
                >
                  <CircularProgress
                    // color="#FFFFFF"
                    style={{
                      height: "15px",
                      width: "15px",
                      marginRight: "8px",
                      color:"#FFFFFF"
                    }}
                  ></CircularProgress>{" "}
                  <Typography className={classes.btn_title}>
                    Connecting..
                  </Typography>
                </Button>
              ) : (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleConnect()}
                  id={`${props.id}_ConnectBtn`}
                >
                  <Typography className={classes.btn_title}>Connect</Typography>
                </Button>
              )}
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_StatusCode`}
                combo={true}
                dropdown={true}
                paramObj={statusCode}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                label={`Status Code (${getVariableTypeById(
                  statusCode.paramObjectTypeId
                )})`}
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                // helperText="Select or add an string type variable"
                error={vaildateParamValue(statusCode.paramValue).errorStatus}
                helperText={vaildateParamValue(statusCode.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusMsg`}
                combo={true}
                dropdown={true}
                paramObj={statusMessage}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusMessage"
                label={`Status Message (${getVariableTypeById(
                  statusMessage.paramObjectTypeId
                )})`}
                value={statusMessage.paramValue}
                options={getOptionsForVariable(statusMessage)}
                onChange={handleChange}
                error={vaildateParamValue(statusMessage.paramValue).errorStatus}
                helperText={vaildateParamValue(statusMessage.paramValue).msg}
                //  helperText="Select or add a string type variable"
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SessionId`}
                combo={true}
                dropdown={true}
                paramObj={sessionId}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="SessionId"
                label={`SessionId (${getVariableTypeById(
                  sessionId.paramObjectTypeId
                )})`}
                value={sessionId.paramValue}
                options={getOptionsForVariable(sessionId)}
                onChange={handleChange}
                // helperText="Select or add an string type variable"
                error={vaildateParamValue(sessionId.paramValue).errorStatus}
                helperText={vaildateParamValue(sessionId.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_VolumeId`}
                combo={true}
                dropdown={true}
                paramObj={volumeId}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="VolumeId"
                label={`VolumeId (${getVariableTypeById(
                  volumeId.paramObjectTypeId
                )})`}
                value={volumeId.paramValue}
                options={getOptionsForVariable(volumeId)}
                onChange={handleChange}
                //  helperText="Select or add an string type variable"
                error={vaildateParamValue(volumeId.paramValue).errorStatus}
                helperText={vaildateParamValue(volumeId.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </>
  );
};

export default ServerConnectWindow;
