import React, { useState, useContext, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Button, Grid, Typography } from "@mui/material";
import VariableMapping from "./VariableMapping";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
  getAllOptions,
  getVariableTypeById,
  handeParseValuesForVarType,
} from "./../Common/CommonMethods";
import { iBPSContext } from "./../../../../../contexts/iBPSContext";
import { MappedVarContext } from "./../../../../../contexts/MappedVarContext";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import {
  setSelectedTab,
  setErrorType,
  setAllMappedDocuments,
} from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { createInstance } from "../../../../../utils/common";
import { OMNIFLOW } from "./../../../../../config/index";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { getDecryptedString } from "../../../../../utils/encryptions";

const CreateWorkitemWindow = (props) => {
  const classes = useStyles();
  const {
    selectedActivity,
    handleOpenModal,
    addParamsToSelAct,
    updateDisplayNameSelAct,
  } = props;
  const [activityName, setActivityName] = useState(
    selectedActivity ? selectedActivity.displayName : ""
  );

  const { params } = selectedActivity;
  const allOptions = getAllOptions();
  const { iBPSValues, setAlliBPSValues } = useContext(iBPSContext);
  const { mappedVarState, setAllMappedVariables } =
    useContext(MappedVarContext);
  const { allMappedVariables } = mappedVarState;

  const { setValue: setNotification } = useContext(NotificationContext);

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const allMappedDocuments = useSelector(
    (state) => state.editorHomepage.allMappedDocuments
  );
  const dispatch = useDispatch();

  //getting mapped variables
  const [varMapData, setVarMapData] = useState(
    mapFieldObjWithValueByName(params, "variableMap", "")
  );
  const [varMapDataValue, setVarMapDataValue] = useState(null);

  //getting mapped document variables
  const [docMapData, setDocMapData] = useState(
    mapFieldObjWithValueByName(params, "docMap", "")
  );
  const [docMapDataValue, setDocMapDataValue] = useState(null);
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [processObj, setProcessObj] = useState(
    mapFieldObjWithValueByName(params, "processId", "")
  );
  const [process, setProcess] = useState({});
  const [queueObj, setQueueObj] = useState(
    mapFieldObjWithValueByName(params, "queueId", "")
  );
  const [queue, setQueue] = useState({});

  const [allDocuments, setAllDocuments] = useState([]);

  const [statusCode, setStatusCode] = useState(
    mapFieldObjWithValueByName(params, "StatusCode", "")
  );

  const [statusMessage, setStatusMessage] = useState(
    mapFieldObjWithValueByName(params, "StatusMessage", "")
  );
  const [processesList, setProcessesList] = useState([]);
  const [queueList, setQueueList] = useState([]);
  useEffect(() => {
    if (varMapData.paramValue) {
      const varMapDataValueObj = JSON.parse(varMapData.paramValue);
      if (typeof varMapDataValueObj === "object") {
        let newArray = Object.keys(varMapDataValueObj).map((key) => {
          return {
            attrName: key,
            RPAVar: varMapDataValueObj[key]?.RPAVar || "",
            attrType: varMapDataValueObj[key]?.attrType || "",
          };
        });

        setVarMapDataValue(newArray);
      }
    } else {
      setVarMapDataValue([]);
    }
  }, [varMapData]);

  useEffect(() => {
    if (varMapDataValue) {
      setAllMappedVariables({
        allMappedVariables: [...varMapDataValue],
      });
    }
  }, [varMapDataValue]);

  useEffect(() => {
    if (docMapData.paramValue) {
      const doc = JSON.parse(docMapData.paramValue);

      if (typeof doc === "object") {
        /* let newArray = Object.keys(doc).map((key) => {
          return {
            docType: key,
            docPath: doc[key],
          };
        });*/
        let newArray = handeParseValuesForVarType({
          stringyfiedObject: docMapData.paramValue,
        });

        newArray = newArray.map((item) => ({
          docPath: item.value,
          docType: item.key,
          valueType: item.paramType,
        }));

        setDocMapDataValue(newArray);
      }
    } else {
      setDocMapDataValue([]);
    }
  }, [docMapData]);
  useEffect(() => {
    if (docMapDataValue) {
      dispatch(setAllMappedDocuments([...docMapDataValue]));
    }
  }, [docMapDataValue]);

  useEffect(() => {
    if (processObj.paramValue) {
      const prs = JSON.parse(processObj.paramValue);
      if (prs) {
        setProcess(prs);
      }
    } else {
      setProcess({});
    }
  }, [processObj]);

  useEffect(() => {
    if (queueObj.paramValue) {
      const prs = JSON.parse(queueObj.paramValue);

      if (prs) {
        setQueue(prs);
      }
    } else {
      setQueue({});
    }
  }, [queueObj]);

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setProcessObj(mapFieldObjWithValueByName(params, "processId", ""));
    setQueueObj(mapFieldObjWithValueByName(params, "queueId", ""));
    setStatusCode(mapFieldObjWithValueByName(params, "StatusCode", ""));
    setStatusMessage(mapFieldObjWithValueByName(params, "StatusMessage", ""));
    setVarMapData(mapFieldObjWithValueByName(params, "variableMap", ""));
    setDocMapData(mapFieldObjWithValueByName(params, "docMap", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "MappedToTop":
        setMappedToTop({ ...mappedToTop, value: checked });
        break;
      case "Process":
        const processVal = processesList.find((proc) => proc.value == value);

        setProcess(processVal || {});
        setQueue({});
        break;
      case "Queue":
        const queueVal = queueList.find((que) => que.value == value);

        setQueue(queueVal || {});
        break;
      case "StatusCode":
        setStatusCode((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusMessage":
        setStatusMessage((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [mappedToTop, setMappedToTop] = useState(
    makingCheckboxFields("MappedToTop", false, "Mapped to Top")
  );

  const handleMapVariables = () => {
    if (process?.value && queue?.value) {
      setAlliBPSValues({
        ...iBPSValues,
        processName: process?.name || "",
        queueName: queue?.name || "",
      });
      handleOpenModal("ProcessVariables");
    } else {
      setNotification({
        isOpen: true,
        title: "Error:",
        message: "please provide process name and queue.",
        notificationType: "ERROR",
      });
    }
  };
  const handleMapDocuments = () => {
    if (process?.value && queue?.value) {
      setAlliBPSValues({
        ...iBPSValues,
        processName: process?.name || "",
        queueName: queue?.name || "",
      });
      handleOpenModal("DocumentsVariables");
    } else {
      setNotification({
        isOpen: true,
        title: "Error:",
        message: "please provide process name and queue.",
        notificationType: "ERROR",
      });
    }
  };
  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    process,
    queue,
    statusCode,
    statusMessage,
    allMappedVariables,
    allMappedDocuments,
  ]);

  const updateParams = () => {
    const mappedVars = {};
    allMappedVariables.forEach((obj) => {
      if (obj.attrName && obj.RPAVar) {
        mappedVars[obj.attrName] = {
          RPAVar: obj.RPAVar,
          attrType: obj.attrType,
        };
      }
    });

    const newVarMapData = {
      ...varMapData,

      paramValue: JSON.stringify(mappedVars),
    };

    let mappedDocs = {};
    if (allMappedDocuments.length > 0) {
      mappedDocs = allMappedDocuments.reduce(
        (obj, item) =>
          Object.assign(
            obj,
            item.docType &&
              item.docPath && {
                [item.docType]:
                  item.valueType === "C"
                    ? item.docPath
                    : "${" + `${item.docPath}` + "}",
              }
          ),
        {}
      );
    }

    const newDocMapData = {
      ...docMapData,
      paramValue: JSON.stringify(mappedDocs),
    };
    const newProcess = {
      ...processObj,
      paramType: "C",
      paramValue: JSON.stringify(process),
    };
    const newQueue = {
      ...queueObj,
      paramType: "C",
      paramValue: JSON.stringify(queue),
    };
    const allParams = [
      invisibleInLogs,
      newQueue,
      newProcess,
      statusCode,
      newVarMapData,
      newDocMapData,
      statusMessage,
    ];

    addParamsToSelAct(allParams);
  };

  const getAllProcess = async () => {
    const axiosInstance = createInstance();
    setProcessObj({ ...processObj, paramType: "V" });
    setQueueObj({ ...queueObj, paramType: "V" });

    const { serverUrl, cabinetName, sessionId } = iBPSValues;
    //const sessionId = getDecryptedString(sessionStorage.getItem("iBPS-key"));

    const res = await axiosInstance.post(`${OMNIFLOW}/process`, {
      serverUrl,
      cabinetName,
      userSessionId: sessionId,
    });

    const output = JSON.parse(res.data.data[0])?.WMGetProcessList_Output || {};
    const processList1 = output["ProcessList"] || {};

    const processInfoArr = processList1["ProcessInfo"] || [];

    if (processInfoArr instanceof Array) {
      const newProcessesList = processInfoArr.map((item) => {
        return { name: item.Name, value: item.ID };
      });
      setProcessesList(newProcessesList);
    } else {
      setProcessesList([
        { name: processInfoArr["Name"], value: processInfoArr["ID"] },
      ]);
    }
  };
  const getQueues = async () => {
    const { serverUrl, cabinetName, sessionId } = iBPSValues;
    // const ibpskey = getDecryptedString(sessionStorage.getItem("iBPS-key"));
    const axiosInstance = createInstance();
    const id = process?.value || null;
    if (id) {
      const process1 = processesList.find((proc) => proc.value === id);
      const res = await axiosInstance.post(`${OMNIFLOW}/queue`, {
        serverUrl,
        cabinetName,
        userSessionId: sessionId,
        processId: process1?.value || "",
      });

      const output = JSON.parse(res.data.data[0])?.WMGetQueueList_Output || {};

      const queueList1 = output["QueueList"] || {};

      const queueInfoArr = queueList1["QueueInfo"] || [];

      const newQueueList = queueInfoArr.map((item) => {
        return { name: item.Name, value: item.ID };
      });
      setQueueList(newQueueList);
    }
  };
  useEffect(() => {
    if (processesList.length > 0) {
      getQueues();
    }
  }, [processObj, process]);

  return (
    <>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={
          selectedActivity.activityId === 106
            ? "Get Workitem"
            : "Create Workitem in IBPS"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <Grid item container spacing={1} alignItems="flex-end">
                <Grid item xs>
                  <PropertyField
                    id={`${props.id}_Process`}
                    dropdown={processObj.paramType === "V"}
                    btnIcon={
                      <Button
                        color="primary"
                        variant="contained"
                        size="small"
                        onClick={() => getAllProcess()}
                        style={{ height: "24px" }}
                        id={`${props.id}_GetProcessBtn`}
                        disableRipple
                      >
                        <Typography className={classes.btn_title}>
                          Get processes
                        </Typography>
                      </Button>
                    }
                    btnIconDefaultHandler={true}
                    name="Process"
                    label="Process"
                    value={
                      (processesList.length > 0
                        ? process?.value
                        : process?.name) || ""
                    }
                    onChange={handleChange}
                    options={processesList}
                    error={vaildateParamValue(process?.name || "").errorStatus}
                    helperText={vaildateParamValue(process?.name || "").msg}
                  />
                </Grid>
              </Grid>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Queue`}
                combo={true}
                dropdown={queueObj.paramType === "V"}
                name="Queue"
                label="Queue"
                value={
                  (queueList.length > 0 ? queue?.value : queue?.name) || ""
                }
                onChange={handleChange}
                options={queueList}
                error={
                  vaildateParamValue(
                    (queueList.length > 0 ? queue?.value : queue?.name) || ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    (queueList.length > 0 ? queue?.value : queue?.name) || ""
                  ).msg
                }
              />
            </Grid>
            <Grid item>
              <VariableMapping
                id={props.id}
                //  documentsArray={allDocuments}
                // mappedToTop={mappedToTop}
                //onMapColumn={mapColumnWithDocument}
                allVariables={allOptions || []}
                mappedVar={allMappedVariables}
                //mappedDocs={allMappedDocuments}
                handleMapVariables={handleMapVariables}
                handleMapDocuments={handleMapDocuments}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusCode`}
                combo={true}
                dropdown={true}
                paramObj={statusCode}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                label={`Status Code (${getVariableTypeById(
                  statusCode.paramObjectTypeId
                )})`}
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                error={
                  vaildateParamValue(statusCode.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusCode.paramValue.toString()).msg
                }
                // helperText="Select or add a int type variable"
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusMsg`}
                combo={true}
                dropdown={true}
                paramObj={statusMessage}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusMessage"
                label={`Status Message (${getVariableTypeById(
                  statusMessage.paramObjectTypeId
                )})`}
                value={statusMessage.paramValue}
                options={getOptionsForVariable(statusMessage)}
                onChange={handleChange}
                error={
                  vaildateParamValue(statusMessage.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusMessage.paramValue.toString()).msg
                }
                // helperText="Select or add a char type variable"
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </>
  );
};

export default CreateWorkitemWindow;
