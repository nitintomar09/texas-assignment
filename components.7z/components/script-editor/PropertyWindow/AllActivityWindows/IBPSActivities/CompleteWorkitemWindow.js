import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import VariableMapping from "./VariableMapping";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
  getAllOptions,
  getVariableTypeById,
  handeParseValuesForVarType,
} from "./../Common/CommonMethods";
import { MappedVarContext } from "./../../../../../contexts/MappedVarContext";
import {
  setSelectedTab,
  setErrorType,
  setAllMappedDocuments,
} from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const CompleteWorkitemWindow = (props) => {
  const classes = useStyles();
  const {
    selectedActivity,
    handleOpenModal,
    updateDisplayNameSelAct,
    addParamsToSelAct,
  } = props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const { mappedVarState, setAllMappedVariables } =
    useContext(MappedVarContext);
  const { allMappedVariables } = mappedVarState;

  const allMappedDocuments = useSelector(
    (state) => state.editorHomepage.allMappedDocuments
  );

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  /*const [attributeValue, setAttributValue] = useState("");
  const [dataClassAttributes, setDataClassAttributes] = useState("");
  const [sessionId, setSessionId] = useState("");
  const [workitemId, setWorkitemId] = useState("");

  const [workitemName, setWorkitemName] = useState("");
*/
  const [allDocuments, setAllDocuments] = useState([]);

  const [statusCode, setStatusCode] = useState("");

  const [statusMessage, setStatusMessage] = useState("");
  const allOptions = getAllOptions();

  //getting mapped variables
  const [varMapData, setVarMapData] = useState(
    mapFieldObjWithValueByName(params, "variableMap", "")
  );
  const [varMapDataValue, setVarMapDataValue] = useState(null);

  //getting mapped docs
  const [docMapData, setDocMapData] = useState(
    mapFieldObjWithValueByName(params, "docMap", "")
  );
  const [docMapDataValue, setDocMapDataValue] = useState(null);

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setVarMapData(mapFieldObjWithValueByName(params, "variableMap", ""));
    setDocMapData(mapFieldObjWithValueByName(params, "docMap", ""));
    setStatusCode(mapFieldObjWithValueByName(params, "StatusCode", ""));
    setStatusMessage(mapFieldObjWithValueByName(params, "StatusMessage", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);
  {
    /* useEffect(() => {
    if (varMapData.paramValue) {
      const varMapDataValueObj = JSON.parse(varMapData.paramValue);
      if (typeof varMapDataValueObj === "object") {
        let newArray = Object.keys(varMapDataValueObj).map((key) => {
          return {
            SystemDefinedName: key,
            RPAVar: varMapDataValueObj[key],
          };
        });

        setVarMapDataValue(newArray);
      }
    } else {
      setVarMapDataValue([]);
    }
  }, [varMapData]);*/
  }
  useEffect(() => {
    if (varMapData.paramValue) {
      const varMapDataValueObj = JSON.parse(varMapData.paramValue);
      if (typeof varMapDataValueObj === "object") {
        let newArray = Object.keys(varMapDataValueObj).map((key) => {
          return {
            attrName: key,
            RPAVar: varMapDataValueObj[key]?.RPAVar || "",
            attrType: varMapDataValueObj[key]?.attrType || "",
          };
        });

        setVarMapDataValue(newArray);
      }
    } else {
      setVarMapDataValue([]);
    }
  }, [varMapData]);
  useEffect(() => {
    if (varMapDataValue) {
      setAllMappedVariables({
        allMappedVariables: [...varMapDataValue],
      });
    }
  }, [varMapDataValue]);

  {
    /*} useEffect(() => {
    if (docMapData.paramValue) {
      const docMapDataValueObj = JSON.parse(docMapData.paramValue);
      if (typeof docMapDataValueObj === "object") {
        let newArray = Object.keys(docMapDataValueObj).map((key, index) => {
          return {
            documentType: key,
            columnValue: docMapDataValueObj[key],
            id: index,
          };
        });

        setAllDocuments(newArray);
      }
    } else {
      setAllDocuments([]);
    }
  }, [varMapData]);*/
  }
  useEffect(() => {
    if (docMapData.paramValue) {
      // console.log(JSON.parse(docMapData.paramValue));
      const doc = JSON.parse(docMapData.paramValue);
      if (typeof doc === "object") {
        /*  let newArray = Object.keys(doc).map((key) => {
          return {
            docPath: key,
            docIndex: doc[key],
          };
        });*/
        // console.log(newArray);
        let newArray = handeParseValuesForVarType({
          stringyfiedObject: docMapData.paramValue,
        });
        newArray = newArray.map((item) => ({
          docPath: item.value,
          docType: item.key,
          valueType: item.paramType,
        }));
        setDocMapDataValue(newArray);
      }
    } else {
      setDocMapDataValue([]);
    }
  }, [docMapData]);
  useEffect(() => {
    if (docMapDataValue) {
      dispatch(setAllMappedDocuments([...docMapDataValue]));
    }
  }, [docMapDataValue]);

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      /*  case "AttributValue":
        setAttributValue(value);
        break;*/
      case "MappedToTop":
        setMappedToTop({ ...mappedToTop, value: checked });
        break;

      /*  case "DataClassAttributes":
        setDataClassAttributes(value);
        break;
      case "SessionId":
        setSessionId(value);
        break;
      case "WorkitemName":
        setWorkitemName(value);
        break;
      case "WorkitemId":
        setWorkitemId(value);
        break;*/
      case "StatusCode":
        setStatusCode((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusMessage":
        setStatusMessage((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };
  //on changing column values for document type
  /* const mapColumnWithDocument = (documentToBeMapped, columnValue) => {
    let newDocs = [...allDocuments];
    //finding Index of document in the all documents array
    const index = allDocuments.findIndex(
      (item) => item.id === documentToBeMapped.id
    );

    //now setting columnValue to the selected columnValue
    if (index !== -1) {
      const newDoc = { ...allDocuments[index], columnValue: columnValue };
      newDocs.splice(index, 1, newDoc);
      setAllDocuments(newDocs);
    } else {
      console.log("document not found");
    }
  };*/
  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [mappedToTop, setMappedToTop] = useState(
    makingCheckboxFields("MappedToTop", false, "Mapped to Top")
  );

  const handleMapVariables = () => {
    handleOpenModal("ProcessVariables");
  };
  const handleMapDocuments = () => {
    handleOpenModal("DocumentsVariables");
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,

    statusCode,
    statusMessage,
    allMappedVariables,
    allMappedDocuments,
  ]);

  const updateParams = () => {
    const mappedVars = {};
    allMappedVariables.forEach((obj) => {
      mappedVars[obj.attrName] = { RPAVar: obj.RPAVar, attrType: obj.attrType };
    });

    const newVarMapData = {
      ...varMapData,
      // paramValue: Object.keys(mappedVars).length > 0 ? JSON.stringify(mappedVars) : null,
      paramValue: JSON.stringify(mappedVars),
    };
    // const mappedDocs = {};
    /* allMappedDocuments.forEach((obj) => {
      mappedDocs[obj.docPath] = obj.docIndex;
    });*/
    let mappedDocs = {};
    if (allMappedDocuments.length > 0) {
      mappedDocs = allMappedDocuments.reduce(
        (obj, item) =>
          Object.assign(
            obj,
            item.docType &&
              item.docPath && {
                [item.docType]:
                  item.valueType === "C"
                    ? item.docPath
                    : "${" + `${item.docPath}` + "}",
              }
          ),
        {}
      );
    }

    const newDocMapData = {
      ...docMapData,
      // paramValue:Object.keys(mappedDocs).length > 0 ? JSON.stringify(mappedDocs) : null,
      paramValue: JSON.stringify(mappedDocs),
    };

    const allParams = [
      invisibleInLogs,

      statusCode,
      newVarMapData,
      newDocMapData,
      statusMessage,
    ];
    //  console.log(allParams);
    addParamsToSelAct(allParams);
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={
          selectedActivity.description || selectedActivity?.activityId === 57
            ? "Save workitem"
            : "Complete the workitems"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {/*<Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              INPUT
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="AttributValue"
              label="Attribute Value"
              value={attributeValue}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="DataClassAttributes"
              label="Data Class Attributes"
              value={dataClassAttributes}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="SessionId"
              label="Session Id"
              value={sessionId}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="WorkitemId"
              label="Workitem Id"
              value={workitemId}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="WorkitemName"
              label="Workitem Name"
              value={workitemName}
              onChange={handleChange}
            />
          </Grid>
  </Grid>*/}
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <VariableMapping
                id={props.id}
                //documentsArray={allDocuments}
                //mappedToTop={mappedToTop}
                //onMapColumn={mapColumnWithDocument}
                allVariables={allOptions || []}
                mappedVar={varMapDataValue}
                handleMapVariables={handleMapVariables}
                //mappedDocs={allMappedDocuments}
                handleMapDocuments={handleMapDocuments}
                // completeWorkitem={true}
              />
            </Grid>
          </Grid>
        ) : selectedTab == "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusCode`}
                combo={true}
                dropdown={true}
                paramObj={statusCode}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                label={`Status Code (${getVariableTypeById(
                  statusCode.paramObjectTypeId
                )})`}
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                error={
                  vaildateParamValue(statusCode.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusCode.paramValue.toString()).msg
                }
                // helperText="Select or add a int type variable"
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusMsg`}
                combo={true}
                dropdown={true}
                paramObj={statusMessage}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusMessage"
                label={`Status Message (${getVariableTypeById(
                  statusMessage.paramObjectTypeId
                )})`}
                value={statusMessage.paramValue}
                options={getOptionsForVariable(statusMessage)}
                onChange={handleChange}
                error={
                  vaildateParamValue(statusMessage.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusMessage.paramValue.toString()).msg
                }
                //helperText="Select or add a char type variable"
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default CompleteWorkitemWindow;

const documentsArray = [
  { documentType: "Aadhar Card", id: 1 },
  { documentType: "PAN Card", id: 2 },
  { documentType: "Passport", id: 3 },
];
