import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, Email } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const AddDocumentWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  console.log(params);
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [documentIndex, setDocumentIndex] = useState(
    mapFieldObjWithValueByName(params, "DocumentIndex", "")
  );
  const [volumeId, setVolumeId] = useState(
    mapFieldObjWithValueByName(params, "VolumeID", "")
  );
  const [documentPath, setDocumentPath] = useState(
    mapFieldObjWithValueByName(params, "DocumentPath", "")
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setDocumentIndex(mapFieldObjWithValueByName(params, "DocumentIndex", ""));
    setVolumeId(mapFieldObjWithValueByName(params, "VolumeID", ""));
    setDocumentPath(mapFieldObjWithValueByName(params, "DocumentPath", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, documentIndex, documentPath, volumeId]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, documentIndex, documentPath, volumeId];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "DocumentPath":
        setDocumentPath((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "VolumeId":
        setVolumeId((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "DocumentIndex":
        setDocumentIndex((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "DocumentPath":
        setDocumentPath({ ...documentPath, paramType: changeToValue });
        break;

      case "VolumeId":
        setVolumeId({ ...volumeId, paramType: changeToValue });
        break;
      case "DocumentIndex":
        setDocumentIndex({ ...documentIndex, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || "Add Documents"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DocumentPath`}
                combo={true}
                dropdown={documentPath.paramType === "V"}
                labelBtn1={true}
                labelBtn2={true}
                paramObj={documentPath}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                btnIcon={
                  <Folder
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="DocumentPath"
                label="Document Path"
                value={documentPath.paramValue}
                options={getOptionsForVariable(documentPath)}
                onChange={handleChange}
                error={
                  vaildateParamValue(documentPath.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(documentPath.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_VolumeId`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={volumeId.paramType === "V"}
                paramObj={volumeId}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="VolumeId"
                label="Volume Id"
                value={volumeId.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(volumeId)}
                error={
                  vaildateParamValue(volumeId.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(volumeId.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DocumentIndex`}
                combo={true}
                dropdown={true}
                paramObj={documentIndex}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="DocumentIndex"
                label={`Document Index (${getVariableTypeById(
                  documentIndex.paramObjectTypeId
                )})`}
                value={documentIndex.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(documentIndex)}
                error={
                  vaildateParamValue(documentIndex.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(documentIndex.paramValue.toString()).msg
                }
                // helperText="Select or add a int type variable"
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default AddDocumentWindow;
