import React from "react";
import { Button, Grid, Typography } from "@mui/material";

import { useStyles } from "../Common/CommonStyles";

const VariableMapping = (props) => {
  const {
    allVariables,

    mappedVar,
    handleMapVariables,
    handleMapDocuments = () => {
      console.log("provide docs map fn");
    },
  } = props;

  const classes = useStyles();
  return (
    <>
      <Grid
        container
        direction="column"
        spacing={1}
        style={{ marginBottom: "27px" }}
      >
        <Grid item>
          <Typography className={classes.label}>Variable Mapping</Typography>
        </Grid>
        <Grid item>
          <Grid container spacing={1} alignItems="center">
            <Grid item>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleMapVariables()}
                id={`${props.id}_MapVariablesBtn`}
                disableRipple
              >
                <Typography className={classes.btn_title}>
                  Map Variables
                </Typography>
              </Button>
            </Grid>
            <Grid item>
              {allVariables && (
                <Typography variant="subtitle2">
                  {mappedVar ? mappedVar.length : 0}
                  {"  "}
                  {mappedVar
                    ? mappedVar.length === 1
                      ? "variable "
                      : "variables "
                    : "variables "}
                  mapped.
                </Typography>
              )}
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid
        container
        style={{ marginBottom: "16px" }}
        direction="column"
        spacing={1}
      >
        <Grid item>
          <Typography className={classes.label}>Document Mapping</Typography>
        </Grid>
        <Grid item>
          <Grid container spacing={1} alignItems="center">
            <Grid item>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleMapDocuments()}
                id={`${props.id}_MapDocumentsBtn`}
                disableRipple
              >
                <Typography className={classes.btn_title}>
                  Map Documents
                </Typography>
              </Button>
            </Grid>
            {/*<Grid item>
              {allDocuments && (
                <Typography variant="subtitle2">
                  {mappedDocs ? mappedDocs.length : 0} of {allDocuments.length}{" "}
                  mapped.
                </Typography>
              )}
              </Grid>*/}
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default VariableMapping;
