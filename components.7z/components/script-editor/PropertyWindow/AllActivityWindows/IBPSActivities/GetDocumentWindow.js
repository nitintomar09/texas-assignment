import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, Email } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { useSelector, useDispatch } from "react-redux";

import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const GetDocumentWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [documentIndex, setDocumentIndex] = useState(
    mapFieldObjWithValueByName(params, "DocumentIndex", "")
  );
  const [documentName, setDocumentName] = useState(
    mapFieldObjWithValueByName(params, "DocumentName", "")
  );
  const [documentPath, setDocumentPath] = useState(
    mapFieldObjWithValueByName(params, "DocumentPath", "")
  );
  const [statusCode, setStatusCode] = useState(
    mapFieldObjWithValueByName(params, "StatusCode", "")
  );

  const [statusMessage, setStatusMessage] = useState(
    mapFieldObjWithValueByName(params, "StatusMessage", "")
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setDocumentIndex(mapFieldObjWithValueByName(params, "DocumentIndex", ""));
    setDocumentName(mapFieldObjWithValueByName(params, "DocumentName", ""));
    setDocumentPath(mapFieldObjWithValueByName(params, "DocumentPath", ""));
    setStatusCode(mapFieldObjWithValueByName(params, "StatusCode", ""));
    setStatusMessage(mapFieldObjWithValueByName(params, "StatusMessage", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    documentIndex,
    documentPath,
    documentName,
    statusCode,
    statusMessage,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      documentIndex,
      documentPath,
      documentName,
      statusCode,
      statusMessage,
    ];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "DocumentPath":
        setDocumentPath((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "DocumentName":
        setDocumentName((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "DocumentIndex":
        setDocumentIndex((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusCode":
        setStatusCode((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusMessage":
        setStatusMessage((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "DocumentPath":
        setDocumentPath({ ...documentPath, paramType: changeToValue });
        break;

      case "DocumentName":
        setDocumentName({ ...documentName, paramType: changeToValue });
        break;
      case "DocumentIndex":
        setDocumentIndex({ ...documentIndex, paramType: changeToValue });
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || "Get Documents"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DocumentPath`}
                combo={true}
                dropdown={documentPath.paramType === "V"}
                labelBtn1={true}
                labelBtn2={true}
                paramObj={documentPath}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                btnIcon={
                  <Folder
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="DocumentPath"
                label="Document Path"
                value={documentPath.paramValue}
                options={getOptionsForVariable(documentPath)}
                onChange={handleChange}
                error={vaildateParamValue(documentPath.paramValue).errorStatus}
                helperText={vaildateParamValue(documentPath.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DocumentIndex`}
                combo={true}
                dropdown={documentIndex.paramType === "V"}
                labelBtn1={true}
                labelBtn2={true}
                paramObj={documentIndex}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="DocumentIndex"
                label="Document Index"
                value={documentIndex.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(documentIndex)}
                error={vaildateParamValue(documentIndex.paramValue).errorStatus}
                helperText={vaildateParamValue(documentIndex.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DocumentName`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={documentName.paramType === "V"}
                paramObj={documentName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="DocumentName"
                label="Document Name"
                value={documentName.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(documentName)}
                error={vaildateParamValue(documentName.paramValue).errorStatus}
                helperText={vaildateParamValue(documentName.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusCode`}
                combo={true}
                dropdown={true}
                paramObj={statusCode}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                label={`Status Code (${getVariableTypeById(
                  statusCode.paramObjectTypeId
                )})`}
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                // helperText="Select or add a int type variable"
                error={
                  vaildateParamValue(statusCode.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusCode.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusMsg`}
                combo={true}
                dropdown={true}
                paramObj={statusMessage}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusMessage"
                label={`Status Message (${getVariableTypeById(
                  statusMessage.paramObjectTypeId
                )})`}
                value={statusMessage.paramValue}
                options={getOptionsForVariable(statusMessage)}
                onChange={handleChange}
                error={vaildateParamValue(statusMessage.paramValue).errorStatus}
                helperText={vaildateParamValue(statusMessage.paramValue).msg}
                //helperText="Select or add a char type variable"
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default GetDocumentWindow;
