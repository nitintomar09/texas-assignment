import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "../../PropertyFields/PropertyField";
import { LaptopWindows } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
} from "../Common/CommonMethods";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";

const CommonWindowsWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [controlId, setControlId] = useState(
    mapFieldObjWithValueByName(params, "ControlId", "")
  );
  const [nameField, setName] = useState(
    mapFieldObjWithValueByName(params, "Name", "")
  );

  const [classNameField, setClassNameField] = useState(
    mapFieldObjWithValueByName(params, "ClassName", "")
  );

  const [automationId, setAutomationId] = useState(
    mapFieldObjWithValueByName(params, "AutomationId", "")
  );
  /*const [actionPerformed, setActionPerformed] = useState(
    mapFieldObjWithValueByName(params, "ActionPerformed", "")
  );*/
  const [expandCollapseState, setExpandCollapseState] = useState(
    mapFieldObjWithValueByName(params, "ExpandCollapseState", "")
  );

  const [toggleState, setToggleState] = useState(
    mapFieldObjWithValueByName(params, "ToggleState", "")
  );
  const [isSelected, setIsSelected] = useState(
    mapFieldObjWithValueByName(params, "IsSelected", "")
  );
  const [isSelectedItem, setIsSelectedItem] = useState(
    mapFieldObjWithValueByName(params, "IsSelectedItem", "")
  );
  const [updatedTextValue, setUpdatedTextValue] = useState(
    mapFieldObjWithValueByName(params, "UpdatedTextValue", "")
  );
  const [keyStokes, setKeyStokes] = useState(
    mapFieldObjWithValueByName(params, "KeyStokes", "")
  );

  const [isDoubleClick, setIsDoubleClick] = useState(
    mapFieldObjWithValueByName(params, "IsDoubleClick", "")
  );

  const [elementLocation, setElementLocation] = useState(
    mapFieldObjWithValueByName(params, "ElementLocation", "")
  );
  const [ancestors, setAncestors] = useState(
    mapFieldObjWithValueByName(params, "Ancestors", "")
  );

  const [gridItem, setGridItem] = useState(
    mapFieldObjWithValueByName(params, "GridItem", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");

    setControlId(mapFieldObjWithValueByName(params, "ControlId", ""));
    setName(mapFieldObjWithValueByName(params, "Name", ""));
    setClassNameField(mapFieldObjWithValueByName(params, "ClassName", ""));
    setAutomationId(mapFieldObjWithValueByName(params, "AutomationId", ""));
    /* setActionPerformed(
      mapFieldObjWithValueByName(params, "ActionPerformed", "")
    );*/
    setExpandCollapseState(
      mapFieldObjWithValueByName(params, "ExpandCollapseState", "")
    );
    setToggleState(mapFieldObjWithValueByName(params, "ToggleState", ""));
    setIsSelected(mapFieldObjWithValueByName(params, "IsSelected", ""));
    setIsSelectedItem(mapFieldObjWithValueByName(params, "IsSelectedItem", ""));
    setUpdatedTextValue(
      mapFieldObjWithValueByName(params, "UpdatedTextValue", "")
    );
    setKeyStokes(mapFieldObjWithValueByName(params, "KeyStokes", ""));

    setIsDoubleClick(mapFieldObjWithValueByName(params, "IsDoubleClick", ""));

    setElementLocation(
      mapFieldObjWithValueByName(params, "ElementLocation", "")
    );
    setAncestors(mapFieldObjWithValueByName(params, "Ancestors", ""));
    setGridItem(mapFieldObjWithValueByName(params, "GridItem", ""));

    setInvisibleInLogs(logsState(params, false));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "ControlId":
        setControlId({ ...controlId, paramValue: value });
        break;
      case "Name":
        setName({
          ...nameField,
          paramValue: value,
        });
        break;
      case "ClassName":
        setClassNameField({ ...classNameField, paramValue: value });
        break;
      case "AutomationId":
        setAutomationId({ ...automationId, paramValue: value });
        break;
      /*case "ActionPerformed":
        setActionPerformed({ ...actionPerformed, paramValue: value });
        break;*/
      case "ExpandCollapseState":
        setExpandCollapseState({ ...expandCollapseState, paramValue: value });
        break;
      case "ToggleState":
        setToggleState({ ...toggleState, paramValue: value });
        break;
      case "IsSelected":
        setIsSelected({ ...isSelected, paramValue: value });
        break;
      case "IsSelectedItem":
        setIsSelectedItem({ ...isSelectedItem, paramValue: value });
        break;

      case "UpdatedTextValue":
        setUpdatedTextValue({ ...updatedTextValue, paramValue: value });
        break;
      case "KeyStokes":
        setKeyStokes({ ...keyStokes, paramValue: value });
        break;
      case "IsDoubleClick":
        setIsDoubleClick({ ...isDoubleClick, paramValue: value });
        break;

      case "ElementLocation":
        setElementLocation({ ...elementLocation, paramValue: value });
        break;
      case "Ancestors":
        setAncestors({ ...ancestors, paramValue: value });
        break;
      case "GridItem":
        setGridItem({ ...gridItem, paramValue: value });
        break;

      default:
        break;
    }
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    controlId,
    nameField,
    classNameField,
    automationId,
    //  actionPerformed,
    expandCollapseState,
    toggleState,
    isSelected,
    isSelectedItem,
    updatedTextValue,
    keyStokes,
    isDoubleClick,
    elementLocation,
    ancestors,
    gridItem,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      controlId,
      nameField,
      classNameField,
      automationId,
      // actionPerformed,
      expandCollapseState,
      toggleState,
      isSelected,
      isSelectedItem,
      updatedTextValue,
      keyStokes,
      isDoubleClick,
      elementLocation,
      ancestors,
      gridItem,
    ];
    addParamsToSelAct(allParams);
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ControlId":
        setControlId({
          ...controlId,
          paramType: changeToValue,
        });
        break;
      case "Name":
        setName({
          ...nameField,
          paramType: changeToValue,
        });
        break;
      case "ClassName":
        setClassNameField({ ...classNameField, paramType: changeToValue });
        break;
      case "AutomationId":
        setAutomationId({ ...automationId, paramType: changeToValue });
        break;

      case "ExpandCollapseState":
        setExpandCollapseState({
          ...expandCollapseState,
          paramType: changeToValue,
        });
        break;
      case "ToggleState":
        setToggleState({ ...toggleState, paramType: changeToValue });
        break;
      case "IsSelected":
        setIsSelected({ ...isSelected, paramType: changeToValue });
        break;
      case "IsSelectedItem":
        setIsSelectedItem({ ...isSelectedItem, paramType: changeToValue });
        break;
      case "UpdatedTextValue":
        setUpdatedTextValue({ ...updatedTextValue, paramType: changeToValue });
        break;
      case "KeyStokes":
        setKeyStokes({
          ...keyStokes,
          paramType: changeToValue,
        });
        break;
      case "IsDoubleClick":
        setIsDoubleClick({ ...isDoubleClick, paramType: changeToValue });
        break;

      case "ElementLocation":
        setElementLocation({ ...elementLocation, paramType: changeToValue });
        break;
      case "Ancestors":
        setAncestors({ ...ancestors, paramType: changeToValue });
        break;
      case "GridItem":
        setGridItem({ ...gridItem, paramType: changeToValue });
        break;

      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={LaptopWindows}
        helperText={selectedActivity.description || ""}
      />
      <div className={classes.scrollDiv}>
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>

              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={controlId.paramType === "V"}
                  paramObj={controlId}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ControlId"
                  label="Control Id"
                  value={controlId.paramValue}
                  options={getOptionsForVariable(controlId)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={nameField.paramType === "V"}
                  paramObj={nameField}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Name"
                  label="Name"
                  value={nameField.paramValue}
                  options={getOptionsForVariable(nameField)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={automationId.paramType === "V"}
                  paramObj={automationId}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="AutomationId"
                  label="Automation Id"
                  value={automationId.paramValue}
                  options={getOptionsForVariable(automationId)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={classNameField.paramType === "V"}
                  paramObj={classNameField}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ClassName"
                  label="ClassName"
                  value={classNameField.paramValue}
                  options={getOptionsForVariable(classNameField)}
                  onChange={handleChange}
                />
              </Grid>

              {/*<Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={true}
                  paramObj={actionPerformed}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ActionPerformed"
                  label="Action Performed"
                  value={actionPerformed.paramValue}
                  options={getOptionsForVariable(actionPerformed)}
                  onChange={handleChange}
                />
              </Grid>*/}
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={expandCollapseState.paramType === "V"}
                  paramObj={expandCollapseState}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ExpandCollapseState"
                  label="Expand Collapse State"
                  value={expandCollapseState.paramValue}
                  options={getOptionsForVariable(expandCollapseState)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={toggleState.paramType === "V"}
                  paramObj={toggleState}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ToggleState"
                  label="Toggle State"
                  value={toggleState.paramValue}
                  options={getOptionsForVariable(toggleState)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={isSelected.paramType === "V"}
                  paramObj={isSelected}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="IsSelected"
                  label="Is Selected"
                  value={isSelected.paramValue}
                  options={getOptionsForVariable(isSelected)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={isSelectedItem.paramType === "V"}
                  paramObj={isSelectedItem}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="IsSelectedItem"
                  label="Is Selected Item"
                  value={isSelectedItem.paramValue}
                  options={getOptionsForVariable(isSelectedItem)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={updatedTextValue.paramType === "V"}
                  paramObj={updatedTextValue}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="UpdatedTextValue"
                  label="Updated Text Value"
                  value={updatedTextValue.paramValue}
                  options={getOptionsForVariable(updatedTextValue)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={keyStokes.paramType === "V"}
                  paramObj={keyStokes}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="KeyStokes"
                  label="KeyStokes"
                  value={keyStokes.paramValue}
                  options={getOptionsForVariable(keyStokes)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={isDoubleClick.paramType === "V"}
                  paramObj={isDoubleClick}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="IsDoubleClick"
                  label="IsDoubleClick"
                  value={isDoubleClick.paramValue}
                  options={getOptionsForVariable(isDoubleClick)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={elementLocation.paramType === "V"}
                  paramObj={elementLocation}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ElementLocation"
                  label="Element Location"
                  value={elementLocation.paramValue}
                  options={getOptionsForVariable(elementLocation)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={ancestors.paramType === "V"}
                  paramObj={ancestors}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Ancestors"
                  label="Ancestors"
                  value={ancestors.paramValue}
                  options={getOptionsForVariable(ancestors)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={gridItem.paramType === "V"}
                  paramObj={gridItem}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="GridItem"
                  label="Grid Item"
                  value={gridItem.paramValue}
                  options={getOptionsForVariable(gridItem)}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default CommonWindowsWindow;
