import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "../../PropertyFields/PropertyField";
import { LaptopWindows } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
} from "../Common/CommonMethods";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";

const LaunchWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [processName, setProcessName] = useState(
    mapFieldObjWithValueByName(params, "ProcessName", "")
  );
  const [appUserModelId, setAppUserModelId] = useState(
    mapFieldObjWithValueByName(params, "AppUserModelId", "")
  );

  const [executedPath, setExecutedPath] = useState(
    mapFieldObjWithValueByName(params, "ExecutedPath", "")
  );

  const [rootClassName, setRootClassName] = useState(
    mapFieldObjWithValueByName(params, "RootClassName", "")
  );
  const [windowVisualState, setWindowVisualState] = useState(
    mapFieldObjWithValueByName(params, "WindowVisualState", "")
  );
  const [rootName, setRootName] = useState(
    mapFieldObjWithValueByName(params, "RootName", "")
  );

  const [resolution, setResolution] = useState(
    mapFieldObjWithValueByName(params, "Resolution", "")
  );
  const [windowTopLeft, setWindowTopLeft] = useState(
    mapFieldObjWithValueByName(params, "WindowTopLeft", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");

    setProcessName(mapFieldObjWithValueByName(params, "ProcessName", ""));
    setAppUserModelId(mapFieldObjWithValueByName(params, "AppUserModelId", ""));
    setExecutedPath(mapFieldObjWithValueByName(params, "ExecutedPath", ""));
    setRootClassName(mapFieldObjWithValueByName(params, "RootClassName", ""));
    setWindowVisualState(
      mapFieldObjWithValueByName(params, "WindowVisualState", "")
    );
    setRootName(mapFieldObjWithValueByName(params, "RootName", ""));
    setResolution(mapFieldObjWithValueByName(params, "Resolution", ""));
    setWindowTopLeft(mapFieldObjWithValueByName(params, "WindowTopLeft", ""));

    setInvisibleInLogs(logsState(params, false));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "ProcessName":
        setProcessName({ ...processName, paramValue: value });
        break;
      case "AppUserModelId":
        setAppUserModelId({
          ...appUserModelId,
          paramValue: value,
        });
        break;
      case "ExecutedPath":
        setExecutedPath({ ...executedPath, paramValue: value });
        break;
      case "RootClassName":
        setRootClassName({ ...rootClassName, paramValue: value });
        break;
      case "WindowVisualState":
        setWindowVisualState({ ...windowVisualState, paramValue: value });
        break;
      case "RootName":
        setRootName({ ...rootName, paramValue: value });
        break;
      case "Resolution":
        setResolution({ ...resolution, paramValue: value });
        break;
      case "WindowTopLeft":
        setWindowTopLeft({ ...windowTopLeft, paramValue: value });
        break;

      default:
        break;
    }
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    processName,
    appUserModelId,
    executedPath,
    rootClassName,
    windowVisualState,
    rootName,
    resolution,
    windowTopLeft,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      processName,
      appUserModelId,
      executedPath,
      rootClassName,
      windowVisualState,
      rootName,
      resolution,
      windowTopLeft,
    ];
    addParamsToSelAct(allParams);
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ProcessName":
        setProcessName({
          ...processName,
          paramType: changeToValue,
        });
        break;
      case "AppUserModelId":
        setAppUserModelId({
          ...appUserModelId,
          paramType: changeToValue,
        });
        break;
      case "ExecutedPath":
        setExecutedPath({ ...executedPath, paramType: changeToValue });
        break;
      case "RootClassName":
        setRootClassName({ ...rootClassName, paramType: changeToValue });
        break;

      case "RootName":
        setRootName({
          ...rootName,
          paramType: changeToValue,
        });
        break;
      case "Resolution":
        setResolution({ ...resolution, paramType: changeToValue });
        break;
      case "WindowTopLeft":
        setWindowTopLeft({ ...windowTopLeft, paramType: changeToValue });
        break;

      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={LaptopWindows}
        helperText={selectedActivity.description || ""}
      />
      <div className={classes.scrollDiv}>
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>

              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={processName.paramType === "V"}
                  paramObj={processName}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ProcessName"
                  label="Process Name"
                  value={processName.paramValue}
                  options={getOptionsForVariable(processName)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={appUserModelId.paramType === "V"}
                  paramObj={appUserModelId}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="AppUserModelId"
                  label="App User Model Id"
                  value={appUserModelId.paramValue}
                  options={getOptionsForVariable(appUserModelId)}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={executedPath.paramType === "V"}
                  paramObj={executedPath}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ExecutedPath"
                  label="Executed Path"
                  value={executedPath.paramValue}
                  options={getOptionsForVariable(executedPath)}
                  onChange={handleChange}
                />
              </Grid>

              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={windowVisualState.paramType === "V"}
                  paramObj={windowVisualState}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="WindowVisualState"
                  label="Window Visual State"
                  value={windowVisualState.paramValue}
                  options={getOptionsForVariable(windowVisualState)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={rootName.paramType === "V"}
                  paramObj={rootName}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="RootName"
                  label="Root Name"
                  value={rootName.paramValue}
                  options={getOptionsForVariable(rootName)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={rootClassName.paramType === "V"}
                  paramObj={rootClassName}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="RootClassName"
                  label="Root ClassName"
                  value={rootClassName.paramValue}
                  options={getOptionsForVariable(rootClassName)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={resolution.paramType === "V"}
                  paramObj={resolution}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Resolution"
                  label="Resolution"
                  value={resolution.paramValue}
                  options={getOptionsForVariable(resolution)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={windowTopLeft.paramType === "V"}
                  paramObj={windowTopLeft}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="WindowTopLeft"
                  label="Window Top Left"
                  value={windowTopLeft.paramValue}
                  options={getOptionsForVariable(windowTopLeft)}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default LaunchWindow;
