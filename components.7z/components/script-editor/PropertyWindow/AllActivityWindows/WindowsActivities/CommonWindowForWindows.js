import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "../../PropertyFields/PropertyField";
import { LaptopWindows } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  handleNetworkRequestError,
  createInstance,
  getAuthKey,
} from "../../../../../utils/common";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  isVar,
  changeVarFormToConst,
} from "../Common/CommonMethods";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import {
  WindowsPropertiesCollapseIcon,
  WindowsPropertiesExpandIcon,
} from "../../../../../utils/AllImages";
import { ELEMENT_EXPLORER } from "../../../../../config";
import { NotificationContext } from "../../../../../contexts/NotificationContext";
import { useHistory } from "react-router-dom";
import { isEmpty } from "lodash";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";
const ShowAllObjectsField = ({
  readOnly,
  arrKeyName,
  arrIndex,
  allObj,
  handleChange,
  handleChangeEle,
  handleShowEle,
  openElementsList,
  combo,
  id,
}) => {
  const classes = useStyles();
  return Object.keys(allObj).map((key, index) => {
    if (allObj[key] && typeof allObj[key] === "object") {
      return (
        <>
          <Grid item container spacing={1} key={index}>
            <Grid item>
              <Typography style={{ fontWeight: 600 }}>{key}</Typography>
            </Grid>
            <Grid item style={{ marginTop: "2px" }}>
              {openElementsList.includes(`${key}`) ? (
                <UniqueIDGenerator>
                  <WindowsPropertiesCollapseIcon
                    className={[classes.removeBtn, classes.focusVisible].join(
                      " "
                    )}
                    onClick={() => handleShowEle(key)}
                    //WCAG Keyboard Accessible: [26-06-2023] Provided tabIndex and onKeyPress
                    tabIndex={0}
                    onKeyPress={(e) => e.key === "Enter" && handleShowEle(key)}
                    role="button"
                    id={`${id}_Collapse`}
                    aria-expanded={false}
                  />
                </UniqueIDGenerator>
              ) : (
                <UniqueIDGenerator>
                  <WindowsPropertiesExpandIcon
                    className={[classes.addBtn, classes.focusVisible].join(" ")}
                    onClick={() => handleShowEle(key)}
                    //WCAG Keyboard Accessible: [26-06-2023] Provided tabIndex and onKeyPress
                    tabIndex={0}
                    onKeyPress={(e) => e.key === "Enter" && handleShowEle(key)}
                    role="button"
                    aria-expanded={true}
                    id={`${id}_Expand`}
                  />
                </UniqueIDGenerator>
              )}
            </Grid>
          </Grid>
          {openElementsList.includes(`${key}`) && allObj[key] && (
            <>
              {Array.isArray(allObj[key])
                ? allObj[key].map((item, i) => {
                    return (
                      <div
                        style={{
                          marginLeft: "16px",
                          paddingRight: "8px",
                          boxShadow: "outset 0px 1px 7px #bfb5b5",
                        }}
                      >
                        <ShowAllObjectsField
                          id={id}
                          arrKeyName={key}
                          arrIndex={i}
                          readOnly={readOnly}
                          allObj={item}
                          handleChangeEle={handleChangeEle}
                          handleChange={handleChange}
                          handleShowEle={handleShowEle}
                          openElementsList={openElementsList}
                          combo={combo}
                        />
                      </div>
                    );
                  })
                : Object.keys(allObj[key]).map((key1, index) => {
                    return (
                      <div
                        style={{
                          marginLeft: "24px",
                          paddingRight: "8px",
                          boxShadow: "outset 0px 1px 7px #bfb5b5",
                        }}
                      >
                        <Grid
                          item
                          container
                          spacing={1}
                          key={index}
                          alignItems="center"
                        >
                          {/*<Grid item>
                          <Typography>{key1}</Typography>
                    </Grid>*/}
                          <Grid item xs>
                            <PropertyField
                              id={id}
                              combo={combo}
                              windowProps={true}
                              width={295}
                              canType={true}
                              dropdown={combo ? true : null}
                              name={key1}
                              label={key1}
                              // value={allObj[key][key1] || ""}
                              value={
                                (allObj[key][key1] &&
                                  (isVar(allObj[key][key1])
                                    ? changeVarFormToConst(allObj[key][key1])
                                    : allObj[key][key1])) ||
                                ""
                              }
                              readOnly={readOnly}
                              onChange={(e) =>
                                handleChangeEle(e, key, arrKeyName, arrIndex)
                              }
                              options={getOptionsForVariable({})}
                            />
                          </Grid>
                        </Grid>
                      </div>
                    );
                  })}
            </>
          )}
        </>
      );
    }

    return (
      <Grid item container spacing={1} key={index} alignItems="center">
        <Grid item xs>
          <PropertyField
            id={id}
            combo={combo}
            windowProps={true}
            width={320}
            canType={true}
            dropdown={combo ? true : null}
            name={key}
            label={key}
            readOnly={readOnly}
            value={
              (allObj[key] &&
                (isVar(allObj[key])
                  ? changeVarFormToConst(allObj[key])
                  : allObj[key])) ||
              ""
            }
            onChange={(e) => handleChangeEle(e, null, arrKeyName, arrIndex)}
            options={getOptionsForVariable({})}
          />
        </Grid>
      </Grid>
    );
  });
};
const CommonWindowForWindows = (props) => {
  const classes = useStyles();
  const history = useHistory();
  const { setValue: setNotification } = useContext(NotificationContext);
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  var params = selectedActivity.params;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  //new params
  const [targetElement, setTargetElement] = useState(
    mapFieldObjWithValueByName(params, "TargetElement", "")
  );
  const [valueField, setValueField] = useState(
    mapFieldObjWithValueByName(params, "Value", "")
  );
  const [showTarget, setShowTarget] = useState(false);
  const [showValue, setShowValue] = useState(false);
  const [openElementsList, setOpenElementsList] = useState([]);
  const [allTargetObj, setAllTargetObj] = useState({});
  const [allValueObj, setAllValueObj] = useState({});

  const setTargetAndValue = () => {
    try {
      const targetEl = mapFieldObjWithValueByName(params, "TargetElement", "");
      const valEl = mapFieldObjWithValueByName(params, "Value", "");
      if (targetEl.paramValue) {
        const jsonObj = JSON.parse(targetEl.paramValue);
        if (jsonObj) {
          setAllTargetObj(jsonObj);
        }
      } else {
        setAllTargetObj(null);
      }
      if (valEl.paramValue) {
        const jsonObj1 = JSON.parse(valEl.paramValue);
        if (jsonObj1) {
          setAllValueObj(jsonObj1);
        }
      } else {
        setAllValueObj(null);
      }
    } catch (error) {
      console.log(error);
    }
  };
  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setTargetAndValue();
    setShowTarget(false);
    setShowValue(false);
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleShowEle = (name) => {
    const doActions = {
      ShowTarget: function () {
        setShowTarget(!showTarget);
      },
      ShowValue: function () {
        setShowValue(!showValue);
      },
      default: function () {
        const newOpenList = [...openElementsList];
        const ifPresent = openElementsList.findIndex((item) => item === name);
        if (ifPresent !== -1) {
          newOpenList.splice(ifPresent, 1);
        } else {
          newOpenList.push(name);
        }
        setOpenElementsList(newOpenList);
      },
    };
    if (name === "ShowTarget" || name === "ShowValue") {
      doActions[name]();
    } else {
      doActions["default"]();
    }
  };

  const handleChangeEle = (e, anncesstor, arrName, arrIndex) => {
    const { name, value } = e.target;
    const newJsonObj = { ...allValueObj };
    if (arrName && newJsonObj[arrName]) {
      const arr = newJsonObj[arrName];
      const ele = arr[arrIndex] || null;
      if (ele) {
        ele[name] = value;
        arr.splice(arrIndex, 1, ele);
      }
    } else if (anncesstor) {
      const selEle = newJsonObj[anncesstor];

      if (selEle) {
        newJsonObj[anncesstor][name] = value;
      }
    } else {
      newJsonObj[name] = value;
    }
    setAllValueObj({ ...newJsonObj });
  };

  const handleChangeEleTarget = (e, anncesstor, arrName, arrIndex) => {
    const { name, value } = e.target;

    const newJsonObj = { ...allTargetObj };
    if (arrName && newJsonObj[arrName]) {
      const arr = newJsonObj[arrName];
      const ele = arr[arrIndex] || null;
      if (ele) {
        ele[name] = value;
        arr.splice(arrIndex, 1, ele);
      }
    } else if (anncesstor) {
      const selEle = newJsonObj[anncesstor];

      if (selEle) {
        newJsonObj[anncesstor][name] = value;
      }
    } else {
      newJsonObj[name] = value;
    }
    setAllTargetObj({ ...newJsonObj });
  };
  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "TargetElement":
        setTargetElement({ ...targetElement, paramValue: value });
        break;
      case "Value":
        setValueField({
          ...valueField,
          paramValue: value,
        });
        break;

      default:
        break;
    }
  };

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, allValueObj, allTargetObj]);

  const updateParams = () => {
    if (isEmpty(allTargetObj)) {
      //Setting the TargetElement and ValueField to empty
      setTargetElement({
        ...targetElement,
        paramValue: "",
      });
      setValueField({
        ...valueField,
        paramValue: "",
      });

      var targetEl = targetElement;
      targetEl.paramValue = allTargetObj;

      var valueFi = valueField;
      valueFi.paramValue = allValueObj;

      const allParams = [invisibleInLogs, targetEl, valueFi];
      addParamsToSelAct(allParams);
    } else {
      let newValueField = { ...valueField };
      if (allValueObj && Object.keys(allValueObj).length > 0) {
        newValueField = {
          ...valueField,
          paramValue: JSON.stringify(allValueObj),
        };
      }
      let newValueTarget = { ...targetElement };
      if (allTargetObj && Object.keys(allTargetObj).length > 0) {
        newValueTarget = {
          ...targetElement,
          paramValue: JSON.stringify(allTargetObj),
        };
      }

      //Updating the TargetElement and ValueField as per new params
      setTargetElement({
        ...targetElement,
        paramValue: JSON.stringify(allTargetObj),
      });
      setValueField({
        ...valueField,
        paramValue: JSON.stringify(allValueObj),
      });

      //Updating the props of the parent's window
      const allParams = [invisibleInLogs, newValueTarget, newValueField];
      addParamsToSelAct(allParams);
    }
  };

  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const GetUIElement = async () => {
    var scriptID = scriptValues.scriptId;
    var versionID = scriptValues.versionId;
    var url = `${ELEMENT_EXPLORER}/${scriptID}/${versionID}`;
    try {
      const axiosInstance = createInstance();
      const authenticationKey = getAuthKey();
      const config = {
        headers: {
          RobotAuthorization: authenticationKey,
        },
      };

      const res = await axiosInstance.get(url, config);

      const data = res.data.data[0].params;

      //updating the params
      selectedActivity.params = data;
      params = data;

      setTargetAndValue();
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "",
            title: "",
            notificationType: "ERROR",
          });
        },
      });
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={LaptopWindows}
        helperText={selectedActivity.description || ""}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Grid container spacing={1}>
                  <Grid item>
                    <Typography component="h5" className={classes.GroupTitle}>
                      INPUT
                    </Typography>
                  </Grid>
                  <Grid item style={{ marginLeft: "auto" }}>
                    <a
                      href="#"
                      onClick={GetUIElement}
                      className={classes.focusVisible}
                      id={`${props.id}_ElementExplorer`}
                    >
                      Element Explorer
                    </a>
                  </Grid>
                </Grid>
              </Grid>

              <Grid item container spacing={1}>
                <Grid item xs>
                  <PropertyField
                    id={`${props.id}_TargetElement`}
                    name={"TargetElement"}
                    label={"Target Element"}
                    readOnly={true}
                    iconAfterLabel={
                      showTarget ? (
                        <UniqueIDGenerator>
                          <WindowsPropertiesCollapseIcon
                            className={[
                              classes.removeBtn,
                              classes.focusVisible,
                            ].join(" ")}
                            onClick={() => handleShowEle("ShowTarget")}
                            titleAccess="Collapse"
                            //WCAG Keyboard Accessible : [26-06-2023] Provided tabIndex and onKeyPress
                            tabIndex={0}
                            onKeyPress={(e) =>
                              e.key === "Enter" && handleShowEle("ShowTarget")
                            }
                            role="button"
                            aria-expanded={false}
                            id={`${props.id}_CollapseBtn`}
                          />
                        </UniqueIDGenerator>
                      ) : (
                        <UniqueIDGenerator>
                          <WindowsPropertiesExpandIcon
                            className={[
                              classes.addBtn,
                              classes.focusVisible,
                            ].join(" ")}
                            onClick={() => handleShowEle("ShowTarget")}
                            titleAccess="Expand"
                            //WCAG Keyboard Accessible : [26-06-2023] Provided tabIndex and onKeyPress
                            tabIndex={0}
                            onKeyPress={(e) =>
                              e.key === "Enter" && handleShowEle("ShowTarget")
                            }
                            role="button"
                            aria-expanded={true}
                            id={`${props.id}_ExpandBtn`}
                          />
                        </UniqueIDGenerator>
                      )
                    }
                    value={targetElement?.paramValue || ""}
                    onChange={handleChange}
                  />
                </Grid>
              </Grid>

              {showTarget && allTargetObj && (
                <div
                  style={{
                    marginLeft: "24px",
                    paddingRight: "8px",
                    boxShadow: "outset 0px 1px 7px #bfb5b5",
                  }}
                >
                  <ShowAllObjectsField
                    id={props.id}
                    combo={true}
                    allObj={allTargetObj}
                    handleChangeEle={handleChangeEleTarget}
                    handleChange={handleChange}
                    handleShowEle={handleShowEle}
                    openElementsList={openElementsList}
                  />
                </div>
              )}

              <Grid item container spacing={1}>
                <Grid item xs>
                  <PropertyField
                    id={`${props.id}_Value`}
                    name={"Value"}
                    label={"Value"}
                    readOnly={true}
                    iconAfterLabel={
                      showValue ? (
                        <UniqueIDGenerator>
                          <WindowsPropertiesCollapseIcon
                            className={[
                              classes.removeBtn,
                              classes.focusVisible,
                            ].join(" ")}
                            onClick={() => {
                              handleShowEle("ShowValue");
                            }}
                            titleAccess="Collapse"
                            //WCAG Keyboard Accessible : [26-06-2023] Provided tabIndex and onKeyPress
                            tabIndex={0}
                            onKeyPress={(e) =>
                              e.key === "Enter" && handleShowEle("ShowValue")
                            }
                            role="button"
                            aria-expanded={false}
                            id={`${props.id}_CollapseBtn`}
                          />
                        </UniqueIDGenerator>
                      ) : (
                        <UniqueIDGenerator>
                          <WindowsPropertiesExpandIcon
                            className={[
                              classes.addBtn,
                              classes.focusVisible,
                            ].join(" ")}
                            onClick={() => handleShowEle("ShowValue")}
                            titleAccess="Expand" //WCAG Keyboard Accessible : [26-06-2023] Provided tabIndex and onKeyPress
                            tabIndex={0}
                            onKeyPress={(e) =>
                              e.key === "Enter" && handleShowEle("ShowValue")
                            }
                            role="button"
                            aria-expanded={true}
                            id={`${props.id}_ExpandBtn`}
                          />
                        </UniqueIDGenerator>
                      )
                    }
                    value={valueField?.paramValue || ""}
                    onChange={handleChange}
                  />
                </Grid>
              </Grid>

              {showValue && allValueObj && (
                <div
                  style={{
                    marginLeft: "24px",
                    paddingRight: "8px",
                    boxShadow: "outset 0px 1px 7px #bfb5b5",
                  }}
                >
                  <ShowAllObjectsField
                    id={props.id}
                    combo={true}
                    allObj={allValueObj}
                    handleChangeEle={handleChangeEle}
                    handleChange={handleChange}
                    handleShowEle={handleShowEle}
                    openElementsList={openElementsList}
                  />
                </div>
              )}
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default CommonWindowForWindows;
