import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const GetDriveLetterWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;
  console.log(params);
  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [fullPath, setFullPath] = useState(
    mapFieldObjWithValueByName(params, "FullPath", "")
  );
  const [driveLetter, setDriveLetter] = useState(
    mapFieldObjWithValueByName(params, "DriveLetter", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setDriveLetter(mapFieldObjWithValueByName(params, "DriveLetter", ""));
    setFullPath(mapFieldObjWithValueByName(params, "FullPath", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [fullPath, driveLetter]);

  const updateParams = () => {
    const allParams = [driveLetter, fullPath];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "FullPath":
        setFullPath((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "DriveLetter":
        setDriveLetter((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "FullPath":
        setFullPath({ ...fullPath, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description ||
          "This activity Gets Drive Letter from full Path."
        }
      />

      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_FullPath`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={fullPath.paramType === "V"}
                  paramObj={fullPath}
                  btnIcon={
                    <FolderOpen
                      className={classes.btnIcon + " " + classes.colorPrimary}
                    />
                  }
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="FullPath"
                  label="Full Path"
                  value={fullPath.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(fullPath)}
                  error={vaildateParamValue(fullPath.paramValue).errorStatus}
                  helperText={vaildateParamValue(fullPath.paramValue).msg}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DriveLetter`}
                combo={true}
                dropdown={true}
                paramObj={driveLetter}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="DriveLetter"
                label={`Drive Letter (${getVariableTypeById(
                  driveLetter.paramObjectTypeId
                )})`}
                value={driveLetter.paramValue}
                options={getOptionsForVariable(driveLetter)}
                onChange={handleChange}
                error={vaildateParamValue(driveLetter.paramValue).errorStatus}
                helperText={vaildateParamValue(driveLetter.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default GetDriveLetterWindow;
