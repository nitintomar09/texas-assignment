import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const GetFileExtensionWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;
  console.log(params);
  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [fullPath, setFullPath] = useState(
    mapFieldObjWithValueByName(params, "fullPath", "")
  );
  const [fileExtension, setFileExtension] = useState(
    mapFieldObjWithValueByName(params, "fileExtension", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setFileExtension(mapFieldObjWithValueByName(params, "fileExtension", ""));
    setFullPath(mapFieldObjWithValueByName(params, "fullPath", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [fullPath, fileExtension]);

  const updateParams = () => {
    const allParams = [fileExtension, fullPath];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "FullPath":
        setFullPath((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "FileExtension":
        setFileExtension((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "FullPath":
        setFullPath({ ...fullPath, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description ||
          "This activity Gets File Extension of a file."
        }
      />

      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_FullPath`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={fullPath.paramType === "V"}
                  paramObj={fullPath}
                  btnIcon={
                    <FolderOpen
                      className={classes.btnIcon + " " + classes.colorPrimary}
                    />
                  }
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="FullPath"
                  label="Full Path"
                  value={fullPath.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(fullPath)}
                  error={vaildateParamValue(fullPath.paramValue).errorStatus}
                  helperText={vaildateParamValue(fullPath.paramValue).msg}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_FileExtension`}
                combo={true}
                dropdown={true}
                paramObj={fileExtension}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="FileExtension"
                label={`File Extention (${getVariableTypeById(
                  fileExtension.paramObjectTypeId
                )})`}
                value={fileExtension.paramValue}
                options={getOptionsForVariable(fileExtension)}
                onChange={handleChange}
                error={vaildateParamValue(fileExtension.paramValue).errorStatus}
                helperText={vaildateParamValue(fileExtension.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default GetFileExtensionWindow;
