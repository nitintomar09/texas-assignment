import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonInput from "../Common/CommonInput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const GetOSTypeWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;
  console.log(params);
  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const [osType, setOSType] = useState(
    mapFieldObjWithValueByName(params, "OSType", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setOSType(mapFieldObjWithValueByName(params, "OSType", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [osType]);

  const updateParams = () => {
    const allParams = [osType];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "OSType":
        setOSType((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description ||
          "This activity Gets OS Type of system."
        }
      />

      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <CommonInput />
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_OSType`}
                combo={true}
                dropdown={true}
                paramObj={osType}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="OSType"
                label={`OS Type (${getVariableTypeById(
                  osType.paramObjectTypeId
                )})`}
                value={osType.paramValue}
                options={getOptionsForVariable(osType)}
                onChange={handleChange}
                error={vaildateParamValue(osType.paramValue).errorStatus}
                helperText={vaildateParamValue(osType.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default GetOSTypeWindow;
