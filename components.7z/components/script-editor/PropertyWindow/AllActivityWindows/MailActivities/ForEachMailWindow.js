import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Repeat } from "@mui/icons-material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonOutput from "../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ForEachMailWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  //const [whereVar, setWhereVar] = useState(false);

  const [element, setElement] = useState(
    mapFieldObjWithValueByName(params, "Element", "")
  );
  const [inVar, setInVar] = useState(
    mapFieldObjWithValueByName(params, "In", "")
  );
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setElement(mapFieldObjWithValueByName(params, "Element", ""));
    setInVar(mapFieldObjWithValueByName(params, "In", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, inVar, element]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, inVar, element];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "Element":
        setElement((prevState) => ({ ...prevState, paramValue: value }));
        break;

      /*case "Where":
        setWhereVar(checked);
        break;*/
      case "IN":
        setInVar((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "Element":
        setElement({ ...element, paramType: changeToValue });
        break;

      case "IN":
        setInVar({ ...inVar, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Repeat}
        helperText={selectedActivity.description || "For each element"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <PropertyField
              id={`${props.id}_Element`}
              combo={true}
              labelBtn1={true}
              labelBtn2={true}
              dropdown={element.paramType === "V"}
              paramObj={element}
              labelBtn1OnClick={changeParamTypeToVorC}
              labelBtn2OnClick={changeParamTypeToVorC}
              name="Element"
              label="Element"
              value={element.paramValue}
              options={getOptionsForVariable(element)}
              onChange={handleChange}
              error={
                vaildateParamValue(element.paramValue.toString()).errorStatus
              }
              helperText={vaildateParamValue(element.paramValue.toString()).msg}
            />
            <PropertyField
              id={`${props.id}_IN`}
              combo={true}
              labelBtn1={true}
              labelBtn2={true}
              dropdown={inVar.paramType === "V"}
              paramObj={inVar}
              labelBtn1OnClick={changeParamTypeToVorC}
              labelBtn2OnClick={changeParamTypeToVorC}
              name="IN"
              label="In"
              value={inVar.paramValue}
              options={getOptionsForVariable(inVar)}
              onChange={handleChange}
              error={
                vaildateParamValue(inVar.paramValue.toString()).errorStatus
              }
              helperText={vaildateParamValue(inVar.paramValue.toString()).msg}
            />
            {/* <PropertyField
          checkbox={true}
          name="Where"
          label="Where"
          value={whereVar}
          onChange={handleChange}
          helperText="The Where condition will be for Main Body only."
       />*/}
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ForEachMailWindow;
