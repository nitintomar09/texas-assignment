import React, { useState, useRef, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, Email } from "@mui/icons-material";

import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const SaveAttachmentsWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  console.log(params);
  const hiddenFileInput = useRef(null);
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const radioButtonsArray = [
    { label: "All", value: "All" },
    { label: "JPG, JPEG, PNG, TIF", value: "Images" },
    { label: "CSV, XLSX, XLS", value: "Files" },
    { label: "PDF, DOC, DOCX", value: "Docs" },
  ];

  const [typeValue, setTypeValue] = useState("All");

  const [saveLocation, setSaveLocation] = useState(
    mapFieldObjWithValueByName(params, "SaveLocation", "")
  );
  const [attachmentType, setAttachmentType] = useState(
    mapFieldObjWithValueByName(params, "AttachmentType", "")
  );
  /*const [attachmentAll, setAttachmentAll] = useState(
    mapFieldObjWithValueByName(params, "AttachmentAll", "")
  );
  const [attachmentImage, setAttachmentImage] = useState(
    mapFieldObjWithValueByName(params, "AttachmentImage", "")
  );
  const [attachmentFile, setAttachmentFile] = useState(
    mapFieldObjWithValueByName(params, "AttachmentFile", "")
  );
  const [attachmentDocs, setAttachmentDocs] = useState(
    mapFieldObjWithValueByName(params, "AttachmentDocs", "")
  );
  const [attachmentOthers, setAttachmentOthers] = useState(
    mapFieldObjWithValueByName(params, "AttachmentOthers", "")
  );
  const [otherFormat, setOtherFormat] = useState(
    mapFieldObjWithValueByName(params, "AttachmentOthersInput", "")
  );*/
  const getTypeVal = (num) => {
    switch (+num) {
      case 1:
        return "All";
      case 2:
        return "Images";
      case 3:
        return "Files";
      case 4:
        return "Docs";
      default:
        return "All";
    }
  };
  const getType = (type) => {
    switch (type) {
      case "All":
        return 1;
      case "Images":
        return 2;
      case "Files":
        return 3;
      case "Docs":
        return 4;
      default:
        return 1;
    }
  };

  useEffect(() => {
    if (attachmentType) {
      const parVal = attachmentType?.paramValue || 1;
      setTypeValue(getTypeVal(parVal));
    }
  }, [attachmentType]);
  useEffect(() => {
    setSaveLocation(mapFieldObjWithValueByName(params, "SaveLocation", ""));
    setAttachmentType(mapFieldObjWithValueByName(params, "AttachmentType", ""));
    /*setAttachmentImage(
      mapFieldObjWithValueByName(params, "AttachmentImage", "")
    );
    setAttachmentFile(mapFieldObjWithValueByName(params, "AttachmentFile", ""));
    setAttachmentDocs(mapFieldObjWithValueByName(params, "AttachmentDocs", ""));
    setAttachmentOthers(
      mapFieldObjWithValueByName(params, "AttachmentOthers", "")
    );
    setOtherFormat(
      mapFieldObjWithValueByName(params, "AttachmentOthersInput", "")
    );*/
    setInvisibleInLogs(logsState(params, false));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "SaveLocation":
        setSaveLocation((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Type":
        setTypeValue(value);

        break;
      /*  case "Images":
        setImages({ ...Images, value: checked });
        break;
      case "Files":
        setFiles({ ...Files, value: checked });
        break;
      case "Docs":
        setDocs({ ...Docs, value: checked });
        break;
      case "All":
        setAll({ ...all, value: checked });
        break;
       case "Others":
        setOther({ ...other, value: checked });
        break;
      case "OtherFormat":
        setOtherFormat({ ...otherFormat, paramValue: value });
        break;
*/
      default:
        break;
    }
  };
  /*  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [all, setAll] = useState(
    makingCheckboxFields("All", attachmentType.paramValue, "All")
  );
  const [Images, setImages] = useState(
    makingCheckboxFields("Images", attachmentType.paramValue, "JPG, PNG, TIF")
  );
  const [Files, setFiles] = useState(
    makingCheckboxFields("Files", attachmentType.paramValue, "CSV, XLSX, XLS")
  );
  const [Docs, setDocs] = useState(
    makingCheckboxFields("Docs", attachmentType.paramValue, "PDF,DOC")
  );

   const [other, setOther] = useState(
    makingCheckboxFields(
      "Others",
      attachmentOthers.paramValue,
      "Others. if others specify"
    )
  );*/

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    //all,
    saveLocation,
    typeValue,
    // Images,
    //Files,
    //Docs,
    //other,
    //otherFormat,
  ]);

  const updateParams = () => {
    const newAtcType = { ...attachmentType, paramValue: getType(typeValue) };
    const allParams = [
      invisibleInLogs,
      saveLocation,
      newAtcType,
      /*  { ...attachmentAll, paramValue: all.value },
      { ...attachmentImage, paramValue: Images.value },
      { ...attachmentFile, paramValue: Files.value },
      { ...attachmentDocs, paramValue: Docs.value },
      { ...attachmentOthers, paramValue: other.value },
      otherFormat,*/
    ];
    addParamsToSelAct(allParams);
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "SaveLocation":
        setSaveLocation({ ...saveLocation, paramType: changeToValue });
        break;
      default:
        break;
    }
  };

  const handleFileInput = (e) => {
    console.log(e);

    if (hiddenFileInput) {
      hiddenFileInput.current.click();
    }
  };
  // to handle the user-selected file
  const handleChangeFile = (event) => {
    const fileUploaded = event.target.files[0];

    if (fileUploaded) {
      setSaveLocation({ ...saveLocation, paramValue: fileUploaded.name });
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={
          selectedActivity.description ||
          "Saves the email messages in a specified folder"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <input
              aria-label="inputFile"
              name="inputFile"
              id="inputFile"
              type="file"
              ref={hiddenFileInput}
              onChange={handleChangeFile}
              style={{
                display: "none",
              }} /* Make the file input element invisible */
            />
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>
              {/* <Grid item>
            <PropertyField
              dropdown={true}
              btnIcon={
                <AddBox
                  className={classes.btnIcon + " " + classes.colorPrimary}
                />
              }
              name="MailVariable"
              label="Mail Variable"
              value={mailVariable}
                               options={getOptionsForVariable(mailVariable)}
              onChange={handleChange}
              helperText="Select the mail list variables,whose attachments you want to see"
            />
            </Grid>*/}
              <Grid item>
                <PropertyField
                  id={`${props.id}_SaveLocation`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={saveLocation.paramType === "V"}
                  paramObj={saveLocation}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  btnIcon={
                    <Folder
                      className={classes.btnIcon + " " + classes.colorPrimary}
                      //  onClick={(e) => handleFileInput(e)}
                    />
                  }
                  name="SaveLocation"
                  label="Save Location"
                  value={saveLocation.paramValue}
                  options={getOptionsForVariable(saveLocation)}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(saveLocation.paramValue.toString())
                      .errorStatus
                  }
                  helperText={
                    vaildateParamValue(saveLocation.paramValue.toString()).msg
                  }
                />
              </Grid>
              <Grid item>
                <Typography className={classes.label}>
                  Save Attachment type of
                </Typography>
              </Grid>
              {/*<Grid item>
                {[
                  { ...all },
                  { ...Images },
                  { ...Files },
                  { ...Docs },
                ].map((item, index) => (
                  <React.Fragment key={index}>
                    <Grid container>
                      <Grid item>
                        <PropertyField checkbox={true} {...item} />
                      </Grid>

                      item.name === "Others. if others specify" &&
                      item.value ? (
                        <Grid item>
                          <PropertyField
                            name="OtherFormat"
                            value={otherFormat.paramValue}
                            onChange={handleChange}
                          />
                        </Grid>
                      ) : null
                    </Grid>
                    {item.name === "All" ? <hr /> : null}
                  </React.Fragment>
                ))}
              </Grid>*/}
              <Grid item>
                <PropertyField
                  id={`${props.id}_Type`}
                  radio={true}
                  ButtonsArray={radioButtonsArray}
                  name="Type"
                  label="Type"
                  value={typeValue}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default SaveAttachmentsWindow;
