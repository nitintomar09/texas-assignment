import React, { useState } from "react";
import PropertyField from "../../../PropertyFields/PropertyField";
import { Grid, Typography } from "@mui/material";
import CheckboxGroup from "../../../PropertyFields/CheckboxGroup";
import { useStyles } from "../../Common/CommonStyles";

const MoveMailExchangeWindow = (props) => {
  const classes = useStyles();
  const [password, setPassword] = useState("");

  const [server, setServer] = useState("");

  const [timeout, setTimeout] = useState("");

  const [exchangeVersion, setExchangeVersion] = useState("");
  const [destinationMailFolder, setDestinationMailFolder] = useState("");
  const [sourceMailFolder, setSourceMailFolder] = useState("");

  const [inputMailList, setInputMailList] = useState("");

  const [domain, setDomain] = useState("");

  const [username, setUsername] = useState("");

  const [applicationId, setApplicationId] = useState("");

  const [authenticationType, setAuthenticationType] = useState("");

  const [directoryId, setDirectoryId] = useState("");
  const [sharedMailbox, setSharedMailbox] = useState("");
  const [sharedMailboxCheckboxValue, setSharedMailboxCheckboxValue] =
    useState(false);

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value, checked } = e.target;
    switch (name) {
      case "ExchangeVersion":
        setExchangeVersion(value);
        break;

      case "Domain":
        setDomain(value);
        break;

      case "Username":
        setUsername(value);
        break;

      case "Password":
        setPassword(value);
        break;

      case "Server":
        setServer(value);
        break;

      case "EmailAutoDiscover":
        setEmailAutoDiscover({ ...emailAutoDiscover, value: checked });
        break;

      case "ExistExchangingService":
        setExistExchangingService({
          ...existExchangingService,
          value: checked,
        });
        break;

      case "Timeout":
        setTimeout(value);
        break;

      case "DestinationMailFolder":
        setDestinationMailFolder(value);
        break;
      case "SourceMailFolder":
        setSourceMailFolder(value);
        break;
      case "InputMailList":
        setInputMailList(value);
        break;

      case "SharedMailbox":
        setSharedMailbox(value);
        break;

      case "SharedMailboxCheckboxValue":
        setSharedMailboxCheckboxValue(!sharedMailboxCheckboxValue);
        break;

      case "ApplicationId":
        setApplicationId(value);
        break;

      case "AuthenticationType":
        setAuthenticationType(value);
        break;

      case "DirectoryId":
        setDirectoryId(value);
        break;

      default:
        break;
    }
  };
  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [emailAutoDiscover, setEmailAutoDiscover] = useState(
    makingCheckboxFields("EmailAutoDiscover", false, "Email Auto-Discover")
  );
  const [existExchangingService, setExistExchangingService] = useState(
    makingCheckboxFields(
      "ExistExchangingService",
      false,
      "Exist Exchanging Service"
    )
  );

  return (
    <div>
      <Grid container direction="column" spacing={2}>
        <Grid item>
          <PropertyField
            id={`${props.id}_Timeout`}
            labelBtn1={true}
            labelBtn2={true}
            name="Timeout"
            label="Timeout (miliseconds)"
            value={timeout}
            onChange={handleChange}
          />
        </Grid>
      </Grid>

      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Typography component="h5" className={classes.GroupTitle}>
            EXCHANGE SETTINGS
          </Typography>
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_ExchangeVersion`}
            labelBtn1={true}
            labelBtn2={true}
            name="ExchangeVersion"
            label="Exchange Version"
            value={exchangeVersion}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_Server`}
            labelBtn1={true}
            labelBtn2={true}
            name="Server"
            label="Server"
            value={server}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <CheckboxGroup
            id={`${props.id}`}
            checkboxArray={[
              { ...emailAutoDiscover },
              { ...existExchangingService },
            ]}
          />
        </Grid>
      </Grid>

      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Typography component="h5" className={classes.GroupTitle}>
            DETAILS
          </Typography>
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_InputMailList`}
            labelBtn1={true}
            labelBtn2={true}
            dropdown={true}
            options={ExcelFilePathOptions}
            name="InputMailList"
            label="Input Mail List"
            value={inputMailList}
            onChange={handleChange}
            helperText="Select the mail list variable whose mail you want to move."
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_SourceMailFolder`}
            labelBtn1={true}
            labelBtn2={true}
            name="SourceMailFolder"
            label="Source Mail Folder"
            value={sourceMailFolder}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_DestMailFolder`}
            labelBtn1={true}
            labelBtn2={true}
            name="DestinationMailFolder"
            label="Destination Mail Folder"
            value={destinationMailFolder}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_SharedMailbox`}
            labelBtn1={true}
            labelBtn2={true}
            labelBtnDisabled={true}
            labelWithCheckbox={true}
            labelCheckboxName="SharedMailboxCheckboxValue"
            labelCheckboxValue={sharedMailboxCheckboxValue}
            name="SharedMailbox"
            label="Shared Mailbox"
            value={sharedMailbox}
            onChange={handleChange}
          />
        </Grid>
      </Grid>

      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Typography component="h5" className={classes.GroupTitle}>
            LOGIN DETAILS
          </Typography>
        </Grid>

        <Grid item>
          <PropertyField
            id={`${props.id}_Domain`}
            labelBtn1={true}
            labelBtn2={true}
            name="Domain"
            label="Domain"
            value={domain}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_Username`}
            labelBtn1={true}
            labelBtn2={true}
            name="Username"
            label="Username"
            value={username}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_Password`}
            labelBtn1={true}
            labelBtn2={true}
            name="Password"
            label="Password"
            value={password}
            secret={true}
            onChange={handleChange}
          />
        </Grid>
      </Grid>

      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Typography component="h5" className={classes.GroupTitle}>
            OFFICE 365 SETTINGS
          </Typography>
        </Grid>

        <Grid item>
          <PropertyField
            id={`${props.id}_ApplicationId`}
            labelBtn1={true}
            labelBtn2={true}
            name="ApplicationId"
            label="Application Id"
            value={applicationId}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_AuthenType`}
            labelBtn1={true}
            labelBtn2={true}
            dropdown={true}
            options={ExcelFilePathOptions}
            name="AuthenticationType"
            label="Authentication Type"
            value={authenticationType}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_DirectoryId`}
            labelBtn1={true}
            labelBtn2={true}
            name="DirectoryId"
            label="Directory Id"
            value={directoryId}
            onChange={handleChange}
          />
        </Grid>
      </Grid>
    </div>
  );
};

export default MoveMailExchangeWindow;
const ExcelFilePathOptions = [
  { name: "C://Documents/Excel", value: "C://Documents/Excel" },
  { name: "Sheetlist", value: "Sheetlist" },
  { name: "C://Documents", value: "C://Documents" },
  { name: "D://Documents/Excel", value: "D://Documents/Excel" },
];
