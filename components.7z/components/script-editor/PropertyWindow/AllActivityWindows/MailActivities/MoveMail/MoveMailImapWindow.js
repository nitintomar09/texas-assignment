import React, { useState } from "react";
import PropertyField from "../../../PropertyFields/PropertyField";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../../Common/CommonStyles";

const MoveMailImapWindow = (props) => {
  const classes = useStyles();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [server, setServer] = useState("");
  const [port, setPort] = useState("");

  const radioButtonsArray = [
    { label: "SSL", value: "SSL" },
    { label: "TLS", value: "TLS" },
  ];
  const [secureConnectionTypeValue, setSecureConnectionTypeValue] =
    useState("SSL");

  const [destinationMailFolder, setDestinationMailFolder] = useState("");
  const [sourceMailFolder, setSourceMailFolder] = useState("");

  const [inputMailList, setInputMailList] = useState("");

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value, checked } = e.target;
    switch (name) {
      case "EmailAccount":
        setEmail(value);
        break;

      case "Password":
        setPassword(value);
        break;
      case "Server":
        setServer(value);
        break;

      case "Port":
        setPort(value);
        break;
      case "SecureConnectionType":
        setSecureConnectionTypeValue(value);
        break;

      case "SecureConnection":
        setSecureConnection({ ...secureConnection, value: checked });
        break;
      case "EnableSSL":
        setEnableSSL({ ...enableSSL, value: checked });
        break;
      case "DestinationMailFolder":
        setDestinationMailFolder(value);
        break;
      case "SourceMailFolder":
        setSourceMailFolder(value);
        break;
      case "InputMailList":
        setInputMailList(value);
        break;
      default:
        break;
    }
  };
  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [secureConnection, setSecureConnection] = useState(
    makingCheckboxFields("SecureConnection", false, "Secure Connection")
  );
  const [enableSSL, setEnableSSL] = useState(
    makingCheckboxFields("EnableSSL", false, "Enable SSL")
  );
  return (
    <div>
      <Grid container direction="column" spacing={2}>
        <Grid item>
          <PropertyField
            id={`${props.id}_EmailAccount`}
            labelBtn1={true}
            labelBtn2={true}
            name="EmailAccount"
            label="Email Account"
            value={email}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_Password`}
            labelBtn1={true}
            labelBtn2={true}
            name="Password"
            label="Password"
            value={password}
            secret={true}
            onChange={handleChange}
          />
        </Grid>
      </Grid>
      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Typography component="h5" className={classes.GroupTitle}>
            SERVER DETAILS
          </Typography>
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_Server`}
            labelBtn1={true}
            labelBtn2={true}
            name="Server"
            label="Server"
            value={server}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_Port`}
            labelBtn1={true}
            labelBtn2={true}
            name="Port"
            label="Port"
            value={port}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            checkbox={true}
            {...enableSSL}
            id={`${props.id}_EnableSSL`}
          />
        </Grid>
      </Grid>
      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Typography component="h5" className={classes.GroupTitle}>
            OTHER INPUT DETAILS
          </Typography>
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_InputMailList`}
            labelBtn1={true}
            labelBtn2={true}
            dropdown={true}
            options={ExcelFilePathOptions}
            name="InputMailList"
            label="Input Mail List"
            value={inputMailList}
            onChange={handleChange}
            helperText="Select the mail list variable whose mail you want to move."
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_SourceMailFolder`}
            labelBtn1={true}
            labelBtn2={true}
            dropdown={true}
            options={ExcelFilePathOptions}
            name="SourceMailFolder"
            label="Source Mail Folder"
            value={sourceMailFolder}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${props.id}_DestinationMailFolder`}
            labelBtn1={true}
            labelBtn2={true}
            dropdown={true}
            options={ExcelFilePathOptions}
            name="DestinationMailFolder"
            label="Destination Mail Folder"
            value={destinationMailFolder}
            onChange={handleChange}
          />
        </Grid>
        <Grid item>
          <PropertyField checkbox={true} {...secureConnection} />
          {secureConnection && secureConnection.value ? (
            <div style={{ paddingLeft: "30px" }}>
              <PropertyField
                id={`${props.id}_SecureConnType`}
                radio={true}
                ButtonsArray={radioButtonsArray}
                name="SecureConnectionType"
                value={secureConnectionTypeValue}
                onChange={handleChange}
              />
            </div>
          ) : null}
        </Grid>
      </Grid>
    </div>
  );
};

export default MoveMailImapWindow;
const ExcelFilePathOptions = [
  { name: "C://Documents/Excel", value: "C://Documents/Excel" },
  { name: "Sheetlist", value: "Sheetlist" },
  { name: "C://Documents", value: "C://Documents" },
  { name: "D://Documents/Excel", value: "D://Documents/Excel" },
];
