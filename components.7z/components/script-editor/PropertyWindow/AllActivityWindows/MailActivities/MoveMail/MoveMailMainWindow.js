import React, { useState } from "react";
import PropertyField from "../../../PropertyFields/PropertyField";
import { SendOutlined } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import MoveMailImapWindow from "./MoveMailImapWindow";
import MoveMailExchangeWindow from "./MoveMailExchangeWindow";
import { useStyles } from "../../Common/CommonStyles";
import CommonFields from "../../Common/CommonFields";

const MoveMailMainWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, updateDisplayNameSelAct } = props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.activityName) || ""
  );
  const radioButtonsArray = [
    { label: "IMAP", value: "IMAP" },
    { label: "Exchange", value: "Exchange" },
  ];
  const [makeLogsPrivate, setMakeLogsPrivate] = useState(false);
  const [typeValue, setTypeValue] = useState("IMAP");

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setMakeLogsPrivate(!makeLogsPrivate);
        break;
      case "Type":
        setTypeValue(value);
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={makeLogsPrivate}
        ActivityIcon={SendOutlined}
        helperText={
          selectedActivity.description ||
          "Moves an email message to a specified folder inside Connect"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              INPUT
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              id={`${props.id}_Type`}
              radio={true}
              ButtonsArray={radioButtonsArray}
              name="Type"
              label="Type"
              value={typeValue}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
        {typeValue === "IMAP" ? (
          <MoveMailImapWindow id={props.id} />
        ) : typeValue === "Exchange" ? (
          <MoveMailExchangeWindow id={props.id} />
        ) : null}
      </div>
    </div>
  );
};

export default MoveMailMainWindow;
