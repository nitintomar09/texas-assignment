import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import CheckboxGroup from "./../../PropertyFields/CheckboxGroup";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
  getVariableTypeById,
} from "../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonInput from "../Common/CommonInput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const DeleteMailExchangeWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;

  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  {
    /* const [password, setPassword] = useState("");

  const [server, setServer] = useState("");

  const [timeout, setTimeout] = useState("");

  const [exchangeVersion, setExchangeVersion] = useState("");

  const [domain, setDomain] = useState("");

  const [username, setUsername] = useState("");

  const [statusField, setStatusField] = useState("");

  const [emailAutoDiscoverOrg, setEmailAutoDiscoverOrg] = useState(
    mapFieldObjWithValueByName(params, "EmailAutoDiscover", "")
  );*/
  }
  const [statusField, setStatusField] = useState(
    mapFieldObjWithValueByName(params, "Status", "")
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    /*  setTimeout(mapFieldObjWithValueByName(params, "Timeout", ""));
    setPassword(mapFieldObjWithValueByName(params, "Password", ""));
    setServer(mapFieldObjWithValueByName(params, "Server", ""));
    setExchangeVersion(
      mapFieldObjWithValueByName(params, "ExchangeVersion", "")
    );
    setDomain(mapFieldObjWithValueByName(params, "Domain", ""));
    setUsername(mapFieldObjWithValueByName(params, "User", ""));
    setEmailAutoDiscoverOrg(
      mapFieldObjWithValueByName(params, "EmailAutoDiscover", "")
    );
    setExistExchangingServiceOrg(
      mapFieldObjWithValueByName(params, "ExistExchangingService", "")
    );*/
    setStatusField(mapFieldObjWithValueByName(params, "Status", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);
  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      /*  case "ExchangeVersion":
        setExchangeVersion({ ...exchangeVersion, paramValue: value });
        break;

      case "Domain":
        setDomain({ ...domain, paramValue: value });
        break;

      case "Username":
        setUsername({ ...username, paramValue: value });
        break;

      case "Password":
        setPassword({ ...password, paramValue: value });
        break;

      case "Server":
        setServer({ ...server, paramValue: value });
        break;

      case "EmailAutoDiscover":
        setEmailAutoDiscover({ ...emailAutoDiscover, value: checked });
        break;

      case "ExistExchangingService":
        setExistExchangingService({
          ...existExchangingService,
          value: checked,
        });
        break;

      case "Timeout":
        setTimeout({ ...timeout, paramValue: value });
        break;
        */

      case "Status":
        setStatusField((prevState) => ({ ...prevState, paramValue: value }));
        break;

      default:
        break;
    }
  };

  /* const changeParamTypeToVorC = (paramName, changeToValue) => {
    console.log(paramName, changeToValue);
    switch (paramName) {
      case "ExchangeVersion":
        setExchangeVersion({ ...exchangeVersion, paramType: changeToValue });
        break;

      case "Password":
        setPassword({ ...password, paramType: changeToValue });
        break;

      case "Server":
        setServer({ ...server, paramType: changeToValue });
        break;

      case "Domain":
        setDomain({ ...domain, paramType: changeToValue });
        break;

      case "Username":
        setUsername({ ...username, paramType: changeToValue });
        break;

      case "Timeout":
        setTimeout({ ...timeout, paramType: changeToValue });
        break;

      case "Status":
        setStatusField({
          ...statusField,
          paramType: changeToValue,
        });
        break;
      default:
        break;
    }
  };
  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [emailAutoDiscover, setEmailAutoDiscover] = useState(
    makingCheckboxFields(
      "EmailAutoDiscover",
      emailAutoDiscoverOrg.paramValue,
      "Email Auto-Discover"
    )
  );
  const [existExchangingService, setExistExchangingService] = useState(
    makingCheckboxFields(
      "ExistExchangingService",
      existExchangingServiceOrg.paramValue,
      "Exist Exchanging Service"
    )
  );*/
  useEffect(() => {
    updateParams();
  }, [
    // emailAutoDiscover,
    //existExchangingService,
    invisibleInLogs,
    //timeout,
    //domain,
    //username,
    //password,
    //server,
    //exchangeVersion,
    statusField,
  ]);

  const updateParams = () => {
    const allParams = [
      /* { ...emailAutoDiscoverOrg, paramValue: emailAutoDiscover.value },
      {
        ...existExchangingServiceOrg,
        paramValue: existExchangingService.value,
      },*/
      invisibleInLogs,
      // timeout,
      //domain,
      //username,
      //password,
      //server,
      //exchangeVersion,
      statusField,
    ];
    addParamsToSelAct(allParams);
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || "Deletes an email message"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <CommonInput />
            {/*<Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={timeout.paramType === "V"}
                  paramObj={timeout}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Timeout"
                  label="Timeout (miliseconds)"
                  value={timeout.paramValue}
                  options={getOptionsForVariable(timeout)}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>

            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  EXCHANGE SETTINGS
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={exchangeVersion.paramType === "V"}
                  paramObj={exchangeVersion}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ExchangeVersion"
                  label="Exchange Version"
                  value={exchangeVersion.paramValue}
                  options={getOptionsForVariable(exchangeVersion)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={server.paramType === "V"}
                  paramObj={server}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Server"
                  label="Server"
                  value={server.paramValue}
                  options={getOptionsForVariable(server)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <CheckboxGroup
                  checkboxArray={[
                    { ...emailAutoDiscover },
                    { ...existExchangingService },
                  ]}
                />
              </Grid>
            </Grid>

            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  LOGIN DETAILS
                </Typography>
              </Grid>

              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={domain.paramType === "V"}
                  paramObj={domain}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Domain"
                  label="Domain"
                  value={domain.paramValue}
                  options={getOptionsForVariable(domain)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={username.paramType === "V"}
                  paramObj={username}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Username"
                  label="Username"
                  value={username.paramValue}
                  options={getOptionsForVariable(username)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={password.paramType === "V"}
                  paramObj={password}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Password"
                  label="Password"
                  value={password.paramValue}
                  secret={true}
                  options={getOptionsForVariable(password)}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>*/}
          </>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Status`}
                combo={true}
                dropdown={true}
                paramObj={statusField}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Status"
                //label="Status"
                label={`Status (${getVariableTypeById(
                  statusField.paramObjectTypeId
                )})`}
                value={statusField.paramValue}
                options={getOptionsForVariable(statusField)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    statusField.paramValue
                      ? statusField.paramValue.toString()
                      : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    statusField.paramValue
                      ? statusField.paramValue.toString()
                      : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab == "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default DeleteMailExchangeWindow;
