import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { SendOutlined } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import CheckboxGroup from "./../../PropertyFields/CheckboxGroup";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
} from "../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const SendMailSMTPWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  console.log(params);
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [email, setEmail] = useState(
    mapFieldObjWithValueByName(params, "EmailAccount", "")
  );
  const [password, setPassword] = useState(
    mapFieldObjWithValueByName(params, "Password", "")
  );

  const [server, setServer] = useState(
    mapFieldObjWithValueByName(params, "Server", "")
  );
  const [port, setPort] = useState(
    mapFieldObjWithValueByName(params, "Port", "")
  );

  const [to, setTo] = useState(mapFieldObjWithValueByName(params, "To", ""));
  const [cc, setCc] = useState(mapFieldObjWithValueByName(params, "CC", ""));
  const [bcc, setBcc] = useState(mapFieldObjWithValueByName(params, "BCC", ""));

  const [subject, setSubject] = useState(
    mapFieldObjWithValueByName(params, "Subject", "")
  );
  const [body, setBody] = useState(
    mapFieldObjWithValueByName(params, "Body", "")
  );
  const [fileAttachments, setFileAttachments] = useState(
    mapFieldObjWithValueByName(params, "FileAttachments", "")
  );
  const [htmlBody, setHtmlBody] = useState(
    mapFieldObjWithValueByName(params, "HTMlBody", false)
  );

  const [sConCheckbox, setSConCheckbox] = useState(
    mapFieldObjWithValueByName(params, "SecureConnection", false)
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setSubject(mapFieldObjWithValueByName(params, "Subject", ""));
    setTo(mapFieldObjWithValueByName(params, "To", ""));
    setCc(mapFieldObjWithValueByName(params, "CC", ""));
    setBcc(mapFieldObjWithValueByName(params, "BCC", ""));
    setBody(mapFieldObjWithValueByName(params, "Body", ""));
    setFileAttachments(
      mapFieldObjWithValueByName(params, "FileAttachments", "")
    );
    setHtmlBody(mapFieldObjWithValueByName(params, "HTMLBody", ""));
    setEmail(mapFieldObjWithValueByName(params, "EmailAccount", ""));
    setPassword(mapFieldObjWithValueByName(params, "Password", ""));
    setPort(mapFieldObjWithValueByName(params, "Port", ""));
    setServer(mapFieldObjWithValueByName(params, "Server", ""));
    setSConCheckbox(mapFieldObjWithValueByName(params, "SecureConnection", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "EmailAccount":
        setEmail((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Password":
        setPassword((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Server":
        setServer((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Port":
        setPort((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "SecureConnection":
        setSecureConnection({ ...secureConnection, value: checked });
        break;

      case "HtmlBody":
        setHtmlBody({ ...htmlBody, paramValue: checked });
        break;
      case "To":
        setTo((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Cc":
        setCc((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Bcc":
        setBcc((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Subject":
        setSubject((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Body":
        setBody((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "FileAttachments":
        setFileAttachments((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;

      default:
        break;
    }
  };
  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };

  const [secureConnection, setSecureConnection] = useState(
    makingCheckboxFields(
      "SecureConnection",
      sConCheckbox.paramValue,
      "Secure Connection"
    )
  );

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    htmlBody,
    subject,
    body,
    to,
    cc,
    bcc,
    fileAttachments,
    secureConnection,
    email,
    password,
    server,
    port,
  ]);

  const updateParams = () => {
    const newHtmlBody = { ...htmlBody, paramValue: htmlBody.value };
    const sCon = { ...sConCheckbox, paramValue: secureConnection.value };
    const allParams = [
      invisibleInLogs,
      newHtmlBody,
      subject,
      body,
      to,
      cc,
      bcc,
      fileAttachments,
      sCon,
      email,
      password,
      server,
      port,
    ];
    addParamsToSelAct(allParams);
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "EmailAccount":
        setEmail({ ...email, paramType: changeToValue });
        break;

      case "Password":
        setPassword({ ...password, paramType: changeToValue });
        break;
      case "Server":
        setServer({ ...server, paramType: changeToValue });
        break;

      case "Port":
        setPort({ ...port, paramType: changeToValue });
        break;
      case "Subject":
        setSubject({ ...subject, paramType: changeToValue });
        break;

      case "Body":
        setBody({ ...body, paramType: changeToValue });
        break;

      case "To":
        setTo({ ...to, paramType: changeToValue });
        break;

      case "Cc":
        setCc({ ...cc, paramType: changeToValue });
        break;

      case "Bcc":
        setBcc({
          ...bcc,
          paramType: changeToValue,
        });
        break;
      case "FileAttachments":
        setFileAttachments({
          ...fileAttachments,
          paramType: changeToValue,
        });
        break;
      default:
        break;
    }
  };
  {
    /* const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
*/
  }

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={SendOutlined}
        helperText={
          selectedActivity.description ||
          "Sends an email message by using the SMTP protocol"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_EmailAccount`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={email.paramType === "V"}
                  paramObj={email}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  options={getOptionsForVariable(email)}
                  name="EmailAccount"
                  label="Email Account"
                  value={email.paramValue}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(email.paramValue.toString()).errorStatus
                  }
                  helperText={
                    vaildateParamValue(email.paramValue.toString()).msg
                  }
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Password`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={password.paramType === "V"}
                  paramObj={password}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  options={getOptionsForVariable(password)}
                  name="Password"
                  label="Password"
                  value={password.paramValue}
                  secret={true}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(password.paramValue.toString())
                      .errorStatus
                  }
                  helperText={
                    vaildateParamValue(password.paramValue.toString()).msg
                  }
                />
              </Grid>
            </Grid>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  SERVER DETAILS
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Server`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={server.paramType === "V"}
                  paramObj={server}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  options={getOptionsForVariable(server)}
                  name="Server"
                  label="Server"
                  value={server.paramValue}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(server.paramValue.toString()).errorStatus
                  }
                  helperText={
                    vaildateParamValue(server.paramValue.toString()).msg
                  }
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Port`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={port.paramType === "V"}
                  paramObj={port}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  options={getOptionsForVariable(port)}
                  name="Port"
                  label="Port"
                  value={port.paramValue}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(port.paramValue.toString()).errorStatus
                  }
                  helperText={
                    vaildateParamValue(port.paramValue.toString()).msg
                  }
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_SecureConnection`}
                  checkbox={true}
                  name="SecureConnection"
                  label="Secure Connection"
                  value={secureConnection.value}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
            <Grid container direction="column" spacing={2}>
              {/* <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              SENDER DETAILS
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="SenderName"
              label="Sender Name"
              value={senderName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="From"
              label="From"
              value={from}
              onChange={handleChange}
            />
         </Grid>*/}
              <Grid item style={{ marginTop: "8px" }}>
                <PropertyField
                  id={`${props.id}_HtmlBody`}
                  checkbox={true}
                  name="HtmlBody"
                  label="HTML Body"
                  value={htmlBody.paramValue}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  RECIEVER DETAILS
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_To`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={to.paramType === "V"}
                  paramObj={to}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="To"
                  label="To"
                  value={to.paramValue}
                  options={getOptionsForVariable(to)}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(to.paramValue.toString()).errorStatus
                  }
                  helperText={vaildateParamValue(to.paramValue.toString()).msg}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Cc`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  name="Cc"
                  label="Cc"
                  dropdown={cc.paramType === "V"}
                  paramObj={cc}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  value={cc.paramValue}
                  options={getOptionsForVariable(cc)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Bcc`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  name="Bcc"
                  label="Bcc"
                  dropdown={bcc.paramType === "V"}
                  paramObj={bcc}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  value={bcc.paramValue}
                  options={getOptionsForVariable(bcc)}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>

            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  EMAIL
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Subject`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  name="Subject"
                  label="Subject"
                  dropdown={subject.paramType === "V"}
                  paramObj={subject}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  value={subject.paramValue}
                  options={getOptionsForVariable(subject)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Body`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  name="Body"
                  label="Body"
                  dropdown={body.paramType === "V"}
                  paramObj={body}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  value={body.paramValue}
                  options={getOptionsForVariable(body)}
                  onChange={handleChange}
                />
              </Grid>
              {/* <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Timeout"
              label="Timeout (miliseconds)"
              value={timeout}
              onChange={handleChange}
            />
        </Grid>*/}
              <Grid item>
                <PropertyField
                  id={`${props.id}_FileAttachments`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  name="FileAttachments"
                  label="File Attachments"
                  dropdown={fileAttachments.paramType === "V"}
                  paramObj={fileAttachments}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  value={fileAttachments.paramValue}
                  options={getOptionsForVariable(fileAttachments)}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default SendMailSMTPWindow;
