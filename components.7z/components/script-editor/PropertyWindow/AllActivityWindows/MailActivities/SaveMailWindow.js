import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, Email } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
const SaveMailWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(false);

  const [mailVariable, setMailVariable] = useState(
    mapFieldObjWithValueByName(params, "MailVariable", "")
  );
  const [saveLocation, setSaveLocation] = useState(
    mapFieldObjWithValueByName(params, "SaveLocation", "")
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setMailVariable(mapFieldObjWithValueByName(params, "MailVariable", ""));
    setSaveLocation(mapFieldObjWithValueByName(params, "SaveLocation", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, saveLocation]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, saveLocation];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "MailVariable":
        setMailVariable((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "SaveLocation":
        setSaveLocation((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "MailVariable":
        setMailVariable({ ...mailVariable, paramType: changeToValue });
        break;

      case "SaveLocation":
        setSaveLocation({ ...saveLocation, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={
          selectedActivity.description ||
          "Saves the email messages in a specified folder"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            {/* <Grid item>
              <PropertyField
                labelBtn1={true}
                labelBtn2={true}
                dropdown={mailVariable.paramType === "V"}
                paramObj={mailVariable}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(mailVariable)}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="MailVariable"
                label="Mail Variable"
                value={mailVariable.paramValue}
                onChange={handleChange}
                helperText="Select the mail list variables,whose attachments you want to see"
              />
              </Grid>*/}
            <Grid item>
              <PropertyField
                id={`${props.id}_SaveLocation`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={saveLocation.paramType === "V"}
                paramObj={saveLocation}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(saveLocation)}
                btnIcon={
                  <Folder
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="SaveLocation"
                label="Save Location"
                value={saveLocation.paramValue}
                onChange={handleChange}
                error={
                  vaildateParamValue(saveLocation.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(saveLocation.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default SaveMailWindow;
