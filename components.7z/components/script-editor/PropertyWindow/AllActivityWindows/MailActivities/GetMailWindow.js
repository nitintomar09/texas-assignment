import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Grid, Typography } from "@mui/material";
import CheckboxGroup from "./../../PropertyFields/CheckboxGroup";
import { Input } from "@mui/icons-material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const GetMailWindow = (props) => {
  const classes = useStyles();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  console.log(params);
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const [timeout, setTimeout] = useState(
    mapFieldObjWithValueByName(params, "Timeout", 30)
  );

  const [outputMail, setOutputMail] = useState(
    mapFieldObjWithValueByName(params, "OutputMails", "")
  );

  const [deleteReadMessagesOrg, setDeleteReadMessagesOrg] = useState(
    mapFieldObjWithValueByName(params, "DeleteReadMessage", false)
  );

  const [topOrg, setTopOrg] = useState(
    mapFieldObjWithValueByName(params, "Top", false)
  );
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setOutputMail(mapFieldObjWithValueByName(params, "OutputMails", ""));
    setDeleteReadMessagesOrg(
      mapFieldObjWithValueByName(params, "DeleteReadMessage", false)
    );
    setTopOrg(mapFieldObjWithValueByName(params, "Top", false));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "DeleteReadMessages":
        setDeleteReadMessages({ ...deleteReadMessages, value: checked });
        break;

      case "Top":
        setTop({ ...top, value: checked });
        break;

      case "Timeout":
        setTimeout((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "OutputMail":
        setOutputMail((prevState) => ({ ...prevState, paramValue: value }));
        break;

      default:
        break;
    }
  };

  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [deleteReadMessages, setDeleteReadMessages] = useState(
    makingCheckboxFields(
      "DeleteReadMessages",
      deleteReadMessagesOrg.paramValue,
      "Delete Read Messages"
    )
  );
  const [top, setTop] = useState(
    makingCheckboxFields("Top", topOrg.paramValue, "Top")
  );

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "Timeout":
        setTimeout({ ...timeout, paramType: changeToValue });
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    updateParams();
  }, [timeout, outputMail, invisibleInLogs, deleteReadMessages, top]);

  const updateParams = () => {
    const allParams = [
      timeout,
      outputMail,
      invisibleInLogs,
      { ...deleteReadMessagesOrg, paramValue: deleteReadMessages.value },
      { ...topOrg, paramValue: top.value },
    ];
    addParamsToSelAct(allParams);
  };
  console.log(params);

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Input}
        helperText={
          selectedActivity.description ||
          "Retrieves an email message from a specified server from Connect"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>

            {/* <Grid item>
              <CheckboxGroup
                checkboxArray={[{ ...deleteReadMessages }, { ...top }]}
              />
        </Grid>*/}

            <Grid item>
              <PropertyField
                id={`${props.id}_number`}
                combo={true}
                type="number"
                labelBtn1={true}
                labelBtn2={true}
                dropdown={timeout.paramType === "V"}
                paramObj={timeout}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="Timeout"
                label="Timeout (minutes)"
                value={timeout.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(timeout)}
                error={
                  vaildateParamValue(timeout.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(timeout.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_OutputMail`}
                combo={true}
                dropdown={true}
                paramObj={outputMail}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="OutputMail"
                // label="Output"
                label={`Output (${getVariableTypeById(
                  outputMail.paramObjectTypeId
                )})`}
                value={outputMail.paramValue}
                options={getOptionsForVariable(outputMail)}
                onChange={handleChange}
                error={
                  vaildateParamValue(outputMail.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(outputMail.paramValue.toString()).msg
                }
                // helperText="Select the mail list variable or add a mail variable"
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default GetMailWindow;
