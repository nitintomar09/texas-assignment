import React, { useEffect } from "react";
import PropertyField from "../../../PropertyFields/PropertyField";
import { Grid, Typography } from "@mui/material";
import CheckboxGroup from "../../../PropertyFields/CheckboxGroup";
import { useStyles } from "../../Common/CommonStyles";
import { useSelector, useDispatch } from "react-redux";
import { setErrorType } from "../../../../../../redux/actions";
import ErrorsWindow from "../../Common/ErrorsWindow";
import { getOptionsForVariable } from "../../Common/CommonMethods";
import CommonOutput from "../../Common/commonOutput";
import { vaildateParamValue } from "../../../../../../utils/validations/validations";

const ConnectImapWindow = (props) => {
  const {
    password,
    server,
    port,
    emailAccount,
    folder,
    timeout,
    handleChange,
    handleChangeByKeyboard,
    deleteReadMessages,
    secureConnection,
    retrieveOnlyUnread,
    markRetrieveAsRead,
    top,
    changeParamTypeToVorC,
    radioButtonsArrayForSecureConnection,
    secureConnectionTypeValue,
    id,
  } = props;
  const classes = useStyles();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setErrorType("Throw"));
  }, []);

  return (
    <div>
      {selectedTab === "input" ? (
        <>
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <PropertyField
                id={`${id}_EmailAccount`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                name="EmailAccount"
                label="Email Account"
                dropdown={emailAccount.paramType === "V"}
                paramObj={emailAccount}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                value={emailAccount.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(emailAccount)}
                error={vaildateParamValue(emailAccount.paramValue).errorStatus}
                helperText={vaildateParamValue(emailAccount.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Password`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                name="Password"
                label="Password"
                secret={true}
                dropdown={password.paramType === "V"}
                paramObj={password}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                value={password.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(password)}
                error={vaildateParamValue(password.paramValue).errorStatus}
                helperText={vaildateParamValue(password.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Folder`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                name="Folder"
                label="Folder"
                dropdown={folder.paramType === "V"}
                paramObj={folder}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                value={folder.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(folder)}
              />
            </Grid>
          </Grid>
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                SERVER DETAILS
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${id}_Server`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                name="Server"
                label="Server"
                dropdown={server.paramType === "V"}
                paramObj={server}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                value={server.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(server)}
                error={vaildateParamValue(server.paramValue).errorStatus}
                helperText={vaildateParamValue(server.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Port`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                name="Port"
                label="port"
                dropdown={port.paramType === "V"}
                paramObj={port}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                value={port.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(port)}
                error={vaildateParamValue(port.paramValue).errorStatus}
                helperText={vaildateParamValue(port.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <CheckboxGroup
                id={`${id}`}
                checkboxArray={[
                  //   { ...deleteReadMessages },
                  // { ...retrieveOnlyUnread },
                  //{ ...markRetrieveAsRead },
                  { ...secureConnection },
                ]}
              />
              {secureConnection && secureConnection?.value ? (
                <div style={{ paddingLeft: "30px" }}>
                  <PropertyField
                    id={`${id}_SecureConnectionType`}
                    radio={true}
                    ButtonsArray={radioButtonsArrayForSecureConnection}
                    name="SecureConnectionType"
                    value={secureConnectionTypeValue.paramValue}
                    onChange={handleChange}
                  />
                </div>
              ) : null}
            </Grid>
            {/*<Grid item>
              <PropertyField checkbox={true} {...top} />
              </Grid>*/}
            <Grid item>
              <PropertyField
                id={`${id}_Timeout`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                name="Timeout"
                label="Timeout (miliseconds)"
                dropdown={timeout.paramType === "V"}
                paramObj={timeout}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                value={timeout.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(timeout)}
              />
            </Grid>
          </Grid>
        </>
      ) : selectedTab === "output" ? (
        <CommonOutput />
      ) : selectedTab === "error" ? (
        <ErrorsWindow />
      ) : null}
    </div>
  );
};

export default ConnectImapWindow;
