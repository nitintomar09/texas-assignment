import React, { useEffect } from "react";
import PropertyField from "../../../PropertyFields/PropertyField";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../../Common/CommonStyles";
import { useSelector, useDispatch } from "react-redux";
import { setErrorType } from "../../../../../../redux/actions";
import ErrorsWindow from "../../Common/ErrorsWindow";
import CommonOutput from "../../Common/commonOutput";
import { getOptionsForVariable } from "../../Common/CommonMethods";
import { vaildateParamValue } from "../../../../../../utils/validations/validations";

const ConnectExchangeWindow = (props) => {
  const classes = useStyles();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const {
    server,
    timeout,
    exchangeVersion,
    domain,
    emailAutoDiscover,
    username,
    password,
    handleChange,
    changeParamTypeToVorC,
    id,
  } = props;
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(setErrorType("Throw"));
  }, []);
  return (
    <div>
      {selectedTab === "input" ? (
        <>
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <PropertyField
                id={`${id}_Timeout`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={timeout.paramType === "V"}
                paramObj={timeout}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="Timeout"
                label="Timeout (miliseconds)"
                value={timeout.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(timeout)}
              />
            </Grid>
          </Grid>

          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                EXCHANGE SETTINGS
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_ExchangeVersion`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={exchangeVersion.paramType === "V"}
                paramObj={exchangeVersion}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="ExchangeVersion"
                label="Exchange Version"
                value={exchangeVersion.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(exchangeVersion)}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Server`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={server.paramType === "V"}
                paramObj={server}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="Server"
                label="Server"
                value={server.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(server)}
                error={
                  vaildateParamValue(
                    server.paramValue || emailAutoDiscover.paramValue
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    server.paramValue || emailAutoDiscover.paramValue
                  ).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_EmailAutoDiscover`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={emailAutoDiscover.paramType === "V"}
                paramObj={emailAutoDiscover}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(emailAutoDiscover)}
                name="EmailAutoDiscover"
                label="Email Auto Discover"
                value={emailAutoDiscover.paramValue}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    emailAutoDiscover.paramValue || server.paramValue
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    emailAutoDiscover.paramValue || server.paramValue
                  ).msg
                }
              />
            </Grid>
          </Grid>

          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                LOGIN DETAILS
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${id}_Domain`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={domain.paramType === "V"}
                paramObj={domain}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(domain)}
                name="Domain"
                label="Domain"
                value={domain.paramValue}
                onChange={handleChange}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Username`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={username.paramType === "V"}
                paramObj={username}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(username)}
                name="Username"
                label="Username"
                value={username.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(username.paramValue).errorStatus}
                helperText={vaildateParamValue(username.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Password`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={password.paramType === "V"}
                paramObj={password}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(password)}
                name="Password"
                label="Password"
                value={password.paramValue}
                secret={true}
                onChange={handleChange}
                error={vaildateParamValue(password.paramValue).errorStatus}
                helperText={vaildateParamValue(password.paramValue).msg}
              />
            </Grid>
          </Grid>
        </>
      ) : selectedTab === "output" ? (
        <CommonOutput />
      ) : selectedTab === "error" ? (
        <ErrorsWindow />
      ) : null}
    </div>
  );
};

export default ConnectExchangeWindow;
