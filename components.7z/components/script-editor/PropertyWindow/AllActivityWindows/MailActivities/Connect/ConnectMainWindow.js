import React, { useState, useEffect } from "react";
import PropertyField from "../../../PropertyFields/PropertyField";
import { SendOutlined } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import ConnectPop3Window from "./ConnectPop3Window";
import ConnectImapWindow from "./ConnectImapWindow";
import ConnectExchangeWindow from "./ConnectExchangeWindow";
import { useStyles } from "../../Common/CommonStyles";
import { useSelector, useDispatch } from "react-redux";

import CommonFields from "./../../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../../redux/actions";
import {
  mapFieldObjWithValueByName,
  logsState,
  getAllOptions,
} from "../../Common/CommonMethods";

const ConnectMainWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;

  const { params } = selectedActivity;
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const allOptions = getAllOptions();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );

  const [secureConnection, setSecureConnection] = useState(
    mapFieldObjWithValueByName(params, "SecureConnection", false)
  );

  const [password, setPassword] = useState(
    mapFieldObjWithValueByName(params, "Password", "")
  );

  const [server, setServer] = useState(
    mapFieldObjWithValueByName(params, "Server", "")
  );

  const [port, setPort] = useState(
    mapFieldObjWithValueByName(params, "Port", "")
  );

  const [emailAccount, setEmailAccount] = useState(
    mapFieldObjWithValueByName(params, "EmailAccount", "")
  );
  const [connectionType, setConnectionType] = useState(
    mapFieldObjWithValueByName(params, "ConnectionType", "")
  );
  const [domain, setDomain] = useState(
    mapFieldObjWithValueByName(params, "Domain", "")
  );
  const [exchangeVersion, setExchangeVersion] = useState(
    mapFieldObjWithValueByName(params, "ExchangeVersion", "")
  );
  const [username, setUsername] = useState(
    mapFieldObjWithValueByName(params, "Username", "")
  );
  const [emailAutoDiscover, setEmailAutoDiscover] = useState(
    mapFieldObjWithValueByName(params, "EmailAccount", "")
  );
  const [folder, setFolder] = useState(
    mapFieldObjWithValueByName(params, "Folder", "")
  );
  const [timeoutField, setTimeoutField] = useState(
    mapFieldObjWithValueByName(params, "Timeout", "")
  );

  const radioButtonsArray = [
    { label: "POP3", value: "POP3" },
    { label: "IMAP", value: "IMAP" },
    { label: "Exchange", value: "Exchange" },
  ];
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const [typeValue, setTypeValue] = useState("POP3");

  //IMAP distinct props

  const [deleteReadMessagesObj, setDeleteReadMessagesObj] = useState(
    mapFieldObjWithValueByName(params, "DeleteReadMessages", "")
  );
  const [retrieveOnlyUnreadObj, setRetrieveOnlyUnreadObj] = useState(
    mapFieldObjWithValueByName(params, "RetrieveOnlyUnread", "")
  );
  const [markRetrieveAsReadObj, setMarkRetrieveAsReadObj] = useState(
    mapFieldObjWithValueByName(params, "MarkRetrieveAsRead", "")
  );
  const [topObj, setTopObj] = useState(
    mapFieldObjWithValueByName(params, "Top", "")
  );

  const radioButtonsArrayForSecureConnection = [
    { label: "SSL", value: "SSL" },
    { label: "TLS", value: "TLS" },
  ];

  const [secureConnectionTypeValue, setSecureConnectionTypeValue] = useState(
    mapFieldObjWithValueByName(params, "SecureConnectionType", "SSL")
  );
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setSecureConnection(
      mapFieldObjWithValueByName(params, "SecureConnection", "")
    );

    setPassword(mapFieldObjWithValueByName(params, "Password", ""));
    setUsername(mapFieldObjWithValueByName(params, "Username", ""));
    setServer(mapFieldObjWithValueByName(params, "Server", ""));
    setPort(mapFieldObjWithValueByName(params, "Port", ""));
    setEmailAccount(mapFieldObjWithValueByName(params, "EmailAccount", ""));
    setFolder(mapFieldObjWithValueByName(params, "Folder", ""));
    setConnectionType(
      mapFieldObjWithValueByName(params, "ConnectionType", "POP3")
    );
    setExchangeVersion(
      mapFieldObjWithValueByName(params, "ExchangeVersion", "")
    );
    setTimeoutField(mapFieldObjWithValueByName(params, "Timeout", ""));
    setEmailAutoDiscover(
      mapFieldObjWithValueByName(params, "EmailAutoDiscover", "")
    );
    setDomain(mapFieldObjWithValueByName(params, "Domain", ""));

    //
    setDeleteReadMessagesObj(
      mapFieldObjWithValueByName(params, "DeleteReadMessages", "")
    );
    setRetrieveOnlyUnreadObj(
      mapFieldObjWithValueByName(params, "RetrieveOnlyUnread", "")
    );
    setMarkRetrieveAsReadObj(
      mapFieldObjWithValueByName(params, "MarkRetrieveAsRead", "")
    );
    setTopObj(mapFieldObjWithValueByName(params, "Top", ""));

    setSecureConnectionTypeValue(
      mapFieldObjWithValueByName(params, "SecureConnectionType", "SSL")
    );

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);
  useEffect(() => {
    if (connectionType.paramValue) {
      setTypeValue(connectionType.paramValue);
    }
  }, [connectionType]);

  const handleChangeByKeyboard = (name, value) => {
    switch (name) {
      case "Type":
        setTypeValue(value);
        setConnectionType((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "SecureConnectionType":
        setSecureConnectionTypeValue((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      default:
        break;
    }
  };

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "Type":
        setTypeValue(value);
        setConnectionType((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "SecureConnection":
        setSecureConnection({ ...secureConnection, paramValue: checked });
        break;

      case "Port":
        setPort((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "EmailAccount":
        setEmailAccount((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Folder":
        setFolder((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Password":
        setPassword((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Server":
        setServer((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ExchangeVersion":
        setExchangeVersion((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "Username":
        setUsername((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Timeout":
        setTimeoutField((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "EmailAutoDiscover":
        setEmailAutoDiscover((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "Domain":
        setDomain((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "SecureConnectionType":
        setSecureConnectionTypeValue((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "SecureConnectionCheckbox":
        setSecureConnectionCheckbox({
          ...secureConnectionCheckbox,
          value: checked,
        });
        break;

      case "DeleteReadMessages":
        setDeleteReadMessages({ ...deleteReadMessages, value: checked });
        break;
      case "Top":
        setTop({ ...top, value: checked });
        break;
      case "RetrieveOnlyUnread":
        setRetrieveOnlyUnread({ ...retrieveOnlyUnread, value: checked });
        break;

      case "MarkRetrieveAsRead":
        setMarkRetrieveAsRead({ ...markRetrieveAsRead, value: checked });
        break;
      default:
        break;
    }
  };

  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [deleteReadMessages, setDeleteReadMessages] = useState(
    makingCheckboxFields(
      "DeleteReadMessages",
      deleteReadMessagesObj?.paramValue,
      "Delete Read Messages"
    )
  );
  const [retrieveOnlyUnread, setRetrieveOnlyUnread] = useState(
    makingCheckboxFields(
      "RetrieveOnlyUnread",
      retrieveOnlyUnreadObj?.paramValue,
      "Retrieve Only Unread"
    )
  );
  const [markRetrieveAsRead, setMarkRetrieveAsRead] = useState(
    makingCheckboxFields(
      "MarkRetrieveAsRead",
      markRetrieveAsReadObj?.paramValue,
      "Mark Retrieve as Read"
    )
  );
  const [secureConnectionCheckbox, setSecureConnectionCheckbox] = useState(
    makingCheckboxFields("SecureConnectionCheckbox", false, "Secure Connection")
  );
  const [top, setTop] = useState(makingCheckboxFields("Top", false, "Top"));
  useEffect(() => {
    updateParams();
  }, [
    connectionType,
    emailAccount,
    invisibleInLogs,
    port,
    secureConnection,
    password,
    server,
    exchangeVersion,
    domain,
    timeoutField,
    emailAutoDiscover,
    //fieldsinconnectimap
    retrieveOnlyUnread,
    deleteReadMessages,
    markRetrieveAsRead,
    secureConnectionCheckbox,
    secureConnectionTypeValue,
    top,
    username,
    folder,
  ]);

  const updateParams = () => {
    const newRetrieve = {
      ...retrieveOnlyUnreadObj,
      paramValue: retrieveOnlyUnread.value,
    };
    const newDel = {
      ...deleteReadMessagesObj,
      paramValue: deleteReadMessages.value,
    };
    const newMarkRetrive = {
      ...markRetrieveAsReadObj,
      paramValue: markRetrieveAsRead.value,
    };
    const newTop = { ...topObj, paramValue: top.value };
    if (connectionType === "Imap") {
      secureConnection.paramValue = secureConnectionCheckbox.value;
    }
    const allParams = [
      connectionType,
      emailAccount,
      invisibleInLogs,
      port,
      secureConnection,
      password,
      server,
      exchangeVersion,
      domain,
      timeoutField,
      emailAutoDiscover,
      username,
      //
      newRetrieve,
      newMarkRetrive,
      newDel,
      newTop,
      secureConnectionTypeValue,
      folder,
    ];
    addParamsToSelAct(allParams);
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    console.log(paramName, changeToValue);
    switch (paramName) {
      case "Port":
        setPort({ ...port, paramType: changeToValue });
        break;

      case "EmailAccount":
        setEmailAccount({ ...emailAccount, paramType: changeToValue });
        break;
      case "Folder":
        setFolder({ ...folder, paramType: changeToValue });
        break;

      case "Password":
        setPassword({ ...password, paramType: changeToValue });
        break;

      case "Server":
        setServer({ ...server, paramType: changeToValue });
        break;
      case "ExchangeVersion":
        setExchangeVersion({ ...exchangeVersion, paramType: changeToValue });
        break;
      case "Username":
        setUsername({ ...username, paramType: changeToValue });
        break;
      case "Timeout":
        setTimeoutField({ ...timeoutField, paramType: changeToValue });
        break;
      case "EmailAutoDiscover":
        setEmailAutoDiscover({
          ...emailAutoDiscover,
          paramType: changeToValue,
        });
        break;
      case "Domain":
        setDomain({ ...domain, paramType: changeToValue });
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={SendOutlined}
        helperText={
          selectedActivity.description ||
          "Retrieves email message from a specified server"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Type`}
                radio={true}
                ButtonsArray={radioButtonsArray}
                name="Type"
                label="Type"
                value={typeValue}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        ) : null}
        {typeValue === "POP3" ? (
          <ConnectPop3Window
            id={props.id}
            handleChange={handleChange}
            secureConnection={secureConnection}
            password={password}
            emailAccount={emailAccount}
            server={server}
            port={port}
            allOptions={allOptions}
            changeParamTypeToVorC={changeParamTypeToVorC}
          />
        ) : typeValue === "IMAP" ? (
          <ConnectImapWindow
            id={props.id}
            secureConnection={secureConnectionCheckbox}
            password={password}
            emailAccount={emailAccount}
            folder={folder}
            server={server}
            port={port}
            timeout={timeoutField}
            handleChange={handleChange}
            handleChangeByKeyboard={handleChangeByKeyboard}
            changeParamTypeToVorC={changeParamTypeToVorC}
            deleteReadMessages={deleteReadMessages}
            retrieveOnlyUnread={retrieveOnlyUnread}
            markRetrieveAsRead={markRetrieveAsRead}
            top={top}
            secureConnectionTypeValue={secureConnectionTypeValue}
            radioButtonsArrayForSecureConnection={
              radioButtonsArrayForSecureConnection
            }
          />
        ) : typeValue === "Exchange" ? (
          <ConnectExchangeWindow
            id={props.id}
            password={password}
            username={username}
            server={server}
            emailAutoDiscover={emailAutoDiscover}
            exchangeVersion={exchangeVersion}
            timeout={timeoutField}
            domain={domain}
            handleChange={handleChange}
            changeParamTypeToVorC={changeParamTypeToVorC}
          />
        ) : null}
      </div>
    </div>
  );
};

export default ConnectMainWindow;
