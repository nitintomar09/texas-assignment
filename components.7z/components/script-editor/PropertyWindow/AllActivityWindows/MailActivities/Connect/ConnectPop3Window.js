import React, { useEffect } from "react";
import PropertyField from "../../../PropertyFields/PropertyField";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../../Common/CommonStyles";
import { useSelector, useDispatch } from "react-redux";
import { setErrorType } from "../../../../../../redux/actions";
import ErrorsWindow from "../../Common/ErrorsWindow";
import CommonOutput from "../../Common/commonOutput";
import { getOptionsForVariable } from "../../Common/CommonMethods";
import { vaildateParamValue } from "../../../../../../utils/validations/validations";

const ConnectPop3Window = (props) => {
  const classes = useStyles();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const {
    server,
    secureConnection,
    password,
    port,
    emailAccount,
    handleChange,
    changeParamTypeToVorC,
    id,
  } = props;
  useEffect(() => {
    dispatch(setErrorType("Throw"));
  }, []);

  return (
    <div>
      {selectedTab === "input" ? (
        <>
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <PropertyField
                id={`${id}_EmailAccount`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={emailAccount.paramType === "V"}
                paramObj={emailAccount}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="EmailAccount"
                label="Email Account"
                value={emailAccount.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(emailAccount)}
                error={vaildateParamValue(emailAccount.paramValue).errorStatus}
                helperText={vaildateParamValue(emailAccount.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Pass`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={password.paramType === "V"}
                paramObj={password}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="Password"
                label="Password"
                value={password.paramValue}
                secret={true}
                onChange={handleChange}
                options={getOptionsForVariable(password)}
                error={vaildateParamValue(password.paramValue).errorStatus}
                helperText={vaildateParamValue(password.paramValue).msg}
              />
            </Grid>
          </Grid>
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                SERVER DETAILS
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${id}_Server`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={server.paramType === "V"}
                paramObj={server}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="Server"
                label="Server"
                value={server.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(server)}
                error={vaildateParamValue(server.paramValue).errorStatus}
                helperText={vaildateParamValue(server.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Port`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={port.paramType === "V"}
                paramObj={port}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="Port"
                label="port"
                value={port.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(port)}
                error={vaildateParamValue(port.paramValue).errorStatus}
                helperText={vaildateParamValue(port.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_SecureConnection`}
                checkbox={true}
                name="SecureConnection"
                label="Secure Connection"
                value={secureConnection.paramValue}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        </>
      ) : selectedTab === "error" ? (
        <ErrorsWindow />
      ) : selectedTab === "output" ? (
        <CommonOutput />
      ) : null}
    </div>
  );
};

export default ConnectPop3Window;
