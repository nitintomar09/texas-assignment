import React, { useState } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { SendOutlined } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import CheckboxGroup from "./../../PropertyFields/CheckboxGroup";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";

const SendMailExchangeWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, updateDisplayNameSelAct } = props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.ActivityName) || ""
  );
  const [makeLogsPrivate, setMakeLogsPrivate] = useState(false);

  const [password, setPassword] = useState("");

  const [server, setServer] = useState("");

  const [senderName, setSenderName] = useState("");

  const [from, setFrom] = useState("");

  const [to, setTo] = useState("");

  const [cc, setCc] = useState("");

  const [bcc, setBcc] = useState("");

  const [subject, setSubject] = useState("");

  const [timeout, setTimeout] = useState("");

  const [body, setBody] = useState("");

  const [fileAttachments, setFileAttachments] = useState("");

  const [exchangeVersion, setExchangeVersion] = useState("");

  const [toForwardMessage, setToForwardMessage] = useState("");

  const [domain, setDomain] = useState("");

  const [username, setUsername] = useState("");

  const [applicationId, setApplicationId] = useState("");

  const [authenticationType, setAuthenticationType] = useState("");

  const [directoryId, setDirectoryId] = useState("");

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setMakeLogsPrivate(!makeLogsPrivate);
        break;
      case "ExchangeVersion":
        setExchangeVersion(value);
        break;

      case "Domain":
        setDomain(value);
        break;

      case "Username":
        setUsername(value);
        break;

      case "Password":
        setPassword(value);
        break;

      case "Server":
        setServer(value);
        break;

      case "ToForwardMessage":
        setToForwardMessage(value);
        break;
      case "SenderName":
        setSenderName(value);
        break;

      case "From":
        setFrom(value);
        break;

      case "EmailAutoDiscover":
        setEmailAutoDiscover({ ...emailAutoDiscover, value: checked });
        break;

      case "ExistExchangingService":
        setExistExchangingService({
          ...existExchangingService,
          value: checked,
        });
        break;

      case "SaveCopy":
        setSaveCopy({ ...saveCopy, value: checked });
        break;

      case "HtmlBody":
        setHtmlBody({
          ...htmlBody,
          value: checked,
        });
        break;
      case "IsDraft":
        setIsDraft({
          ...isDraft,
          value: checked,
        });
        break;
      case "To":
        setTo(value);
        break;

      case "Cc":
        setCc(value);
        break;

      case "Bcc":
        setBcc(value);
        break;

      case "Subject":
        setSubject(value);
        break;

      case "Body":
        setBody(value);
        break;

      case "Timeout":
        setTimeout(value);
        break;

      case "FileAttachments":
        setFileAttachments(value);
        break;

      case "ApplicationId":
        setApplicationId(value);
        break;

      case "AuthenticationType":
        setAuthenticationType(value);
        break;

      case "DirectoryId":
        setDirectoryId(value);
        break;
      default:
        break;
    }
  };
  const makingCheckboxFields = (name, value, label) => {
    return {
      name,
      value,
      label,
      onChange: handleChange,
    };
  };
  const [emailAutoDiscover, setEmailAutoDiscover] = useState(
    makingCheckboxFields("EmailAutoDiscover", false, "Email Auto-Discover")
  );
  const [existExchangingService, setExistExchangingService] = useState(
    makingCheckboxFields(
      "ExistExchangingService",
      false,
      "Exist Exchanging Service"
    )
  );
  const [saveCopy, setSaveCopy] = useState(
    makingCheckboxFields("SaveCopy", false, "Save Copy")
  );
  const [htmlBody, setHtmlBody] = useState(
    makingCheckboxFields("HtmlBody", false, "HTML Body")
  );
  const [isDraft, setIsDraft] = useState(
    makingCheckboxFields("IsDraft", false, "Is Draft")
  );

  return (
    <div>
      <CommonFields
        activityName={activityName}
        handleChange={handleChange}
        selectedActivity={selectedActivity}
        makeLogsPrivate={makeLogsPrivate}
        ActivityIcon={SendOutlined}
        helperText={
          selectedActivity.description ||
          "Sends an email message by using Exchange"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              INPUT
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="FileAttachments"
              label="File Attachments"
              value={fileAttachments}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Timeout"
              label="Timeout (miliseconds)"
              value={timeout}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              EMAIL
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Subject"
              label="Subject"
              value={subject}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Body"
              label="Body"
              value={body}
              //multiline={true}
              onChange={handleChange}
            />
          </Grid>
        </Grid>

        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              EXCHANGE SETTINGS
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="ExchangeVersion"
              label="Exchange Version"
              value={exchangeVersion}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Server"
              label="Server"
              value={server}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <CheckboxGroup
              checkboxArray={[
                { ...emailAutoDiscover },
                { ...existExchangingService },
              ]}
            />
          </Grid>
          <Grid item>
            <PropertyField
              dropdown={true}
              name="ToForwardMessage"
              label="To Forward Message"
              value={toForwardMessage}
              options={ExcelFilePathOptions}
              onChange={handleChange}
              helperText="Select the mail list variables to forward them"
            />
          </Grid>
        </Grid>

        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              LOGIN DETAILS
            </Typography>
          </Grid>

          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Domain"
              label="Domain"
              value={domain}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Username"
              label="Username"
              value={username}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Password"
              label="Password"
              value={password}
              secret={true}
              onChange={handleChange}
            />
          </Grid>
        </Grid>

        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              OFFICE 365 SETTINGS
            </Typography>
          </Grid>

          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="ApplicationId"
              label="Application Id"
              value={applicationId}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="AuthenticationType"
              label="Authentication Type"
              value={authenticationType}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="DirectoryId"
              label="Directory Id"
              value={directoryId}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <CheckboxGroup
              checkboxArray={[{ ...saveCopy }, { ...htmlBody }, { ...isDraft }]}
            />
          </Grid>
        </Grid>
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              RECIEVER DETAILS
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="To"
              label="To"
              value={to}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Cc"
              label="Cc"
              value={cc}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Bcc"
              label="Bcc"
              value={bcc}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
        <Grid container direction="column" spacing={2}>
          <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              SENDER DETAILS
            </Typography>
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="SenderName"
              label="Sender Name"
              value={senderName}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="From"
              label="From"
              value={from}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
      </div>
    </div>
  );
};

export default SendMailExchangeWindow;
const ExcelFilePathOptions = [
  { name: "C://Documents/Excel", value: "C://Documents/Excel" },
  { name: "Sheetlist", value: "Sheetlist" },
  { name: "C://Documents", value: "C://Documents" },
  { name: "D://Documents/Excel", value: "D://Documents/Excel" },
];
