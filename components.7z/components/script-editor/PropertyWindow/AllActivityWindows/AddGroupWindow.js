import React, { useState } from "react";

import { AddEmptyGroupIcon } from "../../../../utils/AllImages";
import { Grid, Typography } from "@mui/material";
import {
  mapFieldObjWithValueByName,
  getOptionsForVariable,
  getAllOptions,
} from "./Common/CommonMethods";
import CommonFields from "./Common/CommonFields";
//import { useStyles } from "./Common/CommonStyles";
//import { useSelector } from "react-redux";
//import PropertyField from "../PropertyFields/PropertyField";

const AddGroupWindow = (props) => {
  // const classes = useStyles();

  const { selectedActivity, updateDisplayNameSelAct } = props;

  //const { params } = selectedActivity;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const allOptions = getAllOptions();
  const [makeLogsPrivate, setMakeLogsPrivate] = useState(false);
  /* const [browserType, setValueField] = useState(
    mapFieldObjWithValueByName(params, "BrowserType", "")
  );
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);*/

  const handleChange = (e) => {
    const { name, value } = e.target;

    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setMakeLogsPrivate(!makeLogsPrivate);
        break;
      /* case "BrowserType":
        setValueField((browserType) => ({ ...browserType, paramValue: value }));
        // setValueField({ ...browserType, paramValue: value });

        break;*/
      default:
        break;
    }
  };
  {
    /* const changeParamTypeToVorC = (paramName, changeToValue) => {
    console.log(paramName);
    console.log(changeToValue);
    switch (paramName) {
      case "BrowserType":
        setValueField({ ...browserType, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
console.log(browserType);*/
  }
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={makeLogsPrivate}
        ActivityIcon={AddEmptyGroupIcon}
        selectedActivity={selectedActivity}
        helperText={
          selectedActivity.description ||
          "This represents a group of activities related by process or function."
        }
      />
      {/* <div className={classes.scrollDiv}>
        {selectedTab === "input" && (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                combo={true}
                dropdown={true}
                // dropdown={browserType.paramType === "V"}
                paramObj={browserType}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                //labelBtn1={true}
                //labelBtn2={true}
                name="BrowserType"
                label="BrowserType"
                value={browserType.paramValue}
                // options={getOptionsForVariable(browserType)}
                options={allOptions}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        )}
        </div>*/}
    </div>
  );
};

export default AddGroupWindow;
