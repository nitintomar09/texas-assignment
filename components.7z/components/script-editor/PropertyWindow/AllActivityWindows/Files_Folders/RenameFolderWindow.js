import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import {
  AddVariableIcon,
  FolderBrowseIcon,
} from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const RenameFolderWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [targetFolder, setTargetFolder] = useState(
    mapFieldObjWithValueByName(params, "TargetFolder", "")
  );
  const [renamedTo, setRenamedTo] = useState(
    mapFieldObjWithValueByName(params, "RenamedTo", "")
  );

  const [status, setStatus] = useState(
    mapFieldObjWithValueByName(params, "Status", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setTargetFolder(mapFieldObjWithValueByName(params, "TargetFolder", ""));
    setRenamedTo(mapFieldObjWithValueByName(params, "RenamedTo", ""));
    setStatus(mapFieldObjWithValueByName(params, "Status", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, targetFolder, renamedTo, status]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, targetFolder, renamedTo, status];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "TargetFolder":
        setTargetFolder((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "RenamedTo":
        setRenamedTo((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Status":
        setStatus((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "TargetFolder":
        setTargetFolder({ ...targetFolder, paramType: changeToValue });
        break;
      case "RenamedTo":
        setRenamedTo({ ...renamedTo, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description ||
          "Renames a Folder in the machine's directory."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_TargetFolder`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={targetFolder.paramType === "V"}
                paramObj={targetFolder}
                btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="TargetFolder"
                label="Target Folder"
                value={targetFolder.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(targetFolder)}
                error={
                  vaildateParamValue(targetFolder.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(targetFolder.paramValue.toString()).msg
                }
              />
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_RenamedTo`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={renamedTo.paramType === "V"}
                paramObj={renamedTo}
                btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="RenamedTo"
                label="Renamed to"
                value={renamedTo.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(renamedTo)}
                error={
                  vaildateParamValue(renamedTo.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(renamedTo.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Status`}
                combo={true}
                dropdown={true}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Status"
                label={`Status (${getVariableTypeById(
                  status.paramObjectTypeId
                )})`}
                paramObj={status}
                value={status.paramValue}
                options={getOptionsForVariable(status)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default RenameFolderWindow;
