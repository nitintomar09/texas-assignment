import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import {
  AddVariableIcon,
  FolderBrowseIcon,
} from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const GetFilesWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [sourceFileLocation, setSourceFileLocation] = useState(
    mapFieldObjWithValueByName(params, "SourceFileLocation", "")
  );
  const [fileName, setFileName] = useState(
    mapFieldObjWithValueByName(params, "FileName", "")
  );

  const [fileList, setFileList] = useState(
    mapFieldObjWithValueByName(params, "FileList", "")
  );
  const [fileType, setFileType] = useState(
    mapFieldObjWithValueByName(params, "FileType", "")
  );

  const [fileSizeCheckBox, setFileSizeCheckBox] = useState(
    mapFieldObjWithValueByName(params, "FileSizeCheckBox", "")
  );

  const [fileSizeDefinitiveRange, setFileSizeDefinitiveRange] = useState(
    mapFieldObjWithValueByName(params, "FileSizeDefinitiveRange", "")
  );

  const [fileSizePrefix, setFileSizePrefix] = useState(
    mapFieldObjWithValueByName(params, "FileSizePrefix", "")
  );
  const [fileSizeSuffix, setFileSizeSuffix] = useState(
    mapFieldObjWithValueByName(params, "FileSizeSuffix", "")
  );
  const [fileSizeValue, setFileSizeValue] = useState(
    mapFieldObjWithValueByName(params, "FileSizeValue", "")
  );

  const [creationDateCheckBox, setCreationDateCheckBox] = useState(
    mapFieldObjWithValueByName(params, "CreationDateCheckBox", "")
  );

  const [creationDateDefinitiveRange, setCreationDateDefinitiveRange] =
    useState(
      mapFieldObjWithValueByName(params, "CreationDateDefinitiveRange", "")
    );

  const [creationDatePrefix, setCreationDatePrefix] = useState(
    mapFieldObjWithValueByName(params, "CreationDatePrefix", "")
  );

  const [creationDateValue, setCreationDateValue] = useState(
    mapFieldObjWithValueByName(params, "CreationDateValue", "")
  );

  const [modificationDateCheckBox, setModificationDateCheckBox] = useState(
    mapFieldObjWithValueByName(params, "ModificationDateCheckBox", "")
  );

  const [modificationDateDefinitiveRange, setModificationDateDefinitiveRange] =
    useState(
      mapFieldObjWithValueByName(params, "ModificationDateDefinitiveRange", "")
    );
  const [modificationDatePrefix, setModificationDatePrefix] = useState(
    mapFieldObjWithValueByName(params, "ModificationDatePrefix", "")
  );
  const [modificationDateValue, setModificationDateValue] = useState(
    mapFieldObjWithValueByName(params, "ModificationDateValue", "")
  );

  const radioButtonsArray = [
    { label: "Definitive", value: "Definitive" },
    { label: "Range", value: "Range" },
  ];

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setSourceFileLocation(
      mapFieldObjWithValueByName(params, "SourceFileLocation", "")
    );
    setFileName(mapFieldObjWithValueByName(params, "FileName", ""));
    setFileList(mapFieldObjWithValueByName(params, "FileList", ""));
    setFileType(mapFieldObjWithValueByName(params, "FileType", ""));
    setFileSizeCheckBox(
      mapFieldObjWithValueByName(params, "FileSizeCheckBox", "")
    );
    setFileSizeDefinitiveRange(
      mapFieldObjWithValueByName(
        params,
        "FileSizeDefinitiveRange",
        "Definitive"
      )
    );
    setFileSizePrefix(mapFieldObjWithValueByName(params, "FileSizePrefix", ""));
    setFileSizeSuffix(mapFieldObjWithValueByName(params, "FileSizeSuffix", ""));
    setFileSizeValue(mapFieldObjWithValueByName(params, "FileSizeValue", ""));
    setCreationDateCheckBox(
      mapFieldObjWithValueByName(params, "CreationDateCheckBox", "")
    );
    setCreationDateDefinitiveRange(
      mapFieldObjWithValueByName(
        params,
        "CreationDateDefinitiveRange",
        "Definitive"
      )
    );
    setCreationDatePrefix(
      mapFieldObjWithValueByName(params, "CreationDatePrefix", "")
    );
    setCreationDateValue(
      mapFieldObjWithValueByName(params, "CreationDateValue", "")
    );
    setModificationDateDefinitiveRange(
      mapFieldObjWithValueByName(
        params,
        "ModificationDateDefinitiveRange",
        "Definitive"
      )
    );
    setModificationDatePrefix(
      mapFieldObjWithValueByName(params, "ModificationDatePrefix", "")
    );
    setModificationDateValue(
      mapFieldObjWithValueByName(params, "ModificationDateValue", "")
    );
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    sourceFileLocation,
    fileName,
    fileList,
    fileType,
    fileSizeCheckBox,
    fileSizeDefinitiveRange,
    fileSizePrefix,
    fileSizeSuffix,
    fileSizeValue,
    creationDateCheckBox,
    creationDateDefinitiveRange,
    creationDatePrefix,
    creationDateValue,
    modificationDateCheckBox,
    modificationDateDefinitiveRange,
    modificationDatePrefix,
    modificationDateValue,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      sourceFileLocation,
      fileName,
      fileList,
      fileType,
      fileSizeCheckBox,
      fileSizeDefinitiveRange,
      fileSizePrefix,
      fileSizeSuffix,
      fileSizeValue,
      creationDateCheckBox,
      creationDateDefinitiveRange,
      creationDatePrefix,
      creationDateValue,
      modificationDateCheckBox,
      modificationDateDefinitiveRange,
      modificationDatePrefix,
      modificationDateValue,
    ];
    addParamsToSelAct(allParams);
  };
  const setEmptyFileState = () => {
    setFileSizePrefix((prevState) => ({
      ...prevState,
      paramType: "C",
      paramValue: "",
    }));
    setFileSizeSuffix({ ...fileSizeSuffix, paramType: "C", paramValue: "" });
    setFileSizeValue((prevState) => ({
      ...prevState,
      paramType: "C",
      paramValue: "",
    }));
  };
  const setEmptyCreationDate = () => {
    setCreationDatePrefix((prevState) => ({
      ...prevState,
      paramType: "C",
      paramValue: "",
    }));
    setCreationDateValue((prevState) => ({
      ...prevState,
      paramType: "C",
      paramValue: "",
    }));
  };
  const setEmptyModificationDate = () => {
    setModificationDatePrefix((prevState) => ({
      ...prevState,
      paramType: "C",
      paramValue: "",
    }));
    setModificationDateValue((prevState) => ({
      ...prevState,
      paramType: "C",
      paramValue: "",
    }));
  };
  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "SourceFileLocation":
        setSourceFileLocation((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;

      case "FileName":
        setFileName((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "FileList":
        setFileList((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "FileType":
        setFileType((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "FileSizeCheckBox":
        setFileSizeCheckBox({ ...fileSizeCheckBox, paramValue: checked });
        break;

      case "FileSizeDefinitiveRange":
        setFileSizeDefinitiveRange({
          ...fileSizeDefinitiveRange,
          paramValue: value,
        });
        setEmptyFileState();
        break;
      case "FileSizePrefix":
        setFileSizePrefix((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "FileSizeSuffix":
        setFileSizeSuffix({ ...fileSizeSuffix, paramValue: value });
        break;
      case "FileSizeValue":
        setFileSizeValue((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "CreationDateCheckBox":
        setCreationDateCheckBox({
          ...creationDateCheckBox,
          paramValue: checked,
        });
        break;
      case "CreationDateDefinitiveRange":
        setCreationDateDefinitiveRange({
          ...creationDateDefinitiveRange,
          paramValue: value,
        });
        setEmptyCreationDate();
        break;
      case "CreationDatePrefix":
        setCreationDatePrefix((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "CreationDateValue":
        setCreationDateValue((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "ModificationDateCheckBox":
        setModificationDateCheckBox({
          ...modificationDateCheckBox,
          paramValue: checked,
        });
        break;
      case "ModificationDateDefinitiveRange":
        setModificationDateDefinitiveRange({
          ...modificationDateDefinitiveRange,
          paramValue: value,
        });
        setEmptyModificationDate();
        break;
      case "ModificationDatePrefix":
        setModificationDatePrefix((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "ModificationDateValue":
        setModificationDateValue((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "SourceFileLocation":
        setSourceFileLocation({
          ...sourceFileLocation,
          paramType: changeToValue,
        });
        break;
      case "FileName":
        setFileName({ ...fileName, paramType: changeToValue });
        break;

      case "FileType":
        setFileType({ ...fileType, paramType: changeToValue });
        break;
      case "FileSizeValue":
        setFileSizeValue({ ...fileSizeValue, paramType: changeToValue });
        break;
      case "FileSizePrefix":
        setFileSizePrefix({ ...fileSizePrefix, paramType: changeToValue });
        break;

      case "CreationDateValue":
        setCreationDateValue({
          ...creationDateValue,
          paramType: changeToValue,
        });
        break;
      case "CreationDatePrefix":
        setCreationDatePrefix({
          ...creationDatePrefix,
          paramType: changeToValue,
        });
        break;

      case "ModificationDateValue":
        setModificationDateValue({
          ...modificationDateValue,
          paramType: changeToValue,
        });
        break;
      case "ModificationDatePrefix":
        setModificationDatePrefix({
          ...modificationDatePrefix,
          paramType: changeToValue,
        });
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description || "Get Files from machine’s directory."
        }
      />

      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_SourceFileLocation`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={sourceFileLocation.paramType === "V"}
                  paramObj={sourceFileLocation}
                  btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="SourceFileLocation"
                  label="Source File Location"
                  value={sourceFileLocation.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(sourceFileLocation)}
                  error={
                    vaildateParamValue(sourceFileLocation.paramValue)
                      .errorStatus
                  }
                  helperText={
                    vaildateParamValue(sourceFileLocation.paramValue).msg
                  }
                />
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_FileName`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={fileName.paramType === "V"}
                  paramObj={fileName}
                  btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="FileName"
                  label="File Name"
                  value={fileName.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(fileName)}
                />
              </Grid>
            </Grid>

            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  FILTERS
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_FileType`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={fileType.paramType === "V"}
                  paramObj={fileType}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="FileType"
                  label="File Type"
                  value={fileType.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(fileType)}
                />
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_FileSize`}
                  checkbox={true}
                  // labelBtn1={true}
                  //labelBtn2={true}
                  //dropdown={fileSizeValue.paramType === "V"}
                  // paramObj={fileSizeValue}
                  // labelBtn1OnClick={changeParamTypeToVorC}
                  //labelBtn2OnClick={changeParamTypeToVorC}
                  name="FileSizeCheckBox"
                  label="File Size"
                  value={fileSizeCheckBox.paramValue}
                  onChange={handleChange}
                />

                {fileSizeCheckBox?.paramValue && (
                  <>
                    <PropertyField
                      id={`${props.id}_FileSizeDefiniteRange`}
                      radio={true}
                      ButtonsArray={radioButtonsArray}
                      name="FileSizeDefinitiveRange"
                      value={fileSizeDefinitiveRange.paramValue}
                      onChange={handleChange}
                    />

                    {fileSizeDefinitiveRange?.paramValue === "Definitive" ? (
                      <Grid
                        container
                        direction="row"
                        spacing={1}
                        alignItems="center"
                      >
                        <Grid item xs={3}>
                          <PropertyField
                            id={`${props.id}_FileSizePrefix`}
                            dropdown={true}
                            name="FileSizePrefix"
                            value={fileSizePrefix.paramValue}
                            onChange={handleChange}
                            options={fileFilterOptions || []}
                          />
                        </Grid>
                        <Grid item xs={6}>
                          <PropertyField
                            id={`${props.id}_FileSizeValue`}
                            width={170}
                            paramObj={fileSizeValue}
                            labelBtn1OnClick={changeParamTypeToVorC}
                            labelBtn2OnClick={changeParamTypeToVorC}
                            combo={true}
                            dropdown={fileSizeValue.paramType === "V"}
                            name="FileSizeValue"
                            value={fileSizeValue.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(fileSizeValue)}
                          />
                        </Grid>
                        <Grid item xs={3}>
                          <PropertyField
                            id={`${props.id}_FileSizeSuffix`}
                            dropdown={true}
                            name="FileSizeSuffix"
                            value={fileSizeSuffix.paramValue}
                            onChange={handleChange}
                            options={sizeOptions || []}
                          />
                        </Grid>
                      </Grid>
                    ) : (
                      <Grid container spacing={1} alignItems="center">
                        <Grid item xs={4}>
                          <PropertyField
                            id={`${props.id}_FileSizePrefix`}
                            width={120}
                            combo={true}
                            paramObj={fileSizePrefix}
                            labelBtn1OnClick={changeParamTypeToVorC}
                            labelBtn2OnClick={changeParamTypeToVorC}
                            dropdown={fileSizePrefix.paramType === "V"}
                            name="FileSizePrefix"
                            label="From"
                            value={fileSizePrefix.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(fileSizePrefix)}
                          />
                        </Grid>
                        <Grid item xs={4}>
                          <PropertyField
                            id={`${props.id}_FileSizeValue`}
                            width={120}
                            combo={true}
                            paramObj={fileSizeValue}
                            labelBtn1OnClick={changeParamTypeToVorC}
                            labelBtn2OnClick={changeParamTypeToVorC}
                            dropdown={fileSizeValue.paramType === "V"}
                            name="FileSizeValue"
                            label="To"
                            value={fileSizeValue.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(fileSizeValue)}
                          />
                        </Grid>
                        <Grid item xs={4} style={{ marginTop: "-5px" }}>
                          <PropertyField
                            id={`${props.id}_FileSizeSuffix`}
                            width={"120px"}
                            dropdown={true}
                            label="Size"
                            name="FileSizeSuffix"
                            value={fileSizeSuffix.paramValue}
                            onChange={handleChange}
                            options={sizeOptions || []}
                          />
                        </Grid>
                      </Grid>
                    )}
                  </>
                )}
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_CreationDate`}
                  checkbox={true}
                  //  labelBtn1={true}
                  // labelBtn2={true}
                  // paramObj={creationDateValue}
                  // labelBtn1OnClick={changeParamTypeToVorC}
                  // labelBtn2OnClick={changeParamTypeToVorC}
                  name="CreationDateCheckBox"
                  label="Creation Date"
                  value={creationDateCheckBox.paramValue}
                  onChange={handleChange}
                />

                {creationDateCheckBox?.paramValue && (
                  <>
                    <PropertyField
                      id={`${props.id}_CreationDateDefinitiveRange`}
                      radio={true}
                      ButtonsArray={radioButtonsArray}
                      name="CreationDateDefinitiveRange"
                      value={creationDateDefinitiveRange.paramValue}
                      onChange={handleChange}
                    />

                    {creationDateDefinitiveRange?.paramValue ===
                    "Definitive" ? (
                      <Grid
                        container
                        direction="row"
                        spacing={1}
                        alignItems="center"
                      >
                        <Grid item xs={4}>
                          <PropertyField
                            id={`${props.id}_CreationDatePrefix`}
                            dropdown={true}
                            name="CreationDatePrefix"
                            value={creationDatePrefix.paramValue}
                            onChange={handleChange}
                            options={dateFilterOptions || []}
                          />
                        </Grid>
                        <Grid item xs={8}>
                          <PropertyField
                            id={`${props.id}_CreationDateValue`}
                            width={200}
                            // paramObj={creationDateValue}
                            //labelBtn1OnClick={changeParamTypeToVorC}
                            //labelBtn2OnClick={changeParamTypeToVorC}
                            combo={true}
                            type={
                              creationDateValue.paramType === "C"
                                ? "datetime-local"
                                : ""
                            }
                            //dropdown={creationDateValue.paramType === "V"}
                            name="CreationDateValue"
                            value={creationDateValue.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(creationDateValue)}
                          />
                        </Grid>
                      </Grid>
                    ) : (
                      <Grid container spacing={1} alignItems="center">
                        <Grid item xs={6}>
                          <PropertyField
                            id={`${props.id}_CreationDatePrefix`}
                            label="From"
                            width={180}
                            combo={true}
                            //  paramObj={creationDatePrefix}
                            //labelBtn1OnClick={changeParamTypeToVorC}
                            //labelBtn2OnClick={changeParamTypeToVorC}
                            type={
                              creationDatePrefix.paramType === "C"
                                ? "datetime-local"
                                : ""
                            }
                            // dropdown={creationDatePrefix.paramType === "V"}
                            name="CreationDatePrefix"
                            value={creationDatePrefix.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(creationDatePrefix)}
                          />
                        </Grid>
                        <Grid item xs={6}>
                          <PropertyField
                            id={`${props.id}_CreationDateValue`}
                            width={180}
                            combo={true}
                            //  paramObj={creationDateValue}
                            //  labelBtn1OnClick={changeParamTypeToVorC}
                            //labelBtn2OnClick={changeParamTypeToVorC}
                            label="To"
                            type={
                              creationDateValue.paramType === "C"
                                ? "datetime-local"
                                : ""
                            }
                            //   dropdown={creationDateValue.paramType === "V"}
                            name="CreationDateValue"
                            value={creationDateValue.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(creationDateValue)}
                          />
                        </Grid>
                      </Grid>
                    )}
                  </>
                )}
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_ModifDate`}
                  checkbox={true}
                  // labelBtn1={true}
                  //labelBtn2={true}
                  //paramObj={modificationDateValue}
                  //labelBtn1OnClick={changeParamTypeToVorC}
                  //labelBtn2OnClick={changeParamTypeToVorC}
                  name="ModificationDateCheckBox"
                  label="Modification Date"
                  value={modificationDateCheckBox.paramValue}
                  onChange={handleChange}
                />

                {modificationDateCheckBox?.paramValue && (
                  <>
                    <PropertyField
                      id={`${props.id}_ModifDateDefinitiveRnge`}
                      radio={true}
                      ButtonsArray={radioButtonsArray}
                      name="ModificationDateDefinitiveRange"
                      value={modificationDateDefinitiveRange.paramValue}
                      onChange={handleChange}
                    />

                    {modificationDateDefinitiveRange?.paramValue ===
                    "Definitive" ? (
                      <Grid
                        container
                        direction="row"
                        spacing={1}
                        alignItems="center"
                      >
                        <Grid item xs={4}>
                          <PropertyField
                            id={`${props.id}_ModifDatePrefix`}
                            dropdown={true}
                            name="ModificationDatePrefix"
                            value={modificationDatePrefix.paramValue}
                            onChange={handleChange}
                            options={dateFilterOptions || []}
                          />
                        </Grid>
                        <Grid item xs={8}>
                          <PropertyField
                            id={`${props.id}_ModifDateValue`}
                            width={200}
                            //  paramObj={modificationDateValue}
                            //labelBtn1OnClick={changeParamTypeToVorC}
                            //labelBtn2OnClick={changeParamTypeToVorC}
                            combo={true}
                            type={
                              modificationDateValue.paramType === "C"
                                ? "datetime-local"
                                : ""
                            }
                            //dropdown={modificationDateValue.paramType === "V"}
                            name="ModificationDateValue"
                            value={modificationDateValue.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(
                              modificationDateValue
                            )}
                          />
                        </Grid>
                      </Grid>
                    ) : (
                      <Grid container spacing={1} alignItems="center">
                        <Grid item xs={6}>
                          <PropertyField
                            id={`${props.id}_ModifDatePrefix`}
                            label="From"
                            width={180}
                            combo={true}
                            /// paramObj={modificationDatePrefix}
                            //labelBtn1OnClick={changeParamTypeToVorC}
                            //labelBtn2OnClick={changeParamTypeToVorC}
                            type={
                              modificationDatePrefix.paramType === "C"
                                ? "datetime-local"
                                : ""
                            }
                            //dropdown={modificationDatePrefix.paramType === "V"}
                            name="ModificationDatePrefix"
                            value={modificationDatePrefix.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(
                              modificationDatePrefix
                            )}
                          />
                        </Grid>
                        <Grid item xs={6}>
                          <PropertyField
                            id={`${props.id}_ModifDateValue`}
                            width={180}
                            combo={true}
                            //  paramObj={modificationDateValue}
                            // labelBtn1OnClick={changeParamTypeToVorC}
                            // labelBtn2OnClick={changeParamTypeToVorC}
                            label="To"
                            type={
                              modificationDateValue.paramType === "C"
                                ? "datetime-local"
                                : ""
                            }
                            // dropdown={modificationDateValue.paramType === "V"}
                            name="ModificationDateValue"
                            value={modificationDateValue.paramValue}
                            onChange={handleChange}
                            options={getOptionsForVariable(
                              modificationDateValue
                            )}
                          />
                        </Grid>
                      </Grid>
                    )}
                  </>
                )}
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_FileList`}
                combo={true}
                dropdown={true}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                paramObj={fileList}
                name="FileList"
                label={`File List (${getVariableTypeById(
                  fileList.paramObjectTypeId
                )})`}
                value={fileList.paramValue}
                options={getOptionsForVariable(fileList)}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default GetFilesWindow;

const sizeOptions = [
  { name: "Mb", value: "Mb" },
  { name: "Kb", value: "Kb" },
];

const dateFilterOptions = [
  { name: "Before", value: "Before" },
  { name: "On", value: "On" },
  { name: "After", value: "After" },
];

const fileFilterOptions = [
  { name: "Less than", value: "Less than" },
  { name: "Equals", value: "Equals" },
  { name: "Greater than", value: "Greater than" },
];
