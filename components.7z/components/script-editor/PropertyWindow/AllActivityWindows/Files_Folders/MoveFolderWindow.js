import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import {
  AddVariableIcon,
  FolderBrowseIcon,
} from "../../../../../utils/AllImages";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const MoveFolderWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [source, setSource] = useState(
    mapFieldObjWithValueByName(params, "SourceFolder", "")
  );
  const [destination, setDestination] = useState(
    mapFieldObjWithValueByName(params, "DestinationFolder", "")
  );

  const [status, setStatus] = useState(
    mapFieldObjWithValueByName(params, "Status", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setSource(mapFieldObjWithValueByName(params, "SourceFolder", ""));
    setDestination(mapFieldObjWithValueByName(params, "DestinationFolder", ""));
    setStatus(mapFieldObjWithValueByName(params, "Status", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, source, destination, status]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, source, destination, status];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "SourceFolder":
        setSource((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "DestinationFolder":
        setDestination((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Status":
        setStatus((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "SourceFolder":
        setSource({ ...source, paramType: changeToValue });
        break;
      case "DestinationFolder":
        setDestination({ ...destination, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description ||
          "Moves a Folder or Folders from one directory to another in the machine."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SrcFolder`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={source.paramType === "V"}
                paramObj={source}
                btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="SourceFolder"
                label="Source Folder"
                value={source.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(source)}
                error={
                  vaildateParamValue(source.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(source.paramValue.toString()).msg
                }
              />
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_DestFolder`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={destination.paramType === "V"}
                paramObj={destination}
                btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="DestinationFolder"
                label="Destination Folder"
                value={destination.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(destination)}
                error={
                  vaildateParamValue(destination.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(destination.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Status`}
                combo={true}
                dropdown={true}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Status"
                label={`Status (${getVariableTypeById(
                  status.paramObjectTypeId
                )})`}
                paramObj={status}
                value={status.paramValue}
                options={getOptionsForVariable(status)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default MoveFolderWindow;
