import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import {
  AddVariableIcon,
  FolderBrowseIcon,
} from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const GetFileSizeWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [sourceFile, setSourceFile] = useState(
    mapFieldObjWithValueByName(params, "SourceFile", "")
  );

  const [size, setSize] = useState(
    mapFieldObjWithValueByName(params, "Size", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setSourceFile(mapFieldObjWithValueByName(params, "SourceFile", ""));
    setSize(mapFieldObjWithValueByName(params, "Size", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, sourceFile, size]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, sourceFile, size];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "SourceFile":
        setSourceFile((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "FileSize":
        setSize((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "SourceFile":
        setSourceFile({ ...sourceFile, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description ||
          "Split the complete path into Folder Directory and Filename"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SourceFile`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={sourceFile.paramType === "V"}
                paramObj={sourceFile}
                btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="SourceFile"
                label="Source File"
                value={sourceFile.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(sourceFile)}
                error={
                  vaildateParamValue(sourceFile.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(sourceFile.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_FileSize`}
                combo={true}
                dropdown={true}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="FileSize"
                label="Size(Kb)"
                paramObj={size}
                value={size.paramValue}
                options={getOptionsForVariable(size)}
                onChange={handleChange}
                error={
                  vaildateParamValue(size.paramValue.toString()).errorStatus
                }
                helperText={vaildateParamValue(size.paramValue.toString()).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default GetFileSizeWindow;
