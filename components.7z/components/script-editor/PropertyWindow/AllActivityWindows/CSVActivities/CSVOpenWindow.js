import React, { useState, useRef, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography, Radio } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { FolderBrowseIcon } from "../../../../../utils/AllImages";
import { useDispatch, useSelector } from "react-redux";
import {
  setSelectedTab,
  setErrorType,
  setCSVFilePath,
} from "./../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonOutput from "./../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const CSVOpenWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const hiddenFileInput = useRef(null);
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [csvFile, setCsvFile] = useState(
    mapFieldObjWithValueByName(params, "CSVFile", "")
  );
  const [csvMode, setCsvMode] = useState(
    mapFieldObjWithValueByName(params, "CSVMode", "")
  );
  const [separator, setSeparator] = useState(
    mapFieldObjWithValueByName(params, "Separator", "")
  );
  const [createNewCheckbox, setCreateNewCheckbox] = useState(
    mapFieldObjWithValueByName(params, "CreateNew", false)
  );
  const [headerRowCheckbox, setHeaderRowCheckbox] = useState(
    mapFieldObjWithValueByName(params, "HeaderRow", true)
  );

  const [selCsvMode, setSelectedCsvMode] = useState("");
  const [customSeparator, setCustomSeparator] = useState("");

  const radioButtonsArray = [
    { label: "For Reading", value: "For Reading" },
    { label: "For Writing", value: "For Writing" },
  ];

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    const csvFileVal = mapFieldObjWithValueByName(params, "CSVFile", "");
    setCsvFile(csvFileVal);

    dispatch(setCSVFilePath(csvFileVal.paramValue));

    setCsvMode(mapFieldObjWithValueByName(params, "CSVMode", ""));

    setSeparator(mapFieldObjWithValueByName(params, "Separator", ""));
    setCreateNewCheckbox(
      mapFieldObjWithValueByName(params, "CreateNew", false)
    );
    setHeaderRowCheckbox(mapFieldObjWithValueByName(params, "HeaderRow", true));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    if (csvMode.paramValue) {
      setSelectedCsvMode(csvMode.paramValue);
    }
  }, [csvMode]);

  useEffect(() => {
    if (csvMode.paramValue) {
      if (
        (sepOptions.find((item) => item.value === separator.paramValue) &&
          separator.paramValue !== "Custom") ||
        separator.paramValue === ""
      ) {
        setCustomSeparator("");
      } else {
        if (separator.paramValue !== "Custom") {
          setCustomSeparator(separator.paramValue);
          setSeparator({ ...separator, paramValue: "Custom" });
        }
      }
    }
  }, [separator]);
  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    csvFile,
    csvMode,
    createNewCheckbox,
    headerRowCheckbox,
    separator,
    customSeparator,
  ]);

  const updateParams = () => {
    const newSepValue = {
      ...separator,
      paramValue:
        separator.paramValue === "Custom"
          ? customSeparator
          : separator.paramValue,
    };
    const allParams = [
      invisibleInLogs,
      csvFile,
      csvMode,
      createNewCheckbox,
      headerRowCheckbox,
      newSepValue,
    ];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "CSVFile":
        setCsvFile((prevState) => ({ ...prevState, paramValue: value }));
        dispatch(setCSVFilePath(value));

        break;
      case "CSVMode":
        setSelectedCsvMode(value);
        setCsvMode({ ...csvMode, paramValue: value });
        break;
      case "Separator":
        setSeparator((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "CustomSeparator":
        setCustomSeparator(value);
        break;
      case "CreateNew":
        setCreateNewCheckbox((prevState) => ({ ...prevState, paramValue: !createNewCheckbox.paramValue }));
        break;
      case "HeaderRow":
        setHeaderRowCheckbox((prevState) => ({ ...prevState, paramValue: !headerRowCheckbox.paramValue }));
        break;

      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "CSVFile":
        setCsvFile({ ...csvFile, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        selectedActivity={selectedActivity}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={selectedActivity.description || "Opens the CSV File"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={1}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_CSVFile`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={csvFile.paramType === "V"}
                  paramObj={csvFile}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                  name="CSVFile"
                  label="CSV File"
                  value={csvFile.paramValue}
                  options={getOptionsForVariable(csvFile)}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(csvFile.paramValue.toString())
                      .errorStatus
                  }
                  helperText={
                    vaildateParamValue(csvFile.paramValue.toString()).msg
                  }
                />
              </Grid>
              <Grid item >
                <Grid container spacing={1} alignItems={'center'}>
                  <Grid item>
                    <PropertyField
                      id={`${props.id}_CSVMode`}
                      radio={true}
                      ButtonsArray={radioButtonsArray}
                      name="CSVMode"
                      label="CSV Open Mode"
                      value={selCsvMode}
                      onChange={handleChange}
                      column={true}
                    />
                  </Grid>
                  {selCsvMode === "For Writing" && (
                    <Grid item style={{marginTop:'56px'}}>
                      <PropertyField
                        checkbox={true}
                        id={`${props.id}_CreateNew`}
                        name="CreateNew"
                        label="Create New"
                        value={createNewCheckbox.paramValue}
                        onChange={handleChange}
                      />
                    </Grid>

                  )}
                </Grid>
              </Grid>

              {/*(sepOptions.find(
                (item) => item.value === separator.paramValue
              ) &&
                separator.paramValue !== "Custom") ||
              separator.paramValue === "" ? (
                <Grid item>
                  <PropertyField
                    dropdown={true}
                    name="Separator"
                    label="Separator"
                    value={separator.paramValue}
                    options={sepOptions}
                    onChange={handleChange}
                  />
                </Grid>
              ) : (
                <Grid item>
                  <PropertyField
                    name="CustomSeparator"
                    label="Separator"
                    value={customSeparator}
                    onChange={handleChange}
                  />
                </Grid>
              )*/}
              <Grid item>
                <PropertyField
                  id={`${props.id}_Separator`}
                  combo={true}
                  dropdown={true}
                  name="Separator"
                  label="Separator"
                  value={separator.paramValue}
                  options={sepOptions}
                  onChange={handleChange}
                />
              </Grid>
              {separator.paramValue === "Custom" ||
                (separator.paramValue &&
                  !sepOptions.find(
                    (item) => item.value === separator.paramValue
                  )) ? (
                <Grid item>
                  <PropertyField
                    id={`${props.id}_CustomSeparator`}
                    combo={true}
                    name="CustomSeparator"
                    // label="Separator"
                    value={customSeparator}
                    onChange={handleChange}
                    error={vaildateParamValue(customSeparator).errorStatus}
                    helperText={vaildateParamValue(customSeparator).msg}
                  />
                </Grid>
              ) : null}

              <Grid item>
                <PropertyField
                  id={`${props.id}_ReadFirstLineAsHeader`}
                  checkbox={true}
                  name="HeaderRow"
                  label="Read First Line As Header"
                  value={headerRowCheckbox.paramValue}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput /> /*(
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                dropdown={true}
                paramObj={openFile}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="OpenFile"
                label={`Open File (${getVariableTypeById(
                  openFile.paramObjectTypeId
                )})`}
                value={openFile.paramValue}
                options={getOptionsForVariable(openFile)}
                onChange={handleChange}
                helperText="Select or add a Boolean type variable to check if the files has been opened or not"
              />
            </Grid>
          </Grid>
                )*/
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default CSVOpenWindow;
const sepOptions = [
  { name: "Tab", value: "Tab" },
  { name: "Space", value: "Space" },
  { name: "Comma", value: "Comma" },
  { name: "Custom", value: "Custom" },
];
