import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";

import { Grid, Typography, Button } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import {
  AddVariableIcon,
  HorizontleMore,
} from "../../../../../utils/AllImages";
import ModalForm from "./../../../../../utils/modalForm";

const SoapWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const [openModal, setOpenModal] = useState(false);

  const [useWinCred, setUseWinCred] = useState(
    mapFieldObjWithValueByName(params, "WindowCredentials", false)
  );

  const [clientCertificate, setClientCertificate] = useState(
    mapFieldObjWithValueByName(params, "ClientCertificate", "")
  );
  const [clientCertificatePassword, setClientCertificatePassword] = useState(
    mapFieldObjWithValueByName(params, "ClientCertificatePassword", "")
  );

  const [continueOnErr, setContinueOnErr] = useState(
    mapFieldObjWithValueByName(params, "ContinueOnError", "")
  );
  const [contactName, setContactName] = useState(
    mapFieldObjWithValueByName(params, "ContactName", "")
  );
  const [endpoint, setEndpoint] = useState(
    mapFieldObjWithValueByName(params, "Endpoint", "")
  );

  const [methods, setMethods] = useState(
    mapFieldObjWithValueByName(params, "Methods", "")
  );
  const [parameters, setParameters] = useState(
    mapFieldObjWithValueByName(params, "Parameters", "")
  );

  const [headers, setHeaders] = useState(
    mapFieldObjWithValueByName(params, "Headers", "")
  );
  const [result, setResult] = useState(
    mapFieldObjWithValueByName(params, "Result", "")
  );
  const [username, setUsername] = useState(
    mapFieldObjWithValueByName(params, "Username", "")
  );
  const [password, setPassword] = useState(
    mapFieldObjWithValueByName(params, "Password", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");

    setClientCertificate(
      mapFieldObjWithValueByName(params, "ClientCertificate", "")
    );
    setClientCertificatePassword(
      mapFieldObjWithValueByName(params, "ClientCertificatePassword", "")
    );
    setContinueOnErr(mapFieldObjWithValueByName(params, "ContinueOnError", ""));
    setContactName(mapFieldObjWithValueByName(params, "ContactName", ""));
    setEndpoint(mapFieldObjWithValueByName(params, "Endpoint", ""));
    setMethods(mapFieldObjWithValueByName(params, "Methods", ""));
    setParameters(mapFieldObjWithValueByName(params, "Parameters", ""));
    setHeaders(mapFieldObjWithValueByName(params, "Headers", ""));
    setResult(mapFieldObjWithValueByName(params, "Result", ""));
    setUsername(mapFieldObjWithValueByName(params, "Username", ""));
    setPassword(mapFieldObjWithValueByName(params, "Password", ""));

    setUseWinCred(
      mapFieldObjWithValueByName(params, "WindowCredentials", false)
    );
    setInvisibleInLogs(logsState(params, false));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "ClientCertificate":
        setClientCertificate({ ...clientCertificate, paramValue: value });
        break;
      case "ClientCertificatePassword":
        setClientCertificatePassword({
          ...clientCertificatePassword,
          paramValue: value,
        });
        break;
      case "ContinueOnError":
        setContinueOnErr({ ...continueOnErr, paramValue: value });
        break;
      case "ContactName":
        setContactName({ ...contactName, paramValue: value });
        break;
      case "Endpoint":
        setEndpoint({ ...endpoint, paramValue: value });
        break;
      case "Methods":
        setMethods({ ...methods, paramValue: value });
        break;
      case "Parameters":
        setParameters({ ...parameters, paramValue: value });
        break;
      case "Headers":
        setHeaders({ ...headers, paramValue: value });
        break;
      case "Result":
        setResult({ ...result, paramValue: value });
        break;
      case "Username":
        setUsername({ ...username, paramValue: value });
        break;
      case "Password":
        setPassword({ ...password, paramValue: value });
        break;
      case "UseWindowsCredentials":
        setUseWinCred({ ...useWinCred, paramValue: checked });
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    clientCertificate,
    clientCertificatePassword,
    continueOnErr,
    contactName,
    endpoint,
    methods,
    parameters,
    headers,
    result,
    username,
    password,
    useWinCred,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      clientCertificate,
      clientCertificatePassword,
      continueOnErr,
      contactName,
      endpoint,
      methods,
      parameters,
      headers,
      result,
      username,
      password,
      useWinCred,
    ];
    addParamsToSelAct(allParams);
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ClientCertificate":
        setClientCertificate({
          ...clientCertificate,
          paramType: changeToValue,
        });
        break;
      case "ClientCertificatePassword":
        setClientCertificatePassword({
          ...clientCertificatePassword,
          paramType: changeToValue,
        });
        break;
      case "ContinueOnError":
        setContinueOnErr({ ...continueOnErr, paramType: changeToValue });
        break;
      case "ContactName":
        setContactName({ ...contactName, paramType: changeToValue });
        break;
      case "Endpoint":
        setEndpoint({ ...endpoint, paramType: changeToValue });
        break;
      case "Methods":
        setMethods({ ...methods, paramType: changeToValue });
        break;
      case "Parameters":
        setParameters({ ...parameters, paramType: changeToValue });
        break;
      case "Username":
        setUsername({ ...username, paramType: changeToValue });
        break;
      case "Password":
        setPassword({ ...password, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  const handleClose = () => {
    setOpenModal(false);
  };
  const onClick1 = () => {
    console.log("close clicked");
    handleClose();
  };
  const onClick2 = () => {
    console.log("SAVE clicked");
    handleClose();
  };

  console.log(openModal);
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || ""}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => setOpenModal(true)}
                  disableRipple
                  id={`${props.id}_OpenAsWizardBtn`}
                >
                  <Typography className={classes.btn_title}>
                    Open as Wizard
                  </Typography>
                </Button>
              </Grid>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_ClientCertificate`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={clientCertificate.paramType === "V"}
                  paramObj={clientCertificate}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ClientCertificate"
                  label="Client Certificate"
                  value={clientCertificate.paramValue}
                  options={getOptionsForVariable(clientCertificate)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_ClientCertificatePass`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={clientCertificatePassword.paramType === "V"}
                  paramObj={clientCertificatePassword}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ClientCertificatePassword"
                  label="Client Certificate Password"
                  value={clientCertificatePassword.paramValue}
                  options={getOptionsForVariable(clientCertificatePassword)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_ContinueOnError`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={continueOnErr.paramType === "V"}
                  paramObj={continueOnErr}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ContinueOnError"
                  label="Continue on Error"
                  value={continueOnErr.paramValue}
                  options={getOptionsForVariable(continueOnErr)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_ContactName`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={contactName.paramType === "V"}
                  paramObj={contactName}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ContactName"
                  label="Contact Name"
                  value={contactName.paramValue}
                  options={getOptionsForVariable(contactName)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Endpoint`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={endpoint.paramType === "V"}
                  paramObj={endpoint}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Endpoint"
                  label="Endpoint"
                  value={endpoint.paramValue}
                  options={getOptionsForVariable(endpoint)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Methods`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={methods.paramType === "V"}
                  paramObj={methods}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Methods"
                  label="Methods"
                  value={methods.paramValue}
                  options={getOptionsForVariable(methods)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Parameters`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={parameters.paramType === "V"}
                  paramObj={parameters}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Parameters"
                  label="Parameters"
                  value={parameters.paramValue}
                  options={getOptionsForVariable(parameters)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Headers`}
                  //  labelBtn1={true}
                  // labelBtn2={true}
                  dropdown={true}
                  //paramObj={parameters}
                  //labelBtn1OnClick={changeParamTypeToVorC}
                  //labelBtn2OnClick={changeParamTypeToVorC}
                  btnIcon={
                    <AddVariableIcon
                      className={classes.btnIcon + " " + classes.colorPrimary}
                    />
                  }
                  name="Headers"
                  label="Headers"
                  value={headers.paramValue}
                  options={getOptionsForVariable(headers)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Result`}
                  //  labelBtn1={true}
                  // labelBtn2={true}
                  dropdown={true}
                  //paramObj={parameters}
                  //labelBtn1OnClick={changeParamTypeToVorC}
                  //labelBtn2OnClick={changeParamTypeToVorC}
                  btnIcon={
                    <AddVariableIcon
                      className={classes.btnIcon + " " + classes.colorPrimary}
                    />
                  }
                  name="Result"
                  label="Result"
                  value={result.paramValue}
                  options={getOptionsForVariable(result)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Username`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={username.paramType === "V"}
                  paramObj={username}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Username"
                  label="Username"
                  value={username.paramValue}
                  options={getOptionsForVariable(username)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Password`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={password.paramType === "V"}
                  paramObj={password}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Password"
                  label="Password"
                  value={password.paramValue}
                  options={getOptionsForVariable(password)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_UseWindowsCredential`}
                  checkbox={true}
                  name="UseWindowsCredentials"
                  label="Use Windows Credentials"
                  value={useWinCred.paramValue}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
      <ModalForm
        id={`${props.id}_SOAPReqDefModal`}
        isOpen={openModal}
        title="SOAP Request Definition"
        Content={
          <SoapModal
            endpoint={endpoint}
            handleChange={handleChange}
            id={`${props.id}_SOAPReqDefModal`}
          />
        }
        btn1Title="Cancel"
        onClick1={onClick1}
        btn2Title="Save"
        onClick2={onClick2}
        closeModal={handleClose}
        containerHeight={440}
        containerWidth={590}
      />
    </div>
  );
};

export default SoapWindow;
const SoapModal = ({ endpoint, handleChange, id }) => {
  const classes = useStyles();
  return (
    <div style={{ marginTop: "12px" }}>
      <Grid container direction="column" spacing={2} alignItems="flex-end">
        <Grid item container direction="row">
          <Grid item xs>
            <PropertyField
              id={`${id}_Endpoint`}
              name="Endpoint"
              label="SOAP Request"
              value={endpoint.paramValue}
              options={getOptionsForVariable(endpoint)}
              onChange={handleChange}
            />
          </Grid>
          <Grid item style={{ backgroundColor: "#000000" }}>
            <HorizontleMore />
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              color="primary"
              //onClick={() => setOpenModal(true)}
              id={`${id}_GetBtn`}
            >
              <Typography className={classes.btn_title}>Get</Typography>
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};
