import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email, ExpandMore } from "@mui/icons-material";

import { Grid, Typography, Button, CircularProgress, IconButton } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  getVariableTypeById,
  handeParseValuesForVarType,
  handeParseValuesForVarTypeSingleObj,
} from "./../Common/CommonMethods";
import ErrorsWindow from "../Common/ErrorsWindow";
import { AddIcon, AddVariableIcon, CloseIcon, DeleteIcon, PopoutIcon } from "../../../../../utils/AllImages";
import ModalForm from "../../../../../utils/modalForm";
import axios from "axios";
import { getEncryptedString } from "./../../../../../utils/encryptions";
import MenuPopper from "./../../../../../utils/MenuPopper";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { createInstance, generateUniqueId } from "../../../../../utils/common";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";
import { GET_SERVICE_CATALOGUE } from "../../../../../config";
import clsx from "clsx";

const RestWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [openModal, setOpenModal] = useState(false);
  const [selTab, setSelTab] = useState("Request Builder");
  const [selTabRes, setSelTabRes] = useState("Preview Response");

  const [clientCertificate, setClientCertificate] = useState(
    mapFieldObjWithValueByName(params, "ClientCertificate", "")
  );
  const [clientCertificatePassword, setClientCertificatePassword] = useState(
    mapFieldObjWithValueByName(params, "ClientCertificatePassword", "")
  );

  const [timeoutField, setTimeoutField] = useState(
    mapFieldObjWithValueByName(params, "Timeout", "")
  );
  const [acceptFormat, setAcceptFormat] = useState(
    mapFieldObjWithValueByName(params, "AcceptFormat", "")
  );
  const [endpoint, setEndpoint] = useState(
    mapFieldObjWithValueByName(params, "Endpoint", "")
  );

  const [methods, setMethods] = useState(
    mapFieldObjWithValueByName(params, "Methods", "")
  );
  const [consumerKey, setConsumerKey] = useState(
    mapFieldObjWithValueByName(params, "ConsumerKey", "")
  );
  const [consumerSecret, setConsumerSecret] = useState(
    mapFieldObjWithValueByName(params, "ConsumerSecret", "")
  );
  const [auth, setAuth] = useState("");
  const [authenticationType, setAuththenticationType] = useState(
    mapFieldObjWithValueByName(params, "AuthenticationType", "")
  );
  const [oAuth1Token, setOAuth1Token] = useState(
    mapFieldObjWithValueByName(params, "OAuth1Token", "")
  );
  const [tokenField, setTokenField] = useState(
    mapFieldObjWithValueByName(params, "Token", "")
  );
  const [oAuth1TokenSecret, setOAuth1TokenSecret] = useState(
    mapFieldObjWithValueByName(params, "OAuth1TokenSecret", "")
  );

  /*const [oAuth2Token, setOAuth2Token] = useState(
    mapFieldObjWithValueByName(params, "OAuth2Token", "")
  );*/

  const [body, setBody] = useState(
    mapFieldObjWithValueByName(params, "Body", "")
  );
  const [formData, setFormData] = useState(
    mapFieldObjWithValueByName(params, "formData", "")
  );
  const [bodyFormat, setBodyFormat] = useState(
    mapFieldObjWithValueByName(params, "BodyFormat", "")
  );

  /*const [cookies, setCookies] = useState(
    mapFieldObjWithValueByName(params, "Cookies", "")
  );*/
  const [parameters, setParameters] = useState(
    mapFieldObjWithValueByName(params, "Parameters", "")
  );

  const [headers, setHeaders] = useState(
    mapFieldObjWithValueByName(params, "Headers", "")
  );

  /*const [resourcePath, setResourcePath] = useState(
    mapFieldObjWithValueByName(params, "ResourcePath", "")
  );

  const [urlSegments, setUrlSegments] = useState(
    mapFieldObjWithValueByName(params, "UrlSegments", "")
  );*/

  const [statusCode, setStatusCode] = useState(
    mapFieldObjWithValueByName(params, "StatusCode", "")
  );

  const [result, setResult] = useState(
    mapFieldObjWithValueByName(params, "Result", "")
  );
  const [username, setUsername] = useState(
    mapFieldObjWithValueByName(params, "Username", "")
  );
  const [password, setPassword] = useState(
    mapFieldObjWithValueByName(params, "Password", "")
  );

  const [isAsync, setIsAsync] = useState(
    mapFieldObjWithValueByName(params, "isAsync", false)
  );
  const [callbackUrl, setCallbackUrl] = useState(
    mapFieldObjWithValueByName(params, "callbackUrl", "")
  );

  const [arrParams, setArrParams] = useState([]);
  const [arrHeaders, setArrHeaders] = useState([]);

  const [arrParamsWizard, setArrParamsWizard] = useState([]);
  const [arrHeadersWizard, setArrHeadersWizard] = useState([]);

  const [formDataValues, setFormDataValues] = useState([]);
  const [arrFormDatas, setFormDatas] = useState([]);

  const [token, setToken] = useState("");
  const [bodyField, setBodyField] = useState("");
  const [endpointField, setEndpointField] = useState("");
  const [timeout, setTimeout] = useState("");
  const [methodsField, setMethodsFields] = useState("");
  const [oAuth1TokenField, setOAuth1TokenField] = useState("");
  const [oAuth1TokenSecretField, setOAuth1TokenSecretField] = useState("");
  const [consumerKeyField, setConsumerKeyField] = useState("");
  const [consumerSecretField, setConsumerSecretField] = useState("");
  const [oAuth2TokenField, setOAuth2TokenField] = useState("");
  const [bodyFormatField, setBodyFormatField] = useState("");
  const [cookiesField, setCookiesField] = useState("");
  const [acceptFormatField, setAcceptFormatField] = useState("");
  const [usernameField, setUsernameField] = useState("");
  const [passwordField, setPasswordField] = useState("");
  const [authField, setAuthField] = useState("");
  const [resultField, setResultField] = useState("");
  const [statusField, setStatusField] = useState("");

  const [accessTokenUrl, setAccessTokenUrl] = useState("");
  const [authUrl, setAuthUrl] = useState("");
  const [clientId, setClientId] = useState("");
  const [clientSecret, setClientSecret] = useState("");
  const [scope, setScope] = useState("");
  const [redirect_uri, setRedirectUri] = useState(
    `http://${window.location.host}/sfweb/accessToken`
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");

    setClientCertificate(
      mapFieldObjWithValueByName(params, "ClientCertificate", "")
    );
    setClientCertificatePassword(
      mapFieldObjWithValueByName(params, "ClientCertificatePassword", "")
    );

    setTimeoutField(mapFieldObjWithValueByName(params, "Timeout", ""));
    setAcceptFormat(mapFieldObjWithValueByName(params, "AcceptFormat", ""));
    setEndpoint(mapFieldObjWithValueByName(params, "Endpoint", ""));
    setMethods(mapFieldObjWithValueByName(params, "Methods", ""));
    setConsumerKey(mapFieldObjWithValueByName(params, "ConsumerKey", ""));
    setConsumerSecret(mapFieldObjWithValueByName(params, "ConsumerSecret", ""));
    setAuththenticationType(
      mapFieldObjWithValueByName(params, "AuthenticationType", "")
    );
    setOAuth1Token(mapFieldObjWithValueByName(params, "OAuth1Token", ""));
    setTokenField(mapFieldObjWithValueByName(params, "Token", ""));
    setIsAsync(mapFieldObjWithValueByName(params, "isAsync", false))
    setCallbackUrl(mapFieldObjWithValueByName(params, "callbackUrl", ""))
    setOAuth1TokenSecret(
      mapFieldObjWithValueByName(params, "OAuth1TokenSecret", "")
    );

    // setOAuth2Token(mapFieldObjWithValueByName(params, "OAuth2Token", ""));

    setBody(mapFieldObjWithValueByName(params, "Body", ""));
    setBodyFormat(mapFieldObjWithValueByName(params, "BodyFormat", ""));

    const paramObj = mapFieldObjWithValueByName(params, "Parameters", "");
    const headerObj = mapFieldObjWithValueByName(params, "Headers", "");

    if (headerObj.paramValue) {
      const arrOfHeaders = handeParseValuesForVarType({
        stringyfiedObject: headers.paramValue,
      });
      if (arrOfHeaders) {
        setArrHeaders([...arrOfHeaders]);
      }
    }
    if (paramObj.paramValue) {
      try {
        const arrOfParams = JSON.parse(parameters.paramValue);
        if (Array.isArray(arrOfParams)) {
          const newArrOfParams = arrOfParams.map((item) => {
            return handeParseValuesForVarTypeSingleObj({
              stringyfiedObject: JSON.stringify(item),
            });
          });
          setArrParams(newArrOfParams);
        }
      } catch (error) {
        console.log(error);
      }
    }

    setParameters(paramObj);
    setHeaders(headerObj);

    setResult(mapFieldObjWithValueByName(params, "Result", ""));
    setStatusCode(mapFieldObjWithValueByName(params, "StatusCode", ""));
    setUsername(mapFieldObjWithValueByName(params, "Username", ""));
    setPassword(mapFieldObjWithValueByName(params, "Password", ""));
    const newFormData = mapFieldObjWithValueByName(params, "formData", "");
    if (newFormData.paramValue) {
      try {
        const formDataObj = JSON.parse(newFormData.paramValue);
        console.log(formDataObj);
        if (formDataObj) {
          let newFormDataValues = [];
          const fileObj = formDataObj?.file;
          const textObj = formDataObj?.text;
          if (fileObj) {
            let arrOfFiles = handeParseValuesForVarType({
              stringyfiedObject: JSON.stringify(fileObj),
            });
            arrOfFiles = arrOfFiles.map((item) => {
              return { ...item, fieldType: "File" };
            });
            if (arrOfFiles) {
              newFormDataValues = [...arrOfFiles];
            }
          }
          if (textObj) {
            let arrOfTexts = handeParseValuesForVarType({
              stringyfiedObject: JSON.stringify(textObj),
            });
            arrOfTexts = arrOfTexts.map((item) => {
              return { ...item, fieldType: "Text" };
            });
            newFormDataValues = [...newFormDataValues, ...arrOfTexts];
            console.log(newFormDataValues);
            setFormDataValues(newFormDataValues);
          }
        }
      } catch (error) {
        console.log(error);
      }
    }
    setFormData(newFormData);
    setInvisibleInLogs(logsState(params, false));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  /*****************************************************************************************
   * @author asloob_ali BUG ID : 105940 Description : 105940 - Variable: Getting error Type should not be empty if a tried to create a variable thorugh property window in Rest Services
   *  Reason:new combobox/selectbox was not implemented in this property window.
   * Resolution : combobox/selectbox  implemented in this property window.
   *  Date : 01/03/2022             ****************************************/
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "ClientCertificate":
        setClientCertificate((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "ClientCertificatePassword":
        setClientCertificatePassword((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;

      case "Timeout":
        setTimeoutField((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "AcceptFormat":
        setAcceptFormat((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Endpoint":
        setEndpoint((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Methods":
        setMethods((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ConsumerKey":
        setConsumerKey((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ConsumerSecret":
        setConsumerSecret((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Auth":
        setAuth(value);
        break;
      case "AuthenticationType":
        setAuththenticationType((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "OAuth1Token":
        setOAuth1Token((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Token":
        setTokenField((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "IsAsync":
        setIsAsync((prevState) => ({ ...prevState, paramValue: !isAsync.paramValue }));
        break;
      case "CallbackUrl":
        setCallbackUrl((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "OAuth1TokenSecret":
        setOAuth1TokenSecret((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      /* case "OAuth2Token":
        setOAuth2Token({ ...oAuth2Token, paramValue: value });
        break;
*/
      case "Body":
        setBody((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "BodyFormat":
        setBodyFormat((prevState) => ({ ...prevState, paramValue: value }));
        if (
          value === "multipart/form-data" ||
          value === "x-www-form-urlencoded"
        ) {
          setBody((prevState) => ({ ...prevState, paramValue: "" }));
        }
        break;

      case "StatusCode":
        setStatusCode((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Parameters":
        setParameters((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Headers":
        setHeaders((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Result":
        setResult((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Username":
        setUsername((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Password":
        setPassword((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "formData":
        setFormData((prevState) => ({ ...prevState, paramValue: value }));
        break;

      default:
        break;
    }
  };

  const handleChangeLocal = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "Token":
        setToken(value);
        break;
      case "Body":
        setBodyField(value);
        break;
      case "Endpoint":
        setEndpointField((prev) => value);
        break;
      case "Timeout":
        setTimeout(value);
        break;
      case "Methods":
        setMethodsFields((prev) => value);
        break;
      case "AcceptFormat":
        setAcceptFormatField(value);
        break;
      case "Auth":
        setAuthField(value);
        break;
      case "OAuth1Token":
        setOAuth1TokenField(value);
        break;
      case "OAuth1TokenSecret":
        setOAuth1TokenSecretField(value);
        break;
      case "ConsumerKey":
        setConsumerKeyField(value);
        break;
      case "ConsumerSecret":
        setConsumerSecretField(value);
        break;
      /* case "OAuth2Token":
        setOAuth2TokenField(value);
        break;*/
      case "BodyFormat":
        setBodyFormatField(value);
        if (
          value === "multipart/form-data" ||
          value === "x-www-form-urlencoded"
        ) {
          setBodyField("");
        }
        break;
      case "Username":
        setUsernameField(value);
        break;
      case "Password":
        setPasswordField(value);
        break;
      case "AuthUrl":
        setAuthUrl(value);
        break;
      case "AccessTokenUrl":
        setAccessTokenUrl(value);
        break;
      case "ClientId":
        setClientId(value);
        break;
      case "Scope":
        setScope(value);
        break;
      case "RedirectUri":
        setRedirectUri(value);
        break;
      case "ClientSecret":
        setClientSecret(value);
        break;
      case "Result":
        setResultField(value);
        break;
      case "StatusCode":
        setStatusField(value);
        break;

      default:
        break;
    }
  };

  const handleTabChange = (tabItem) => {
    setSelTab(tabItem);
  };
  const handleResTabChange = (tabItem) => {
    setSelTabRes(tabItem);
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    clientCertificate,
    clientCertificatePassword,

    timeoutField,
    authenticationType,
    acceptFormat,
    endpoint,
    methods,
    consumerKey,
    consumerSecret,
    oAuth1Token,
    oAuth1TokenSecret,
    body,
    bodyFormat,

    statusCode,
    parameters,
    headers,
    result,
    username,
    password,
    formData,
    tokenField,
    isAsync,
    callbackUrl
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      clientCertificate,
      clientCertificatePassword,

      timeoutField,
      authenticationType,
      acceptFormat,
      endpoint,
      methods,
      consumerKey,
      consumerSecret,
      oAuth1Token,
      oAuth1TokenSecret,

      body,
      bodyFormat,

      statusCode,

      parameters,
      headers,

      result,
      username,
      password,
      formData,
      tokenField,
      isAsync,
      callbackUrl
    ];

    addParamsToSelAct(allParams);
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ClientCertificate":
        setClientCertificate({
          ...clientCertificate,
          paramType: changeToValue,
        });
        break;
      case "ClientCertificatePassword":
        setClientCertificatePassword({
          ...clientCertificatePassword,
          paramType: changeToValue,
        });
        break;

      case "Timeout":
        setTimeoutField({ ...timeoutField, paramType: changeToValue });
        break;

      case "Endpoint":
        setEndpoint({ ...endpoint, paramType: changeToValue });
        break;

      case "ConsumerKey":
        setConsumerKey({ ...consumerKey, paramType: changeToValue });
        break;
      case "ConsumerSecret":
        setConsumerSecret({ ...consumerSecret, paramType: changeToValue });
        break;
      case "OAuth1Token":
        setOAuth1Token({ ...oAuth1Token, paramType: changeToValue });
        break;
      case "Token":
        setTokenField({ ...tokenField, paramType: changeToValue });
        break;
      case "OAuth1TokenSecret":
        setOAuth1TokenSecret({
          ...oAuth1TokenSecret,
          paramType: changeToValue,
        });
        break;
      case "Body":
        setBody({ ...body, paramType: changeToValue });
        break;
      case "BodyFormat":
        setBodyFormat({ ...bodyFormat, paramType: changeToValue });
        break;

      case "Parameters":
        setParameters({ ...parameters, paramType: changeToValue });
        break;
      case "Headers":
        setHeaders({ ...headers, paramType: changeToValue });
        break;
      case "Username":
        setUsername({ ...username, paramType: changeToValue });
        break;
      case "Password":
        setPassword({ ...password, paramType: changeToValue });
        break;
      case "formData":
        setFormData({ ...formData, paramType: changeToValue });
        break;
      default:
        break;
    }
  };

  const handleClose = () => {
    setOpenModal(false);
  };
  const onClick1 = () => {
    setToken("");
    setBodyField("");
    setEndpointField("");
    setTimeout("");
    setMethodsFields("");
    setAcceptFormatField("");
    setAuthField("");
    setOAuth1TokenField("");
    setOAuth1TokenSecretField("");
    setConsumerKeyField("");
    setConsumerSecretField("");
    setOAuth2TokenField("");
    setBodyFormatField("");
    setUsernameField("");
    setPasswordField("");
    setResultField("");
    setStatusField("");
    setAuthUrl("");
    setAccessTokenUrl("");
    setClientId("");
    setScope("");
    setArrParamsWizard([]);
    setArrHeadersWizard([]);
    setClientSecret("");
    setFormDatas([]);

    handleClose();
  };
  const onClick2 = () => {
    console.log("SAVE clicked");

    /*****************************************************************************************
     * @author asloob_ali BUG ID : 103886 Description : 103886 -Rest services- Inputs are not saved properly after Saving request definition in wizard
     *  Reason:some of the properties was not properly saved..
     * Resolution : fixed the issue,now user will be able to save properties from wizard to property window by clicking on save button.
     *  Date : 28/12/2021             ****************************************/
    if (endpointField) {
      setEndpoint({ ...endpoint, paramType: "C", paramValue: endpointField });
    }
    if (timeout) {
      setTimeoutField({ ...timeoutField, paramType: "C", paramValue: timeout });
    }
    if (methodsField) {
      setMethods({ ...methods, paramType: "C", paramValue: methodsField });
    }
    if (bodyField) {
      setBody({ ...body, paramType: "C", paramValue: bodyField });
    }
    if (bodyFormatField) {
      setBodyFormat({
        ...bodyFormat,
        paramType: "C",
        paramValue: bodyFormatField,
      });
    }
    if (acceptFormatField) {
      setAcceptFormat({
        ...acceptFormat,
        paramType: "C",
        paramValue: acceptFormatField,
      });
    }
    if (authField) {
      setAuth(authField);
      setAuththenticationType({
        ...authenticationType,
        paramType: "C",
        paramValue: authField,
      });
    }
    if (oAuth1TokenField) {
      setOAuth1Token({
        ...oAuth1Token,
        paramType: "C",
        paramValue: oAuth1TokenField,
      });
    }
    if (token) {
      setTokenField({ ...tokenField, paramType: "C", paramValue: token });
    }
    if (oAuth1TokenSecretField) {
      setOAuth1TokenSecret({
        ...oAuth1TokenSecret,
        paramType: "C",
        paramValue: oAuth1TokenSecretField,
      });
    }
    if (consumerKeyField) {
      setConsumerKey({
        ...consumerKey,
        paramType: "C",
        paramValue: consumerKeyField,
      });
    }
    if (consumerSecretField) {
      setConsumerSecret({
        ...consumerSecret,
        paramType: "C",
        paramValue: consumerSecretField,
      });
    }

    if (usernameField) {
      setUsername({ ...username, paramType: "C", paramValue: usernameField });
    }
    if (passwordField) {
      setPassword({ ...password, paramType: "C", paramValue: passwordField });
    }

    if (arrHeadersWizard.length > 0) {
      setArrHeaders([...arrHeadersWizard]);
    }
    if (arrParamsWizard.length > 0) {
      setArrParams([...arrParamsWizard]);
    }
    if (arrFormDatas.length > 0) {
      const formDataV = arrFormDatas.filter(
        (item) => item.fieldType !== "File"
      );
      setFormDataValues([...formDataV]);
    }

    handleClose();
  };

  const handleFormDataEleType = (e, item, selfItm, index) => {
    const newFormDataValues = [...formDataValues];
    const obj = formDataValues[index];
    // obj.value = "";
    obj.fieldType = item;
    newFormDataValues.splice(index, 1, obj);
    setFormDataValues(newFormDataValues);
  };
  const addFormDataValues = () => {
    const newObj = { key: "", value: "", paramType: "C", fieldType: "Text" };
    const newArr = [...formDataValues, newObj];
    setFormDataValues(newArr);
  };

  const handleArrObjsValuesChange = (e, index, arr) => {
    const { name, value } = e.target;
    console.log(value);
    const newArr = [...arr];
    const obj = arr[index];
    if (name === "Key") {
      obj.key = value;
    } else if (name === "Value") {
      obj.value = value;
    }
    newArr.splice(index, 1, obj);
    return newArr;
  };
  const handleArrObjsValuesDelete = (index, arr) => {
    const newArr = [...arr];
    newArr.splice(index, 1);
    return newArr;
  };

  const handleFormDataValuesChange = (e, index) => {
    console.log(e, index);
    const newArr = handleArrObjsValuesChange(e, index, formDataValues);
    setFormDataValues(newArr);
  };
  const handleFormDataValuesDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, formDataValues);
    setFormDataValues(newArr);
  };

  useEffect(() => {
    if (formDataValues) {
      const fileObjsArr = formDataValues.filter(
        (item) => item.fieldType === "File"
      );
      const textObjsArr = formDataValues.filter(
        (item) => item.fieldType === "Text"
      );

      let newFileObj = {};
      let newTextObj = {};
      newFileObj = fileObjsArr.reduce(
        (obj, item) =>
          Object.assign(obj, {
            [item.key]:
              item.paramType === "C"
                ? item.value
                : "${" + `${item.value}` + "}",
          }),
        {}
      );
      newTextObj = textObjsArr.reduce(
        (obj, item) =>
          Object.assign(obj, {
            [item.key]:
              item.paramType === "C"
                ? item.value
                : "${" + `${item.value}` + "}",
          }),
        {}
      );
      let formDataParamValue = { file: newFileObj, text: newTextObj };
      setFormData({
        ...formData,
        paramValue: JSON.stringify(formDataParamValue),
      });
    }
  }, [formDataValues]);

  useEffect(() => {
    if (arrParams.length > 0) {
      const newParamObj = arrParams.map((param) => {
        return {
          [param.key]:
            param.paramType === "C"
              ? param.value
              : "${" + `${param.value}` + "}",
        };
      });

      if (newParamObj) {
        setParameters({
          ...parameters,
          paramValue: JSON.stringify(newParamObj),
        });
      }
    }
  }, [arrParams]);

  useEffect(() => {
    if (arrHeaders.length > 0) {
      const newHeaderObj = arrHeaders.reduce(
        (obj, item) =>
          Object.assign(obj, {
            [item.key]:
              item.paramType === "C"
                ? item.value
                : "${" + `${item.value}` + "}",
          }),
        {}
      );
      if (newHeaderObj) {
        setHeaders({ ...headers, paramValue: JSON.stringify(newHeaderObj) });
      }
    }
  }, [arrHeaders]);

  const addWizardParameters = () => {
    const newObj = { key: "", value: "", paramType: "C" };
    const newArr = [...arrParamsWizard, newObj];
    setArrParamsWizard(newArr);
  };
  const handleWizardParamsValueChange = (e, index) => {
    const newArr = handleArrObjsValuesChange(e, index, arrParamsWizard);
    setArrParamsWizard(newArr);
  };
  const handleWizardParamDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, arrParamsWizard);
    setArrParamsWizard(newArr);
  };
  const addWizardHeaders = () => {
    const newObj = { key: "", value: "", paramType: "C" };
    const newArr = [...arrHeadersWizard, newObj];
    setArrHeadersWizard(newArr);
  };
  const handleWizardHeadersValueChange = (e, index) => {
    const newArr = handleArrObjsValuesChange(e, index, arrHeadersWizard);
    setArrHeadersWizard(newArr);
  };
  const handleWizardHeaderDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, arrHeadersWizard);
    setArrHeadersWizard(newArr);
  };

  const addParameters = () => {
    const newObj = { key: "", value: "", paramType: "C" };
    const newArr = [...arrParams, newObj];
    setArrParams(newArr);
  };
  const handleParamsValueChange = (e, index) => {
    const newArr = handleArrObjsValuesChange(e, index, arrParams);
    setArrParams(newArr);
  };
  const handleParamDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, arrParams);
    setArrParams(newArr);
  };
  const addHeaders = () => {
    const newObj = { key: "", value: "", paramType: "C" };
    const newArr = [...arrHeaders, newObj];
    setArrHeaders(newArr);
  };
  const handleHeadersValueChange = (e, index) => {
    const newArr = handleArrObjsValuesChange(e, index, arrHeaders);
    setArrHeaders(newArr);
  };
  const handleHeaderDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, arrHeaders);
    setArrHeaders(newArr);
  };

  const handleResultAndStatusCode = ({ resultVal, statusCodeVal }) => {
    setResultField(resultVal);
    setStatusField(statusCodeVal);
  };

  /*****************************************************************************************
   * @author asloob_ali BUG ID : 105505 Description : 105505 -Rest Services: Form data gets removed after clicking on Test button in the Wizard
   *  Reason:form data was saved locally in the modal.
   * Resolution : up lifted the state for form data.
   *  Date : 23/02/2022             ****************************************/
  const handleFormDataArrEleType = (e, item, selfItm, index) => {
    const newFormDataValues = [...arrFormDatas];
    const obj = arrFormDatas[index];
    obj.fieldType = item;
    obj.value = "";
    obj.file = null;
    newFormDataValues.splice(index, 1, obj);
    setFormDatas(newFormDataValues);
  };
  const addFormDataArrValues = () => {
    const newObj = { key: "", value: "", paramType: "C", fieldType: "Text" };
    const newArr = [...arrFormDatas, newObj];
    setFormDatas(newArr);
  };

  const handleFormDataArrValuesChange = (e, index) => {
    const newArr = handleArrObjsValuesChange(e, index, arrFormDatas);
    setFormDatas(newArr);
  };
  const handleFormDataArrValuesDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, arrFormDatas);
    setFormDatas(newArr);
  };
  const changeValueTypeToVorC = (
    paramName,
    changeToValue,
    index,
    nameOfField
  ) => {
    let obj = null;
    switch (nameOfField) {
      case "FormData":
        obj = formDataValues[index];
        obj.paramType = changeToValue;
        obj.value = "";
        const newFormDataValues = [...formDataValues];
        newFormDataValues.splice(index, 1, obj);
        setFormDataValues(newFormDataValues);
        break;
      case "Headers":
        obj = arrHeaders[index];
        obj.paramType = changeToValue;
        obj.value = "";
        const newHeaderValues = [...arrHeaders];
        newHeaderValues.splice(index, 1, obj);
        setArrHeaders(newHeaderValues);
        break;
      case "Parameters":
        obj = arrParams[index];
        obj.paramType = changeToValue;
        obj.value = "";
        const newParamValues = [...arrParams];
        newParamValues.splice(index, 1, obj);
        setArrParams(newParamValues);
        break;
      default:
        break;
    }
  };
  const handleOpenWizard = () => {
    if (endpoint.paramValue && endpoint.paramType === "C") {
      setEndpointField(endpoint.paramValue);
    }
    if (timeoutField.paramValue && timeoutField.paramType === "C") {
      setTimeout(timeoutField.paramValue);
    }
    if (methods.paramValue) {
      setMethodsFields(methods.paramValue);
    }
    if (body.paramValue && body.paramType === "C") {
      setBody(body.paramValue);
    }
    if (bodyFormat.paramValue) {
      setBodyFormatField(bodyFormat.paramValue);
    }
    if (acceptFormat.paramValue) {
      setAcceptFormatField(acceptFormat.paramValue);
    }
    if (authenticationType.paramValue) {
      setAuthField(authenticationType.paramValue);
    }
    if (oAuth1Token.paramValue && oAuth1Token.paramType === "C") {
      setOAuth1TokenField(oAuth1Token.paramValue);
    }
    if (tokenField && tokenField.paramType === "C") {
      setToken(tokenField.paramValue);
    }
    if (oAuth1TokenSecret.paramValue && oAuth1TokenSecret.paramType === "C") {
      setOAuth1TokenSecretField(oAuth1TokenSecret.paramValue);
    }
    if (consumerKey.paramValue && consumerKey.paramType === "C") {
      setConsumerKeyField(consumerKey.paramValue);
    }
    if (consumerSecret.paramValue && consumerSecret.paramType === "C") {
      setConsumerSecretField(consumerSecret.paramValue);
    }
    if (username.paramValue && username.paramType === "C") {
      setUsernameField(username.paramValue);
    }
    if (password.paramValue && password.paramType === "C") {
      setPasswordField(password.paramValue);
    }

    if (arrParams.length > 0) {
      setArrParamsWizard(
        [...arrParams].filter((item) => item.paramType === "C")
      );
    }
    if (arrHeaders.length > 0) {
      setArrHeadersWizard(
        [...arrHeaders].filter((item) => item.paramType === "C")
      );
    }
    if (formDataValues.length > 0) {
      setFormDatas(
        formDataValues.filter(
          (item) => item.paramType === "C" && item.fieldType === "Text"
        )
      );
    }
    setOpenModal(true);
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || ""}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid
              container
              direction="column"
              spacing={1}
            //style={{ paddingRight: "5px" }}
            >
              <Grid item>
                <Button
                  variant="outlined"
                  color="primary"
                  onClick={() => handleOpenWizard()}
                  disableFocusRipple
                  className={classes.focusPrimary}
                  id={`${props.id}_OpenAsWizardBtn`}
                >
                  <PopoutIcon />
                  <Typography style={{ marginLeft: '8px', color: '#0072C6' }}>
                    Open as Wizard
                  </Typography>
                </Button>
              </Grid>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>




              <Grid item>
                <PropertyField
                  id={`${props.id}_Endpoint`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={endpoint.paramType === "V"}
                  paramObj={endpoint}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Endpoint"
                  label="Endpoint"
                  value={endpoint.paramValue}
                  options={getOptionsForVariable(endpoint)}
                  onChange={handleChange}
                  combo={true}
                  error={vaildateParamValue(endpoint.paramValue).errorStatus}
                  helperText={vaildateParamValue(endpoint.paramValue).msg}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_Methods`}
                  dropdown={true}
                  name="Methods"
                  label="Methods"
                  value={methods.paramValue}
                  options={reqMethods}
                  onChange={handleChange}
                  combo={true}
                  error={vaildateParamValue(methods.paramValue).errorStatus}
                  helperText={vaildateParamValue(methods.paramValue).msg}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_AcceptFrmt`}
                  combo={true}
                  dropdown={true}
                  name="AcceptFormat"
                  label="Accept Format"
                  value={acceptFormat.paramValue}
                  // options={getOptionsForVariable(acceptFormat)}
                  options={acceptFormatOps}
                  onChange={handleChange}
                />
              </Grid>
              {/* <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={oAuth2Token.paramType === "V"}
                  paramObj={oAuth2Token}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="OAuth2Token"
                  label="OAuth2Token"
                  value={oAuth2Token.paramValue}
                  options={getOptionsForVariable(oAuth2Token)}
                  onChange={handleChange}
                />
             </Grid>*/}
              {(methods.paramValue === "PUT" ||
                methods.paramValue === "POST") && (
                  <>
                    {bodyFormat.paramValue !== "multipart/form-data" &&
                      bodyFormat.paramValue !== "x-www-form-urlencoded" && (
                        <Grid item>
                          <PropertyField
                            id={`${props.id}_Body`}
                            combo={true}
                            labelBtn1={true}
                            labelBtn2={true}
                            dropdown={body.paramType === "V"}
                            paramObj={body}
                            labelBtn1OnClick={changeParamTypeToVorC}
                            labelBtn2OnClick={changeParamTypeToVorC}
                            name="Body"
                            label="Body"
                            value={body.paramValue}
                            options={getOptionsForVariable(body)}
                            onChange={handleChange}
                            error={
                              vaildateParamValue(body.paramValue).errorStatus
                            }
                            helperText={vaildateParamValue(body.paramValue).msg}
                          />
                        </Grid>
                      )}
                    <Grid item>
                      <PropertyField
                        id={`${props.id}_BodyFormat`}
                        combo={true}
                        dropdown={true}
                        name="BodyFormat"
                        label="Body Format"
                        value={bodyFormat.paramValue}
                        options={bodyFormatOps}
                        onChange={handleChange}
                        error={
                          vaildateParamValue(bodyFormat.paramValue).errorStatus
                        }
                        helperText={vaildateParamValue(bodyFormat.paramValue).msg}
                      />
                    </Grid>
                    {(bodyFormat.paramValue === "multipart/form-data" ||
                      bodyFormat.paramValue === "x-www-form-urlencoded") && (
                        <>
                          <Grid item container direction="column" spacing={1} style={{ marginTop: '12px', marginBottom: '12px' }}>

                            <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', marginLeft: '8px', width: '305px' }}>
                              <Grid container direction='column' spacing={1}>
                                <Grid item>
                                  <Typography className={classes.GroupTitle}>Form Data</Typography>
                                </Grid>

                                {formDataValues.map((item, index) => (
                                  <Grid item key={index}>
                                    <Grid container spacing={1} alignItems={'flex-start'}>
                                      <Grid item xs={6}>
                                        <PropertyField
                                          id={`${props.id}_Key_${generateUniqueId()}`}
                                          name="Key"
                                          label="Key"
                                          value={item.key}
                                          onChange={(e) =>
                                            handleFormDataValuesChange(e, index)
                                          }
                                          readOnly={item.readOnly}
                                          rootWidth="150px"
                                          height={32}
                                        />
                                      </Grid>
                                      <Grid item xs={6}>
                                        <PropertyField
                                          id={`${props.id}_Value_${generateUniqueId()}`}
                                          name="Value"
                                          label="Value"
                                          combo={true}
                                          width={160}
                                          varType={1}
                                          paramObj={item}
                                          labelBtn1={true}
                                          labelBtn2={true}
                                          dropdown={item.paramType === "V"}
                                          labelBtn1OnClick={(paramName, changeToValue) =>
                                            changeValueTypeToVorC(
                                              paramName,
                                              changeToValue,
                                              index,
                                              "FormData"
                                            )
                                          }
                                          labelBtn2OnClick={(paramName, changeToValue) =>
                                            changeValueTypeToVorC(
                                              paramName,
                                              changeToValue,
                                              index,
                                              "FormData"
                                            )
                                          }
                                          value={item.value}
                                          onChange={(e) =>
                                            handleFormDataValuesChange(e, index)
                                          }
                                          readOnly={item.readOnly}
                                          options={getOptionsForVariable({
                                            paramObjectTypeId: 1,
                                          })}
                                        />
                                      </Grid>
                                      <Grid item xs={10}>

                                        <PropertyField
                                          id={`${props.id}_FieldType`}
                                          combo={true}
                                          dropdown={true}
                                          name="FormDataFieldType"
                                          label="Field Type"
                                          value={item.fieldType}
                                          options={bodyFormat.paramValue ===
                                            "x-www-form-urlencoded"
                                            ? fileFormatOptions2 : fileFormatOptions1}
                                          onChange={(e) => {
                                            const { value } = e.target
                                            handleFormDataEleType(
                                              e,
                                              value,
                                              null,
                                              index
                                            )
                                          }}
                                          error={
                                            vaildateParamValue(item.fieldType).errorStatus
                                          }
                                          helperText={vaildateParamValue(item.fieldType).msg}
                                          width={270}
                                        />
                                        {/*<Grid
                                    container
                                    spacing={1}
                                    justifyContent="flex-end"
                                    style={{ marginLeft: "5px" }}
                                  >
                                    <Grid item>
                                      <Typography>{item.fieldType}</Typography>
                                    </Grid>
                                    <Grid item>
                                      <MenuPopper
                                        id={`${props.id}_MenuPopper`}
                                        MenuIcon={ExpandMore}
                                        selfClicked={item}
                                        handleSelectedItem={(e, itm, selfItm) =>
                                          handleFormDataEleType(
                                            e,
                                            itm,
                                            selfItm,
                                            index
                                          )
                                        }
                                        items={
                                          bodyFormat.paramValue ===
                                            "x-www-form-urlencoded"
                                            ? ["Text"]
                                            : ["Text", "File"]
                                        }
                                      />
                                    </Grid>
                                      </Grid>*/}
                                      </Grid>
                                      {!item.readOnly && (
                                        <Grid item style={{ marginInlineStart: 'auto' }}>
                                          {/*} <UniqueIDGenerator>
                                      <DeleteIcon
                                        id={`${props.id
                                          }_DeleteIcon_${generateUniqueId()}`}
                                        className={classes.deleteBtn}
                                        style={{
                                          marginBottom: "5px",
                                          cursor: "pointer",
                                        }}
                                        onClick={() =>
                                          handleFormDataValuesDelete(index)
                                        }
                                        tabIndex={0}
                                        onKeyPress={(e) =>
                                          e.key === "Enter" &&
                                          handleFormDataArrValuesDelete(index)
                                        }
                                        role="button"
                                        aria-label="Delete"
                                      />
                                      </UniqueIDGenerator>*/}
                                          <IconButton
                                            id={`_DeleteIcon_${generateUniqueId()}`}
                                            onClick={() => handleFormDataValuesDelete(index)}
                                            aria-label="Delete"
                                            style={{ marginTop: '15px' }}
                                          >
                                            <CloseIcon
                                            //className={classes.deleteCrossIcon}
                                            />
                                          </IconButton>
                                        </Grid>
                                      )}
                                    </Grid>
                                  </Grid>
                                ))}
                                {/*<Grid item>
                            <Button
                              variant="contained"
                              color="primary"
                              onClick={() => addFormDataValues()}
                              className={classes.focusPrimary}
                              disableRipple
                              id={`${props.id}_AddBtn`}
                            >
                              <Typography className={classes.btn_title}>
                                Add
                              </Typography>
                            </Button>
                        </Grid>*/}
                                <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                                  <Grid container spacing={1}
                                    onClick={() => addFormDataValues()}
                                    onKeyPress={(e) =>
                                      e.key === "Enter" && addFormDataValues()
                                    }
                                    tabIndex={0}

                                    role="button"
                                    aria-label="Add Form Data"
                                  >
                                    <Grid item>

                                      <AddIcon
                                        className={classes.addColumnBtn}

                                      />
                                    </Grid>
                                    <Grid item>
                                      <Typography className={classes.tertiary_add_btn_title}>
                                        Add
                                      </Typography>
                                    </Grid>
                                  </Grid>
                                </Grid>
                              </Grid>
                            </div>
                          </Grid>
                        </>
                      )}
                  </>
                )}

              {/*<Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={headers.paramType === "V"}
                  paramObj={headers}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                 
                  name="Headers"
                  label="Headers"
                  value={headers.paramValue}
                  options={getOptionsForVariable(headers)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={parameters.paramType === "V"}
                  paramObj={parameters}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Parameters"
                  label="Parameters"
                  value={parameters.paramValue}
                  options={getOptionsForVariable(parameters)}
                  onChange={handleChange}
                />
              </Grid>*/}
              <Grid item container direction="column" spacing={1} style={{ marginTop: '12px', marginBottom: '12px' }}>

                <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', marginLeft: '8px', width: '305px' }}>
                  <Grid container direction='column' spacing={1}>
                    <Grid item>
                      <Typography className={classes.GroupTitle}>Header(s)</Typography>
                    </Grid>
                    {arrHeaders.map((item, index) => (
                      <Grid item key={index}>
                        <Grid container spacing={1} alignItems="flex-start">
                          <Grid item >
                            <PropertyField
                              rootWidth='129px'
                              id={`${props.id}_Key_${generateUniqueId()}`}
                              name="Key"
                              label="Key"
                              value={item.key}
                              onChange={(e) => handleHeadersValueChange(e, index)}
                              readOnly={item.readOnly}
                              height={32}

                            />
                          </Grid>
                          <Grid item xs={5}>
                            <PropertyField
                              id={`${props.id}_Value_${generateUniqueId()}`}
                              name="Value"
                              label="Value"
                              combo={true}
                              width={139}
                              varType={1}
                              paramObj={item}
                              labelBtn1={true}
                              labelBtn2={true}
                              dropdown={item.paramType === "V"}
                              labelBtn1OnClick={(paramName, changeToValue) =>
                                changeValueTypeToVorC(
                                  paramName,
                                  changeToValue,
                                  index,
                                  "Headers"
                                )
                              }
                              labelBtn2OnClick={(paramName, changeToValue) =>
                                changeValueTypeToVorC(
                                  paramName,
                                  changeToValue,
                                  index,
                                  "Headers"
                                )
                              }
                              value={item.value}
                              onChange={(e) => handleHeadersValueChange(e, index)}
                              readOnly={item.readOnly}
                              options={getOptionsForVariable({
                                paramObjectTypeId: 1,
                              })}
                            />
                          </Grid>

                          {!item.readOnly && (
                            <Grid item style={{ marginLeft: "auto" }}>
                              {/*<UniqueIDGenerator>
                            <DeleteIcon
                              id={`${props.id
                                }_DeleteIcon_${generateUniqueId()}`}
                              className={classes.deleteBtn}
                              style={{
                                marginBottom: "5px",
                                cursor: "pointer",
                              }}
                              onClick={() => handleHeaderDelete(index)}
                              tabIndex={0}
                              onKeyPress={(e) =>
                                e.key === "Enter" && handleHeaderDelete(index)
                              }
                              role="button"
                              aria-label="Delete"
                            />
                            </UniqueIDGenerator>*/}
                              <IconButton
                                id={`_DeleteIcon_${generateUniqueId()}`}
                                onClick={() => handleHeaderDelete(index)}
                                aria-label="Delete"
                                style={{ marginTop: '15px' }}
                              >
                                <CloseIcon
                                //className={classes.deleteCrossIcon}
                                />
                              </IconButton>
                            </Grid>
                          )}
                        </Grid>
                      </Grid>
                    ))}
                    <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                      <Grid container spacing={1}
                        onClick={() => addHeaders()}
                        onKeyPress={(e) =>
                          e.key === "Enter" && addHeaders()
                        }
                        tabIndex={0}

                        role="button"
                        aria-label="Add Header"
                      >
                        <Grid item>

                          <AddIcon
                            className={classes.addColumnBtn}

                          />
                        </Grid>
                        <Grid item>
                          <Typography className={classes.tertiary_add_btn_title}>
                            Add
                          </Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                    {/* <Grid item>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => addHeaders()}
                    className={classes.focusPrimary}
                    disableRipple
                    id={`${props.id}_AddHeaderBtn`}
                  >
                    <Typography className={classes.btn_title}>
                      Add
                    </Typography>
                  </Button>
              </Grid>*/}
                  </Grid>
                </div>
              </Grid>
              <Grid item container direction="column" spacing={1} style={{ marginTop: '12px', marginBottom: '12px' }}>

                <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', marginLeft: '8px', width: '305px' }}>
                  <Grid container direction='column' spacing={1}>
                    <Grid item>
                      <Typography className={classes.GroupTitle}>Parameter(s)</Typography>
                    </Grid>
                    {/*arrParams.length > 0 && (
                  <Grid item>
                    <Grid container spacing={1} alignItems="flex-end">
                      <Grid item xs={5}>
                        <Typography>Key</Typography>
                      </Grid>
                      <Grid item xs={5}>
                        <Typography>Value</Typography>
                      </Grid>
                    </Grid>
                  </Grid>
                )*/}
                    {arrParams.map((item, index) => (
                      // <Grid item key={index}>
                      //   <Grid container spacing={1} alignItems="center">
                      //     <Grid
                      //       item
                      //       xs={5} //style={{ paddingTop: "24px" }}
                      //     >
                      //       <PropertyField
                      //         id={`${props.id}_Key_${generateUniqueId()}`}
                      //         name="Key"
                      //         //  label="Key"
                      //         value={item.key}
                      //         onChange={(e) => handleParamsValueChange(e, index)}
                      //         readOnly={item.readOnly}
                      //         height={28}
                      //       />
                      //     </Grid>
                      <Grid item key={index}>
                        <Grid container spacing={1} alignItems="flex-start">
                          <Grid item >
                            <PropertyField
                              rootWidth='129px'
                              id={`${props.id}_Key_${generateUniqueId()}`}
                              name="Key"
                              label="Key"
                              value={item.key}
                              onChange={(e) => handleParamsValueChange(e, index)}
                              readOnly={item.readOnly}
                              height={32}
                            />
                          </Grid>
                          <Grid item xs={5}>
                            <PropertyField
                              id={`${props.id}_Value_${generateUniqueId()}`}
                              combo={true}
                              width={139}
                              varType={1}
                              name="Value"
                              label="Value"
                              paramObj={item}
                              labelBtn1={true}
                              labelBtn2={true}
                              dropdown={item.paramType === "V"}
                              labelBtn1OnClick={(paramName, changeToValue) =>
                                changeValueTypeToVorC(
                                  paramName,
                                  changeToValue,
                                  index,
                                  "Parameters"
                                )
                              }
                              labelBtn2OnClick={(paramName, changeToValue) =>
                                changeValueTypeToVorC(
                                  paramName,
                                  changeToValue,
                                  index,
                                  "Parameters"
                                )
                              }
                              value={item.value}
                              onChange={(e) => handleParamsValueChange(e, index)}
                              readOnly={item.readOnly}
                              options={getOptionsForVariable({
                                paramObjectTypeId: 1,
                              })}

                            />
                          </Grid>

                          {!item.readOnly && (
                            <Grid item style={{ marginLeft: "auto" }}>
                              {/*<UniqueIDGenerator>
                            <DeleteIcon
                              id={`${props.id
                                }_DeleteIcon_${generateUniqueId()}`}
                              className={classes.deleteBtn}
                              style={{
                                marginBottom: "5px",
                                cursor: "pointer",
                              }}
                              onClick={() => handleParamDelete(index)}
                              tabIndex={0}
                              onKeyPress={(e) =>
                                e.key === "Enter" && handleParamDelete(index)
                              }
                              role="button"
                              aria-label="Delete"
                            />
                            </UniqueIDGenerator>*/}


                              <IconButton
                                id={`_DeleteIcon_${generateUniqueId()}`}
                                onClick={() => handleParamDelete(index)}
                                aria-label="Delete"
                                style={{ marginTop: '15px' }}
                              >
                                <CloseIcon
                                //className={classes.deleteCrossIcon}
                                />
                              </IconButton>

                            </Grid>

                          )}
                        </Grid>
                      </Grid>
                    ))}
                    {/*<Grid item>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => addParameters()}
                    className={classes.focusPrimary}
                    disableRipple
                    id={`${props.id}_AddParamsBtn`}
                  >
                    <Typography className={classes.btn_title}>
                      Add
                    </Typography>
                  </Button>
              </Grid>*/}
                    <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                      <Grid container spacing={1}
                        onClick={() => addParameters()}
                        onKeyPress={(e) =>
                          e.key === "Enter" && addParameters()
                        }
                        tabIndex={0}

                        role="button"
                        aria-label="Add Parameter"
                      >
                        <Grid item>

                          <AddIcon
                            className={classes.addColumnBtn}

                          />
                        </Grid>
                        <Grid item>
                          <Typography className={classes.tertiary_add_btn_title}>
                            Add
                          </Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </div>
              </Grid>
            </Grid>
            <Grid item >
              <PropertyField
                checkbox={true}
                id={`${props.id}_IsAsync`}
                name="IsAsync"
                label="Is Async"
                value={isAsync.paramValue}
                onChange={handleChange}
              />
            </Grid>
            {isAsync.paramValue
              &&
              <Grid item>
                <PropertyField
                  id={`${props.id}_CallbackUrl`}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={callbackUrl.paramType === "V"}
                  paramObj={callbackUrl}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="CallbackUrl"
                  label="Callback URL"
                  value={callbackUrl.paramValue}
                  options={getOptionsForVariable(callbackUrl)}
                  onChange={handleChange}
                  combo={true}
                  error={vaildateParamValue(callbackUrl.paramValue).errorStatus}
                  helperText={vaildateParamValue(callbackUrl.paramValue).msg}
                />
              </Grid>
            }
            <Grid item style={{ marginTop: '8px' }}>
              <PropertyField
                id={`${props.id}_AuthenticationType`}
                combo={true}
                dropdown={true}
                name="AuthenticationType"
                label="Authentication Type"
                value={authenticationType.paramValue}
                options={authOps}
                onChange={handleChange}
              />
            </Grid>
            {authenticationType.paramValue === "OAuth1" && (
              <Grid container direction="column" spacing={2}>
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    OAUTH1
                  </Typography>
                </Grid>

                <Grid item>
                  <PropertyField
                    id={`${props.id}_ConsumerKey`}
                    combo={true}
                    labelBtn1={true}
                    labelBtn2={true}
                    dropdown={consumerKey.paramType === "V"}
                    paramObj={consumerKey}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    name="ConsumerKey"
                    label="Consumer Key"
                    value={consumerKey.paramValue}
                    options={getOptionsForVariable(consumerKey)}
                    onChange={handleChange}
                    error={
                      vaildateParamValue(consumerKey.paramValue).errorStatus
                    }
                    helperText={vaildateParamValue(consumerKey.paramValue).msg}
                  />
                </Grid>
                <Grid item>
                  <PropertyField
                    id={`${props.id}_ConsumerSecret`}
                    combo={true}
                    labelBtn1={true}
                    labelBtn2={true}
                    dropdown={consumerSecret.paramType === "V"}
                    paramObj={consumerSecret}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    name="ConsumerSecret"
                    label="Consumer Secret"
                    value={consumerSecret.paramValue}
                    options={getOptionsForVariable(consumerSecret)}
                    onChange={handleChange}
                    error={
                      vaildateParamValue(consumerSecret.paramValue).errorStatus
                    }
                    helperText={
                      vaildateParamValue(consumerSecret.paramValue).msg
                    }
                  />
                </Grid>
                <Grid item>
                  <PropertyField
                    id={`${props.id}_OAuth1Token`}
                    combo={true}
                    labelBtn1={true}
                    labelBtn2={true}
                    dropdown={oAuth1Token.paramType === "V"}
                    paramObj={oAuth1Token}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    name="OAuth1Token"
                    label="OAuth1Token"
                    value={oAuth1Token.paramValue}
                    options={getOptionsForVariable(oAuth1Token)}
                    onChange={handleChange}
                    error={
                      vaildateParamValue(oAuth1Token.paramValue).errorStatus
                    }
                    helperText={vaildateParamValue(oAuth1Token.paramValue).msg}
                  />
                </Grid>
                <Grid item>
                  <PropertyField
                    id={`${props.id}_OAuth1TokenSecret`}
                    combo={true}
                    labelBtn1={true}
                    labelBtn2={true}
                    dropdown={oAuth1TokenSecret.paramType === "V"}
                    paramObj={oAuth1TokenSecret}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    name="OAuth1TokenSecret"
                    label="OAuth1TokenSecret"
                    value={oAuth1TokenSecret.paramValue}
                    options={getOptionsForVariable(oAuth1TokenSecret)}
                    onChange={handleChange}
                    error={
                      vaildateParamValue(oAuth1TokenSecret.paramValue)
                        .errorStatus
                    }
                    helperText={
                      vaildateParamValue(oAuth1TokenSecret.paramValue).msg
                    }
                  />
                </Grid>
              </Grid>
            )}

            {/* <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={resourcePath.paramType === "V"}
                  paramObj={resourcePath}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="ResourcePath"
                  label="Resource Path"
                  value={resourcePath.paramValue}
                  options={getOptionsForVariable(resourcePath)}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={urlSegments.paramType === "V"}
                  paramObj={urlSegments}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="UrlSegments"
                  label="Url Segments"
                  value={urlSegments.paramValue}
                  options={getOptionsForVariable(urlSegments)}
                  onChange={handleChange}
                />
              </Grid>*/}

            {authenticationType.paramValue === "Basic Auth" && (
              <Grid container direction="column" spacing={2}>
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    Basic Auth
                  </Typography>
                </Grid>
                <Grid item>
                  <PropertyField
                    id={`${props.id}_UserName`}
                    combo={true}
                    labelBtn1={true}
                    labelBtn2={true}
                    dropdown={username.paramType === "V"}
                    paramObj={username}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    name="Username"
                    label="Username"
                    value={username.paramValue}
                    options={getOptionsForVariable(username)}
                    onChange={handleChange}
                    error={vaildateParamValue(username.paramValue).errorStatus}
                    helperText={vaildateParamValue(username.paramValue).msg}
                  />
                </Grid>
                <Grid item>
                  <PropertyField
                    id={`${props.id}_Pass`}
                    combo={true}
                    labelBtn1={true}
                    labelBtn2={true}
                    dropdown={password.paramType === "V"}
                    paramObj={password}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    name="Password"
                    label="Password"
                    value={password.paramValue}
                    options={getOptionsForVariable(password)}
                    onChange={handleChange}
                    error={vaildateParamValue(password.paramValue).errorStatus}
                    helperText={vaildateParamValue(password.paramValue).msg}
                  />
                </Grid>
              </Grid>
            )}
            {authenticationType.paramValue === "Bearer Token" && (
              <Grid container direction="column" spacing={2}>
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    Bearer Token
                  </Typography>
                </Grid>

                <Grid item>
                  <PropertyField
                    id={`${props.id}_Token`}
                    combo={true}
                    labelBtn1={true}
                    labelBtn2={true}
                    dropdown={tokenField.paramType === "V"}
                    paramObj={tokenField}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    name="Token"
                    label="Token"
                    value={tokenField.paramValue}
                    options={getOptionsForVariable(tokenField)}
                    onChange={handleChange}
                    error={
                      vaildateParamValue(tokenField.paramValue).errorStatus
                    }
                    helperText={vaildateParamValue(tokenField.paramValue).msg}
                  />
                </Grid>
              </Grid>
            )}
            <Grid item>
              <PropertyField
                id={`${props.id}_ClientCertificate`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={clientCertificate.paramType === "V"}
                paramObj={clientCertificate}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="ClientCertificate"
                label="Client Certificate"
                value={clientCertificate.paramValue}
                options={getOptionsForVariable(clientCertificate)}
                onChange={handleChange}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_ClientCertificatePass`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={clientCertificatePassword.paramType === "V"}
                paramObj={clientCertificatePassword}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="ClientCertificatePassword"
                label="Client Certificate Password"
                value={clientCertificatePassword.paramValue}
                options={getOptionsForVariable(clientCertificatePassword)}
                onChange={handleChange}
              />
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_Timeout`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={timeoutField.paramType === "V"}
                paramObj={timeoutField}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="Timeout"
                label="Timeout (seconds)(default 30 seconds)"
                value={timeoutField.paramValue}
                options={getOptionsForVariable(timeoutField)}
                onChange={handleChange}
              />
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Result`}
                combo={true}
                dropdown={true}
                paramObj={result}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Result"
                label={`Result (${getVariableTypeById(
                  result.paramObjectTypeId
                )})`}
                value={result.paramValue}
                options={getOptionsForVariable(result)}
                onChange={handleChange}
                error={vaildateParamValue(result.paramValue).errorStatus}
                helperText={vaildateParamValue(result.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusCode`}
                combo={true}
                dropdown={true}
                paramObj={statusCode}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                label={`Status Code (${getVariableTypeById(
                  statusCode.paramObjectTypeId
                )})`}
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                error={vaildateParamValue(statusCode.paramValue).errorStatus}
                helperText={vaildateParamValue(statusCode.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
      <ModalForm
        id={`${props.id}`}
        isOpen={openModal}
        tabs={["Request Builder", "Response"]}
        selTab={selTab}
        handleTabChange={handleTabChange}
        handleChange={handleChange}
        title="REST Request Definition"
        Content={
          selTab === "Request Builder" ? (
            <RestModal
              id={`${props.id}_ModalForm`}
              endpointField={endpointField}
              methodsField={methodsField}
              timeout={timeout}
              acceptFormatField={acceptFormatField}
              oAuth1TokenField={oAuth1TokenField}
              oAuth1TokenSecretField={oAuth1TokenSecretField}
              consumerKeyField={consumerKeyField}
              consumerSecretField={consumerSecretField}
              oAuth2TokenField={oAuth2TokenField}
              bodyField={bodyField}
              bodyFormatField={bodyFormatField}
              authField={authField}
              usernameField={usernameField}
              passwordField={passwordField}
              authUrl={authUrl}
              accessTokenUrl={accessTokenUrl}
              clientId={clientId}
              clientSecret={clientSecret}
              scope={scope}
              redirect_uri={redirect_uri}
              token={token}
              handleChangeLocal={handleChangeLocal}
              handleTabChange={handleTabChange}
              addParameters={addWizardParameters}
              addHeaders={addWizardHeaders}
              handleParamsValueChange={handleWizardParamsValueChange}
              handleHeadersValueChange={handleWizardHeadersValueChange}
              handleHeaderDelete={handleWizardHeaderDelete}
              handleParamDelete={handleWizardParamDelete}
              arrParams={arrParamsWizard}
              arrHeaders={arrHeadersWizard}
              setArrParams={setArrParamsWizard}
              setArrHeaders={setArrHeadersWizard}
              handleResultAndStatusCode={handleResultAndStatusCode}
              changeValueTypeToVorC={changeValueTypeToVorC}
              arrFormDatas={arrFormDatas}
              addFormDataValues={addFormDataArrValues}
              handleFormDataEleType={handleFormDataArrEleType}
              handleFormDataValuesChange={handleFormDataArrValuesChange}
              handleFormDataValuesDelete={handleFormDataArrValuesDelete}
            />
          ) : (
            <RestResTab
              id={`${props.id}_RestResTab`}
              endpoint={endpointField}
              handleResTabChange={handleResTabChange}
              selTabRes={selTabRes}
              methods={methodsField}
              result={resultField}
              arrParams={arrParamsWizard}
              arrHeaders={arrHeadersWizard}
              statusCode={statusField}
              authField={authField}
              consumerKeyField={consumerKeyField}
              consumerSecretField={consumerSecretField}
              oAuth1TokenField={oAuth1TokenField}
              oAuth1TokenSecretField={oAuth1TokenSecretField}
            />
          )
        }
        headerCloseBtn={true}
        onClickHeaderCloseBtn={handleClose}
        btn1Title="Cancel"
        onClick1={onClick1}
        btn2Title="Save"
        onClick2={onClick2}
        closeModal={handleClose}
        containerHeight={533}
        containerWidth={800}
      />
    </div>
  );
};

export default RestWindow;
const RestModal = ({
  id,
  endpointField,
  timeout,
  methodsField,
  oAuth1TokenField,
  oAuth1TokenSecretField,
  consumerKeyField,
  consumerSecretField,
  oAuth2TokenField,
  authField,
  bodyField,
  token,
  bodyFormatField,

  acceptFormatField,
  usernameField,
  passwordField,
  authUrl,
  accessTokenUrl,
  clientId,
  clientSecret,
  scope,
  redirect_uri,
  handleChangeLocal,
  handleTabChange,
  addParameters,
  addHeaders,

  handleParamsValueChange,
  handleParamDelete,

  handleHeadersValueChange,
  handleHeaderDelete,
  arrParams,
  arrHeaders,
  setArrParams,
  setArrHeaders,
  handleResultAndStatusCode,
  changeValueTypeToVorC,
  arrFormDatas,
  handleFormDataEleType,
  addFormDataValues,
  // handleArrObjsValuesChange,
  // handleArrObjsValuesDelete,
  handleFormDataValuesChange,
  handleFormDataValuesDelete,
}) => {
  const classes = useStyles();
  const [isProcessing, setIsProcessing] = useState(false);
  const [selWebServiceMode, setSelWebserviceMode] = useState("1");
  const [selWebServiceIndex, setSelWebserviceIndex] = useState(null);
  const [allWebServices, setAllWebservices] = useState([]);
  const [selectedWebServiceDetails, setSelectedWebServiceDetails] = useState(null);




  const radioButtonsArray = [
    { label: "Add New", value: "1" },
    { label: "Select From Catalog", value: "2" },
  ];
  const getWebServicesDetails = async () => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${GET_SERVICE_CATALOGUE}`);
      if (res.status === 200) {
        setAllWebservices(res.data?.data || [])
      }
    } catch (error) {
      console.log(error)
    }
  }

  const getSelectedWebServiceDetails = async ({ MethodIndex }) => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${GET_SERVICE_CATALOGUE}/${MethodIndex}`);
      if (res.status === 200) {
        setSelectedWebServiceDetails(res.data?.data ? res.data.data[0] : null)
      }
    } catch (error) {
      console.log(error)
    }
  }
  useEffect(() => {
    if (selWebServiceMode === "2") {
      getWebServicesDetails()
    }
  }, [selWebServiceMode])
  useEffect(() => {
    if (selWebServiceIndex) {
      getSelectedWebServiceDetails({ MethodIndex: selWebServiceIndex })
    }

  }, [selWebServiceIndex])

  useEffect(() => {
    // if (selWebServiceIndex) {
    //const selWebService = allWebServices.find(item => item.MethodIndex === selWebServiceIndex);
    if (selectedWebServiceDetails) {
      const selWebService = { ...selectedWebServiceDetails }

      handleChangeLocal({ target: { name: "Endpoint", value: selWebService.BaseURI } })
      handleChangeLocal({ target: { name: "Methods", value: selWebService.OperationType } })
      handleChangeLocal({ target: { name: "AcceptFormat", value: selWebService.AcceptFormat } })
      handleChangeLocal({ target: { name: "Body", value: selWebService.Body } })
      handleChangeLocal({ target: { name: "Auth", value: selWebService.AuthenticationType } })
      handleChangeLocal({ target: { name: "Username", value: selWebService.Username } })
      handleChangeLocal({ target: { name: "Password", value: selWebService.Password } })


      if (selWebService.Headers) {
        const arrOfHeaders = handeParseValuesForVarType({
          stringyfiedObject: selWebService.Headers,
        });
        if (arrOfHeaders) {
          setArrHeaders(arrOfHeaders)
        } else {
          setArrHeaders([])
        }
        console.log(arrOfHeaders)
      }
      if (selWebService.Parameters) {
        try {
          const arrOfParams = JSON.parse(selWebService.Parameters);
          if (Array.isArray(arrOfParams)) {
            const newArrOfParams = arrOfParams.map((item) => {
              return handeParseValuesForVarTypeSingleObj({
                stringyfiedObject: JSON.stringify(item),
              });
            });
            console.log(newArrOfParams)
            setArrParams(newArrOfParams);
          } else {
            setArrParams([])
          }
        } catch (error) {
          console.log(error);
        }
      }
    }
    // }

  }, [selectedWebServiceDetails])

  /* const handleFormDataEleType = (e, item, selfItm, index) => {
    const newFormDataValues = [...arrFormDatas];
    const obj = arrFormDatas[index];
    obj.fieldType = item;
    obj.value = "";
    obj.file = null;
    newFormDataValues.splice(index, 1, obj);
    setFormDatas(newFormDataValues);
  };
  const addFormDataValues = () => {
    const newObj = { key: "", value: "", paramType: "C", fieldType: "Text" };
    const newArr = [...arrFormDatas, newObj];
    setFormDatas(newArr);
  };

 const handleArrObjsValuesChange = (e, index, arr) => {
    const { name, value } = e.target;
    const newArr = [...arr];
    const obj = arr[index];
    if (name === "Key") {
      obj.key = value;
    } else if (name === "Value") {
      if (obj.fieldType === "File") {
       // const fileSelected = e.target.files[0];
        console.log(fileSelected);

        if (fileSelected) {
          obj.file = fileSelected;
          obj.value = fileSelected.name;
        }
      } else {
        obj.value = value;
      }
    }
    newArr.splice(index, 1, obj);
    return newArr;
  };
  const handleArrObjsValuesDelete = (index, arr) => {
    const newArr = [...arr];
    newArr.splice(index, 1);
    return newArr;
  };

  const handleFormDataValuesChange = (e, index) => {
    const newArr = handleArrObjsValuesChange(e, index, arrFormDatas);
    setFormDatas(newArr);
  };
  const handleFormDataValuesDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, arrFormDatas);
    setFormDatas(newArr);
  };*/

  const getBase64 = (StrForBasicAuth) => {
    return getEncryptedString(StrForBasicAuth);
  };
  const handleTestApi = async () => {
    let newArrParams = [...arrParams];
    const newHeaderObj = arrHeaders.reduce(
      (obj, item) => Object.assign(obj, { [item.key]: item.value }),
      {}
    );

    let jsonBodyObj = {};
    try {
      if (bodyField && methodsField !== "GET") {
        Object.assign(jsonBodyObj, JSON.parse(bodyField));
      }
    } catch (err) {
      console.log(err);
      alert("Not Valid Json format in Body.");
    }

    let config = {
      method: methodsField?.toLowerCase() || "get",
      timeout: timeout ? timeout * 1000 : 30000,
      headers: {
        Accept: acceptFormatField ? `${acceptFormatField}` : "application/json",
        ...newHeaderObj,
        "content-type":
          bodyFormatField === "multipart/form-data" ||
            bodyFormatField === "x-www-form-urlencoded"
            ? "multipart/form-data"
            : bodyFormatField,
      },
      data: {
        ...jsonBodyObj,
      },
    };
    if (
      bodyFormatField === "multipart/form-data" ||
      bodyFormatField === "x-www-form-urlencoded"
    ) {
      const bodyFormData = new FormData();

      arrFormDatas.forEach((item) => {
        if (item?.key) {
          bodyFormData.append(
            `${item.key}`,
            item.fieldType === "Text" ? `${item.value}` : item.file
          );
        }
      });
      config["data"] = bodyFormData;
    }
    if (authField) {
      let authorizationStr = "";
      switch (authField) {
        case "Basic Auth":
          if (usernameField && passwordField) {
            const strForBasicAuth = `${usernameField}:${passwordField}`;
            authorizationStr = "Basic " + getBase64(strForBasicAuth);
          }
          break;
        case "Bearer Token":
          if (token) {
            authorizationStr = "Bearer " + token;
          }
          break;
        default:
          break;
      }
      if (authField !== "None" && authField !== "OAuth1") {
        config.headers["Authorization"] = authorizationStr;
      } else if (authField === "OAuth1") {
        newArrParams = [
          ...newArrParams,
          { key: "oauth_consumer_key", value: consumerKeyField },
          { key: "oauth_consumer_secret", value: consumerSecretField },
          { key: "oauth_token", value: oAuth1TokenField },
          { key: "oauth_token_secret", value: oAuth1TokenSecretField },
        ];
      }
    }
    config["url"] = endpointField + getParamStr(newArrParams);
    console.log(config);
    try {
      setIsProcessing(true);
      const res = await axios(config);
      console.log(res);
      handleTabChange("Response");
      handleResultAndStatusCode({ resultVal: res, statusCodeVal: res.status });
      if (res.status === 200) {
        setIsProcessing(false);
      }
    } catch (error) {
      setIsProcessing(false);
      console.log(error);
      console.log(error.response);

      handleResultAndStatusCode({
        resultVal: error,
        statusCodeVal: error?.response?.status || "No Response",
      });
      handleTabChange("Response");
    }
  };

  const handleAccessToken = async () => {
    const arr = [
      { key: "response_type", value: "code" },
      { key: "client_id", value: clientId },
      // { key: "redirect_uri", value: "http://localhost:3000" },
    ];
    /*  const config = {
      method: "get",
      //method: "post",
      // "Access-Control-Allow-Origin": "*",
      url: authUrl + getParamStr(arr),
      // withCredentials: false,
      // "Content-Type": "application/x-www-form-urlencoded",
    };
    const res = await axios(config);
    console.log(res);
    if (res.status === 200) {
      setHtmlPage(res.data);
        const w = window.open("about:blank");
      w.document.open();
      w.document.write(res.data);
      w.document.close();
    
    }*/

    /*
     * Create form to request access token from Google's OAuth 2.0 server.
     */
    // Google's OAuth 2.0 endpoint for requesting an access token
    var oauth2Endpoint = "https://accounts.google.com/o/oauth2/v2/auth";

    // Create <form> element to submit parameters to OAuth 2.0 endpoint.
    var form = document.createElement("form");
    form.setAttribute("method", "GET"); // Send as a GET request.
    form.setAttribute("action", oauth2Endpoint);

    // Parameters to pass to OAuth 2.0 endpoint.
    var params = {
      client_id: `${clientId}`,
      // redirect_uri: "http://localhost:3000",
      redirect_uri: redirect_uri,
      response_type: "token",
      //  scope: "https://www.googleapis.com/auth/gmail.modify",
      scope: `${scope}`,
      include_granted_scopes: "true",
      // 'state': 'pass-through value'
    };

    // Add form parameters as hidden input values.
    for (var p in params) {
      var input = document.createElement("input");
      input.setAttribute("type", "hidden");
      input.setAttribute("name", p);
      input.setAttribute("value", params[p]);
      form.appendChild(input);
    }
    // Add form to page and submit it to open the OAuth 2.0 endpoint.
    form.target = "_blank";
    document.body.appendChild(form);

    form.submit();
    /* const w = window.open(
      redirect_uri,
      "windowPopup",
      "about:blank,height=600,width=600"
    );
    w.document.open();
    w.document.write(form);
    
    w.document.close();*/

    //http://localhost:3000/#access_token=ya29.a0ARrdaM-V4TwjGFEfU0XCLMU7cOSfuMabTpwkacf530jgQBBV42iPcro7AtlfkWWjQWmUaRMq4pWbJJ7yehiEl7G78hyqyayWuF_ufe5BNErMxR9mQPFngk2DTkPAmF0LEQXUv0d_AZN9_iksnmuArhovx9iIvA
    //&token_type=Bearer&expires_in=3599&scope=https://www.googleapis.com/auth/gmail.modify%20https://www.googleapis.com/auth/drive.metadata.readonly
    //messages
    //https://www.googleapis.com/gmail/v1/users/asloobali1234@gmail.com/messages
    //token
    //ya29.a0ARrdaM_LD2Sso_AZmfOH70Mr3WV31jiif6bX0xBA_ig2c4n3RoAclPeiBGwr43_J5vCGrEly1f8N82icn3kjEoeWM2eCiuVYGq8YtJ6CboTOjcWGHQDbBy4pWm_q2Esl33068Fvgr7sI02d7TADe5H8hesrB
    // http://localhost:3000/#access_token=ya29.a0ARrdaM_LD2Sso_AZmfOH70Mr3WV31jiif6bX0xBA_ig2c4n3RoAclPeiBGwr43_J5vCGrEly1f8N82icn3kjEoeWM2eCiuVYGq8YtJ6CboTOjcWGHQDbBy4pWm_q2Esl33068Fvgr7sI02d7TADe5H8hesrB&token_type=Bearer&expires_in=3599&scope=https://www.googleapis.com/auth/gmail.modify%20https://www.googleapis.com/auth/drive.metadata.readonly
  };
  /*****************************************************************************************
   * @author asloob_ali BUG ID : 102391 Description : 102391 - Header information is missing in REST request definition wizard
   *  Reason:in screen Headers were not given so functionality was not implemented.
   * Resolution : added headers functionality, so user can provide headers in key value pairs using text fields..
   *  Date : 10/11/2021             ***************************************************************************************/

  /*****************************************************************************************
   * @author asloob_ali BUG ID : 102373 Description : There is no option to add Body in POST\PUT request in the Wizard
   *  Reason:in screen Body field was not given so functionality was not implemented.
   * Resolution : added Body Field and functionality, so user can provide Json values in key value pairs using text field..
   *  Date : 10/11/2021             ***************************************************************************************/

  /*****************************************************************************************
   * @author asloob_ali BUG ID : 102386 Description :  Rest request definition wizard is not giving correct result with multiple key values
   *  Reason:i was using an json Object type structure for storing the parameters,i did'nt think of a scenerio where the parameters key could be same. so in json object we cant store multiple same keys. so it was overiding the value of other key.
   * Resolution : changed the procedure for handling parameters and generating a string from them.now using array of objects structure for storing parameters.
   *  Date : 9/11/2021             ***************************************************************************************/

  const handleWebServiceChanges = (e) => {

    const { name, value } = e.target;
    switch (name) {
      case "WebServiceMode":
        setSelWebserviceMode(value)
        break;
      case "WebServiceCatalog":
        setSelWebserviceIndex(value)
        break;
      default:
        break;

    };
  }
  return (
    <div style={{ marginTop: "16px" }}>
      <Grid container direction="column">
        <Grid item>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <PropertyField
                id={`${id}_WebServiceMode`}
                radio={true}
                ButtonsArray={radioButtonsArray}
                name="WebServiceMode"
                label="Web Service"
                value={selWebServiceMode}
                onChange={handleWebServiceChanges}
              />
            </Grid>
            {selWebServiceMode === '2' && <Grid item xs={6}>
              <PropertyField
                id={`${id}_WebserviceCatalog`}
                name="WebServiceCatalog"
                dropdown={true}
                label="Web Service Catalog"
                value={selWebServiceIndex}
                options={allWebServices.map(item => ({ "name": item.MethodName, "value": item.MethodIndex }))}
                onChange={handleWebServiceChanges}
              />
            </Grid>}
          </Grid>
        </Grid>
        <Grid item>
          <PropertyField
            id={`${id}_Endpoint`}
            name="Endpoint"
            label="Endpoint"
            value={endpointField}
            onChange={handleChangeLocal}
          />
        </Grid>
        <Grid item>
          <PropertyField
            id={`${id}_timeout`}
            name="Timeout"
            label="Timeout (seconds)(default 30 seconds)"
            value={timeout}
            onChange={handleChangeLocal}
          />
        </Grid>
        <Grid item>
          <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', }}>
            <Grid container direction='column' spacing={1}>
              <Grid item>
                <Typography className={classes.GroupTitle}>Header(s)</Typography>
              </Grid>

              {arrHeaders.map((item, index) => (
                <Grid item key={index}>
                  <Grid container spacing={3} alignItems="flex-end">
                    <Grid item >
                      <PropertyField
                        rootWidth='315px'
                        id={`${id}_Key_${generateUniqueId()}`}
                        name="Key"
                        label="Key"
                        value={item.key}
                        onChange={(e) => handleHeadersValueChange(e, index)}
                        readOnly={item.readOnly}

                      />
                    </Grid>
                    <Grid item >
                      <PropertyField
                        rootWidth='315px'
                        id={`${id}_Value_${generateUniqueId()}`}
                        name="Value"
                        label="Value"
                        value={item.value}
                        onChange={(e) => handleHeadersValueChange(e, index)}
                        readOnly={item.readOnly}

                      // options={getOptionsForVariable({ paramObjectTypeId: 1 })}
                      />
                    </Grid>
                    {!item.readOnly && (
                      <Grid item >
                        {/*<DeleteIcon
                      className={classes.deleteBtn}
                      style={{ marginBottom: "5px", cursor: "pointer" }}
                      onClick={() => handleHeaderDelete(index)}
                      tabIndex={0}
                      onKeyPress={(e) =>
                        e.key === "Enter" && handleHeaderDelete(index)
                      }
                      role="button"
                      aria-label="Delete"
                      id={`${id}_DeleteIcon_${generateUniqueId()}`}
                    />*/}
                        <IconButton
                          id={`_DeleteIcon_${generateUniqueId()}`}
                          onClick={() => handleHeaderDelete(index)}
                          aria-label="Delete"
                          style={{ marginTop: '-20px' }}
                        >
                          <CloseIcon
                          //className={classes.deleteCrossIcon}
                          />
                        </IconButton>

                      </Grid>
                    )}
                  </Grid>
                </Grid>
              ))}
              <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                <Grid container spacing={1}
                  onClick={() => addHeaders()}
                  onKeyPress={(e) =>
                    e.key === "Enter" && addHeaders()
                  }
                  tabIndex={0}

                  role="button"
                  aria-label="Add Header"
                >
                  <Grid item>

                    <AddIcon
                      className={classes.addColumnBtn}

                    />
                  </Grid>
                  <Grid item>
                    <Typography className={classes.tertiary_add_btn_title}>
                      Add
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
              {/*<Grid item>
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => addHeaders()}
                  className={classes.focusPrimary}
                  disableRipple
                  id={`${id}_AddHeaderBtn`}
                >
                  <Typography className={classes.btn_title}>Add Header</Typography>
                </Button>
                                          </Grid>*/}
            </Grid>
          </div>
        </Grid>
        <Grid item xs={4}>
          <PropertyField
            id={`${id}_Methods`}
            dropdown={true}
            name="Methods"
            label="Request Method"
            value={methodsField}
            onChange={handleChangeLocal}
            options={reqMethods}
          />
        </Grid>
        {(methodsField === "POST" || methodsField === "PUT") && (
          <>
            <Grid item>
              <PropertyField
                id={`${id}_BodyFormat`}
                dropdown={true}
                name="BodyFormat"
                label="Body Format"
                value={bodyFormatField}
                onChange={handleChangeLocal}
                options={bodyFormatOps}
              />
            </Grid>

            {(bodyFormatField === "multipart/form-data" ||
              bodyFormatField === "x-www-form-urlencoded") && (
                <>
                  <Grid item>
                    <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', }}>
                      <Grid container direction='column' spacing={1}>
                        <Grid item>
                          <Typography className={classes.GroupTitle}>Form Data</Typography>
                        </Grid>
                        {/*arrFormDatas.length > 0 && (
                    <Grid item>
                      <Grid container spacing={1} alignItems="flex-end">
                        <Grid item xs={4}>
                          <Typography>Key</Typography>
                        </Grid>
                        <Grid item xs={5}>
                          <Typography>Value</Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                  )*/}
                        {arrFormDatas.map((item, index) => (
                          <Grid item key={index}>
                            <Grid container spacing={1} alignItems={"flex-start"}>
                              <Grid item xs={4}>
                                <PropertyField
                                  name="Key"
                                  label={'key'}
                                  id={`${id}_Key_${generateUniqueId()}`}
                                  value={item.key}
                                  onChange={(e) => handleFormDataValuesChange(e, index)}
                                  readOnly={item.readOnly}
                                  height={32}
                                  width={230}

                                />
                              </Grid>
                              <Grid item xs={4}>
                                <PropertyField
                                  id={`${id}_Value_${generateUniqueId()}`}
                                  name="Value"
                                  label="Value"
                                  type={
                                    item.fieldType === "Text" || item.value
                                      ? "text"
                                      : "file"
                                  }
                                  value={item.value}
                                  onChange={(e) => handleFormDataValuesChange(e, index)}
                                  readOnly={item.fieldType === "File"}
                                  height={32}
                                  width={230}
                                />
                              </Grid>
                              <Grid item xs={2}>
                                {/*<Grid container spacing={1}>
                            <Grid item>
                              <Typography>{item.fieldType}</Typography>
                            </Grid>
                            <Grid item>
                              <MenuPopper
                                id={`${id}_MenuPopper`}
                                MenuIcon={ExpandMore}
                                selfClicked={item}
                                handleSelectedItem={(e, itm, selfItm) =>
                                  handleFormDataEleType(e, itm, selfItm, index)
                                }
                                items={
                                  bodyFormatField === "x-www-form-urlencoded"
                                    ? ["Text"]
                                    : ["Text", "File"]
                                }
                              />
                              </Grid>*/}
                                <PropertyField
                                  id={`${id}_FieldType`}
                                  // combo={true}
                                  dropdown={true}
                                  name="FormDataFieldType"
                                  label="Field Type"
                                  value={item.fieldType}
                                  options={bodyFormatField ===
                                    "x-www-form-urlencoded"
                                    ? fileFormatOptions2 : fileFormatOptions1}
                                  onChange={(e) => {
                                    const { value } = e.target
                                    handleFormDataEleType(
                                      e,
                                      value,
                                      null,
                                      index
                                    )
                                  }}
                                  error={
                                    vaildateParamValue(item.fieldType).errorStatus
                                  }
                                  helperText={vaildateParamValue(item.fieldType).msg}
                                  width={210}
                                  height={32}
                                />
                              </Grid>

                              {!item.readOnly && (
                                <Grid item style={{ marginInlineStart: 'auto' }}>
                                  {/*<UniqueIDGenerator>
                              <DeleteIcon
                                className={classes.deleteBtn}
                                style={{
                                  marginBottom: "5px",
                                  cursor: "pointer",
                                }}
                                onClick={() => handleFormDataValuesDelete(index)}
                                tabIndex={0}
                                onKeyPress={(e) =>
                                  e.key === "Enter" &&
                                  handleFormDataValuesDelete(index)
                                }
                                role="button"
                                aria-label="Delete"
                                id={`${id}_DeleteIcon_${generateUniqueId()}`}
                              />
                              </UniqueIDGenerator>*/}
                                  <IconButton
                                    id={`_DeleteIcon_${generateUniqueId()}`}
                                    onClick={() => handleFormDataValuesDelete(index)}
                                    aria-label="Delete"
                                    style={{ marginTop: '15px' }}
                                  >
                                    <CloseIcon
                                    //className={classes.deleteCrossIcon}
                                    />
                                  </IconButton>
                                </Grid>

                              )}
                            </Grid>
                          </Grid>

                        ))}
                        {/* <Grid item>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => addFormDataValues()}
                      className={classes.focusPrimary}
                      disableRipple
                      id={`${id}_AddBtn`}
                    >
                      <Typography className={classes.btn_title}>Add</Typography>
                    </Button>
                </Grid>*/}
                        <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                          <Grid container spacing={1}
                            onClick={() => addFormDataValues()}
                            onKeyPress={(e) =>
                              e.key === "Enter" && addFormDataValues()
                            }
                            tabIndex={0}

                            role="button"
                            aria-label="Add Form Data"
                          >
                            <Grid item>

                              <AddIcon
                                className={classes.addColumnBtn}

                              />
                            </Grid>
                            <Grid item>
                              <Typography className={classes.tertiary_add_btn_title}>
                                Add
                              </Typography>
                            </Grid>
                          </Grid>
                        </Grid>

                      </Grid>
                    </div>
                  </Grid>
                </>
              )}

            {bodyFormatField !== "multipart/form-data" &&
              bodyFormatField !== "x-www-form-urlencoded" && (
                <Grid item>
                  <PropertyField
                    id={`${id}_Body`}
                    name="Body"
                    label="Body"
                    multiline={true}
                    value={bodyField}
                    onChange={handleChangeLocal}
                  />
                </Grid>
              )}
          </>
        )}
        <Grid item xs={4}>
          <PropertyField
            id={`${id}_AcceptFormat`}
            dropdown={true}
            name="AcceptFormat"
            label="Accept Format as"
            value={acceptFormatField}
            onChange={handleChangeLocal}
            options={acceptFormatOps}
          />
        </Grid>

        <Grid item xs={4}>
          <PropertyField
            id={`${id}_Auth`}
            dropdown={true}
            name="Auth"
            label="Authentication"
            value={authField}
            onChange={handleChangeLocal}
            options={authOps}
          />
        </Grid>
        {authField === "OAuth1" && (
          <>
            <Grid item>
              <PropertyField
                id={`${id}_OAuth1Token`}
                name="OAuth1Token"
                label="OAuth1Token"
                value={oAuth1TokenField}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_OAuth1TokenSecret`}
                name="OAuth1TokenSecret"
                label="OAuth1TokenSecret"
                value={oAuth1TokenSecretField}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_ConsumerKey`}
                name="ConsumerKey"
                label="Consumer Key"
                value={consumerKeyField}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_ConsumerSecret`}
                name="ConsumerSecret"
                label="Consumer Secret"
                value={consumerSecretField}
                onChange={handleChangeLocal}
              />
            </Grid>
          </>
        )}
        {authField === "OAuth2" && (
          <>
            <Grid item>
              <PropertyField
                id={`${id}_AuthUrl`}
                name="AuthUrl"
                label="Auth Url"
                value={authUrl}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_AccessTokenUrl`}
                name="AccessTokenUrl"
                label="Access Token Url"
                value={accessTokenUrl}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_ClientId`}
                secret={true}
                name="ClientId"
                label="Client Id"
                value={clientId}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_ClientSecret`}
                secret={true}
                name="ClientSecret"
                label="Client Secret"
                value={clientSecret}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Scope`}
                name="Scope"
                label="Scope"
                value={scope}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_RedirectUri`}
                name="RedirectUri"
                label="Redirect Uri"
                readOnly={true}
                value={redirect_uri}
                onChange={handleChangeLocal}
                helperText="Your app's redirect uris / callback urls must include this."
              />
            </Grid>
            <Grid item>
              <Button
                variant="contained"
                color="primary"
                onClick={() => handleAccessToken()}
                className={classes.focusPrimary}
                disableRipple
                id={`${id}_GetAccessTokenBtn`}
              >
                <Typography className={classes.btn_title}>
                  Get Access Token
                </Typography>
              </Button>
            </Grid>
          </>
        )}
        {authField === "Basic Auth" && (
          <>
            <Grid item>
              <PropertyField
                id={`${id}_Username`}
                name="Username"
                label="Username"
                value={usernameField}
                onChange={handleChangeLocal}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${id}_Password`}
                name="Password"
                type="secret"
                label="Password"
                value={passwordField}
                onChange={handleChangeLocal}
              />
            </Grid>
          </>
        )}
        {authField === "Bearer Token" && (
          <>
            <Grid item>
              <PropertyField
                id={`${id}_Token`}
                name="Token"
                label="Token"
                value={token}
                multiline={true}
                onChange={handleChangeLocal}
              />
            </Grid>
          </>
        )}


        {/*arrParams.map((item, index) => (
          <Grid item key={index}>
            <Grid container spacing={1} alignItems="flex-end">
              <Grid item xs={5}>
                <PropertyField
                  id={`${id}_Key_${generateUniqueId()}`}
                  name="Key"
                  // label="Key"
                  value={item.key}
                  onChange={(e) => handleParamsValueChange(e, index)}
                />
              </Grid>
              <Grid item xs={5}>
                <PropertyField
                  id={`${id}_Value_${generateUniqueId()}`}
                  name="Value"
                  // label="Value"
                  //paramObj={item}
                  //labelBtn1={true}
                  //labelBtn2={true}
                  //dropdown={item.paramType === "V"}
                  /*labelBtn1OnClick={(paramName, changeToValue) =>
                    changeValueTypeToVorC(
                      paramName,
                      changeToValue,
                      index,
                      "Parameters"
                    )
                  }
                  labelBtn2OnClick={(paramName, changeToValue) =>
                    changeValueTypeToVorC(
                      paramName,
                      changeToValue,
                      index,
                      "Parameters"
                    )
                  }
                  value={item.value}
                  //options={getOptionsForVariable({ paramObjectTypeId: 1 })}
                  onChange={(e) => handleParamsValueChange(e, index)}
                />
              </Grid>
              <Grid item>
                <UniqueIDGenerator>
                  <DeleteIcon
                    className={classes.deleteBtn}
                    style={{ marginBottom: "5px", cursor: "pointer" }}
                    onClick={() => handleParamDelete(index)}
                    tabIndex={0}
                    onKeyPress={(e) =>
                      e.key === "Enter" && handleParamDelete(index)
                    }
                    role="button"
                    aria-label="Delete"
                    id={`${id}_DeleteIcon_${generateUniqueId()}`}
                  />
                </UniqueIDGenerator>
              </Grid>
            </Grid>
          </Grid>
        ))*/}
        <Grid item>
          <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', }}>
            <Grid container direction='column' spacing={1}>
              <Grid item>
                <Typography className={classes.GroupTitle}>Parameter(s)</Typography>
              </Grid>

              {arrParams.map((item, index) => (
                <Grid item key={index}>
                  <Grid container spacing={3} alignItems="flex-end">
                    <Grid item >
                      <PropertyField
                        rootWidth='315px'
                        id={`${id}_Key_${generateUniqueId()}`}
                        name="Key"
                        label="Key"
                        value={item.key}
                        onChange={(e) => handleParamsValueChange(e, index)}
                        readOnly={item.readOnly}

                      />
                    </Grid>
                    <Grid item >
                      <PropertyField
                        rootWidth='315px'
                        id={`${id}_Value_${generateUniqueId()}`}
                        name="Value"
                        label="Value"
                        value={item.value}
                        onChange={(e) => handleParamsValueChange(e, index)}
                        readOnly={item.readOnly}

                      // options={getOptionsForVariable({ paramObjectTypeId: 1 })}
                      />
                    </Grid>
                    {!item.readOnly && (
                      <Grid item >

                        <IconButton
                          id={`_DeleteIcon_${generateUniqueId()}`}
                          onClick={() => handleParamDelete(index)}
                          aria-label="Delete"
                          style={{ marginTop: '-20px' }}
                        >
                          <CloseIcon
                          //className={classes.deleteCrossIcon}
                          />
                        </IconButton>

                      </Grid>
                    )}
                  </Grid>
                </Grid>
              ))}
              <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                <Grid container spacing={1}
                  onClick={() => addParameters()}
                  onKeyPress={(e) =>
                    e.key === "Enter" && addParameters()
                  }
                  tabIndex={0}

                  role="button"
                  aria-label="Add Parameter"
                >
                  <Grid item>

                    <AddIcon
                      className={classes.addColumnBtn}

                    />
                  </Grid>
                  <Grid item>
                    <Typography className={classes.tertiary_add_btn_title}>
                      Add
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>

            </Grid>
          </div>
        </Grid>

        <Grid item>
          {isProcessing ? (
            <Button
              variant="contained"
              color="primary"
              className={classes.focusPrimary}
              disableRipple
            >
              <CircularProgress
                // color="#FFFFFF"
                variant="indeterminate"
                style={{
                  height: "20px",
                  width: "20px",
                  marginRight: "8px",
                  color: "#FFFFFF"
                }}
              ></CircularProgress>
              <Typography className={classes.btn_title}>Test</Typography>
            </Button>
          ) : (
            <Button
              variant="contained"
              color="primary"
              onClick={() => handleTestApi()}
              className={classes.focusPrimary}
              disableRipple
              id={`${id}_TestBtn`}
            >
              <Typography className={classes.btn_title}>Test</Typography>
            </Button>
          )}
        </Grid>
      </Grid>
    </div>
  );
};
const getParamStr = (arrayOfParams = []) => {
  let paramStr = "";

  arrayOfParams.forEach((item, index) => {
    if (index === 0) {
      paramStr = `?${item.key}=${item.value}`;
    } else {
      paramStr = paramStr + `&${item.key}=${item.value}`;
    }
  });
  return paramStr;
};
const RestResTab = ({
  id,
  endpoint,
  methods,
  statusCode,
  result,
  handleResTabChange,
  selTabRes,
  arrParams,
  arrHeaders,
  authField,
  consumerKeyField,
  consumerSecretField,
  oAuth1TokenField,
  oAuth1TokenSecretField,
}) => {
  const classes = useStyles();

  const getParamUrl = () => {
    let newArrParams = [...arrParams];
    if (authField === "OAuth1") {
      newArrParams = [
        ...newArrParams,
        { key: "oauth_consumer_key", value: consumerKeyField },
        { key: "oauth_consumer_secret", value: consumerSecretField },
        { key: "oauth_token", value: oAuth1TokenField },
        { key: "oauth_token_secret", value: oAuth1TokenSecretField },
      ];
    }

    return getParamStr(newArrParams);
  };
  const newHeaderObj = arrHeaders.reduce(
    (obj, item) => Object.assign(obj, { [item.key]: item.value }),
    {}
  );

  return (
    <div style={{ marginTop: "15px" }}>
      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Typography className={classes.tabs} style={{ fontWeight: 600 }}>
            Request Info:
          </Typography>
        </Grid>
        <Grid item container spacing={1}>
          <Grid item>
            <Typography className={classes.tabs}>Request Url:</Typography>
          </Grid>
          <Grid item>
            <Typography>{endpoint + getParamUrl()}</Typography>
          </Grid>
        </Grid>
        <Grid item container spacing={1}>
          <Grid item>
            <Typography className={classes.tabs}>Request Method:</Typography>
          </Grid>
          <Grid item>
            <Typography>{methods.toLowerCase()}</Typography>
          </Grid>
        </Grid>
        <Grid item container spacing={1}>
          <Grid item>
            <Typography className={classes.tabs}>Status Code:</Typography>
          </Grid>
          <Grid item>
            <Typography>{statusCode}</Typography>
          </Grid>
        </Grid>
        <Grid
          item
          container
          style={{ marginBottom: "-32px", zIndex: 1 }}
          role="tablist"
        >
          {resTabs.map((item, index) => (
            <Grid
              item
              key={index}
              onClick={() => handleResTabChange(item)}
              tabIndex={0}
              onKeyPress={(e) => e.key === "Enter" && handleResTabChange(item)}
              role="tab"
              aria-selected={selTabRes === item}
              id={`${id}_${item}`}
            >
              <Typography
                className={
                  selTabRes === item ? classes.selBtn : classes.simpleBtn
                }
              >
                {item}
              </Typography>
            </Grid>
          ))}
        </Grid>
        <Grid
          item
          style={{
            height: "300px",
            paddingTop: "15px",
            marginLeft: '10px',
            width: "90%",
            overflowY: "scroll",
            border: "1px solid #d5d5d5",
          }}
        >
          {selTabRes === "Preview Response" ? (
            result?.headers &&
              result["headers"]["content-type"] &&
              result["headers"]["content-type"].startsWith("image/") ? (
              <img
                style={{ width: "200px", height: "200px" }}
                src={result?.config?.url}
                alt="responseImage"
              />
            ) : (
              <pre>{result && JSON.stringify(result, null, 2)}</pre>
            )
          ) : selTabRes === "Raw Body" ? (
            <div style={{ paddingTop: "15px" }}>{JSON.stringify(result)}</div>
          ) : (
            <div style={{ paddingTop: "15px" }}>
              {result?.config && (
                <Grid container direction="column" spacing={1}>
                  <Grid item>
                    <span style={{ fontWeight: 700 }}>Request Url</span> :{" "}
                    <span>{result.config.url}</span>
                  </Grid>
                </Grid>
              )}
              {newHeaderObj && (
                <Grid container direction="column" spacing={1}>
                  <Grid item>
                    <Typography style={{ fontWeight: 700 }}>
                      Request Headers:
                    </Typography>
                  </Grid>
                  {Object.keys(newHeaderObj).map((key, i) => (
                    <Grid item style={{ marginLeft: "5px" }} key={i}>
                      <span style={{ fontWeight: 700 }}>{key}</span> :{" "}
                      <span>{newHeaderObj[key]}</span>
                    </Grid>
                  ))}
                </Grid>
              )}
              <Grid
                container
                direction="column"
                spacing={1}
                style={{ marginTop: "10px" }}
              >
                <Grid item>
                  <Typography style={{ fontWeight: 700 }}>
                    Response Headers:
                  </Typography>
                </Grid>
                {result.headers &&
                  Object.keys(result.headers).map((key, i) => (
                    <Grid item style={{ marginLeft: "5px" }} key={i}>
                      <span style={{ fontWeight: 700 }}>{key}</span> :{" "}
                      <span>{result.headers[key]}</span>
                    </Grid>
                  ))}
              </Grid>
              {result?.config?.data && (
                <Grid
                  container
                  direction="column"
                  style={{ marginTop: "10px" }}
                >
                  <Grid item>
                    <Typography style={{ fontWeight: 700 }}>
                      Request Payload:
                    </Typography>
                  </Grid>
                  <Grid item>
                    <pre>{result.config.data}</pre>
                  </Grid>
                </Grid>
              )}
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  );
};

const reqMethods = [
  { name: "GET", value: "GET" },
  { name: "POST", value: "POST" },
  { name: "PUT", value: "PUT" },
  { name: "DELETE", value: "DELETE" },
];
const authOps = [
  { name: "None", value: "None" },
  { name: "OAuth1", value: "OAuth1" },
  // { name: "OAuth2", value: "OAuth2" },
  { name: "Basic Auth", value: "Basic Auth" },
  { name: "Bearer Token", value: "Bearer Token" },
];
const acceptFormatOps = [
  { name: "JSON", value: "application/json" },
  { name: "XML", value: "application/xml" },
  { name: "HTML", value: "text/html" },
  { name: "Text", value: "text/plain" },
  { name: "Any", value: "*/*" },
];
const bodyFormatOps = [
  { name: "form-data", value: "multipart/form-data" },
  { name: "x-www-form-urlencoded", value: "x-www-form-urlencoded" },
  { name: "JSON", value: "application/json" },
  { name: "XML", value: "application/xml" },
  { name: "JavaScript", value: "application/javascript" },
  { name: "Text", value: "text/plain" },
  { name: "HTML", value: "text/html" },
];
const resTabs = ["Preview Response", "Raw Body", "Request Info"];
const fileFormatOptions1 = [{ name: 'File', value: "File" }, { name: "Text", value: "Text" }]
const fileFormatOptions2 = [{ name: "Text", value: "Text" }]
