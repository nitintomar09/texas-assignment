import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Email, ExpandMore, Remove } from "@mui/icons-material";
import { Grid, Typography, Avatar } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  getAllOptions,
  getAllVariables,
  getAllOptionsForGeneralIf,
} from "./../Common/CommonMethods";
import {
  setExpandPropWindow,
  setErrorType,
  setSelectedTab,
} from "../../../../../redux/actions";
import { AddIcon, CloseIcon } from "../../../../../utils/AllImages";
import MenuPopper from "../../../../../utils/MenuPopper";
import ModalForm from "../../../../../utils/modalForm";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { generateUniqueId } from "../../../../../utils/common";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";

const IfWindow = (props) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const expandedPropWindow = useSelector(
    (state) => state.editorHomepage.expandedPropWindow
  );

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const {
    selectedActivity,

    updateDisplayNameSelAct,
    addCondArrToSelAct,
  } = props;
  const { params } = selectedActivity;
  const [openModal, setOpenModal] = useState(false);

  const optForMail = [
    { name: "SenderName", value: "SenderName", variableObjType: 1 },
    { name: "CC", value: "CC", variableObjType: 1 },
    { name: "BCC", value: "BCC", variableObjType: 1 },
    { name: "Subject", value: "Subject", variableObjType: 1 },
    { name: "ReceivingDate", value: "ReceivingDate", variableObjType: 9 },
  ];
  const [conditionArray, setCondtionArray] = useState(
    selectedActivity.conditionArray || [
      {
        conditionID: 1,
        conditionType: 1,
        param1: "",
        paramType1: "V",
        operator: "",
        paramType2: "C",
        // param2: "",
        param2: null,
        expression: 0,
      },
    ]
  );

  const allOptions = getAllOptionsForGeneralIf();
  const allVariables = getAllVariables();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");

    setCondtionArray(
      selectedActivity.conditionArray || [
        {
          conditionID: 1,
          conditionType: 1,
          param1: "",
          paramType1: "V",
          operator: "",
          paramType2: "C",
          //param2: "",
          param2: null,

          expression: 0,
        },
      ]
    );
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateConditions();
  }, [conditionArray]);

  const handleExpandPropWindow = () => {
    dispatch(setExpandPropWindow(!expandedPropWindow));
  };
  const handleClose = () => {
    setOpenModal(false);
  };
  const onClick1 = () => {
    handleClose();
  };
  const updateConditions = () => {
    addCondArrToSelAct(conditionArray);
  };

  const handleChange = (e, index) => {
    const item = conditionArray[index];
    const { name, value } = e.target;
    if (name === "ActivityName") {
      setActivityName(value);
      updateDisplayNameSelAct(value);
    } else if (name === "MakeLogsPrivate") {
      setInvisibleInLogs({
        ...invisibleInLogs,
        paramValue: !invisibleInLogs.paramValue,
      });
    }
    if (index !== undefined) {
      switch (name) {
        case "Operand1":
          item.param1 = value;

          break;

        case "Operand2":
          item.param2 = value;

          break;
        case "OperatorType":
          item.operator = value;
          //in these operators case we dont need value of second param
          if (["9", "10", "11"].includes(value)) {
            item.param2 = "";
          }
          break;
        default:
          break;
      }

      const newArr = [...conditionArray];
      newArr.splice(index, 1, item);
      setCondtionArray(newArr);
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue, index) => {
    switch (paramName) {
      case "Operand2":
        const item = conditionArray[index];
        item.paramType2 = changeToValue;
        item.param2 = "";
        const newArr = [...conditionArray];
        newArr.splice(index, 1, item);
        setCondtionArray(newArr);
        break;

      default:
        break;
    }
  };

  const removeCondition = () => {
    const newConditionArr = [...conditionArray];
    if (newConditionArr.length > 1) {
      let last = newConditionArr[conditionArray.length - 2];
      last.expression = 0;
      newConditionArr.splice(newConditionArr.length - 2, 2);

      setCondtionArray([...newConditionArr, last]);
    } else if (newConditionArr.length === 1) {
      setCondtionArray([]);
    }
  };

  const addNewCondition = () => {
    const newConditionArr = [...conditionArray];
    let last = conditionArray[conditionArray.length - 1];
    if (last) {
      last.expression = 1;
      newConditionArr.splice(newConditionArr.length - 1, 1);

      /*****************************************************************************************
       * @author asloob_ali BUG ID : 103485 Description : 103485 - - Control Flow: If Else\Repeat If : I m not able to change the cconditional operator after saving the script
       *  Reason:the property id of conditions on db and ui mismatched.
       * Resolution : fixed the issue by naming id property of condition array to conditionID..
       *  Date : 28/12/2021             ****************************************/
      const newCond = {
        conditionID: conditionArray.length + 1,
        conditionType: 1,
        param1: "",
        paramType1: "V",
        operator: "",
        paramType2: "C",
        param2: "",
        expression: 0,
      };
      setCondtionArray([...newConditionArr, last, newCond]);
    } else {
      const newCond = {
        conditionID: conditionArray.length + 1,
        conditionType: 1,
        param1: "",
        paramType1: "V",
        operator: "",
        paramType2: "C",
        param2: "",
        expression: 0,
      };
      setCondtionArray([newCond]);
    }
  };
  const getConditionType = (num) => {
    switch (num) {
      case 1:
        return "General";
      case 2:
        return "Mail";
      case 3:
        return "File";
      case 4:
        return "Folder";
    }
  };
  const getConditionTypeNum = (str) => {
    switch (str) {
      case "General":
        return 1;
      case "Mail":
        return 2;
      case "File":
        return 3;
      case "Folder":
        return 4;
      default:
        return 1;
    }
  };
  /*const handleCond = (e, item, selCond) => {
    const itemConIndex = conditionArray.findIndex(
      (con) => con.conditionID === selCond.conditionID
    );

    const itemCon = conditionArray[itemConIndex - 1];
    if (itemCon) {
      itemCon.expression = item === "OR" ? 2 : 1;
      const newArr = [...conditionArray];
      newArr.splice(itemConIndex - 1, 1, itemCon);
      setCondtionArray(newArr);
    }
  };*/
  const handleCond = (e, index) => {

    const { value } = e.target;
    const itemCon = conditionArray[index - 1];
    if (itemCon) {
      itemCon.expression = value === "OR" ? 2 : 1;
      const newArr = [...conditionArray];
      newArr.splice(index - 1, 1, itemCon);
      setCondtionArray(newArr);
    }
  };
  /* const handleCondType = (e, item, selCond) => {
     const itemCon = conditionArray.find(
       (con) => con.conditionID === selCond.conditionID
     );
     const itemConIndex = conditionArray.findIndex(
       (con) => con.conditionID === selCond.conditionID
     );
     if (itemCon) {
       itemCon.conditionType = getConditionTypeNum(item);
       itemCon.param1 = "";
       const newArr = [...conditionArray];
       newArr.splice(itemConIndex, 1, itemCon);
       setCondtionArray(newArr);
     }
   };*/
  const handleCondType = (e, index) => {
    const { value } = e.target;
    const itemCon = conditionArray[index];
    if (itemCon) {
      itemCon.conditionType = getConditionTypeNum(value);
      itemCon.param1 = "";
      const newArr = [...conditionArray];
      newArr.splice(index, 1, itemCon);
      setCondtionArray(newArr);
    }
  };

  const getOperatorsOptions = (cond) => {
    const param1 = cond.param1;
    if (param1) {
      const varObj =
        cond.conditionType === 2
          ? optForMail.find((variable) => variable.name === param1)
          : allVariables.find((variable) => variable.variableName === param1);
      const varType = varObj?.variableObjType;
      switch (varType) {
        case 1:
          return allOperators.filter((opr) =>
            availableOperators["textValue"].includes(opr.value)
          );
        case 2:
        case 8:
          return allOperators.filter((opr) =>
            availableOperators["integerValue"].includes(opr.value)
          );
        case 3:
          return allOperators.filter((opr) =>
            availableOperators["booleanValue"].includes(opr.value)
          );
        case 4:
        case 9:
          return allOperators.filter((opr) =>
            availableOperators["dateTime"].includes(opr.value)
          );
      }
    }
  };

  const getOptionsForVar = (cond) => {
    const param1 = cond.param1;
    if (param1) {
      const varObj =
        cond.conditionType === 2
          ? optForMail.find((variable) => variable.name === param1)
          : allVariables.find((variable) => variable.variableName === param1);
      const varType = varObj?.variableObjType;
      if (varType) {
        return allVariables
          .filter((obj) => obj.variableObjType === varType)
          .map((item) => {
            return { name: item.variableName, value: item.variableName };
          });
      } else {
        return [];
      }
    }
  };
  const getVarType = (cond) => {
    const param1 = cond?.param1;
    let varType = null;

    if (param1) {
      const varObj =
        cond.conditionType === 2
          ? optForMail.find((variable) => variable.name === param1)
          : allVariables.find((variable) => variable.variableName === param1);
      varType = varObj?.variableObjType;
    }
    return varType;
  };
  const getFieldType = (cond) => {
    const param1 = cond.param1;
    let fieldType = "text";
    if (param1) {
      const varObj =
        cond.conditionType === 2
          ? optForMail.find((variable) => variable.name === param1)
          : allVariables.find((variable) => variable.variableName === param1);
      const varType = varObj?.variableObjType;

      switch (varType) {
        case 2:
        case 8:
          fieldType = "number";
          break;
        case 4:
          fieldType = "date";
          break;
        case 9:
          fieldType = "datetime-local";
          break;
        default:
          break;
      }
    }
    return fieldType;
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        selectedActivity={selectedActivity}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={
          selectedActivity.description || selectedActivity.activityId === 79
            ? "This activity loops throgh a block of code as long as condition is true"
            : "apply condition"
        }
      />

      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={1}>
              <Grid item container>
                {/*<Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    If
                  </Typography>
        </Grid>*/}
                <Grid
                  item
                  style={{ marginLeft: "auto", cursor: "pointer", marginBottom: '12px' }}
                  onClick={() => setOpenModal(true)}
                  tabIndex={0}
                  onKeyPress={(e) => e.key === "Enter" && setOpenModal(true)}
                  role="button"
                  id={`${props.id}_SeeCndSummaryBtn`}
                >
                  <Typography className={classes.textColorPrimary}>
                    See Condition Summary
                  </Typography>
                </Grid>
              </Grid>
              {/* <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  {`{`}
                </Typography>
        </Grid>*/}
              {conditionArray.map((cond, index) => {
                return (
                  <React.Fragment key={index}>
                    {/*index > 0 ? (
                      <Grid item container alignItems="center">
                        <Grid item>
                          <Typography
                            component="h5"
                            className={classes.GroupTitle}
                          >
                            {conditionArray[index - 1]?.expression === 1
                              ? "AND"
                              : "OR"}
                          </Typography>
                        </Grid>
                        <Grid item style={{ marginTop: "10px" }}>
                          <MenuPopper
                            id={`${props.id}_MenuPopper_${generateUniqueId()}`}
                            MenuIcon={ExpandMore}
                            selfClicked={cond}
                            handleSelectedItem={handleCond}
                            items={["AND", "OR"]}
                          />
                        </Grid>
                      </Grid>
                    ) : null*/}
                    {index > 0 ? (

                      <Grid item xs={12}>
                        <PropertyField
                          id={`${props.id}_${generateUniqueId()}`}
                          width={310}
                          //combo={true}
                          height={32}
                          dropdown={true}
                          name="AndOrCondition"

                          value={conditionArray[index - 1]?.expression === 1
                            ? "AND"
                            : "OR"}
                          options={
                            andOrOROptions || []
                          }
                          onChange={(e) => handleCond(e, index)}
                        />
                      </Grid>

                    ) : null}
                    <div style={{ border: '1px solid #D3D3D3', padding: '8px', borderRadius: '4px', width: '310px', marginBottom: '12px', marginTop: '12px' }}>
                      <Grid container direction='column' spacing={1}>
                        <Grid item>

                          <Grid item container alignItems="center" spacing={1}>
                            {index === conditionArray.length - 1 && <Grid item xs={12}>
                              <Grid container alignItems='flex-end'>

                                <Grid item style={{ marginLeft: "auto" }}>

                                  <UniqueIDGenerator>
                                    <CloseIcon
                                      id={`${props.id
                                        }_RemoveCndBtn_${generateUniqueId()}`}
                                      className={classes.deleteCrossIcon}
                                      onClick={() => removeCondition()}
                                      tabIndex={0}
                                      onKeyPress={(e) => e.key === "Enter" && removeCondition()}
                                      role="button"
                                      aria-label="Delete"
                                    // style={{ marginBottom: '-8px' }}
                                    />
                                  </UniqueIDGenerator>



                                </Grid>
                              </Grid>
                            </Grid>}
                            <Grid item xs={12}>
                              <PropertyField
                                id={`${props.id}_${generateUniqueId()}`}
                                width={310}
                                // combo={true}
                                height={32}
                                dropdown={true}
                                name="ConditionType"
                                label="Condition Type"

                                value={getConditionType(cond?.conditionType || 1)}
                                options={
                                  conditionTypeOptions || []
                                }
                                onChange={(e) => handleCondType(e, index)}
                              />
                            </Grid>
                            {/*<Grid item>
                        <Typography
                          component="h5"
                          className={classes.GroupTitle}
                        >
                          {getConditionType(cond?.conditionType || 1)}
                        </Typography>
                      </Grid>
                      <Grid item style={{ marginTop: "10px", zIndex: 1 }}>
                        <MenuPopper
                          id={`${props.id}_MenuPopper_${generateUniqueId()}`}
                          MenuIcon={ExpandMore}
                          selfClicked={cond}
                          handleSelectedItem={handleCondType}
                          // items={["General", "Mail", "File", "Folder"]}
                          items={["General", "Mail"]}
                        />
                                                          </Grid>*/}
                          </Grid>
                          <Grid
                            item
                            container
                            direction="row"
                            spacing={2}
                            alignItems="flex-start"
                            style={{
                              marginTop: expandedPropWindow ? "-30px" : "-10px",
                            }}
                          >
                            <Grid item xs={8}>
                              <PropertyField
                                id={`${props.id}_${cond.param1
                                  }_${generateUniqueId()}`}
                                width={200}
                                combo={true}
                                dropdown={true}
                                name="Operand1"
                                label="Variable Name"
                                value={cond.param1}
                                options={
                                  cond.conditionType === 2
                                    ? optForMail
                                    : allOptions || []
                                }
                                onChange={(e) => handleChange(e, index)}
                              />
                            </Grid>
                            <Grid item xs={4}>
                              <PropertyField
                                id={`${props.id}_${cond.operator
                                  }_${generateUniqueId()}`}
                                // combo={true}
                                dropdown={true}
                                name="OperatorType"
                                label="Operator"
                                value={cond.operator}
                                onChange={(e) => handleChange(e, index)}
                                options={getOperatorsOptions(cond) || []}
                                height={28}
                              //  width={230}

                              />
                            </Grid>
                            {cond.operator == "9" ||
                              cond.operator == "10" ||
                              cond.operator == "11" ? null : (
                              <Grid item xs={expandedPropWindow ? 4 : 12}>
                                <PropertyField
                                  id={`${props.id}_${cond.param2
                                    }_${generateUniqueId()}`}
                                  combo={true}
                                  dropdown={true}
                                  canType={true}
                                  type={getFieldType(cond)}
                                  labelBtn1={true}
                                  labelBtn2={true}
                                  paramObj={{ paramType: cond.paramType2 }}
                                  labelBtn1OnClick={(paramName, changeToValue) =>
                                    changeParamTypeToVorC(
                                      paramName,
                                      changeToValue,
                                      index
                                    )
                                  }
                                  labelBtn2OnClick={(paramName, changeToValue) =>
                                    changeParamTypeToVorC(
                                      paramName,
                                      changeToValue,
                                      index
                                    )
                                  }
                                  name="Operand2"
                                  label={expandedPropWindow ? "" : "Value"}
                                  value={cond.param2}
                                  onChange={(e) => handleChange(e, index)}
                                  varType={getVarType(cond)}
                                  options={getOptionsForVar(cond) || []}
                                  error={
                                    vaildateParamValue(cond?.param2.toString() || "")
                                      .errorStatus
                                  }
                                  helperText={
                                    vaildateParamValue(cond?.param2.toString() || "")
                                      .msg
                                  }
                                  width={320}
                                />
                              </Grid>

                            )}
                          </Grid>
                        </Grid>
                      </Grid>
                    </div>
                    {/*index === conditionArray.length - 1 ? (
                      <Grid item>
                        <Typography
                          component="h5"
                          className={classes.GroupTitle}
                        >
                          {`}`}
                        </Typography>
                      </Grid>
                    ) : null*/}
                  </React.Fragment>
                );
              })}

              <Grid item container>
                {/*<Grid item>
                  <Grid
                    container
                    spacing={1}
                    onClick={() => addNewCondition()}
                    tabIndex={0}
                    onKeyPress={(e) => e.key === "Enter" && addNewCondition()}
                    role="button"
                    id={`${props.id}_AddNewCndBtn`}
                  >
                    <Grid item>
                      <Avatar variant="circular" className={classes.addIcon}>
                        <AddIcon
                          style={{
                            height: "16px",
                            width: "16px",
                            color: "#0072C6",
                          }}
                        />
                      </Avatar>
                    </Grid>
                    <Grid item>
                      <Typography style={{ color: "#0072C6" }}>
                        Add Condition
                      </Typography>
                    </Grid>
                  </Grid>
                        </Grid>*/}

                <Grid item xs={4} style={{ marginLeft: 'auto', cursor: 'pointer' }}>
                  <Grid container 
                    onClick={() => addNewCondition()}
                    onKeyPress={(e) =>
                      e.key === "Enter" && addNewCondition()
                    }
                    tabIndex={0}

                    role="button"
                    aria-label="Add"
                  >
                    <Grid item>
                      <AddIcon
                        className={classes.addColumnBtn}

                      />
                    </Grid>
                    <Grid item>
                      <Typography className={classes.tertiary_add_btn_title}>
                        Add Condition
                      </Typography>
                    </Grid>
                  </Grid>
                </Grid>
                {/*<Grid item style={{ marginLeft: "auto" }}>
                  <Grid
                    container
                    spacing={1}
                    onClick={() => removeCondition()}
                    tabIndex={0}
                    onKeyPress={(e) => e.key === "Enter" && removeCondition()}
                    role="button"
                    id={`${props.id}_RemoveCndBtn`}
                  >
                    <Grid item>
                      <Avatar variant="circular" className={classes.removeIcon}>
                        <Remove
                          style={{
                            height: "16px",
                            width: "16px",
                            color: "#FF0000",
                          }}
                        />
                      </Avatar>
                    </Grid>
                    <Grid item>
                      <Typography style={{ color: "#FF0000" }}>
                        Remove
                      </Typography>
                    </Grid>
                  </Grid>
                        </Grid>*/}
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
      <ModalForm
        id={props.id}
        isOpen={openModal}
        title="Condition Summary"
        Content={
          <ConditionModal
            conditionArray={conditionArray}
            getConditionType={getConditionType}
          />
        }
        btn1Title="Close"
        onClick1={onClick1}
        closeModal={handleClose}
        containerHeight={533}
        containerWidth={633}
      />
    </div>
  );
};

export default IfWindow;
const ConditionModal = ({ conditionArray, getConditionType }) => {
  const classes = useStyles();
  const getOperatorName = (num) => {
    const oprtr = allOperators.find((item) => item.value === +num);
    if (oprtr) {
      return oprtr.strName;
    }
    return "";
  };
  return (
    <div style={{ padding: "20px" }}>
      <Grid container direction="column" spacing={2}>
        {conditionArray.map((cond, i) => (
          <Grid item container key={cond.conditionID} spacing={2}>
            <Grid item>
              <Typography style={{ fontWeight: 700 }}>
                {i === 0
                  ? "If"
                  : i > 0 && conditionArray[i - 1].expression === 2
                    ? "OR"
                    : "AND"}
              </Typography>
            </Grid>
            <Grid item>
              <Typography>
                in {getConditionType(cond.conditionType)}{" "}
                <span
                  className={classes.textColorPrimary}
                  style={{ padding: "4px" }}
                >
                  {cond.param1}
                </span>{" "}
                <span style={{ padding: "4px" }}>
                  {getOperatorName(cond.operator)}
                </span>{" "}
                <span style={{ padding: "4px" }}>
                  {cond.paramType2 === "C" ? `"${cond.param2}"` : cond.param2}
                </span>
              </Typography>
            </Grid>
          </Grid>
        ))}
      </Grid>
    </div>
  );
};
const allOperators = [
  { name: "==(Equals)", value: 1, strName: "Equals" },
  { name: ">", value: 2, strName: "GreaterThan" },
  { name: ">=", value: 3, strName: "GreaterThanOrEqual" },
  { name: "<", value: 4, strName: "LessThan" },
  { name: "<=", value: 5, strName: "LessThanOrEqual" },
  { name: "!=", value: 6, strName: "NotEqual" },
  // { name: "EqualsIgnoreCase", value: 7, strName: "EqualsIgnoreCase" },
  { name: "Contains", value: 8, strName: "Contains" },
  { name: "isNull", value: 9, strName: "isNull" },
  { name: "isNotNull", value: 10, strName: "isNotNull" },
  { name: "isEmpty", value: 11, strName: "isEmpty" },
  { name: "Before", value: 12, strName: "Before" },
  { name: "After", value: 13, strName: "After" },
];

const availableOperators = {
  integerValue: [1, 2, 3, 4, 5, 6],
  // floatValue: [1, 2, 3, 4, 5, 6],
  textValue: [1, 7, 9, 10, 11, 6],
  dateTime: [12, 13, 1, 6, 9, 10],
  booleanValue: [1, 6, 9, 10],
};
const andOrOROptions = [
  { name: "AND", value: "AND" },
  { name: "OR", value: "OR" }
]
const conditionTypeOptions = [{ "name": "General", "value": "General" }, { "name": "Mail", "value": "Mail" }]
/**
 * 1- Equals(==)  
2- GreaterThan(>)
3- GreaterThanOrEqual(>=)
4- LessThan(<)
5- LessThanOrEqual(<=)
6- NotEqual(!=)

 


If =>Text

 

1- Equals(==)
7- EqualsIgnoreCase
8- Contains
9- isNull
10- isNotNull
11- isEmpty
6- NotEquals(!=)

 


If=>Date/DateTime
12- Before
13- After
1- Equals(==)
6- NotEquals(!=)
14- isNull
15- isNotNull
 */
