import React, { useState, useEffect } from "react";
import PropertyField from "../../PropertyFields/PropertyField";
import { Repeat } from "@mui/icons-material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
} from "../Common/CommonMethods";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonOutput from "../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ForEachWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [item, setItem] = useState(
    mapFieldObjWithValueByName(params, "Item", "")
  );
  const [inVar, setInVar] = useState(
    mapFieldObjWithValueByName(params, "In", "")
  );
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setItem(mapFieldObjWithValueByName(params, "Item", ""));
    setInVar(mapFieldObjWithValueByName(params, "In", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, inVar, item]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, inVar, item];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "Item":
        setItem((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "IN":
        setInVar((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "Item":
        setItem({ ...item, paramType: changeToValue });
        break;

      case "IN":
        setInVar({ ...inVar, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        selectedActivity={selectedActivity}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Repeat}
        helperText={selectedActivity.description || "For each item"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <PropertyField
              id={`${props.id}_${item.paramValue}`}
              combo={true}
              labelBtn1={true}
              labelBtn2={true}
              dropdown={item.paramType === "V"}
              paramObj={item}
              labelBtn1OnClick={changeParamTypeToVorC}
              labelBtn2OnClick={changeParamTypeToVorC}
              name="Item"
              label="Item"
              value={item.paramValue}
              options={getOptionsForVariable(item)}
              onChange={handleChange}
              error={vaildateParamValue(item.paramValue.toString()).errorStatus}
              helperText={vaildateParamValue(item.paramValue.toString()).msg}
            />
            <PropertyField
              id={`${props.id}_${inVar.paramValue}`}
              combo={true}
              labelBtn1={true}
              labelBtn2={true}
              dropdown={inVar.paramType === "V"}
              paramObj={inVar}
              labelBtn1OnClick={changeParamTypeToVorC}
              labelBtn2OnClick={changeParamTypeToVorC}
              name="IN"
              label="In"
              value={inVar.paramValue}
              options={getOptionsForVariable(inVar)}
              onChange={handleChange}
              error={
                vaildateParamValue(inVar.paramValue.toString()).errorStatus
              }
              helperText={vaildateParamValue(inVar.paramValue.toString()).msg}
            />
          </>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ForEachWindow;
