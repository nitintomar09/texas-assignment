import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
} from "./../Common/CommonMethods";
import ErrorsWindow from "../Common/ErrorsWindow";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "./../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const RepeatWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [count, setCount] = useState(
    mapFieldObjWithValueByName(params, "RepeatCount", "")
  );

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setCount(mapFieldObjWithValueByName(params, "RepeatCount", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [count, invisibleInLogs]);

  const updateParams = () => {
    let allParams = [count, invisibleInLogs];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "RepeatCount":
        setCount((prevState) => ({ ...prevState, paramValue: value }));
        break;

      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "RepeatCount":
        setCount({ ...count, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        selectedActivity={selectedActivity}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          "Repeat a set of activities given number of times"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_${count.paramValue}`}
                combo={true}
                type="number"
                dropdown={count.paramType === "V"}
                paramObj={count}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                labelBtn1={true}
                labelBtn2={true}
                name="RepeatCount"
                label="Repeat Count"
                value={count.paramValue}
                options={getOptionsForVariable(count)}
                onChange={handleChange}
                error={
                  vaildateParamValue(count.paramValue.toString()).errorStatus
                }
                helperText={vaildateParamValue(count.paramValue.toString()).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : null}
      </div>
    </div>
  );
};

export default RepeatWindow;
