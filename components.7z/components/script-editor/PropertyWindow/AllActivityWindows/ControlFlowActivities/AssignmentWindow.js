import React, {
  useState,
  useEffect,
  Fragment,
  useRef,
  useContext,
} from "react";
import { useSelector, useDispatch } from "react-redux";
import PropertyField from "../../PropertyFields/PropertyField";
import { WebAsset, ExpandLess, ChevronRight } from "@mui/icons-material";
import { Grid, TextField, Typography, List, ListItem } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { VariablesContext } from "../../../../../contexts/VariablesListContext";
import {
  logsState,
  mapFieldObjWithValueByName,
  mapFieldObjWithValueByName2,
  getAllOptions,
  makeOptionsFromVariables,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import {
  AddIcon,
  AddVariableIcon,
  EditIcon,
} from "../../../../../utils/AllImages";
import ModalForm from "../../../../../utils/modalForm";
import SearchBox from "../../../../../utils/Search-Component";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";

const AssignmentWindow = (props) => {
  const classes = useStyles();
  const { t } = useTranslation()
  const expressionRef = useRef(null);
  const { value } = useContext(VariablesContext);
  const { allVariables } = value;
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const variablesFunctionsList = useSelector(
    (state) => state.propertyWindow.variablesFunctionsList
  );
  const [searchedFunctionList, setSearchFunctionList] = useState(
    variablesFunctionsList ? { ...variablesFunctionsList } : {}
  );
  const [searchedVars, setSearchVars] = useState(getAllOptions() || []);
  const dispatch = useDispatch();
  const allOptions = getAllOptions();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const [openModal, setOpenModal] = useState(false);

  const [param1, setParam1] = useState(
    mapFieldObjWithValueByName(params, "Param1", "")
  );
  const [param2, setParam2] = useState(
    mapFieldObjWithValueByName2(params, "Param2", "")
  );

  const [expressionVal, setExpressionVal] = useState("");
  const [cursorPositionStart, setCursorPositionStart] = useState(0);
  const [cursorPositionEnd, setCursorPositionEnd] = useState(0);
  const [lastAddedFunction, setLastAddedFunction] = useState(null);
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setParam1(mapFieldObjWithValueByName(params, "Param1", ""));
    setParam2(mapFieldObjWithValueByName2(params, "Param2", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, param2, param1]);

  useEffect(() => {
    setSearchVars(makeOptionsFromVariables(allVariables));
  }, [allVariables]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, param2, param1];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;

    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "Param2":
        setParam2((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Param1":
        setParam1((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ExpressionValue":
        setExpressionVal(value);

        break;
      default:
        break;
    }
  };

  const handleOpenAssignmentModal = () => {
    if (param2.paramValue) {
      setExpressionVal(param2.paramValue);
    } else {
      setExpressionVal("");
    }
    setOpenModal(true);
  };
  const handleClose = () => {
    setOpenModal(false);
  };
  const onClick1 = () => {
    console.log("close clicked");
    handleClose();
    setExpressionVal("");
  };
  const onClick2 = () => {
    console.log("SAVE clicked");
    if (expressionVal) {
      setParam2({ ...param2, paramValue: expressionVal });
    }
    handleClose();
  };

  const highlightSelectedArea = () => {
    if (lastAddedFunction && expressionRef?.current) {
    }
  };
  /*****************************************************************************************
   * @author asloob_ali BUG ID : 103494  Description : 103494  - Control Flow: Assignment: In Expression Editor Window search is not working and UI is wrong
   *  Reason:Date functionality was not implemented.
   * Resolution : implemented search functionality for variables as well as for functions.
   *  Date : 27/12/2021             ****************/
  const handleSearchChange = (sText, type) => {
    if (type === "Functions") {
      if (variablesFunctionsList) {
        const varFuncList = {};
        Object.keys(variablesFunctionsList).forEach((key) => {
          if (key.toLowerCase().includes(sText.toLowerCase())) {
            varFuncList[key] = variablesFunctionsList[key];
          } else if (variablesFunctionsList[key]) {
            const arrOfFuncList = variablesFunctionsList[key].filter((item) =>
              item?.functionDisplayName
                .toLowerCase()
                .includes(sText.toLowerCase())
            );
            if (arrOfFuncList.length > 0) {
              varFuncList[key] = arrOfFuncList;
            }
          }
        });
        setSearchFunctionList(varFuncList);
      }
    } else if (type === "Variables") {
      const newVars = allOptions?.filter((item) =>
        item?.name.toLowerCase().includes(sText.toLowerCase())
      );
      setSearchVars(newVars);
    }
  };

  const addTextToCusorPosition = (textToBeAdded) => {
    const currentExpression = expressionVal.split("");

    if (expressionVal.length > 0) {
      if (
        cursorPositionStart === cursorPositionEnd &&
        cursorPositionStart !== 0
      ) {
        currentExpression.splice(cursorPositionStart, 0, textToBeAdded);
        setExpressionVal(currentExpression.join(""));
      } else if (
        cursorPositionStart === 0 &&
        cursorPositionStart === cursorPositionEnd
      ) {
        currentExpression.splice(currentExpression.length, 0, textToBeAdded);
        setExpressionVal(currentExpression.join(""));
      } else {
        const selItemsLength = cursorPositionEnd - cursorPositionStart;
        currentExpression.splice(
          cursorPositionStart,
          selItemsLength,
          textToBeAdded
        );
        setExpressionVal(currentExpression.join(""));
      }
    } else {
      setExpressionVal(textToBeAdded);
    }
    highlightSelectedArea();
  };
  const handleSelVar = (variableName) => {
    const newExpression = "${" + `${variableName}` + "}";
    addTextToCusorPosition(newExpression);
  };

  const handelClickedFunction = (item) => {
    setLastAddedFunction(item.functionName);
    let newText = "";
    if (expressionVal.length > 0) {
      if (
        expressionVal.charAt(expressionVal.length - 1) === "." ||
        (cursorPositionStart !== 0 &&
          expressionVal.charAt(cursorPositionStart - 1) === ".")
      ) {
        newText = `${item.functionName}`;
      } else {
        newText = "." + `${item.functionName}`;
      }
    } else {
      newText = `${item.functionName}`;
    }

    addTextToCusorPosition(newText);
  };
  const handleOnFocus = (e) => {
    console.log(e);
  };
  const handleOnSelect = (e) => {
    setCursorPositionStart(e.target.selectionStart || 0);
    setCursorPositionEnd(e.target.selectionEnd || 0);
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        selectedActivity={selectedActivity}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          t("Assign value of an expression or constant to a variable")
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                {t("INPUT")}
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_${param1.paramValue}`}
                combo={true}
                dropdown={true}
                paramObj={param1}
                btnIcon={
                  <UniqueIDGenerator>
                    <AddVariableIcon
                      className={classes.btnIcon + " " + classes.colorPrimary}
                    />
                  </UniqueIDGenerator>
                }
                name="Param1"
                label={t("Assigning variable")}
                value={param1.paramValue}
                onChange={handleChange}
                options={allOptions || []}
                error={
                  vaildateParamValue(param1.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(param1.paramValue.toString()).msg
                }
              />
            </Grid>

            <Grid item>
              <PropertyField
                //dropdown={param2.paramType === "V"}
                //labelBtn1={true}
                //labelBtn2={true}
                // paramObj={param2}
                //labelBtn1OnClick={changeParamTypeToVorC}
                //labelBtn2OnClick={changeParamTypeToVorC}
                id={`${props.id}_${param2.paramValue}`}
                combo={true}
                name="Param2"
                label={t("Assigned value")}
                value={param2.paramValue}
                endAdornment={
                  <Grid
                    container
                    spacing={1}
                    justifyContent="flex-end"
                    style={{ marginLeft: "auto" }}
                  >
                    <Grid item>
                      <Typography className={classes.addBtn}>
                        <AddIcon />
                      </Typography>
                    </Grid>
                    <Grid item >
                      <Typography className={classes.editBtn} >
                        <UniqueIDGenerator>
                          <EditIcon
                            id={`${props.id}_EditIcon`}
                            onClick={() => handleOpenAssignmentModal()}
                            className={classes.focusVisible}
                            tabIndex={0}
                            onKeyPress={(e) =>
                              e.key === "Enter" && handleOpenAssignmentModal()
                            }
                            role="button"
                            aria-label="Edit"
                            style={{marginInlineEnd:'-5px'}}
                          />
                        </UniqueIDGenerator>
                      </Typography>
                    </Grid>
                  </Grid>
                }
                readOnly={true}
                onChange={handleChange}
                //helperText={`For operators you can write +,-,*,/,( and ). you can write shorthand using "$<variable-name>$".Functions can be invoked by '.'(Dot symbol).`}
                /* options={getOptionsForVariable(
                  allVariables.find(
                    (item) => item.variableName === param1.paramValue
                  )
                )}*/
                error={
                  vaildateParamValue(param2.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(param2.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
      <ModalForm
        id={props.id}
        isOpen={openModal}
        handleChange={handleChange}
        Content={
          <AssignmentModal
            id={props.id}
            param2={param2}
            param1={param1}
            ref={expressionRef}
            handleChange={handleChange}
            handleSearchChange={handleSearchChange}
            handelClickedFunction={handelClickedFunction}
            handleSelVar={handleSelVar}
            expressionVal={expressionVal}
            variablesFunctionsList={searchedFunctionList}
            allAvailableVars={searchedVars}
            handleOnFocus={handleOnFocus}
            handleOnSelect={handleOnSelect}
          />
        }
        btn1Title={t("Close")}
        onClick1={onClick1}
        btn2Title={t("Save")}
        onClick2={onClick2}
        closeModal={handleClose}
        containerHeight={533}
        containerWidth={633}
      />
    </div>
  );
};

export default AssignmentWindow;
const AssignmentModal = React.forwardRef(
  (
    {
      param1,
      handleChange,
      handleSearchChange,
      handleSelVar,
      handelClickedFunction,
      expressionVal,
      variablesFunctionsList,
      allAvailableVars,
      handleOnFocus,
      handleOnSelect,
      id,
    },
    ref
  ) => {
    const classes = useStyles();
    const { t } = useTranslation()
    const [openedListGroup, setOpenedListGroup] = useState([]);
    // const [openedList, setOpenedList] = useState(null);

    const handleOpenListGroup = (groupName) => {
      const newOpenListGroup = [...openedListGroup];
      const index = newOpenListGroup.findIndex((item) => item === groupName);
      if (index !== -1) {
        newOpenListGroup.splice(index, 1);
      } else {
        newOpenListGroup.push(groupName);
      }
      setOpenedListGroup(newOpenListGroup);
      /*  if (groupName === openedList) {
      setOpenedList(null);
    } else {
      setOpenedList(groupName);
    }*/
    };
    return (
      <div style={{ marginTop: "25px" }}>
        <Grid container direction="column" spacing={1}>
          <Grid item container>
            <Grid item>
              <Typography className={classes.label1}>
                {t("Expression Editor Window")}
              </Typography>
            </Grid>
            <Grid item style={{ marginLeft: "auto" }}>
              <span style={{ marginRight: "4px" }}>{t("Type:")}</span>
              <span style={{ color: "#007206" }}>{t("String")}</span>
            </Grid>
          </Grid>
          <Grid item xs>
            <TextField
              id={id}
              type={"text"}
              // error={props.error}
              // helperText={props.helperText}
              size="small"
              multiline={true}
              rows={4}
              fullWidth={true}
              onSelect={handleOnSelect}
              // onFocus={handleOnFocus}
              // label="Expression Editor Window"
              //  name="Param2"
              name="ExpressionValue"
              InputProps={{
                className: classes.multilineInput,
                spellCheck: false,
              }}
              // InputLabelProps={{ className: classes.label1 }}
              // value={param2.paramValue}
              ref={ref}
              value={expressionVal}
              onChange={handleChange}
              variant="outlined"
              placeholder={t("Write down the expression here..")}
            ></TextField>
          </Grid>
        </Grid>
        <Grid
          container
          direction="column"
          //spacing={1}
          style={{ marginTop: "12px" }}
        >
          <Grid item>
            <Typography className={classes.label}>{t("Operators")}</Typography>
          </Grid>
          <Grid item>
            <Typography>( )</Typography>
          </Grid>
        </Grid>
        <Grid container style={{ marginTop: "25px" }}>
          <Grid item xs={6}>
            <Grid container direction="column">
              <Grid item>
                <Typography className={classes.label}>{t("Functions")}</Typography>
              </Grid>
              <Grid item>
                <Typography style={{ fontSize: "10px", color: "#606060" }}>
                  {t(`Write functions by typing "."`)}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={6}>
            <Grid container direction="column">
              <Grid item>
                <Typography className={classes.label}>
                  {t("Variables (including constants)")}
                </Typography>
              </Grid>
              <Grid item>
                <Typography style={{ fontSize: "10px", color: "#606060" }}>
                  {t(`Write variables by typing "$"`)}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid container style={{ marginTop: "12px" }} spacing={1}>
          <Grid item xs={6}>
            <div
              style={{
                height: "200px",
                border: "2px solid #d5d5d5",
                padding: "5px",
              }}
            >
              <Grid container direction="column" spacing={1}>
                <Grid item>
                  <SearchBox
                    id={`${id}_Func_SearchBox`}
                    onSearchChange={(sText) =>
                      handleSearchChange(sText, "Functions")
                    }
                    width="275px"
                    placeholder={t("Search Functions")}
                    name="AvailableFunctions"
                  />
                </Grid>
                {/*<Grid
                item
                style={
                  {
                    //maxHeight: "300px",
                    // overflowY: "scroll",
                  }
                }
              >
                  <List
        component="nav"
        aria-labelledby="function-list"
        //className={classes.root}
      >
        {variablesFunctionsList && Object.keys(variablesFunctionsList).map((varKey,index) => (
          <React.Fragment
            key={index}
          >
            <VarFunctionList
              varKey={varKey}
              openedListGroup={openedListGroup}
              handleOpenListGroup={handleOpenListGroup}
              
            />
            <Divider variant="fullWidth" />
          </React.Fragment>
        ))
        </List>
        </Grid>*/}
              </Grid>

              <VarFunctionList
                id={id}
                variablesFunctionsList={variablesFunctionsList}
                openedListGroup={openedListGroup}
                handleOpenListGroup={handleOpenListGroup}
                //  openedList={openedList}
                handelClickedFunction={handelClickedFunction}
              />
            </div>
          </Grid>
          <Grid item xs={6}>
            <div
              style={{
                height: "200px",
                border: "2px solid #d5d5d5",
                padding: "5px",
              }}
            >
              <Grid container direction="column" spacing={1}>
                <Grid item>
                  <SearchBox
                    id={`${id}_Variables_SearchBox`}
                    onSearchChange={(sText) =>
                      handleSearchChange(sText, "Variables")
                    }
                    width="275px"
                    placeholder="Search Variables"
                    name="AvailableVariables"
                  />
                </Grid>
                <Grid item>
                  <div
                    style={{
                      overflowY: "scroll",
                      maxHeight: "150px",
                      overflowX: "hidden",
                    }}
                  >
                    {allAvailableVars.map((item, index) => (
                      <Grid
                        item
                        container
                        spacing={1}
                        alignItems="flex-end"
                        key={index}
                        tabIndex={0}
                        onKeyPress={(e) =>
                          e.key === "Enter" && handleSelVar(item.name)
                        }
                        role="button"
                        aria-label={item.name}
                        id={`${id}_${item.name}_Btn`}
                        style={{
                          margin: "2px",
                          width: "95%",
                          cursor: "pointer",
                        }}
                      >
                        <Grid item>{index + 1}.</Grid>
                        <Grid item>
                          <Typography
                            style={{ fontWeight: 700, cursor: "pointer" }}
                            onClick={() => handleSelVar(item.name)}
                            id={`${id}_${item.name}_Text`}
                          >
                            {truncateString({
                              str: item.name,
                              max: 35,
                              min: 30,
                            })}
                          </Typography>
                        </Grid>
                      </Grid>
                    ))}
                  </div>
                </Grid>
              </Grid>
            </div>
          </Grid>
        </Grid>
      </div>
    );
  }
);
const truncateString = ({ str, max, min }) => {
  return str.trim().length > max ? str.substring(0, min) + ".." : str;
};
const VarFunctionList = ({
  variablesFunctionsList,
  openedListGroup,
  handleOpenListGroup,
  // openedList,
  handelClickedFunction,
  id,
}) => {
  //console.log(variablesFunctionsList);
  const classes = useStyles();

  return (
    variablesFunctionsList && (
      <List
        component="nav"
        aria-labelledby="function-list"
        className={classes.rootAssignment}
      >
        {Object.keys(variablesFunctionsList).map((varKey, index) => (
          <Fragment key={index}>
            <ListItem
              button
              onClick={() => {
                handleOpenListGroup(varKey);
              }}
              className={classes.list_item}
              id={`${id}_${index}`}
            >
              {openedListGroup && !openedListGroup.includes(`${varKey}`) ? (
                <ExpandLess className={classes.chevronIcon} />
              ) : (
                <ChevronRight className={classes.chevronIcon} />
              )}
              <Grid container alignItems="center" spacing={1}>
                <Grid item>
                  <Typography className={classes.listTitle}>
                    {varKey &&
                      truncateString({
                        str: varKey + " functions",
                        max: 25,
                        min: 20,
                      })}
                  </Typography>
                </Grid>
              </Grid>
            </ListItem>
            {openedListGroup && !openedListGroup.includes(`${varKey}`) ? (
              <Grid
                container
                direction="column"
                spacing={0}
                style={{ marginLeft: "50px", marginTop: "6px" }}
              >
                {variablesFunctionsList &&
                  variablesFunctionsList[varKey].map((item, i) => (
                    <Grid container direction="column" spacing={1} key={i}>
                      <Grid
                        item
                        onClick={() => handelClickedFunction(item)}
                        style={{ cursor: "pointer", width: "fit-content" }}
                        tabIndex={0}
                        onKeyPress={(e) =>
                          e.key === "Enter" && handelClickedFunction(item)
                        }
                        role="button"
                        aria-label={item.functionDisplayName || i}
                        id={`${id}_${item.functionDisplayName || i}`}
                      >
                        <Typography className={classes.listSubTitle}>
                          {item.functionDisplayName || ""}
                        </Typography>
                      </Grid>
                      <Grid item>
                        <Typography className={classes.helperText}>
                          {truncateString({
                            str: item.description || "",
                            max: 20,
                            min: 16,
                          })}
                        </Typography>
                      </Grid>
                    </Grid>
                  ))}
              </Grid>
            ) : null}
          </Fragment>
        ))}
      </List>
    )
  );
};
/**
  <div className={classes.scrollDiv}>
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid
              item
              container
              direction="row"
              spacing={2}
              alignItems="flex-end"
              style={{ marginTop: "-30px" }}
            >
              <Grid item xs={5}>
                <PropertyField
                  dropdown={true}
                  name="Param1"
                  value={param1.paramValue}
                  onChange={handleChange}
                  options={allOptions || []}
                />
              </Grid>
              <Grid item xs={2}>
                <Typography style={{ textAlign: "center", marginTop: "-24px" }}>
                  =
                </Typography>
              </Grid>
              <Grid item xs={5}>
                <PropertyField
                  dropdown={param2.paramType === "V"}
                  labelBtn1={true}
                  labelBtn2={true}
                  paramObj={param2}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="Param2"
                  value={param2.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(
                    allVariables.find(
                      (item) => item.variableName === param1.paramValue
                    )
                  )}
                />
              </Grid>
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
 */
