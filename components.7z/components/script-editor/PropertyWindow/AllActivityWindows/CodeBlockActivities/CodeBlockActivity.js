import React, { useState, useRef, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography, Radio, Button, IconButton, LinearProgress } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
    logsState,
    getOptionsForVariable,
    mapFieldObjWithValueByName,
    getVariableTypeById,
} from "./../Common/CommonMethods";
import { AddVariableIcon, ErrorHandlingIcon, FolderBrowseIcon, PopoutIcon } from "../../../../../utils/AllImages";
import { useDispatch, useSelector } from "react-redux";
import {
    setSelectedTab,
    setErrorType,
    setCSVFilePath,
} from "./../../../../../redux/actions";
import {CB_CRETAE_PROJECT} from "../../../../../config/index";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonOutput from "./../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import ModalForm from "../../../../../utils/modalForm";
import { createInstance, getToken, getUser, handleNetworkRequestError, openCodeEditorInNewTab } from "../../../../../utils/common";
import LoadingIndicator from "../../../../../utils/loadingIndicator";
import { useContext } from "react";
import { NotificationContext } from "../../../../../contexts/NotificationContext";
import { useHistory } from "react-router-dom/cjs/react-router-dom";
const CodeBlockWindow = (props) => {
    const classes = useStyles();
    const user = getUser();
    const authToken = getToken();
    const scriptValues = useSelector((state) => state.script.openScriptDetails);
    
    const { versionId, scriptId, versionName, scriptName } = scriptValues;

    const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct,id } =
        props;
    const { params } = selectedActivity;

    const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
    const dispatch = useDispatch();
    const [activityName, setActivityName] = useState(
        (selectedActivity && selectedActivity.displayName) || ""
    );
    const [invisibleInLogs, setInvisibleInLogs] = useState(
        logsState(params, false)
    );

    // const [gitRepoPath, setGitRepoPath] = useState(
    //     mapFieldObjWithValueByName(params, "RemoteRepositoryPath", "")
    // );
    // const [workspaceType, setWorkspaceType] = useState(
    //     mapFieldObjWithValueByName(params, "WorkspaceType", "Server Workspace")
    // );
    // const [workspacePath, setWorkspacePath] = useState(
    //     mapFieldObjWithValueByName(params, "WorkspacePath", "")
    // );
    // const [className, setRemoteRepoType] = useState(
    //     mapFieldObjWithValueByName(params, "RemoteRepositoryType", "Github")
    // );
    const [className, setClassName]=useState(mapFieldObjWithValueByName(params, "ClassName", ""));
    const [methodName, setMethodName]=useState(mapFieldObjWithValueByName(params, "MethodName", ""));
    const [isLoading,setIsLoading]=useState(false);

    const [output, setOutput] = useState(
        mapFieldObjWithValueByName(params, "Output", "")
    );

     const { setValue } = useContext(NotificationContext);
     const history = useHistory();
    //const [setSe]
    /* const [authType, setAuthType] = useState(
         mapFieldObjWithValueByName(params, "AuthenticationType", "")
     );
     const [username, setUsername] = useState(
         mapFieldObjWithValueByName(params, "Username", "")
     );
     const [password, setPassword] = useState(
         mapFieldObjWithValueByName(params, "Password", "")
     );
     const [token, setToken] = useState(
         mapFieldObjWithValueByName(params, "Token", "")
     );*/

    /* const [selAuthType, setSelectedAuthType] = useState("");
     const radioButtonsArray = [
         { label: "User Credentials", value: "User Credentials" },
         { label: "Token", value: "Token" },
     ];
     const [openSettings, setOpenSettings] = useState(false);*/

    // const radioButtonsArrayRemoteRepoType = [
    //     { label: "Github", value: "Github" },
    //     { label: "Gitlab", value: "Gitlab" },
    //     { label: "Bitbucket", value: "Bitbucket" },

    // ];
    // const RemoteRepoTypeOptions = [
    //     { name: "Github", value: "Github" },
    //     { name: "Gitlab", value: "Gitlab" },
    //     { name: "Bitbucket", value: "Bitbucket" },

    // ];
    // const radioButtonsArrayRepoType = [
    //     { label: "Server Workspace", value: "Server Workspace" },
    //     { label: "Local Workspace", value: "Local Workspace" },
    //     // { label: "Remote Repository", value: "Remote Repository" },
    // ];
    useEffect(() => {
        setActivityName(selectedActivity ? selectedActivity.displayName : "");
        setInvisibleInLogs(logsState(params, false));
        // const repoPath = mapFieldObjWithValueByName(params, "RemoteRepositoryPath", "");
        // setGitRepoPath(repoPath);
        // const workspaceTypeValue = mapFieldObjWithValueByName(params, "WorkspaceType", "Server Workspace")
        // setWorkspaceType(workspaceTypeValue);
        // const workspacePathValue = mapFieldObjWithValueByName(params, "WorkspacePath", "")
        // setWorkspacePath(workspacePathValue);
        // const remoteRepoTypeValue = mapFieldObjWithValueByName(params, "RemoteRepositoryType", "Github")
        // setRemoteRepoType(remoteRepoTypeValue);
        const classN=mapFieldObjWithValueByName(params, "ClassName", "");
        setClassName(classN);
        const methodN=mapFieldObjWithValueByName(params, "MethodName", "");
        setMethodName(methodN)

        setOutput(mapFieldObjWithValueByName(params, "Output", ""));
        dispatch(setErrorType("Throw"));
        dispatch(setSelectedTab("input"));
    }, [selectedActivity]);

    useEffect(() => {
        updateParams();
    }, [
        invisibleInLogs,
        //gitRepoPath,
        //workspaceType,
        //workspacePath,
        className,
        methodName,
        output
    ]);

    const updateParams = () => {
        if(className.paramValue==""){
            const generatedClass=generateCodeBlockName(scriptName);
            setClassName((prevState) => ({ ...prevState, paramValue: generatedClass }));
        }
        if(methodName.paramValue==""){
            //const formattedServiceFlowName = scriptName.charAt(0).toUpperCase() + scriptName.slice(1).toLowerCase();
            const generatedMain=generateCodeBlockName(scriptName);
            setMethodName((prevState)=>({...prevState, paramValue:generatedMain.toLocaleLowerCase()+"_Main"}));
        }
       
        const allParams = [
            invisibleInLogs,
            //gitRepoPath,
            //workspaceType,
            //workspacePath,
            className,
            methodName,
            output

        ];
        addParamsToSelAct(allParams);
    };


    /* const handleClose = () => {
         setOpenSettings(false)
     }
     const handleCancel = () => {
         console.log('cancel')
     }
     const handleSave = () => {
         console.log('save')
     }*/
    const handleChange = (e) => {
        const { name, value } = e.target;
        // handleOpenDirectory();
        switch (name) {
            case "ActivityName":
                setActivityName(value);
                updateDisplayNameSelAct(value);
                break;
            case "MakeLogsPrivate":
                setInvisibleInLogs({
                    ...invisibleInLogs,
                    paramValue: !invisibleInLogs.paramValue,
                });
                break;
            // case "RemoteRepositoryPath":
            //     setGitRepoPath((prevState) => ({ ...prevState, paramValue: value }));
            //     break;
            // case "RepositoryType":
            //     setRemoteRepoType((prevState) => ({ ...prevState, paramValue: value }));
            //     setGitRepoPath((prevState) => ({ ...prevState, paramValue: "" }));
            //     break;
            // case "WorkspaceType":
            //     // setSelectedAuthType(value);
            //     setWorkspaceType((prevState) => ({ ...prevState, paramValue: value }));
            //     setWorkspacePath((prevState) => ({ ...prevState, paramValue: "" }));
            //     break;
            case "ClassName":
                setClassName((prevState)=>({ ...prevState,paramValue:value}));
                break;
            case "MethodName":
                setMethodName((prevState)=>({ ...prevState,paramValue:value}));
                break;
            case "Output":
                setOutput((prevState) => ({ ...prevState, paramValue: value }));
                break;
            // case "WorkspacePath":
            //     // setSelectedAuthType(value);
            //     setWorkspacePath((prevState) => ({ ...prevState, paramValue: value }));
            //     break;
            default:
                break;
        }
    };

    const validateClassMethods=(className, methodName)=>{
        
            const classNameRegex = /^[A-Z][a-zA-Z0-9_]*$/; // Class name validation
            const methodNameRegex = /^[a-z][a-zA-Z0-9_]*$/; // Method name validation
        
            if (className.trim() === "" || methodName.trim() === "") {
                alert("ClassName and MethodName are required!");
                return false;
            }
        
            if (!classNameRegex.test(className)) {
                alert("Invalid ClassName! It must start with an uppercase letter and contain only letters, numbers, or underscores.");
                return false;
            }
        
            if (!methodNameRegex.test(methodName)) {
                alert("Invalid MethodName! It must start with a lowercase letter and contain only letters, numbers, or underscores.");
                return false;
            }
        
            return true;
    }

    function generateCodeBlockName(serviceFlowName) {
        //const formattedServiceFlowName = serviceFlowName.charAt(0).toUpperCase() + serviceFlowName.slice(1).toLowerCase();
        //const uniqueId = Date.now();
        const uniqueId = id.match(/_\d+/);
        const codeBlockName = `SFCodeBlock${uniqueId}`;
        const validName = codeBlockName.replace(/[^a-zA-Z0-9]/g, '');
        return validName;
    }

    const projectCreationIfNotExist = (payload) => {
        const axiosInstance = createInstance();
        debugger
        axiosInstance.post(`${CB_CRETAE_PROJECT}`, {
            activityId: selectedActivity.activityId,
            codeBlockName: scriptName +id.match(/CodeBlock_\d+/),
            serviceFlowId: scriptId,
            serviceFlowName: scriptName,
            versionId: versionId,
            versionName:versionName,
            className: className.paramValue,
            entryFunction: methodName.paramValue,
            userName:user[0].authUser.userLoginId
           
        })
        .then((res) => {
            if (res.status === 200) {
                console.log("Project already exists and created.");
                openCodeEditorInNewTab({ scriptId, versionName, token: authToken, user, isCodeEditor: true, className, methodName, scriptName })
        
            }
            if (res.status === 201) {
                console.log("Project created successfully.");
                openCodeEditorInNewTab({ scriptId, versionName, token: authToken, user, isCodeEditor: true, className, methodName, scriptName })
        
            }
        })
        .catch((error) => {
            debugger
            handleNetworkRequestError({
                      error,
                      history,
                      onError: (errMsg) => {
                        setValue({
                          isOpen: true,
                          message: errMsg || "",
                          title: "",
                          notificationType: "ERROR",
                        });
                      },
                    });
            //alert("Some issue occurred.");
        })
        .finally(() => {
            setIsLoading(false);
        });
    };
    
    const handleLaunchCodeEditor = () => {
        const isValid= validateClassMethods(className.paramValue,methodName.paramValue);
        if(isValid){
            setIsLoading(true)
            projectCreationIfNotExist({ scriptId, versionName, token: authToken, user, isCodeEditor: true, className, methodName });
           }
    }
    const changeParamTypeToVorC = (paramName, changeToValue) => {
        switch (paramName) {
            case "ClassName":
                setClassName((prevState) => ({ ...prevState, paramType: changeToValue }));
                break;
            case "MethodName":
                setMethodName((prevState) => ({ ...prevState, paramType: changeToValue }));
                break;
            default:
                break;
        }
    };
    /*  const handleOpenDirectory = async () => {
  
          async function readDirectory() {
              const dirHandle = await showDirectoryPicker();
  
              // Function to recursively read a directory
              async function readFiles(dirHandle) {
                  for await (const [name, handle] of dirHandle) {
                      if (handle.kind === 'file') {
                          console.log(`File: ${name}`);
                          // const file = await handle.getFile();
                          //  console.log(await file.text()); // To read file content
                      } else if (handle.kind === 'directory') {
                          console.log(`Directory: ${name}`);
                          await readFiles(handle); // Recursive call to read subdirectory
                      }
                  }
              }
  
              await readFiles(dirHandle);
          }
          readDirectory();
  
  
          async function readDirectoryWithPath() {
              const dirHandle = await showDirectoryPicker();
  
              // Recursive function to get the full path of each file
              async function traverseDirectory(dirHandle, path = '') {
                  for await (const [name, handle] of dirHandle) {
                      const fullPath = `${path}/${name}`;
                      if (handle.kind === 'file') {
                          console.log(`File: ${fullPath}`);
                      } else if (handle.kind === 'directory') {
                          console.log(`Directory: ${fullPath}`);
                          await traverseDirectory(handle, fullPath); // Recurse into subdirectory
                      }
                  }
              }
  
              await traverseDirectory(dirHandle);
          }
  
          readDirectoryWithPath();
  
      }*/
    return (
        <div>
            <CommonFields
                id={props.id}
                ScopeActivity={selectedActivity.activityType === "S"}
                selectedActivity={selectedActivity}
                activityName={activityName}
                handleChange={handleChange}
                makeLogsPrivate={invisibleInLogs.paramValue}
                ActivityIcon={WebAsset}
                helperText={selectedActivity.description || "Handles Code Module"}
            />
            <div
                className={classes.scrollDiv + " " + classes.focusVisible}
                tabIndex={0}
            >
                {selectedTab === "input" ? (
                    <>
                        <Grid container direction="column" spacing={1}>
                            
                            <Grid item>
                                <Typography component="h5" className={classes.GroupTitle}>
                                    INPUT
                                </Typography>
                            </Grid>
                            <Grid item>
                            <PropertyField
                                    id={`${props.id}_CodeBlockClass`}
                                    combo={true}
                                    paramObj={className}
                                    labelBtn1OnClick={changeParamTypeToVorC}
                                    labelBtn2OnClick={changeParamTypeToVorC}
                                    //dropdown={true}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    dropdown={className.paramType === "V"}
                                    name="ClassName"
                                    label="Class Name"
                                    value={className.paramValue}
                                    //options={RemoteRepoTypeOptions}
                                    onChange={handleChange}
                                    options={getOptionsForVariable(className)}
                                    error={vaildateParamValue(className.paramValue).errorStatus}
                                    helperText={vaildateParamValue(className.paramValue).msg}
                                />
                            </Grid>
                            <Grid item>
                            <PropertyField
                                    id={`${props.id}_CodeBlockFunction`}
                                    combo={true}
                                    paramObj={methodName}
                                    labelBtn1OnClick={changeParamTypeToVorC}
                                    labelBtn2OnClick={changeParamTypeToVorC}
                                    //dropdown={true}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    dropdown={methodName.paramType === "V"}
                                    name="MethodName"
                                    label="Entry Method Name"
                                    value={methodName.paramValue}
                                    //options={RemoteRepoTypeOptions}
                                    options={getOptionsForVariable(methodName)}
                                    onChange={handleChange}
                                    error={vaildateParamValue(methodName.paramValue).errorStatus}
                                    helperText={vaildateParamValue(methodName.paramValue).msg}
                                />
                            </Grid>
                            <Grid item>
                            <PropertyField
                                    id={`${props.id}_CodeBlockObject`}
                                    disabled={true}
                                    //combo={true}
                                    //paramObj={methodName}
                                    //labelBtn1OnClick={changeParamTypeToVorC}
                                    //labelBtn2OnClick={changeParamTypeToVorC}
                                    //dropdown={true}
                                    //labelBtn1={true}
                                    //labelBtn2={true}
                                    //dropdown={methodName.paramType === "V"}
                                    name="ServiceFlowObject"
                                    label="ServiceFlow Object"
                                    value={"SFObject"}
                                    //options={RemoteRepoTypeOptions}
                                    //options={getOptionsForVariable(methodName)}
                                    //onChange={handleChange}
                                    //error={vaildateParamValue(methodName.paramValue).errorStatus}
                                    //helperText={vaildateParamValue(methodName.paramValue).msg}
                                />
                            </Grid>
                            <Grid item>
                                <Grid item container direction='column' justifyContent={"flex-start"}>
                                    <Grid item >
                                        <Button
                                        variant="outlined"
                                        color="primary"
                                        onClick={() => handleLaunchCodeEditor()}
                                        disableFocusRipple
                                        // className={classes.focusPrimary}
                                        id={`${props.id}_LaunchWizardBtn`}
                                        
                                        >
                                           <PopoutIcon />
                                            <Typography sx={{ marginLeft: '8px', color: '#0072C6' }}>
                                                Open Code Editor
                                            </Typography>
                                        </Button>
                                    </Grid>
                                    <Grid item>
                                        {isLoading? <LoadingIndicator/>:null}
                                    </Grid>
                                </Grid>
                            </Grid>
                            {/* <Grid item>
                                <PropertyField
                                    id={`${props.id}_RemoteRepoType`}
                                    radio={true}
                                    ButtonsArray={radioButtonsArrayRepoType}
                                    name="WorkspaceType"
                                    label="Workspace Type"
                                    value={workspaceType.paramValue}
                                    onChange={handleChange}
                                    column={true}
                                />
                            </Grid> */}
                            {/* {workspaceType.paramValue === 'Server Workspace' && <Grid item>
                                <PropertyField
                                    id={`${props.id}_ServerWorkspace`}
                                    combo={true}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    disabled={true}
                                    readonly={true}
                                    // dropdown={gitRepoPath.paramType === "V"}
                                    //paramObj={gitRepoPath}
                                    //labelBtn1OnClick={changeParamTypeToVorC}
                                    //labelBtn2OnClick={changeParamTypeToVorC}
                                    //btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                                    name="ServerWorkspace"
                                    label="Workspace path"
                                    value={"/serviceflow/workspace"}
                                    onChange={handleChange}

                                />
                            </Grid>}
                            {workspaceType.paramValue === 'Local Workspace' &&


                                <Grid item>
                                    <PropertyField
                                        id={`${props.id}_LocalWorkspace`}
                                        combo={true}
                                        labelBtn1={true}
                                        labelBtn2={true}
                                        //dropdown={workspacePath.paramType === "V"}
                                        paramObj={workspacePath}
                                        labelBtn1OnClick={changeParamTypeToVorC}
                                        labelBtn2OnClick={changeParamTypeToVorC}
                                        value={workspacePath.paramValue}
                                        options={getOptionsForVariable(workspacePath)}
                                        onChange={handleChange}
                                        error={
                                            vaildateParamValue(workspacePath.paramValue.toString())
                                                .errorStatus
                                        }
                                        helperText={
                                            vaildateParamValue(workspacePath.paramValue.toString()).msg
                                        }
                                        name="WorkspacePath"
                                        label="Workspace path"
                                    />
                                </Grid>
                            } */}

                            {/* <Grid item>
                                <PropertyField
                                    id={`${props.id}_RemoteRepoType`}
                                    combo={true}
                                    //dropdown={true}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    name="RepositoryType"
                                    label="Repository"
                                    value={remoteRepoType.paramValue}
                                    options={RemoteRepoTypeOptions}
                                    onChange={handleChange}
                                    error={vaildateParamValue(remoteRepoType.paramValue).errorStatus}
                                    helperText={vaildateParamValue(remoteRepoType.paramValue).msg}
                                />
                            </Grid>
                            <Grid item>
                                <PropertyField
                                    id={`${props.id}_GitRepositoryPath`}
                                    combo={true}
                                    labelBtn1={true}
                                    labelBtn2={true}
                                    dropdown={gitRepoPath.paramType === "V"}
                                    paramObj={gitRepoPath}
                                    labelBtn1OnClick={changeParamTypeToVorC}
                                    labelBtn2OnClick={changeParamTypeToVorC}
                                    btnIcon={<FolderBrowseIcon className={classes.btnIcon} />}
                                    name="RemoteRepositoryPath"
                                    label="Repository Path"
                                    value={gitRepoPath.paramValue}
                                    options={getOptionsForVariable(gitRepoPath)}
                                    onChange={handleChange}
                                    error={
                                        vaildateParamValue(gitRepoPath.paramValue.toString())
                                            .errorStatus
                                    }
                                    helperText={
                                        vaildateParamValue(gitRepoPath.paramValue.toString()).msg
                                    }
                                />
                            </Grid> */}

                            {/*<Grid item >
                                <Grid container spacing={1} alignItems={'center'}>
                                    <Grid item>
                                        <PropertyField
                                            id={`${props.id}_AuthenticationType`}
                                            radio={true}
                                            ButtonsArray={radioButtonsArray}
                                            name="AuthenticationType"
                                            label="Authentication Type"
                                            value={selAuthType}
                                            onChange={handleChange}
                                        />
                                    </Grid>
                                    {selAuthType === "User Credentials" && (
                                        <>
                                            <Grid item >
                                                <PropertyField

                                                    id={`${props.id}_Username`}
                                                    name="Username"
                                                    label="Username"
                                                    combo={true}
                                                    labelBtn1={true}
                                                    labelBtn2={true}
                                                    dropdown={username.paramType === "V"}
                                                    paramObj={username}
                                                    labelBtn1OnClick={changeParamTypeToVorC}
                                                    labelBtn2OnClick={changeParamTypeToVorC}
                                                    value={username.paramValue}
                                                    options={getOptionsForVariable(username)}
                                                    onChange={handleChange}
                                                    error={
                                                        vaildateParamValue(username.paramValue.toString())
                                                            .errorStatus
                                                    }
                                                    helperText={
                                                        vaildateParamValue(username.paramValue.toString()).msg
                                                    }
                                                />
                                            </Grid>
                                            <Grid item >
                                                <PropertyField

                                                    id={`${props.id}_Password`}
                                                    name="Password"
                                                    label="Password"
                                                    combo={true}
                                                    labelBtn1={true}
                                                    labelBtn2={true}
                                                    dropdown={password.paramType === "V"}
                                                    paramObj={password}
                                                    labelBtn1OnClick={changeParamTypeToVorC}
                                                    labelBtn2OnClick={changeParamTypeToVorC}
                                                    value={password.paramValue}
                                                    options={getOptionsForVariable(password)}
                                                    onChange={handleChange}
                                                    error={
                                                        vaildateParamValue(password.paramValue.toString())
                                                            .errorStatus
                                                    }
                                                    helperText={
                                                        vaildateParamValue(password.paramValue.toString()).msg
                                                    }
                                                />

                                            </Grid>
                                        </>

                                    )}

                                    {selAuthType === "Token" && (

                                        <Grid item >
                                            <PropertyField

                                                id={`${props.id}_Token`}
                                                name="Token"
                                                label="Token"
                                                combo={true}
                                                labelBtn1={true}
                                                labelBtn2={true}
                                                dropdown={token.paramType === "V"}
                                                paramObj={token}
                                                labelBtn1OnClick={changeParamTypeToVorC}
                                                labelBtn2OnClick={changeParamTypeToVorC}
                                                value={token.paramValue}
                                                options={getOptionsForVariable(token)}
                                                onChange={handleChange}
                                                error={
                                                    vaildateParamValue(token.paramValue.toString())
                                                        .errorStatus
                                                }
                                                helperText={
                                                    vaildateParamValue(token.paramValue.toString()).msg
                                                }
                                            />
                                        </Grid>


                                    )}
                                </Grid>
                                </Grid>*/}
                        </Grid>
                        
                    </>
                ) : selectedTab === "output" ? (
                    <Grid container direction="column" spacing={2}>
                        <Grid item>
                            <Typography component="h5" className={classes.GroupTitle}>
                                OUTPUT
                            </Typography>
                        </Grid>
                        <Grid item>
                            <PropertyField
                                id={`${props.id}_Output`}
                                combo={true}
                                dropdown={true}
                                paramObj={output}
                                btnIcon={
                                    <AddVariableIcon
                                        className={classes.btnIcon + " " + classes.colorPrimary}
                                    />
                                }
                                name="Output"
                                label={`Output (${getVariableTypeById(
                                    output.paramObjectTypeId
                                )})`}
                                value={output.paramValue}
                                options={getOptionsForVariable(output)}
                                onChange={handleChange}
                                error={vaildateParamValue(output.paramValue).errorStatus}
                                helperText={vaildateParamValue(output.paramValue).msg}
                            />
                        </Grid>

                    </Grid>
                ) : selectedTab === "error" ? (
                    <ErrorsWindow />
                ) : null}
            </div>

            {/*<ModalForm
                id={`${props.id}`}
                isOpen={openSettings}
                handleChange={handleChange}
                title="Code Block Setting"
                Content={
                    <CodeBlockSettingsModal
                        id={`${props.id}_CodeBlockModal`}

                    />
                }
                headerCloseBtn={true}
                onClickHeaderCloseBtn={handleClose}
                btn1Title="Cancel"
                onClick1={handleCancel}
                btn2Title="Save"
                onClick2={handleSave}
                closeModal={handleClose}
                containerHeight={533}
                containerWidth={800}
            />*/}
        </div>
    );
};

export default CodeBlockWindow;

/*const CodeBlockSettingsModal = (props) => {
    const { id } = props;
    const classes = useStyles()
    const [repoType, setRepoType] = useState('Server Workspace');
    const [authType, setAuthType] = useState('User Credentials');
    const [gitRepoPath, setGitRepoPath] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [token, setToken] = useState('');

    const [serverWorkspace, setServerWorkspace] = useState('/ServiceFlow/Workspace');



    const radioButtonsArrayRepo = [
        { label: "Server Workspace", value: "Server Workspace" },
        { label: "Git Repository", value: "Git Repository" },
    ];
    const radioButtonsArrayAuth = [
        { label: "User Credentials", value: "User Credentials" },
        { label: "Token", value: "Token" },
    ];
    const handleChange = (e) => {
        const { name, value } = e.target;
        switch (name) {

            case "GitRepository":
                setGitRepoPath(value);
                break;
            case "AuthenticationType":
                setAuthType(value);
                break;
            case "RepositoryType":
                setRepoType(value);
                break;
              case "ServerWorkspace":
                  setServerWorkspace(value);
                  break;
            case "Username":
                setUsername(value);
                break;
            case "Password":
                setPassword(value);
                break;
            case "Token":
                setToken(value);
                break;
            default:
                break;
        }
    };
    const handleConnectGitApi = () => {
        console.log('Hello')
    }
    return (
        <div style={{ marginTop: "16px" }}>
            <Grid container direction="column" spacing={2}>
                <Grid item>
                    <PropertyField
                        id={`${id}_repoType`}
                        radio={true}
                        ButtonsArray={radioButtonsArrayRepo}
                        name="RepositoryType"
                        label="Repository Type"
                        value={repoType}
                        onChange={handleChange}
                    />
                </Grid>
                {repoType === 'Server Workspace' &&
                    <Grid item>
                        <PropertyField
                            id={`${id}_ServerWorkspace`}
                            name="ServerWorkspace"
                            label="Server Workspace"
                            value={serverWorkspace}
                            onChange={handleChange}
                        />
                    </Grid>}
                {repoType === 'Git Repository' &&
                    <>
                        <Grid item>
                            <PropertyField
                                id={`${id}_GitRepository`}
                                name="GitRepository"
                                label="Git Repository"
                                value={gitRepoPath}
                                onChange={handleChange}
                            />
                        </Grid>

                        <Grid item>
                            <PropertyField
                                id={`${id}_authType`}
                                radio={true}
                                ButtonsArray={radioButtonsArrayAuth}
                                name="AuthenticationType"
                                label="Authentication Type"
                                value={authType}
                                onChange={handleChange}
                            />
                        </Grid>
                        {authType === 'User Credentials' && <>

                            <Grid item>
                                <PropertyField
                                    id={`${id}_Username`}
                                    name="Username"
                                    label="Username"
                                    value={username}
                                    onChange={handleChange}
                                />
                            </Grid>
                            <Grid item>
                                <PropertyField
                                    id={`${id}_Password`}
                                    name="Password"
                                    label="Password"
                                    value={password}
                                    onChange={handleChange}
                                />
                            </Grid>


                        </>}

                        {authType === 'Token' &&

                            <Grid item>
                                <PropertyField
                                    id={`${id}_Token`}
                                    name="Token"
                                    label="Token"
                                    value={token}
                                    onChange={handleChange}
                                />
                            </Grid>
                        }

                        <Grid item>
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={() => handleConnectGitApi()}
                                className={classes.focusPrimary}
                                disableRipple
                                id={`${id}_TestBtn`}
                                disabled={!gitRepoPath}
                            >
                                <Typography className={classes.btn_title}>Connect</Typography>
                            </Button>
                        </Grid>
                    </>
                }
            </Grid>
        </div>

    );

}*/