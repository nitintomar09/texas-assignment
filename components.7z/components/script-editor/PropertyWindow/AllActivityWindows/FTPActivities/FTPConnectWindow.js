import React, { useState, useContext, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
} from "./../Common/CommonMethods";

import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonOutput from "./../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const FTPConnectWindow = (props) => {
  const classes = useStyles();

  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;

  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const radioButtonsArray = [
    { label: "FTP", value: "FTP" },
    { label: "FTPS", value: "FTPS" },
    { label: "SFTP", value: "SFTP" },
  ];

  const [typeValue, setTypeValue] = useState("FTP");
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [ftpURL, setFtpURL] = useState(
    mapFieldObjWithValueByName(params, "ftpUrl", "")
  );
  const [username, setUsername] = useState(
    mapFieldObjWithValueByName(params, "ftpUsername", "")
  );

  const [password, setPassword] = useState(
    mapFieldObjWithValueByName(params, "ftpPassword", "")
  );
  const [ftpPort, setFtpPort] = useState(
    mapFieldObjWithValueByName(params, "ftpPort", "")
  );

  const [ftpProtocol, setFtpProtocol] = useState(
    mapFieldObjWithValueByName(params, "ftpProtocol", "")
  );
  /* const [statusCode, setStatusCode] = useState(
    mapFieldObjWithValueByName(params, "StatusCode", "")
  );

  const [statusMessage, setStatusMessage] = useState(
    mapFieldObjWithValueByName(params, "StatusMessage", "")
  );

  const [isConnecting, setIsConnecting] = useState(false);*/
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));

    setPassword(mapFieldObjWithValueByName(params, "ftpPassword", ""));
    setFtpURL(mapFieldObjWithValueByName(params, "ftpUrl", ""));
    setUsername(mapFieldObjWithValueByName(params, "ftpUsername", ""));
    setFtpPort(mapFieldObjWithValueByName(params, "ftpPort", ""));
    setFtpProtocol(mapFieldObjWithValueByName(params, "ftpProtocol", ""));
    //setStatusCode(mapFieldObjWithValueByName(params, "StatusCode", ""));
    //setStatusMessage(mapFieldObjWithValueByName(params, "StatusMessage", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    if (ftpProtocol.paramValue) {
      setTypeValue(ftpProtocol.paramValue);
    }
  }, [ftpProtocol]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "ftpUrl":
        setFtpURL((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "ftpPort":
        setFtpPort((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ftpUsername":
        setUsername((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ftpPassword":
        setPassword((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Type":
        setTypeValue(value);
        setFtpProtocol((prevState) => ({ ...prevState, paramValue: value }));
        break;

      default:
        break;
    }
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    password,
    ftpURL,
    username,
    // statusCode,
    //statusMessage,
    ftpPort,
    ftpProtocol,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,

      password,
      ftpURL,
      username,
      //statusCode,
      //statusMessage,
      ftpPort,
      ftpProtocol,
    ];
    addParamsToSelAct(allParams);
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ftpUrl":
        setFtpURL({ ...ftpURL, paramType: changeToValue });
        break;
      case "ftpPort":
        setFtpPort({ ...ftpPort, paramType: changeToValue });
        break;
      case "ftpUsername":
        setUsername({ ...username, paramType: changeToValue });
        break;
      case "ftpPassword":
        setPassword({ ...password, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <>
      <CommonFields
        id={props.id}
        selectedActivity={selectedActivity}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || "Connect to a FTP Server"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_FTPProtocol`}
                radio={true}
                ButtonsArray={radioButtonsArray}
                name="Type"
                label="FTP Protocol"
                value={typeValue}
                onChange={handleChange}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_FTPUrl`}
                combo={true}
                dropdown={ftpURL.paramType === "V"}
                paramObj={ftpURL}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(ftpURL)}
                labelBtn1={true}
                labelBtn2={true}
                name="ftpUrl"
                label="FTP URL"
                value={ftpURL.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(ftpURL.paramValue).errorStatus}
                helperText={vaildateParamValue(ftpURL.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_FTPport`}
                combo={true}
                dropdown={ftpPort.paramType === "V"}
                paramObj={ftpPort}
                labelBtn1={true}
                labelBtn2={true}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="ftpPort"
                label="FTP Port"
                value={ftpPort.paramValue}
                options={getOptionsForVariable(ftpPort)}
                onChange={handleChange}
                //error={vaildateParamValue(ftpPort).errorStatus}
                //helperText={vaildateParamValue(ftpPort).msg}
              />
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_ftpUserName`}
                combo={true}
                dropdown={username.paramType === "V"}
                paramObj={username}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(username)}
                labelBtn1={true}
                labelBtn2={true}
                name="ftpUsername"
                label="FTP Username"
                value={username.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(username.paramValue).errorStatus}
                helperText={vaildateParamValue(username.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_ftpPass`}
                combo={true}
                dropdown={password.paramType === "V"}
                paramObj={password}
                secret={true}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(password)}
                labelBtn1={true}
                labelBtn2={true}
                name="ftpPassword"
                label="FTP Password"
                value={password.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(password.paramValue).errorStatus}
                helperText={vaildateParamValue(password.paramValue).msg}
              />
            </Grid>
            {/*<Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Process"
              label="Process"
              value={process}
              onChange={handleChange}
            />
          </Grid>
          <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              name="Queue"
              label="Queue"
              value={queue}
              onChange={handleChange}
            />
          </Grid>

            <Grid item>
              {isConnecting ? (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleConnect()}
                >
                  <CircularProgress
                    color="#FFFFFF"
                    style={{
                      height: "15px",
                      width: "15px",
                      marginRight: "8px",
                    }}
                  ></CircularProgress>{" "}
                  <Typography className={classes.btn_title}>
                    Connecting..
                  </Typography>
                </Button>
              ) : (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleConnect()}
                >
                  <Typography className={classes.btn_title}>Connect</Typography>
                </Button>
              )}
              </Grid>*/}
          </Grid>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : /* <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                dropdown={true}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                label="Status Code"
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                helperText="Select or add an int type variable"
              />
            </Grid>
            <Grid item>
              <PropertyField
                dropdown={true}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusMessage"
                label="Status Message"
                value={statusMessage.paramValue}
                options={getOptionsForVariable(statusMessage)}
                onChange={handleChange}
                helperText="Select or add a char type variable"
              />
            </Grid>
            
           
            </Grid>*/

        selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </>
  );
};

export default FTPConnectWindow;
