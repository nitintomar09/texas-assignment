import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const FTPMoveWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [remotePathFrom, setRemotePathFrom] = useState(
    mapFieldObjWithValueByName(params, "RemotePathFrom", "")
  );
  const [remotePathTo, setRemotePathTo] = useState(
    mapFieldObjWithValueByName(params, "RemotePathTo", "")
  );

  const [status, setStatus] = useState(
    mapFieldObjWithValueByName(params, "Status", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setRemotePathFrom(mapFieldObjWithValueByName(params, "RemotePathFrom", ""));
    setRemotePathTo(mapFieldObjWithValueByName(params, "RemotePathTo", ""));
    setStatus(mapFieldObjWithValueByName(params, "Status", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, remotePathFrom, remotePathTo, status]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, remotePathFrom, remotePathTo, status];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "RemotePathFrom":
        setRemotePathFrom((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "RemotePathTo":
        setRemotePathTo((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Status":
        setStatus((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "RemotePathFrom":
        setRemotePathFrom({ ...remotePathFrom, paramType: changeToValue });
        break;
      case "RemotePathTo":
        setRemotePathTo({ ...remotePathTo, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description ||
          "Move a Folder from a directory to other at FTP server."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_RemotePathFrom`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={remotePathFrom.paramType === "V"}
                paramObj={remotePathFrom}
                btnIcon={
                  <FolderOpen
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="RemotePathFrom"
                label="Remote Path From"
                value={remotePathFrom.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(remotePathFrom)}
                error={
                  vaildateParamValue(
                    remotePathFrom.paramValue
                      ? remotePathFrom.paramValue.toString()
                      : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    remotePathFrom.paramValue
                      ? remotePathFrom.paramValue.toString()
                      : ""
                  ).msg
                }
              />
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_RemotePathTo`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={remotePathTo.paramType === "V"}
                paramObj={remotePathTo}
                btnIcon={
                  <FolderOpen
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="RemotePathTo"
                label="Remote Path To"
                value={remotePathTo.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(remotePathTo)}
                error={
                  vaildateParamValue(
                    remotePathTo.paramValue
                      ? remotePathTo.paramValue.toString()
                      : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    remotePathTo.paramValue
                      ? remotePathTo.paramValue.toString()
                      : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Status`}
                combo={true}
                dropdown={true}
                paramObj={status}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Status"
                label={`Status (${getVariableTypeById(
                  status.paramObjectTypeId
                )})`}
                value={status.paramValue}
                options={getOptionsForVariable(status)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default FTPMoveWindow;
