import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const FTPDeleteWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [remotePath, setRemotePath] = useState(
    mapFieldObjWithValueByName(params, "RemotePath", "")
  );

  const [status, setStatus] = useState(
    mapFieldObjWithValueByName(params, "Status", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setRemotePath(mapFieldObjWithValueByName(params, "RemotePath", ""));
    setStatus(mapFieldObjWithValueByName(params, "Status", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, remotePath, status]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, remotePath, status];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "RemotePath":
        setRemotePath((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Status":
        setStatus((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "RemotePath":
        setRemotePath({ ...remotePath, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description || "Delete a Folder from FTP server."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_RemotePath`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={remotePath.paramType === "V"}
                paramObj={remotePath}
                btnIcon={
                  <FolderOpen
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="RemotePath"
                label="Remote Path "
                value={remotePath.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(remotePath)}
                error={
                  vaildateParamValue(
                    remotePath.paramValue
                      ? remotePath.paramValue.toString()
                      : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    remotePath.paramValue
                      ? remotePath.paramValue.toString()
                      : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Status`}
                combo={true}
                dropdown={true}
                paramObj={status}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Status"
                label={`Status (${getVariableTypeById(
                  status.paramObjectTypeId
                )})`}
                value={status.paramValue}
                options={getOptionsForVariable(status)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    status.paramValue ? status.paramValue.toString() : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default FTPDeleteWindow;
