import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const DeleteColumnWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  //const [tableName, setTableName] = useState("");
  const [columnName, setColumnName] = useState(
    mapFieldObjWithValueByName(params, "ColumnName", "")
  );
  const [deleteStatus, setDeleteStatus] = useState(
    mapFieldObjWithValueByName(params, "deleteStatus", "")
  );
  //const [sheetName, setSheetName] = useState("");

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    // setTableName(mapFieldObjWithValueByName(params, "TableName", ""));
    setColumnName(mapFieldObjWithValueByName(params, "ColumnName", ""));
    //setSheetName(mapFieldObjWithValueByName(params, "SheetName", ""));
    setDeleteStatus(mapFieldObjWithValueByName(params, "deleteStatus", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, columnName, deleteStatus]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, columnName, deleteStatus];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "ColumnName":
        setColumnName((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "deleteStatus":
        setDeleteStatus((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ColumnName":
        setColumnName({ ...columnName, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={selectedActivity.description || "Delete a table column"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_ColumnName`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={columnName.paramType === "V"}
                paramObj={columnName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="ColumnName"
                label="Column Name"
                value={columnName.paramValue}
                options={getOptionsForVariable(columnName)}
                onChange={handleChange}
                error={vaildateParamValue(columnName.paramValue).errorStatus}
                helperText={vaildateParamValue(columnName.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DeleteStatus`}
                combo={true}
                dropdown={true}
                paramObj={deleteStatus}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="deleteStatus"
                label={`Delete Status (${getVariableTypeById(
                  deleteStatus.paramObjectTypeId
                )})`}
                value={deleteStatus.paramValue}
                options={getOptionsForVariable(deleteStatus)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    deleteStatus.paramValue
                      ? deleteStatus.paramValue.toString()
                      : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    deleteStatus.paramValue
                      ? deleteStatus.paramValue.toString()
                      : ""
                  ).msg
                }
                // helperText="Select or add a Boolean type variable to store the delete status."
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default DeleteColumnWindow;
