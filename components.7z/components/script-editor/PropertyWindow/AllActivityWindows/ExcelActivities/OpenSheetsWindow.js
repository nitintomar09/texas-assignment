import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  logsState,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";

import { useDispatch, useSelector } from "react-redux";
import { setErrorType, setSelectedTab } from "./../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const OpenSheetsWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [sheetName, setSheetName] = useState(
    mapFieldObjWithValueByName(params, "SheetName", "")
  );
  const [openSheet, setOpenSheet] = useState(
    mapFieldObjWithValueByName(params, "OpenSheet", "")
  );
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setSheetName(mapFieldObjWithValueByName(params, "SheetName", ""));
    setOpenSheet(mapFieldObjWithValueByName(params, "OpenSheet", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, sheetName, openSheet]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, sheetName, openSheet];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "SheetName":
        setSheetName((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "OpenSheet":
        setOpenSheet((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "SheetName":
        setSheetName({ ...sheetName, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description || "Opens the Sheets of an Excel File."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SheetName`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={sheetName.paramType === "V"}
                paramObj={sheetName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(sheetName)}
                name="SheetName"
                label="Sheet Name"
                value={sheetName.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(sheetName.paramValue).errorStatus}
                helperText={vaildateParamValue(sheetName.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_OpenSheet`}
                combo={true}
                dropdown={true}
                paramObj={openSheet}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="OpenSheet"
                label={`Open Sheet (${getVariableTypeById(
                  openSheet.paramObjectTypeId
                )})`}
                value={openSheet.paramValue}
                options={getOptionsForVariable(openSheet)}
                onChange={handleChange}
                // helperText="Select or add a Boolean type variable to check if the Sheet has been opened or not."
                error={
                  vaildateParamValue(
                    openSheet.paramValue ? openSheet.paramValue.toString() : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    openSheet.paramValue ? openSheet.paramValue.toString() : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default OpenSheetsWindow;
