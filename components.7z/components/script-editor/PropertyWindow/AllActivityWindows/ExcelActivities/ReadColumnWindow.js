import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import CheckboxField from "../../PropertyFields/CheckboxField";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ReadColumnWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  /*const [sheetName, setSheetName] = useState(
    mapFieldObjWithValueByName(params, "SheetName", "")
  );
  const [sheetNameCurrentlyOpen, setSheetNameCurrentlyOpen] = useState(
    mapFieldObjWithValueByName(params, "CurrentlyOpened", "")
  );*/
  const [sheetColumnIndex, setSheetColumnIndex] = useState(
    mapFieldObjWithValueByName(params, "SheetColumnIndex", "")
  );
  const [outputData, setOutputData] = useState(
    mapFieldObjWithValueByName(params, "OutputData", "")
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));

    setSheetColumnIndex(
      mapFieldObjWithValueByName(params, "SheetColumnIndex", "")
    );
    setOutputData(mapFieldObjWithValueByName(params, "OutputData", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, sheetColumnIndex, outputData]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, sheetColumnIndex, outputData];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "SheetColumnIndex":
        setSheetColumnIndex((prevState) => ({
          ...prevState,
          paramValue: value,
        }));
        break;
      case "OutputData":
        setOutputData((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "SheetColumnIndex":
        setSheetColumnIndex({
          ...sheetColumnIndex,
          paramType: changeToValue,
        });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          "Read Column value from staring cell and store in a variable"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography className={classes.GroupTitle}>INPUT</Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_SheetColumnIndex`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={sheetColumnIndex.paramType === "V"}
                paramObj={sheetColumnIndex}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(sheetColumnIndex)}
                name="SheetColumnIndex"
                label="Sheet Column Index"
                value={sheetColumnIndex.paramValue}
                onChange={handleChange}
                error={
                  vaildateParamValue(sheetColumnIndex.paramValue).errorStatus
                }
                helperText={vaildateParamValue(sheetColumnIndex.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_OutputData`}
                combo={true}
                dropdown={true}
                paramObj={outputData}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="OutputData"
                //label="Output Data"
                label={`Output Data (${getVariableTypeById(
                  outputData.paramObjectTypeId
                )})`}
                value={outputData.paramValue}
                options={getOptionsForVariable(outputData)}
                onChange={handleChange}
                error={vaildateParamValue(outputData.paramValue).errorStatus}
                helperText={vaildateParamValue(outputData.paramValue).msg}
                // helperText="Select or add a List type variable to store the Col Data of the Excel Sheet."
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ReadColumnWindow;
