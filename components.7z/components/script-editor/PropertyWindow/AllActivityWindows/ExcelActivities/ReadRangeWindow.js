import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  mapFieldObjWithValueByName,
  getOptionsForVariable,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ReadRangeWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(false);

  const [dataRange, setDataRange] = useState(
    mapFieldObjWithValueByName(params, "DataRange", "")
  );

  const [specifyRange, setSpecifyRange] = useState(
    mapFieldObjWithValueByName(params, "SpecifyRange", "")
  );

  const [range1, setRange1] = useState("");
  const [range2, setRange2] = useState("");

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setDataRange(mapFieldObjWithValueByName(params, "DataRange", ""));
    const specifyParam = mapFieldObjWithValueByName(params, "SpecifyRange", "");
    setSpecifyRange(specifyParam);

    if (specifyParam.paramValue) {
      const arr = specifyParam.paramValue.split("-", 2);
      if (arr.length === 2) {
        setRange1(arr[0]);
        setRange2(arr[1]);
      }
    }
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, dataRange, range1, range2]);

  const updateParams = () => {
    if (specifyRange && (range1 || range2)) {
      specifyRange.paramValue = `${range1}-${range2}`;
    }
    const allParams = [invisibleInLogs, dataRange, specifyRange];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "DataRange":
        setDataRange((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Range1":
        setRange1(value);
        break;
      case "Range2":
        setRange2(value);
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description || "Delete Range in Excel Workbook"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SpecifyRange`}
                range={true}
                // labelBtn1={true}
                //labelBtn2={true}
                //labelBtnDisabled={true}
                name1="Range1"
                name2="Range2"
                label="Specify Range"
                value1={range1}
                value2={range2}
                onChange={handleChange}
                error1={vaildateParamValue(range1).errorStatus}
                helperText1={vaildateParamValue(range1).msg}
                error2={vaildateParamValue(range2).errorStatus}
                helperText2={vaildateParamValue(range2).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DataRange`}
                combo={true}
                dropdown={true}
                paramObj={dataRange}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                options={getOptionsForVariable(dataRange)}
                name="DataRange"
                //label="Data Range"
                label={`Data Range (${getVariableTypeById(
                  dataRange.paramObjectTypeId
                )})`}
                value={dataRange.paramValue}
                onChange={handleChange}
                error={vaildateParamValue(dataRange.paramValue).errorStatus}
                helperText={vaildateParamValue(dataRange.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ReadRangeWindow;
