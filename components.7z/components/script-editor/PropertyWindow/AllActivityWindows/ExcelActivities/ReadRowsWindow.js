import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonInput from "../Common/CommonInput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ReadRowsWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [rowsData, setRowsData] = useState(
    mapFieldObjWithValueByName(params, "rows", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setRowsData(mapFieldObjWithValueByName(params, "rows", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, rowsData]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, rowsData];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "Rows":
        setRowsData((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          "It will get the Sheet names of the Excel File"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <CommonInput />
        ) : /* <Grid container direction="column" spacing={2}>
             <Grid item>
            <Typography component="h5" className={classes.GroupTitle}>
              INPUT
            </Typography>
          </Grid>
           <Grid item>
            <PropertyField
              labelBtn1={true}
              labelBtn2={true}
              labelBtnDisabled={selectExcelFileCurrentlyOpen ? false : true}
              dropdown={selectExcelFile.paramType === "V"}
              paramObj={selectExcelFile}
              labelBtn1OnClick={changeParamTypeToVorC}
              labelBtn2OnClick={changeParamTypeToVorC}
              labelCheckbox={
                <CheckboxField
                  name="SelectExcelFileCurrentlyOpen"
                  value={selectExcelFileCurrentlyOpen}
                  label="Currently Opened"
                  onChange={handleChange}
                />
              }
              name="SelectExcelFile"
              label="Select/Browse Excel"
              value={selectExcelFile.paramValue}
              onChange={handleChange}
              options={allOptions || []}
            />
            </Grid>
            </Grid>*/
        selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Rows`}
                combo={true}
                dropdown={true}
                paramObj={rowsData}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Rows"
                label={`Rows (${getVariableTypeById(
                  rowsData.paramObjectTypeId
                )})`}
                value={rowsData.paramValue}
                options={getOptionsForVariable(rowsData)}
                onChange={handleChange}
                error={vaildateParamValue(rowsData.paramValue).errorStatus}
                helperText={vaildateParamValue(rowsData.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ReadRowsWindow;
