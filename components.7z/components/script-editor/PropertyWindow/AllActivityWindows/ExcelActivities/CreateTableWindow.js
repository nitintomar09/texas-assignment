import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const CreateTableWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [outputStatus, setOutputStatus] = useState(
    mapFieldObjWithValueByName(params, "OutputStatus", "")
  );
  const [tableName, setTableName] = useState(
    mapFieldObjWithValueByName(params, "TableName", "")
  );
  const [specifyRange, setSpecifyRange] = useState(
    mapFieldObjWithValueByName(params, "SpecifyRange", "")
  );
  const [range1, setRange1] = useState("");
  const [range2, setRange2] = useState("");

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setTableName(mapFieldObjWithValueByName(params, "TableName", ""));
    setOutputStatus(mapFieldObjWithValueByName(params, "OutputStatus", ""));
    const specifyParam = mapFieldObjWithValueByName(params, "SpecifyRange", "");
    setSpecifyRange(specifyParam);

    if (specifyParam.paramValue) {
      const arr = specifyParam.paramValue.split("-", 2);
      if (arr.length === 2) {
        setRange1(arr[0]);
        setRange2(arr[1]);
      }
    }
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, outputStatus, tableName, range1, range2]);

  const updateParams = () => {
    if (specifyRange && (range1 || range2)) {
      specifyRange.paramValue = `${range1}-${range2}`;
    }
    const allParams = [invisibleInLogs, tableName, outputStatus, specifyRange];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "TableName":
        setTableName((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "OutputStatus":
        setOutputStatus((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Range1":
        setRange1(value);
        break;
      case "Range2":
        setRange2(value);
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "TableName":
        setTableName({ ...tableName, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description || "To create table in Excel Spreadsheet"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SpecifyRange`}
                range={true}
                // labelBtn1={true}
                //labelBtn2={true}
                //labelBtnDisabled={true}
                name1="Range1"
                name2="Range2"
                label="Specify Range"
                value1={range1}
                value2={range2}
                onChange={handleChange}
                error1={vaildateParamValue(range1).errorStatus}
                helperText1={vaildateParamValue(range1).msg}
                error2={vaildateParamValue(range2).errorStatus}
                helperText2={vaildateParamValue(range2).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_TableName`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={tableName.paramType === "V"}
                paramObj={tableName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="TableName"
                label="Table Name"
                value={tableName.paramValue}
                options={getOptionsForVariable(tableName)}
                onChange={handleChange}
                error={vaildateParamValue(tableName.paramValue).errorStatus}
                helperText={vaildateParamValue(tableName.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_OutputStatus`}
                combo={true}
                dropdown={true}
                paramObj={outputStatus}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="OutputStatus"
                label={`Output Status (${getVariableTypeById(
                  outputStatus.paramObjectTypeId
                )})`}
                value={outputStatus.paramValue}
                options={getOptionsForVariable(outputStatus)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    outputStatus.paramValue
                      ? outputStatus.paramValue.toString()
                      : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    outputStatus.paramValue
                      ? outputStatus.paramValue.toString()
                      : ""
                  ).msg
                }
                // helperText="Select or add a Boolean type variable to store the delete status."
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default CreateTableWindow;
