import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
} from "../Common/CommonMethods";

import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
const ExecuteMacroWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [macroName, setMacro] = useState(
    mapFieldObjWithValueByName(params, "MacroName", "")
  );
  const [vbsScript, setVBSScript] = useState(
    mapFieldObjWithValueByName(params, "VBSScript", "")
  );
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setMacro(mapFieldObjWithValueByName(params, "MacroName", ""));
    setVBSScript(mapFieldObjWithValueByName(params, "VBSScript", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, macroName, vbsScript]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, macroName, vbsScript];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "MacroName":
        setMacro((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "VBSScript":
        setVBSScript((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "MacroName":
        setMacro({ ...macroName, paramType: changeToValue });
        break;
      case "VBSScript":
        setVBSScript({ ...vbsScript, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={selectedActivity.description || "To execute macro in excel"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_MacroName`}
                combo={true}
                dropdown={macroName.paramType === "V"}
                paramObj={macroName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                labelBtn1={true}
                labelBtn2={true}
                name="MacroName"
                label="Macro Name"
                value={macroName.paramValue}
                options={getOptionsForVariable(macroName)}
                onChange={handleChange}
                error={vaildateParamValue(macroName.paramValue).errorStatus}
                helperText={vaildateParamValue(macroName.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_VBSScript`}
                combo={true}
                dropdown={vbsScript.paramType === "V"}
                multiline={vbsScript.paramType === "C"}
                paramObj={vbsScript}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                labelBtn1={true}
                labelBtn2={true}
                name="VBSScript"
                label="Excel File Path"
                value={vbsScript.paramValue}
                options={getOptionsForVariable(vbsScript)}
                onChange={handleChange}
                error={vaildateParamValue(vbsScript.paramValue).errorStatus}
                helperText={vaildateParamValue(vbsScript.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ExecuteMacroWindow;
const ExcelFilePathOptions = [
  { name: "C://Documents/Excel", value: "C://Documents/Excel" },
  { name: "Sheetlist", value: "Sheetlist" },
  { name: "C://Documents", value: "C://Documents" },
  { name: "D://Documents/Excel", value: "D://Documents/Excel" },
];

const EncryptionMethodOptions = [
  { name: "ENC_Method_AES(default)", value: "ENC_Method_AES(default)" },
  { name: "ENC_Method2_AES", value: "ENC_Method2_AES" },
];
