import React, { useState, useRef, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { FolderOpen, WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { extractHeader } from "../../../../../utils/common";
import { useDispatch, useSelector } from "react-redux";
import { setSelectedTab, setErrorType } from "./../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const OpenExcelWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const hiddenFileInput = useRef(null);
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [excelFilePath, setExcelFilePath] = useState(
    mapFieldObjWithValueByName(params, "ExcelFilePath", "")
  );
  const [openFile, setOpenFile] = useState(
    mapFieldObjWithValueByName(params, "OpenFile", "")
  );
  const [password, setPassword] = useState(
    mapFieldObjWithValueByName(params, "Password", "")
  );
  const [passwordCheckbox, setPasswordCheckbox] = useState(false);
  const [createNewCheckbox, setCreateNewCheckbox] = useState(
    mapFieldObjWithValueByName(params, "CreateNew", false)
  );
  const [readOnlyCheckbox, setReadOnlyCheckbox] = useState(
    mapFieldObjWithValueByName(params, "ReadOnly", false)
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setExcelFilePath(mapFieldObjWithValueByName(params, "ExcelFilePath", ""));
    setPassword(mapFieldObjWithValueByName(params, "Password", ""));
    setCreateNewCheckbox(
      mapFieldObjWithValueByName(params, "CreateNew", false)
    );
    setReadOnlyCheckbox(mapFieldObjWithValueByName(params, "ReadOnly", false));
    setOpenFile(mapFieldObjWithValueByName(params, "OpenFile", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);
  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    excelFilePath,
    password,
    createNewCheckbox,
    readOnlyCheckbox,
    openFile,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      excelFilePath,
      password,
      createNewCheckbox,
      readOnlyCheckbox,
      openFile,
    ];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value, checked } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "ExcelFilePath":
        setExcelFilePath((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Password":
        setPassword((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "CreateNew":
        setCreateNewCheckbox({ ...createNewCheckbox, paramValue: checked });
        if (checked) {
          setReadOnlyCheckbox({ ...readOnlyCheckbox, paramValue: false });
        }
        break;
      case "ReadOnly":
        setReadOnlyCheckbox({ ...readOnlyCheckbox, paramValue: checked });
        if (checked) {
          setCreateNewCheckbox({ ...createNewCheckbox, paramValue: false });
        }
        break;
      case "OpenFile":
        setOpenFile((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "PasswordCheckbox":
        setPasswordCheckbox(!passwordCheckbox);
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "ExcelFilePath":
        setExcelFilePath({ ...excelFilePath, paramType: changeToValue });
        break;

      case "Password":
        setPassword({ ...password, paramType: changeToValue });
        break;
      default:
        break;
    }
  };

  // to handle the user-selected file
  {
    /* const handleChangeFile = (event) => {
    const fileUploaded = event.target.files[0];

    if (fileUploaded) {
      setExcelFilePath({ ...excelFilePath, paramValue: fileUploaded.name });

      const fileReader = new FileReader();
      fileReader.readAsBinaryString(fileUploaded);

      fileReader.onload = (e) => {
        const binaryData = e.target.result;

        const wb = XLSX.read(binaryData, { type: "binary" });
        console.log(wb.SheetNames);

        const sheetHeaders = [];
        wb.SheetNames.forEach((sheet) => {
          const arr = extractHeader(wb.Sheets[sheet]);
          const json = { [sheet]: arr };
          sheetHeaders.push(json);
        });
        dispatch(setSheetHeaders(sheetHeaders));
      };
    }
  };*/
  }

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={selectedActivity.description || "Opens the Excel File"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={1}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_ExcelFilePath`}
                  combo={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  dropdown={excelFilePath.paramType === "V"}
                  paramObj={excelFilePath}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  btnIcon={
                    <FolderOpen
                      className={classes.btnIcon + " " + classes.colorPrimary}
                    />
                  }
                  name="ExcelFilePath"
                  label="Excel File Path"
                  value={excelFilePath.paramValue}
                  options={getOptionsForVariable(excelFilePath)}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(excelFilePath.paramValue).errorStatus
                  }
                  helperText={vaildateParamValue(excelFilePath.paramValue).msg}
                />
              </Grid>
              <Grid item>
                {/* <input
                  name="inputFile"
                  id="inputFile"
                  type="file"
                  accept=".xlsx,.xls"
                  ref={hiddenFileInput}
                  onChange={handleChangeFile}
                  style={{
                    display: "none",
                  }} // Make the file input element invisible 
                />*/}
                <PropertyField
                  id={`${props.id}_Password`}
                  combo={true}
                  secret={true}
                  labelBtn1={true}
                  labelBtn2={true}
                  labelBtnDisabled={passwordCheckbox ? false : true}
                  disabled={passwordCheckbox ? false : true}
                  labelWithCheckbox={true}
                  dropdown={password.paramType === "V"}
                  paramObj={password}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  labelCheckboxName="PasswordCheckbox"
                  labelCheckboxValue={passwordCheckbox}
                  name="Password"
                  label="Password(Optional)"
                  value={password.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(password)}
                />
              </Grid>
            </Grid>
            <Grid container direction="column" spacing={1}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  OPTIONAL
                </Typography>
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_CreateNew`}
                  checkbox={true}
                  name="CreateNew"
                  label="Create New"
                  value={createNewCheckbox.paramValue}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_ReadOnly`}
                  checkbox={true}
                  name="ReadOnly"
                  label="Read-Only"
                  value={readOnlyCheckbox.paramValue}
                  onChange={handleChange}
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_OpenFile`}
                combo={true}
                dropdown={true}
                paramObj={openFile}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="OpenFile"
                label={`Open File (${getVariableTypeById(
                  openFile.paramObjectTypeId
                )})`}
                value={openFile.paramValue}
                options={getOptionsForVariable(openFile)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    openFile.paramValue ? openFile.paramValue.toString() : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    openFile.paramValue ? openFile.paramValue.toString() : ""
                  ).msg ||
                  "Select or add a Boolean type variable to check if the files has been opened or not"
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default OpenExcelWindow;
