import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const AddNewSheetWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [sheetName, setSheetName] = useState(
    mapFieldObjWithValueByName(params, "SheetName", "")
  );
  const [output, setOutput] = useState(
    mapFieldObjWithValueByName(params, "output", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setSheetName(mapFieldObjWithValueByName(params, "SheetName", ""));
    setOutput(mapFieldObjWithValueByName(params, "output", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, sheetName, output]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, sheetName, output];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "SheetName":
        setSheetName((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Output":
        setOutput((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "SheetName":
        setSheetName({ ...sheetName, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          "It will add new sheet in the Excel File"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_SheetName`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={sheetName.paramType === "V"}
                paramObj={sheetName}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="SheetName"
                label="Sheet Name"
                value={sheetName.paramValue}
                options={getOptionsForVariable(sheetName)}
                onChange={handleChange}
                error={vaildateParamValue(sheetName.paramValue).errorStatus}
                helperText={vaildateParamValue(sheetName.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_Output`}
                combo={true}
                dropdown={true}
                paramObj={output}
                name="Output"
                label={`Output (${getVariableTypeById(
                  output.paramObjectTypeId
                )})`}
                value={output.paramValue}
                options={getOptionsForVariable(output)}
                onChange={handleChange}
                error={
                  vaildateParamValue(
                    output.paramValue ? output.paramValue.toString() : ""
                  ).errorStatus
                }
                helperText={
                  vaildateParamValue(
                    output.paramValue ? output.paramValue.toString() : ""
                  ).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default AddNewSheetWindow;
