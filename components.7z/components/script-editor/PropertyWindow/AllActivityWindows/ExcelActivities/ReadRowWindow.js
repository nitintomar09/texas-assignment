import React, { useState, useEffect } from "react";
import PropertyField from "../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography, Select } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
  truncateString,
  getAllOptions,
} from "../Common/CommonMethods";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { getVariableTypeById } from "./../Common/CommonMethods";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ReadRowsWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();
  const { params } = selectedActivity;
  const allOptions = getAllOptions();

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  // const [openRole, setOpenRole] = useState(-1);

  const [rowIndex, setRowIndex] = useState(
    mapFieldObjWithValueByName(params, "RowIndex", "")
  );
  const [rowData, setRowData] = useState(
    mapFieldObjWithValueByName(params, "RowData", "")
  );
  /*  const [rowDataValue, setRowDataValue] = useState([]);

  const openedSheet = useSelector((state) => state.excelActivity.openSheet);
  const headers = useSelector((state) => state.excelActivity.sheetHeaders);

  const [headersArr, setHeadersArr] = useState([]);
  useEffect(() => {
    if (headers) {
      let arrHead = [];
      headers.forEach((item) => {
        if (typeof item == "object") {
          const arr = item[openedSheet];
          if (arr) {
            arrHead = [...arr];
          }
        }
      });
      setHeadersArr(arrHead);
    }
  }, [headers]);

  useEffect(() => {
    if (headersArr.length > 0) {
      const newArr = headersArr.map((item) => {
        return { name: item, value: "" };
      });
      setRowDataValue(newArr);
    }
  }, [headersArr]);*/

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));

    setRowIndex(mapFieldObjWithValueByName(params, "RowIndex", ""));
    setRowData(mapFieldObjWithValueByName(params, "RowData", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);
  /*useEffect(() => {
    if (rowData.paramValue) {
      console.log(JSON.parse(rowData.paramValue));
      if (typeof rowData.paramValue === "object") {
        const rowDataValueObj = JSON.parse(rowData.paramValue);
        if (typeof rowDataValueObj === "object") {
          let newArray = Object.keys(rowDataValueObj).map((key) => {
            return { name: key, value: rowDataValueObj[key] };
          });

          setRowDataValue(newArray);
        }
      }
    }
  }, [rowData]);*/
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "RowIndex":
        setRowIndex((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "RowData":
        setRowData((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "RowIndex":
        setRowIndex({
          ...rowIndex,
          paramType: changeToValue,
        });
        break;
      default:
        break;
    }
  };
  /* const handleCloseColumn = (index) => {
    setOpenRole(index);
  };
  const handleOpenColumn = (index) => {
    setOpenRole(index);
  };

  const mapRPAWithVar = (VarToBeMapped, value) => {
    let newVars = [...rowDataValue];

    const index = rowDataValue.findIndex(
      (item) => item.name === VarToBeMapped.name
    );

    if (index !== -1) {
      const newVar = { ...rowDataValue[index], value: value };
      newVars.splice(index, 1, newVar);
      setRowDataValue(newVars);
    } else {
      console.log("process var not found");
    }
    let obj = {};
    newVars.forEach((item) => {
      let { name, value } = item;
      let json = { [name]: value };
      obj = { ...obj, ...json };
    });
    if (Object.keys(obj).length > 0) {
      setRowData({ ...rowData, paramValue: JSON.stringify(obj) });
    }
  };
*/
  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, rowIndex, rowData]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, rowIndex, rowData];
    addParamsToSelAct(allParams);
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          "Read Rows one by one in the opened Excel"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_RowIndex`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={rowIndex.paramType === "V"}
                paramObj={rowIndex}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="RowIndex"
                label="Row Index"
                value={rowIndex.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(rowIndex)}
                error={vaildateParamValue(rowIndex.paramValue).errorStatus}
                helperText={vaildateParamValue(rowIndex.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_RowData`}
                combo={true}
                dropdown={true}
                paramObj={rowData}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="RowData"
                label={`Row Data (${getVariableTypeById(
                  rowData.paramObjectTypeId
                )})`}
                value={rowData.paramValue}
                options={getOptionsForVariable(rowData)}
                onChange={handleChange}
                error={vaildateParamValue(rowData.paramValue).errorStatus}
                helperText={vaildateParamValue(rowData.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ReadRowsWindow;

/**
 *   <Grid item>
              <Typography className={classes.label}>Row Data Mapped</Typography>
            </Grid>
            <Grid item>
              {rowDataValue.length > 0 && (
                <Grid
                  container
                  direction="row"
                  style={{ paddingBottom: "15px" }}
                >
                  <Grid item xs={5}>
                    <Typography className={classes.label}>
                      Sheet Headers
                    </Typography>
                  </Grid>
                  <Grid item xs>
                    <Typography className={classes.label}>Variables</Typography>
                  </Grid>
                </Grid>
              )}
              {rowDataValue.map((variable, index) => (
                <Grid
                  container
                  className={classes.padding}
                  spacing={1}
                  key={variable.name}
                  style={{ marginTop: "5px", marginBottom: "5px" }}
                >
                  <Grid item xs={5}>
                    <Typography
                      className={classes.text_12}
                      title={variable.name}
                    >
                      {truncateString(variable.name)}
                    </Typography>
                  </Grid>
                  <Grid item xs>
                    <Select
                      native
                      variant="outlined"
                      fullWidth={true}
                      className={classes.input}
                      value={variable.value ? variable.value : ""}
                      onChange={(e) => {
                        mapRPAWithVar(variable, e.target.value);
                      }}
                      open={openRole === index}
                      onClose={() => handleCloseColumn(index)}
                      onOpen={() => handleOpenColumn(index)}
                      SelectDisplayProps={{ shrink: true }}
                      style={{ width: "190px" }}
                    >
                      <option hidden defaultValue>
                        -select-
                      </option>
                      {allOptions &&
                        allOptions.map((item) => (
                          <option value={item.value} key={item.name}>
                            {item.name}
                          </option>
                        ))}
                    </Select>
                  </Grid>
                </Grid>
              ))}
            </Grid>
 */
