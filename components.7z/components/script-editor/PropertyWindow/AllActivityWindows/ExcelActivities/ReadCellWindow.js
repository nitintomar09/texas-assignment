import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  getOptionsForVariable,
  mapFieldObjWithValueByName,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ReadCellWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [cellIndex, setCellIndex] = useState(
    mapFieldObjWithValueByName(params, "CellIndex", "")
  );
  const [valueField, setValue] = useState(
    mapFieldObjWithValueByName(params, "CellValue", "")
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setValue(mapFieldObjWithValueByName(params, "CellValue", ""));
    setCellIndex(mapFieldObjWithValueByName(params, "CellIndex", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, cellIndex, valueField]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, valueField, cellIndex];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "CellIndex":
        setCellIndex((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "CellValue":
        setValue((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "CellIndex":
        setCellIndex({ ...cellIndex, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description || "Read Value from a specified Cell"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_CellIndex`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={cellIndex.paramType === "V"}
                paramObj={cellIndex}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="CellIndex"
                label="Cell Index"
                value={cellIndex.paramValue}
                options={getOptionsForVariable(cellIndex)}
                onChange={handleChange}
                error={vaildateParamValue(cellIndex.paramValue).errorStatus}
                helperText={vaildateParamValue(cellIndex.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_CellValue`}
                combo={true}
                dropdown={valueField.paramType === "V"}
                paramObj={valueField}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="CellValue"
                label={`Cell Value (${getVariableTypeById(
                  valueField.paramObjectTypeId
                )})`}
                value={valueField.paramValue}
                options={getOptionsForVariable(valueField)}
                onChange={handleChange}
                error={vaildateParamValue(valueField.paramValue).errorStatus}
                helperText={vaildateParamValue(valueField.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ReadCellWindow;
