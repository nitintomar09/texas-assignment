import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
} from "./../Common/CommonMethods";
import ErrorsWindow from "../Common/ErrorsWindow";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "./../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const WebActivityWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  console.log(params);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [targetField, setTargetField] = useState(
    mapFieldObjWithValueByName(params, "Target", "")
  );
  const [valueField, setValueField] = useState(
    mapFieldObjWithValueByName(params, "Value", "")
  );
  const [recordId, setRecordId] = useState(
    mapFieldObjWithValueByName(params, "RecordId", "")
  );

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setTargetField(mapFieldObjWithValueByName(params, "Target", ""));
    setValueField(mapFieldObjWithValueByName(params, "Value", ""));
    setRecordId(mapFieldObjWithValueByName(params, "RecordId", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [targetField, valueField]);

  const updateParams = () => {
    let allParams = [targetField, valueField];
    if (selectedActivity.activityId === 2) {
      allParams.push(recordId);
    }
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    console.log(e.target.name);
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "Target":
        setTargetField((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "Value":
        setValueField((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "Target":
        setTargetField({ ...targetField, paramType: changeToValue });
        break;
      case "Value":
        setValueField({ ...valueField, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={`${props.id}`}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={selectedActivity.description || "web activity"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Target`}
                combo={true}
                dropdown={targetField.paramType === "V"}
                paramObj={targetField}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                labelBtn1={true}
                labelBtn2={true}
                name="Target"
                label="Target"
                value={targetField.paramValue}
                options={getOptionsForVariable(targetField)}
                onChange={handleChange}
                error={vaildateParamValue(targetField.paramValue).errorStatus}
                helperText={vaildateParamValue(targetField.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Value`}
                combo={true}
                dropdown={valueField.paramType === "V"}
                paramObj={valueField}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                labelBtn1={true}
                labelBtn2={true}
                name="Value"
                label="Value"
                value={valueField.paramValue}
                options={getOptionsForVariable(valueField)}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : null}
      </div>
    </div>
  );
};

export default WebActivityWindow;
