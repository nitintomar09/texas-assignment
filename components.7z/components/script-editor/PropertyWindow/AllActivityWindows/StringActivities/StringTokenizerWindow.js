import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder, FolderOpen } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const StringTokenizerWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [inputString, setInputString] = useState(
    mapFieldObjWithValueByName(params, "InputString", "")
  );
  const [separator, setSeparator] = useState(
    mapFieldObjWithValueByName(params, "separator", "")
  );

  const [tokens, setTokens] = useState(
    mapFieldObjWithValueByName(params, "Tokens", "")
  );

  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setInputString(mapFieldObjWithValueByName(params, "InputString", ""));
    setSeparator(mapFieldObjWithValueByName(params, "separator", ""));
    setTokens(mapFieldObjWithValueByName(params, "Tokens", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, inputString, separator, tokens]);

  const updateParams = () => {
    const allParams = [invisibleInLogs, inputString, separator, tokens];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "InputString":
        setInputString((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "separator":
        setSeparator((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "Tokens":
        setTokens((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "InputString":
        setInputString({ ...inputString, paramType: changeToValue });
        break;
      case "separator":
        setSeparator({ ...separator, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={selectedActivity?.description || ""}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_InputString`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={inputString.paramType === "V"}
                paramObj={inputString}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="InputString"
                label="Input String"
                value={inputString.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(inputString)}
                error={vaildateParamValue(inputString.paramValue).errorStatus}
                helperText={vaildateParamValue(inputString.paramValue).msg}
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Separator`}
                combo={true}
                labelBtn1={true}
                labelBtn2={true}
                dropdown={separator.paramType === "V"}
                paramObj={separator}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                name="separator"
                label="Separator"
                value={separator.paramValue}
                onChange={handleChange}
                options={getOptionsForVariable(separator)}
                error={vaildateParamValue(separator.paramValue).errorStatus}
                helperText={vaildateParamValue(separator.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_Tokens`}
                combo={true}
                dropdown={true}
                paramObj={tokens}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="Tokens"
                label={`Tokens (${getVariableTypeById(
                  tokens.paramObjectTypeId
                )})`}
                value={tokens.paramValue}
                options={getOptionsForVariable(tokens)}
                onChange={handleChange}
                error={vaildateParamValue(tokens.paramValue).errorStatus}
                helperText={vaildateParamValue(tokens.paramValue).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default StringTokenizerWindow;
