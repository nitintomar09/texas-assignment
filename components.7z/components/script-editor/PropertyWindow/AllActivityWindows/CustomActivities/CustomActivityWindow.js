import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  logsState,
  mapFieldObjWithValueByName,
  getAllOptions,
  getOptionsForVariable,
  getVariableTypeById,
} from "./../Common/CommonMethods";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "../Common/commonOutput";
import ErrorsWindow from "../Common/ErrorsWindow";
import CommonInput from "../Common/CommonInput";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const CustomActivityWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;

  const [params, setParams] = useState([...selectedActivity.params] || []);

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setParams([...selectedActivity.params]);
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, params]);

  const updateParams = () => {
    const newParams = params.filter(
      (item) => item.paramName !== "invisiblelogs"
    );
    const allParams = [invisibleInLogs, ...newParams];

    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name !== "ActivityName" && name !== "MakeLogsPrivate") {
      const newParams = [...params];
      const newParam = params.find((item) => item.paramName === name);
      const oldParamIndex = params.findIndex((item) => item.paramName === name);
      if (oldParamIndex !== -1) {
        newParam.paramValue = value;
        newParams.splice(oldParamIndex, 1, newParam);
        setParams(newParams);
      }
    } else {
      switch (name) {
        case "ActivityName":
          setActivityName(value);
          updateDisplayNameSelAct(value);
          break;
        case "MakeLogsPrivate":
          setInvisibleInLogs({
            ...invisibleInLogs,
            paramValue: !invisibleInLogs.paramValue,
          });
          break;
        default:
          break;
      }
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    const newParams = [...params];
    const newParam = params.find((item) => item.paramName === paramName);
    const oldParamIndex = params.findIndex(
      (item) => item.paramName === paramName
    );
    if (oldParamIndex !== -1) {
      newParam.paramType = changeToValue;
      newParams.splice(oldParamIndex, 1, newParam);
      setParams(newParams);
    }
  };
  return (
    <div>
      <CommonFields
        ScopeActivity={selectedActivity.activityType === "S"}
        selectedActivity={selectedActivity}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={selectedActivity.description || "Custom Activity"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={1}>
            {params &&
              params.filter(
                (item) =>
                  item.paramTypeInput === 1 &&
                  item.paramName !== "invisiblelogs"
              ).length > 0 && (
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    INPUT
                  </Typography>
                </Grid>
              )}

            {params.filter(
              (item) =>
                item.paramTypeInput === 1 && item.paramName !== "invisiblelogs"
            ).length !== 0 ? (
              params
                .filter(
                  (item) =>
                    item.paramTypeInput === 1 &&
                    item.paramName !== "invisiblelogs"
                )
                .map((param) => (
                  <Grid item key={param.paramId}>
                    <PropertyField
                      combo={true}
                      labelBtn1={true}
                      labelBtn2={true}
                      dropdown={param.paramType === "V"}
                      paramObj={param}
                      labelBtn1OnClick={changeParamTypeToVorC}
                      labelBtn2OnClick={changeParamTypeToVorC}
                      options={getOptionsForVariable(param)}
                      name={param.paramName}
                      label={param.paramName}
                      value={param.paramValue}
                      onChange={handleChange}
                      error={
                        vaildateParamValue(param.paramValue?.toString() || "")
                          .errorStatus
                      }
                      helperText={
                        vaildateParamValue(param.paramValue?.toString() || "")
                          .msg
                      }
                    />
                  </Grid>
                ))
            ) : (
              <CommonInput />
            )}
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={1}>
            {params &&
              params.filter(
                (item) =>
                  item.paramTypeInput === 2 &&
                  item.paramName !== "invisiblelogs"
              ).length > 0 && (
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    OUTPUT
                  </Typography>
                </Grid>
              )}
            {params.filter(
              (item) =>
                item.paramTypeInput === 2 && item.paramName !== "invisiblelogs"
            ).length !== 0 ? (
              params
                .filter(
                  (item) =>
                    item.paramTypeInput === 2 &&
                    item.paramName !== "invisiblelogs"
                )
                .map((param) => (
                  <Grid item key={param.paramId}>
                    <PropertyField
                      combo={true}
                      dropdown={param.paramType === "V"}
                      paramObj={param}
                      btnIcon={
                        <AddVariableIcon
                          className={
                            classes.btnIcon + " " + classes.colorPrimary
                          }
                        />
                      }
                      options={getOptionsForVariable(param)}
                      name={param.paramName}
                      label={`${param.paramName} (${getVariableTypeById(
                        param.paramObjectTypeId
                      )})`}
                      value={param.paramValue}
                      onChange={handleChange}
                      error={
                        vaildateParamValue(param.paramValue?.toString() || "")
                          .errorStatus
                      }
                      helperText={
                        vaildateParamValue(param.paramValue?.toString() || "")
                          .msg
                      }
                    />
                  </Grid>
                ))
            ) : (
              <CommonOutput />
            )}
          </Grid>
        ) : selectedTab ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default CustomActivityWindow;
