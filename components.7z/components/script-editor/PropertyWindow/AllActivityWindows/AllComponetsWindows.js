//Excel property windows
export { default as CopySheetWindow } from "./ExcelActivities/CopySheetWindow";
export { default as CreateTableWindow } from "./ExcelActivities/CreateTableWindow";
export { default as DeleteColumnWindow } from "./ExcelActivities/DeleteColumnWindow";
export { default as DeleteRangeWindow } from "./ExcelActivities/DeleteRangeWindow";
export { default as ExecuteMacroWindow } from "./ExcelActivities/ExecuteMacroWindow";
export { default as FilterTableWindow } from "./ExcelActivities/FilterTableWindow";
export { default as ForEachWindow } from "./ExcelActivities/ForEachWindow";
export { default as GetSheetsWindow } from "./ExcelActivities/GetSheetsWindow";
export { default as GetTableRangeWindow } from "./ExcelActivities/GetTableRangeWindow";
export { default as OpenExcelWindow } from "./ExcelActivities/OpenExcelWindow";
export { default as OpenSheetsWindow } from "./ExcelActivities/OpenSheetsWindow";
export { default as ReadCellWindow } from "./ExcelActivities/ReadCellWindow";
export { default as ReadColumnWindow } from "./ExcelActivities/ReadColumnWindow";
export { default as ReadRowsWindow } from "./ExcelActivities/ReadRowsWindow";
export { default as WriteCellWindow } from "./ExcelActivities/WriteCellWindow";
export { default as WriteRangeWindow } from "./ExcelActivities/WriteRangeWindow";

//Files and Folders property windows
export { default as CreateFolderWindow } from "./Files_Folders/CreateFolderWindow";
export { default as DeleteFileWindow } from "./Files_Folders/DeleteFileWindow";
export { default as DeleteFolderWindow } from "./Files_Folders/DeleteFolderWindow";
export { default as GetFilesWindow } from "./Files_Folders/GetFilesWindow";
export { default as MoveFileWindow } from "./Files_Folders/MoveFileWindow";
export { default as MoveFolderWindow } from "./Files_Folders/MoveFolderWindow";
export { default as RenameFileWindow } from "./Files_Folders/RenameFileWindow";
export { default as RenameFolderWindow } from "./Files_Folders/RenameFolderWindow";
export { default as SplitFilePathAndNameWindow } from "./Files_Folders/SplitFilePathAndNameWindow";

//control flow
export { default as IfWindow } from "./ControlFlowActivities/IfWindow";

//IBPS
export { default as AddDocumentToWorkitemWindow } from "./IBPSActivities/AddDocumentToWorkitemWindow";
export { default as AddDocumentWindow } from "./IBPSActivities/AddDocumentWindow";
export { default as CompleteWorkitemWindow } from "./IBPSActivities/CompleteWorkitemWindow";
export { default as CreateWorkitemWindow } from "./IBPSActivities/CreateWorkitemWindow";
export { default as GetDocumentWindow } from "./IBPSActivities/GetDocumentWindow";
export { default as ServerConnectWindow } from "./IBPSActivities/ServerConnectWindow";

//web
export { default as WebActivityWindow } from "./WebActivities/WebActivityWindow";

//Zip unZIp
export { default as CompressFileWindow } from "./ZipActivities/CompressFileWindow";
export { default as DecompressFileWindow } from "./ZipActivities/DecompressFileWindow";

//Group
export { default as AddGroupWindow } from "./AddGroupWindow";

//Mail

export { default as ConnectMainWindow } from "./MailActivities/Connect/ConnectMainWindow";
export { default as MoveMailMainWindow } from "./MailActivities/MoveMail/MoveMailMainWindow";
export { default as DeleteMailExchangeWindow } from "./MailActivities/DeleteMailExchangeWindow";
export { default as GetMailWindow } from "./MailActivities/GetMailWindow";
export { default as SaveAttachmentsWindow } from "./MailActivities/SaveAttachmentsWindow";
export { default as SaveMailWindow } from "./MailActivities/SaveMailWindow";
export { default as SendMailExchangeWindow } from "./MailActivities/SendMailExchangeWindow";
export { default as SendMailSMTPWindow } from "./MailActivities/SendMailSMTPWindow";
