import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { Folder } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import {
  getOptionsForVariable,
  getVariableTypeById,
  logsState,
  mapFieldObjWithValueByName,
} from "./../Common/CommonMethods";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import ErrorsWindow from "../Common/ErrorsWindow";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ChangeDateFormat = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const { params } = selectedActivity;

  const dispatch = useDispatch();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [dateTo, setDateTo] = useState(
    mapFieldObjWithValueByName(params, "dateTo", "")
  );

  const [dateFormatFrom, setDateFormatFrom] = useState(
    mapFieldObjWithValueByName(params, "dateFormatFrom", "")
  );
  const [dateFormatTo, setDateFormatTo] = useState(
    mapFieldObjWithValueByName(params, "dateFormatTo", "")
  );
  const [dateFrom, setDateFrom] = useState(
    mapFieldObjWithValueByName(params, "dateFrom", "")
  );
  useEffect(() => {
    setActivityName((selectedActivity && selectedActivity.displayName) || "");
    setInvisibleInLogs(logsState(params, false));
    setDateTo(mapFieldObjWithValueByName(params, "dateTo", ""));
    setDateFormatTo(mapFieldObjWithValueByName(params, "dateFormatTo", ""));
    setDateFormatFrom(mapFieldObjWithValueByName(params, "dateFormatFrom", ""));
    setDateFrom(mapFieldObjWithValueByName(params, "dateFrom", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [dateFrom, dateTo, dateFormatFrom, dateFormatTo, invisibleInLogs]);

  const updateParams = () => {
    const allParams = [
      dateFrom,
      dateTo,
      dateFormatFrom,
      dateFormatTo,
      invisibleInLogs,
    ];
    addParamsToSelAct(allParams);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "DateFormatTo":
        setDateFormatTo((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "DateTo":
        setDateTo((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "DateFormatFrom":
        setDateFormatFrom((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "DateFrom":
        setDateFrom((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "DateFrom":
        setDateFrom({ ...dateFrom, paramType: changeToValue });
        break;
      case "DateFormatTo":
        setDateFormatTo({ ...dateFormatTo, paramType: changeToValue });
        break;

      case "DateFormatFrom":
        setDateFormatFrom({ ...dateFormatFrom, paramType: changeToValue });
        break;

      default:
        break;
    }
  };
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        selectedActivity={selectedActivity}
        activityName={activityName}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Folder}
        helperText={
          selectedActivity.description || "This activity changes date format."
        }
      />

      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <>
            <Grid container direction="column" spacing={2}>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  INPUT
                </Typography>
              </Grid>

              <Grid item>
                <PropertyField
                  id={`${props.id}_DateFormatFrom`}
                  combo={true}
                  // labelBtn1={true}
                  //labelBtn2={true}
                  // type="date"
                  dropdown={dateFormatFrom.paramType === "V"}
                  paramObj={dateFormatFrom}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="DateFormatFrom"
                  label="Date Format From"
                  value={dateFormatFrom.paramValue}
                  onChange={handleChange}
                  options={getOptionsForVariable(dateFormatFrom)}
                  error={
                    vaildateParamValue(dateFormatFrom.paramValue.toString())
                      .errorStatus
                  }
                  helperText={
                    vaildateParamValue(dateFormatFrom.paramValue.toString()).msg
                  }
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_DateFormatTo`}
                  combo={true}
                  dropdown={dateFormatTo.paramType === "V"}
                  paramObj={dateFormatTo}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="DateFormatTo"
                  label="Date Format To"
                  value={dateFormatTo.paramValue}
                  options={getOptionsForVariable(dateFormatTo)}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(dateFormatTo.paramValue.toString())
                      .errorStatus
                  }
                  helperText={
                    vaildateParamValue(dateFormatTo.paramValue.toString()).msg
                  }
                />
              </Grid>
              <Grid item>
                <PropertyField
                  id={`${props.id}_DateFrom`}
                  combo={true}
                  dropdown={dateFrom.paramType === "V"}
                  paramObj={dateFrom}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  name="DateFrom"
                  label="Date From"
                  value={dateFrom.paramValue}
                  options={getOptionsForVariable(dateFrom)}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(dateFrom.paramValue.toString())
                      .errorStatus
                  }
                  helperText={
                    vaildateParamValue(dateFrom.paramValue.toString()).msg
                  }
                />
              </Grid>
            </Grid>
          </>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_DateTo`}
                combo={true}
                dropdown={true}
                paramObj={dateTo}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="DateTo"
                label={`Date To (${getVariableTypeById(
                  dateTo.paramObjectTypeId
                )})`}
                value={dateTo.paramValue}
                options={getOptionsForVariable(dateTo)}
                onChange={handleChange}
                error={
                  vaildateParamValue(dateTo.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(dateTo.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </div>
  );
};

export default ChangeDateFormat;
const dateFormatOptions = [
  { name: "dd-MM-yyyy", value: "dd-MM-yyyy" },
  { name: "MM-dd-yyyy", value: "MM-dd-yyyy" },
  { name: "dd/MM/yyyy", value: "dd/MM/yyyy" },
  { name: "MM/dd/yyyy", value: "MM/dd/yyyy" },
  { name: "d MMM yyyy", value: "d MMM yyyy" },
];
