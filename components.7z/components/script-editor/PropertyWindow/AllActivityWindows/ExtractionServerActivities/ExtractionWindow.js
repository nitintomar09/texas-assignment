import React, { useState, useContext, useEffect, useRef } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Document, Page, pdfjs } from "react-pdf";

import PropertyField from "./../../PropertyFields/PropertyField";
import {
  Email,
  FolderOpen,
  SkipNextOutlined,
  SkipPreviousOutlined,
  ZoomInOutlined,
  ZoomOutOutlined,
} from "@mui/icons-material";
import { Grid, Typography, Button, Select } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "../Common/CommonFields";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import {
  getOptionsForVariable,
  logsState,
  mapFieldObjWithValueByName,
  getVariableTypeById,
  truncateString,
  getAllVariables,
} from "./../Common/CommonMethods";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import {
  createInstance,
  handleNetworkRequestError,
} from "../../../../../utils/common";
import {
  OMNIXTRACT_GET_DOC_TYPE,
  OMNIXTRACT_EXTRACT_DOCUMENT,
  OMNIXTRACT_GET_DOC_TYPE_4_VERSION,
  OMNIXTRACT_EXTRACT_DOCUMENT_4_VERSION,
  OMNIXTRACT_GET_FIELDS_LIST,
} from "./../../../../../config/index";
import ModalForm from "../../../../../utils/modalForm";
import SearchBox from "./../../../../../utils/Search-Component/index";
import CustomTabs from "../../../../../utils/CustomTabs";
import LoadingIndicator from "../../../../../utils/loadingIndicator";
import { useHistory } from "react-router";
import Tiff from "tiff.js";
import Pagination from "../../../../../utils/Pagination";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const ExtractionWindow = (props) => {
  const classes = useStyles();

  const {
    selectedActivity,
    addParamsToSelAct,
    updateDisplayNameSelAct,
  } = props;
  const [activityName, setActivityName] = useState(
    selectedActivity ? selectedActivity.displayName : ""
  );

  const { params } = selectedActivity;
  const history = useHistory();
  const { setValue: setNotification } = useContext(NotificationContext);

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const oxServerValues = useSelector(
    (state) => state.propertyWindow.oxServerValues
  );
  //const allVariables = getAllVariables();

  const dispatch = useDispatch();
  const [documentType, setDocumentType] = useState(
    mapFieldObjWithValueByName(params, "DocumentDefinition", "")
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );
  const [filePath, setFilePath] = useState(
    mapFieldObjWithValueByName(params, "FileSource", "")
  );

  const [extractedData, setExtractedData] = useState(
    mapFieldObjWithValueByName(params, "ExtractedData", "")
  );
  const [statusCode, setStatusCode] = useState(
    mapFieldObjWithValueByName(params, "statusCode", "")
  );
  /* const [keyFieldsData, setKeyFieldsData] = useState(
    mapFieldObjWithValueByName(params, "KeyFields", "")
  );
  const [tableFieldsData, setTableFieldsData] = useState(
    mapFieldObjWithValueByName(params, "TableFields", "")
  );*/
  const [strLanguage, setStrLanguage] = useState(
    mapFieldObjWithValueByName(params, "strLanguage", "ENGLISH")
  );
  const [strPageRange, setStrPageRange] = useState(
    mapFieldObjWithValueByName(params, "strPageRange", "")
  );
  const [docList, setDocList] = useState([]);
  // const [keyFieldsList, setKeyFieldsList] = useState([]);
  //const [tableFieldsList, setTableFieldsList] = useState([]);

  const [openModal, setOpenModal] = useState(false);
  //const [openRole, setOpenRole] = useState(-1);
  //const [openRole1, setOpenRole1] = useState(-1);

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setFilePath(mapFieldObjWithValueByName(params, "FileSource", ""));
    setExtractedData(mapFieldObjWithValueByName(params, "ExtractedData", ""));
    setStrLanguage(
      mapFieldObjWithValueByName(params, "strLanguage", "ENGLISH")
    );
    setStrPageRange(mapFieldObjWithValueByName(params, "strPageRange", ""));
    setDocumentType(
      mapFieldObjWithValueByName(params, "DocumentDefinition", "")
    );
    setStatusCode(mapFieldObjWithValueByName(params, "statusCode", ""));
    // setKeyFieldsData(mapFieldObjWithValueByName(params, "KeyFields", ""));
    //setTableFieldsData(mapFieldObjWithValueByName(params, "TableFields", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  /* const mapObjWithNameAndRpaVar = (obj) => {
    return Object.keys(obj).map((key) => {
      return {
        Name: key,
        RPAVar: obj[key],
      };
    });
  };
  useEffect(() => {
    console.log(keyFieldsData);
    if (keyFieldsData.paramValue) {
      const varMapDataValueObj = JSON.parse(keyFieldsData.paramValue);
      if (typeof varMapDataValueObj === "object") {
        let newArray = mapObjWithNameAndRpaVar(varMapDataValueObj);
        console.log(newArray);
        setKeyFieldsList(newArray);
      }
    } else {
      setKeyFieldsList([]);
    }
  }, [keyFieldsData]);
  useEffect(() => {
    console.log(tableFieldsData);
    if (tableFieldsData.paramValue) {
      const varMapDataValueObj = JSON.parse(tableFieldsData.paramValue);
      if (typeof varMapDataValueObj === "object") {
        let newArray = mapObjWithNameAndRpaVar(varMapDataValueObj);
        console.log(newArray);
        setTableFieldsList(newArray);
      }
    } else {
      setTableFieldsList([]);
    }
  }, [tableFieldsData]);

  const getKeyFieldList = async () => {
    try {
      const axiosInstance = createInstance();
      if (oxServerValues) {
        const { oxServerUrl, token } = oxServerValues;

        const res = await axiosInstance.post(`${OMNIXTRACT_GET_FIELDS_LIST}`, {
          oxServerUrl,
          token,
          DocumentType: documentType.paramValue,
        });
        console.log(res);

        if (res.data.data) {
          const keyFields = res.data.data[0]?.KEYFIELDS || [];
          const tableFields = res.data.data[0]?.TABLEFIELDS || [];
          const keyFieldsWithMapStruct = keyFields.map((item) => {
            return { Name: item, RPAVar: "" };
          });
          const tableFieldsWithMapStruct = tableFields.map((item) => {
            return { Name: item, RPAVar: "" };
          });
          setKeyFieldsList(keyFieldsWithMapStruct);
          setTableFieldsList(tableFieldsWithMapStruct);
        }
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (err) => {
          setNotification({
            isOpen: true,
            title: "",
            message:
              "Unable To Fetch KeyFields/TableFields for this document definition.",
            notificationType: "ERROR",
          });
        },
      });
    }
  };
  useEffect(() => {
    if (documentType.paramValue) {
      if (docList.length > 0) {
        getKeyFieldList();
      }
    }
  }, [documentType]);*/

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "DocumentDefinition":
        const docVal = docList.find((proc) => proc.value == value);
        if (docVal) {
          setDocumentType((prevState) => ({
            ...prevState,
            paramValue: docVal?.value,
          }));
        } else {
          setDocumentType((prevState) => ({ ...prevState, paramValue: value }));
        }
        break;
      case "FileSource":
        setFilePath((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "ExtractedData":
        setExtractedData((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StatusCode":
        setStatusCode((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StrLanguage":
        setStrLanguage((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "StrPageRange":
        setStrPageRange((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };
  const handleClose = () => {
    setOpenModal(false);
  };
  const onClick1 = () => {
    console.log("close clicked");
    handleClose();
  };
  const onClick2 = () => {
    console.log("Okay clicked");
    handleClose();
  };
  /*const handleCloseColumn = (index) => {
    setOpenRole(index);
  };
  const handleOpenColumn = (index) => {
    setOpenRole(index);
  };
  const handleCloseColumn1 = (index) => {
    setOpenRole1(index);
  };
  const handleOpenColumn1 = (index) => {
    setOpenRole1(index);
  };*/
  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "FileSource":
        setFilePath({ ...filePath, paramType: changeToValue });
        break;
      case "StrLanguage":
        setStrLanguage({ ...strLanguage, paramType: changeToValue });
        break;
      case "StrPageRange":
        setStrPageRange({ ...strPageRange, paramType: changeToValue });
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    documentType,
    filePath,
    extractedData,
    // keyFieldsList,
    //tableFieldsList,
    strLanguage,
    strPageRange,
    statusCode,
  ]);

  const updateParams = () => {
    const newDocTypeObj = {
      ...documentType,
      paramType: "C",
    };
    /* const mappedKeyFields = {};
    keyFieldsList.forEach((obj) => {
      mappedKeyFields[obj.Name] = obj.RPAVar;
    });

    const newKeyFieldsData = {
      ...keyFieldsData,
      // paramValue: Object.keys(mappedKeyFields).length > 0 ? JSON.stringify(mappedKeyFields) : null,
      paramValue: JSON.stringify(mappedKeyFields),
    };
    const mappedTableFields = {};
    tableFieldsList.forEach((obj) => {
      mappedTableFields[obj.Name] = obj.RPAVar;
    });

    const newTableFieldsData = {
      ...tableFieldsData,
      // paramValue: Object.keys(mappedTableFields).length > 0 ? JSON.stringify(mappedTableFields) : null,
      paramValue: JSON.stringify(mappedTableFields),
    };*/
    const allParams = [
      invisibleInLogs,
      filePath,
      newDocTypeObj,
      extractedData,
      // newKeyFieldsData,
      //newTableFieldsData,
      strLanguage,
      strPageRange,
      statusCode,
    ];

    addParamsToSelAct(allParams);
  };

  const getAllDocs = async () => {
    const axiosInstance = createInstance();
    if (oxServerValues) {
      setDocumentType({ ...documentType, paramType: "V" });
      const { oxServerUrl, token } = oxServerValues;
      try {
        let apiUrl =
          oxServerValues.version === 4
            ? OMNIXTRACT_GET_DOC_TYPE_4_VERSION
            : OMNIXTRACT_GET_DOC_TYPE;
        const res = await axiosInstance.post(apiUrl, {
          oxServerUrl,
          token,
        });
        console.log(JSON.parse(res.data?.data[0]));
        const output = JSON.parse(res.data?.data[0] || {});
        const docList1 = output["DoctypeList"] || [];

        if (docList1 instanceof Array) {
          const newdocList = docList1.map((item) => {
            return { name: item, value: item };
          });
          setDocList(newdocList);
        } else {
          console.log(docList1);
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (err) => {
            setNotification({
              isOpen: true,
              title: "",
              message: err || "Unable To Fetch Document Definitions.",
              notificationType: "ERROR",
            });
          },
        });
      }
    } else {
      setNotification({
        isOpen: true,
        title: "",
        message: "Please connect to extraction server.",
        notificationType: "ERROR",
      });
    }
  };

  /*const mapRPAWithKeyFields = (VarToBeMapped, RPAVar) => {
    let newVars = [...keyFieldsList];

    console.log(VarToBeMapped);
    const index = keyFieldsList.findIndex(
      (item) => item.Name === VarToBeMapped.Name
    );

    //now setting RPAVar to the selected process var
    if (index !== -1) {
      const newVar = { ...keyFieldsList[index], RPAVar: RPAVar };
      console.log(newVar);
      newVars.splice(index, 1, newVar);
      setKeyFieldsList(newVars);

      //setAllMapped([...allMapped, newVar]);
    } else {
      console.log("key field not found");
    }
  };*/
  /*const mapRPAWithTableFields = (VarToBeMapped, RPAVar) => {
    let newVars = [...tableFieldsList];

    console.log(VarToBeMapped);
    const index = tableFieldsList.findIndex(
      (item) => item.Name === VarToBeMapped.Name
    );

    //now setting RPAVar to the selected process var
    if (index !== -1) {
      const newVar = { ...tableFieldsList[index], RPAVar: RPAVar };
      console.log(newVar);
      newVars.splice(index, 1, newVar);
      setTableFieldsList(newVars);

      
    } else {
      console.log("table field not found");
    }
  };*/

  return (
    <>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={selectedActivity.description || "Get Extracted Data"}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        <Grid container direction="column" spacing={1}>
          {oxServerValues && selectedTab === "input" && (
            <>
              <Grid item>
                <Typography component="h5" className={classes.GroupTitle}>
                  SERVER
                </Typography>
              </Grid>
              <Grid item>
                <Grid container direction="column" spacing={1}>
                  <Grid item container direction="row">
                    <Grid item xs={3}>
                      <Typography component="h5" className={classes.label}>
                        Version :
                      </Typography>
                    </Grid>
                    <Grid item xs>
                      <Typography component="h5">
                        {oxServerValues.version || ""}
                      </Typography>
                    </Grid>
                  </Grid>
                  <Grid item container direction="row">
                    <Grid item xs={3}>
                      <Typography component="h5" className={classes.label}>
                        Server URL :
                      </Typography>
                    </Grid>
                    <Grid item xs>
                      <Typography component="h5">
                        {oxServerValues.oxServerUrl || ""}
                      </Typography>
                    </Grid>
                  </Grid>
                  {oxServerValues.version == 4 && (
                    <>
                      <Grid item container direction="row">
                        <Grid item xs={3}>
                          <Typography component="h5" className={classes.label}>
                            Client Id :
                          </Typography>
                        </Grid>
                        <Grid item xs>
                          <Typography component="h5">
                            {oxServerValues.clientId || ""}
                          </Typography>
                        </Grid>
                      </Grid>{" "}
                      <Grid item container direction="row">
                        <Grid item xs={3}>
                          <Typography component="h5" className={classes.label}>
                            Client Secret
                          </Typography>
                        </Grid>
                        <Grid item xs>
                          <Typography component="h5">
                            ******************...
                          </Typography>
                        </Grid>
                      </Grid>
                    </>
                  )}
                  {oxServerValues.version == 3.2 && (
                    <Grid item container>
                      <Grid item xs={3}>
                        <Typography component="h5" className={classes.label}>
                          API Key :
                        </Typography>
                      </Grid>
                      <Grid item xs>
                        <Typography
                          component="h5"
                          //title={oxServerValues.oxApiKey || ""}
                        >
                          {/*truncateString(oxServerValues.oxApiKey || "")*/}
                          ******************...
                        </Typography>
                      </Grid>
                    </Grid>
                  )}
                </Grid>
              </Grid>
            </>
          )}
        </Grid>
        {selectedTab === "input" ? (
          <Grid
            container
            direction="column"
            spacing={2}
            style={{ marginTop: oxServerValues ? "-30px" : "0px" }}
          >
            <Grid item>
              <Grid container alignItems="flex-end">
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    INPUT
                  </Typography>
                </Grid>
                {/*<Grid
                  item
                  style={{ marginLeft: "auto", cursor: "pointer" }}
                  onClick={() => getAllDocs()}
                >
                  <Typography className={classes.textColorPrimary}>
                    Fetch
                  </Typography>
                </Grid>*/}
              </Grid>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StrLanguage`}
                // dropdown={strLanguage.paramType === "V"}
                // paramObj={strLanguage}
                // labelBtn1OnClick={changeParamTypeToVorC}
                //labelBtn2OnClick={changeParamTypeToVorC}
                //options={getOptionsForVariable(strLanguage)}
                // labelBtn1={true}
                // labelBtn2={true}
                combo={true}
                readOnly={true}
                name="StrLanguage"
                label="Language"
                value={strLanguage.paramValue}
                onChange={handleChange}
              />
            </Grid>
            <Grid item>
              <Grid container direction="column" alignItems="flex-start">
                <Grid
                  item
                  style={{
                    marginLeft: "auto",
                    cursor: "pointer",
                    marginBottom: "-15px",
                    zIndex: 1,
                  }}
                  onClick={() => getAllDocs()}
                  tabIndex={0}
                  onKeyPress={(e) => e.key === "Enter" && getAllDocs()}
                  role="button"
                  aria-label="Fetch"
                  id={`${props.id}_FetchBtn`}
                >
                  <Typography className={classes.textColorPrimary}>
                    Fetch
                  </Typography>
                </Grid>
                <Grid item style={{ width: "100%" }}>
                  <PropertyField
                    id={`${props.id}_DocumentDef`}
                    combo={true}
                    dropdown={documentType.paramType === "V"}
                    readOnly={documentType.paramType === "C"}
                    name="DocumentDefinition"
                    label="Document Definition"
                    value={documentType.paramValue || ""}
                    onChange={handleChange}
                    options={docList}
                    error={
                      vaildateParamValue(documentType.paramValue.toString())
                        .errorStatus
                    }
                    helperText={
                      vaildateParamValue(documentType.paramValue.toString()).msg
                    }
                  />
                </Grid>
              </Grid>
            </Grid>
            <Grid item>
              <Button
                variant="contained"
                color="primary"
                onClick={() => setOpenModal(true)}
                disabled={!documentType.paramValue}
                id={`${props.id}_TextExtraction`}
                disableRipple
              >
                <Typography className={classes.btn_title}>
                  Test Extraction
                </Typography>
              </Button>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_FileSource`}
                combo={true}
                dropdown={filePath.paramType === "V"}
                paramObj={filePath}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(filePath)}
                labelBtn1={true}
                labelBtn2={true}
                name="FileSource"
                label="File Source"
                value={filePath.paramValue}
                onChange={handleChange}
                error={
                  vaildateParamValue(filePath.paramValue.toString()).errorStatus
                }
                helperText={
                  vaildateParamValue(filePath.paramValue.toString()).msg
                }
              />
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_StrPageRange`}
                combo={true}
                dropdown={strPageRange.paramType === "V"}
                paramObj={strPageRange}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(strPageRange)}
                labelBtn1={true}
                labelBtn2={true}
                name="StrPageRange"
                label="Page Range"
                value={strPageRange.paramValue}
                onChange={handleChange}
                error={
                  vaildateParamValue(strPageRange.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(strPageRange.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_ExtractedData`}
                combo={true}
                dropdown={true}
                paramObj={extractedData}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="ExtractedData"
                label={`Extracted Data (${getVariableTypeById(
                  extractedData.paramObjectTypeId
                )})`}
                value={extractedData.paramValue}
                options={getOptionsForVariable(extractedData)}
                onChange={handleChange}
                //helperText="List of Extracted pages."
                error={
                  vaildateParamValue(extractedData.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(extractedData.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_StatusCode`}
                combo={true}
                dropdown={true}
                paramObj={statusCode}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="StatusCode"
                label={`Status Code (${getVariableTypeById(
                  statusCode.paramObjectTypeId
                )})`}
                value={statusCode.paramValue}
                options={getOptionsForVariable(statusCode)}
                onChange={handleChange}
                error={
                  vaildateParamValue(statusCode.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(statusCode.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
      <ModalForm
        id={`${props.id}_TextExtraction`}
        isOpen={openModal}
        title="Test Extraction"
        Content={
          <ExtractionModal
            id={`${props.id}_TextExtraction`}
            doucmentDef={documentType.paramValue}
            pageRange={strPageRange.paramValue}
            lang={strLanguage.paramValue}
          />
        }
        btn1Title="Close"
        btn2Title="Okay"
        onClick1={onClick1}
        onClick2={onClick2}
        closeModal={handleClose}
        containerHeight={650}
        containerWidth={950}
      />
    </>
  );
};

export default ExtractionWindow;
const ExtractionModal = ({ doucmentDef, pageRange, lang, id }) => {
  const classes = useStyles();

  pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

  const history = useHistory();
  const { setValue: setNotification } = useContext(NotificationContext);
  const hiddenFileInput = useRef(null);
  const imgRef = useRef(null);
  const parentRef = useRef(null);
  const oxServerValues = useSelector(
    (state) => state.propertyWindow.oxServerValues
  );

  //file type for tiff image 1,for pdf 2
  const [fileName, setFileName] = useState("");
  const [fileType, setFileType] = useState("");
  const [numOfPages, setNumOfPages] = useState(0);
  const [currPage, setCurrPage] = useState(0);
  const [pageTab, setPageTab] = useState(0);

  const [selTab, setSelTab] = useState("Key Fields");
  const [fileSelected, setFileSelected] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [result, setResult] = useState(dummyData[0]);

  const [imgStyle, setImageStyle] = useState({
    height: "620",
    width: "100%",
  });

  const [pdfStyle, setPdfStyle] = useState({
    height: "800",
    width: "600",
  });

  const handleZoomIn = () => {
    // Fetching current height and width
    console.log(imgRef);
    const height = imgRef?.current?.clientHeight;
    const width = imgRef?.current?.clientWidth;
    if (fileType === 1) {
      // Increase dimension(Zooming)
      setImageStyle({
        height: height + 15,
        width: width + 25,
      });
    } else if (fileType === 2) {
      setPdfStyle({
        height: height + 15,
        width: width + 25,
      });
    }
  };
  const handleZoomOut = () => {
    const height = imgRef?.current?.clientHeight;
    const width = imgRef?.current?.clientWidth;

    if (fileType === 1) {
      if (height > 615) {
        setImageStyle({
          height: height - 15,
          width: width - 25,
        });
      }
    } else if (fileType === 2) {
      if (height > 300) {
        setPdfStyle({
          height: height - 15,
          width: width - 25,
        });
      }
    }
  };
  const fitToWidth = () => {};

  const handleFileInput = (e) => {
    console.log(e);

    if (hiddenFileInput) {
      hiddenFileInput.current.click();
    }
  };

  const handleTiffImages = (selectedFile) => {
    const reader = new FileReader();
    reader.readAsArrayBuffer(selectedFile);
    reader.addEventListener("load", () => {
      const arrayBuffer = reader.result;

      Tiff.initialize({ TOTAL_MEMORY: 16777216 * 10 });
      const tiff = new Tiff({ buffer: arrayBuffer });

      setNumOfPages(tiff.countDirectory());
      setCurrPage(1);
      tiff.setDirectory(1);

      const dataURL = tiff.toDataURL();

      setPreviewUrl(dataURL);
    });
  };
  const handlePdfFiles = (selectedFile) => {
    const reader = new FileReader();
    reader.readAsDataURL(selectedFile);
    reader.addEventListener("load", () => {
      const base64Url = reader.result;

      setPreviewUrl(base64Url);
      setCurrPage(1);
    });
  };
  // to handle the user-selected file
  const handleChangeFile = (event) => {
    const selectedFile = event.target.files[0];

    if (selectedFile) {
      setFileName(selectedFile.name);
      setFileSelected(selectedFile);
      setImageStyle({
        height: "620",
        width: "100%",
      });
      setPdfStyle({
        height: "800",
        width: "600",
      });
      if (selectedFile.type === "image/tiff") {
        handleTiffImages(selectedFile);
        setFileType(1);
      } else if (selectedFile.type === "application/pdf") {
        handlePdfFiles(selectedFile);
        setFileType(2);
      }
    }
  };
  const isButtonDisable = () => {
    if (!fileSelected || !doucmentDef) {
      return true;
    }
    return false;
  };
  const handleTestExtraction = async () => {
    const fileData = new FormData();
    try {
      const apiUrl =
        oxServerValues.version === 4
          ? OMNIXTRACT_EXTRACT_DOCUMENT_4_VERSION
          : OMNIXTRACT_EXTRACT_DOCUMENT;
      if (oxServerValues) {
        setIsProcessing(true);

        const axiosInstance = createInstance();
        const { oxServerUrl, token } = oxServerValues;
        fileData.append("file", fileSelected);
        fileData.append("oXDocTypeName", doucmentDef);

        fileData.append("oxServerUrl", oxServerUrl);
        fileData.append("token", token);

        fileData.append("strLanguage", lang);
        //fileData.append("strPageRange", `${1}-${numOfPages}`);
        fileData.append("strPageRange", `${pageRange || 1}`);

        const config = {
          headers: {
            "content-type": "multipart/form-data",
          },
        };

        const res = await axiosInstance.post(apiUrl, fileData, config);
        console.log(res);
        if (res.status === 200) {
          const resData = res.data?.data && res.data.data[0];
          if (resData) {
            setResult(resData);
          }
          setIsProcessing(false);
          setIsSuccess(true);
        }
      } else {
        setNotification({
          isOpen: true,
          title: "",
          message: "Please Connect To Extraction Server.",
          notificationType: "ERROR",
        });
      }
    } catch (error) {
      console.log(error);
      handleNetworkRequestError({
        error,
        history,
        onError: (err) => {
          setNotification({
            isOpen: true,
            title: "",
            message: err || "Unable To Extract Data.",
            notificationType: "ERROR",
          });
        },
      });
      setIsProcessing(false);
    }
  };
  /*const handleSearchData = () => {
    console.log("search");
  };
  const handleTabChange = (tab) => {
    setSelTab(tab);
  };*/
  const increamentCurrPage = () => {
    if (currPage < numOfPages) {
      if (fileType === 1) {
        const reader = new FileReader();
        reader.readAsArrayBuffer(fileSelected);
        reader.addEventListener("load", () => {
          const arrayBuffer = reader.result;

          Tiff.initialize({ TOTAL_MEMORY: 16777216 * 10 });
          const tiff = new Tiff({ buffer: arrayBuffer });

          tiff.setDirectory(currPage + 1);
          const dataURL = tiff.toDataURL();
          setPreviewUrl(dataURL);
        });
      }
      setCurrPage(currPage + 1);
    }
  };
  const decreamentCurrPage = () => {
    if (currPage > 1) {
      if (fileType === 1) {
        const reader = new FileReader();
        reader.readAsArrayBuffer(fileSelected);
        reader.addEventListener("load", () => {
          const arrayBuffer = reader.result;

          Tiff.initialize({ TOTAL_MEMORY: 16777216 * 10 });
          const tiff = new Tiff({ buffer: arrayBuffer });

          tiff.setDirectory(currPage - 1);
          const dataURL = tiff.toDataURL();
          setPreviewUrl(dataURL);
        });
      }
      setCurrPage(currPage - 1);
    }
  };
  const onDocumentLoadSuccess = (epdf) => {
    console.log(`Number of pages: ${epdf.numPages}`);

    setNumOfPages(epdf?.numPages || 1);
  };

  /*const handlePageChange = (e) => {
    console.log(e);
    setCurrPage(e.currentPage + 1);
  };
  const handlePageTabChange = (tab) => {
    setPageTab(tab);
  };*/
  //console.log(totalPagesData[pageTab]);
  if (oxServerValues) {
    //if (true) {
    return (
      <div style={{ marginTop: "16px" }}>
        <Grid container spacing={2}>
          <Grid item xs={7}>
            <input
              aria-label="inputFile"
              name="inputFile"
              id="inputFile"
              type="file"
              ref={hiddenFileInput}
              onChange={handleChangeFile}
              style={{
                display: "none",
              }} /* Make the file input element invisible */
            />
            <Grid container direction="column" spaicng={1}>
              <Grid item>
                <PropertyField
                  id={`${id}_sampleDoc`}
                  btnIcon={
                    <FolderOpen
                      className={classes.btnIcon + " " + classes.colorPrimary}
                      onClick={(e) => handleFileInput(e)}
                    />
                  }
                  name="sampleDoc"
                  label="Sample File"
                  value={fileName}
                  readOnly={true}
                  btnIconDefaultHandler={true}
                />
              </Grid>
              <Grid item>
                <div
                  style={{
                    height: "480px",
                    marginTop: "3px",
                    width: "100%",
                    border: "1px solid #e6e1e1",
                    paddingTop: "10px",
                    // paddingBottom: "10px",
                    alignItems: "center",
                    position: "relative",
                  }}
                >
                  {previewUrl && (
                    <div
                      style={{
                        height: "30px",
                        backgroundColor: "#e6e1e1",
                        width: "100%",
                        marginTop: "15px",
                        marginBottom: "15px",
                        padding: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      <Grid
                        item
                        container
                        spacing={1}
                        justifyContent="center"
                        alignContent="center"
                        style={{
                          backgroundColor: "#FFFFFF",
                          borderTopLeftRadius: "50px",
                          borderTopRightRadius: "50px",
                          borderBottomLeftRadius: "50px",
                          borderBottomRightRadius: "50px",
                          width: "100px",
                          marginRight: "12px",
                          height: "22px",
                        }}
                      >
                        <Grid item>
                          <SkipPreviousOutlined
                            onClick={decreamentCurrPage}
                            style={{
                              height: "16px",
                              width: "16px",
                              cursor: "pointer",
                            }}
                          />
                        </Grid>
                        <Grid item>
                          <Typography component="h5">
                            {currPage}/{numOfPages}
                          </Typography>
                        </Grid>
                        <Grid item>
                          <SkipNextOutlined
                            onClick={increamentCurrPage}
                            style={{
                              height: "16px",
                              width: "16px",
                              cursor: "pointer",
                            }}
                          />
                        </Grid>
                      </Grid>
                      <ZoomInOutlined
                        className={classes.btnIcon}
                        onClick={() => handleZoomIn()}
                        onKeyPress={(e) => e.key === "Enter" && handleZoomIn()}
                        tabIndex={0}
                      />
                      <ZoomOutOutlined
                        className={classes.btnIcon}
                        onClick={() => handleZoomOut()}
                        onKeyPress={(e) => e.key === "Enter" && handleZoomOut()}
                        tabIndex={0}
                      />
                    </div>
                  )}
                  <div
                    style={{
                      // marginTop: fileType === 1 ? "10px" : "0px",
                      // height: fileType === 1 ? "390px" : "430px",
                      marginTop: "10px",
                      height: "410px",

                      width: "100%",
                      display: "flex",
                      // padding: "10px",
                      // overflow: fileType === 1 ? "scroll" : "hidden",
                      overflow: "scroll",
                      alignItems: "flex-start",
                      justifyContent: "flex-start",

                      // position: "relative",
                      position: "absolute",
                      //  top: fileType === 1 ? "50px" : "0px",
                      top: "50px",

                      left: 0,
                    }}
                    ref={parentRef}
                  >
                    {previewUrl && fileType === 1 && (
                      <img
                        ref={imgRef}
                        src={previewUrl}
                        style={{
                          height: imgStyle.height,
                          width: imgStyle.width,
                          // position: "absolute",
                        }}
                        alt="Preview Icon"
                      />
                    )}
                    {previewUrl && fileType === 2 && (
                      <Document
                        //  options={{ workerSrc: "/pdf.worker.js" }}
                        file={previewUrl}
                        onLoadSuccess={onDocumentLoadSuccess}
                      >
                        <Page
                          pageNumber={currPage}
                          size="A4"
                          height={pdfStyle.height}
                          width={pdfStyle.width}
                          inputRef={imgRef}
                        />
                      </Document>
                    )}
                  </div>
                </div>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs style={{ overflowX: "scroll" }}>
            <Grid container direction="column" spaicng={1}>
              <Grid item container>
                <Grid item container direction="column" spacing={1} xs={5}>
                  <Grid item>
                    <Typography className={classes.label}>
                      Document Definition
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography component="h6">
                      {truncateString(doucmentDef || "")}
                    </Typography>
                  </Grid>
                </Grid>
                <Grid
                  item
                  container
                  direction="row"
                  spacing={1}
                  xs
                  justifyContent="flex-end"
                >
                  {isSuccess && (
                    <Grid item>
                      <Typography style={{ color: "green" }}>
                        Success
                      </Typography>
                    </Grid>
                  )}
                  {isProcessing && (
                    <>
                      <Grid item>
                        <Typography className={classes.textColorPrimary}>
                          Extracting..
                          <LoadingIndicator
                            color="#4ef542"
                            height="20px"
                            width="20px"
                          />
                        </Typography>
                      </Grid>
                    </>
                  )}

                  <Grid item>
                    <Button
                      variant="contained"
                      color="primary"
                      onClick={() => handleTestExtraction()}
                      disabled={isButtonDisable()}
                      disableRipple
                    >
                      <Typography className={classes.btn_title}>
                        Test
                      </Typography>
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item container>
                <div
                  style={{
                    height: "480px",
                    marginTop: doucmentDef ? "10px" : "24px",
                    width: "100%",
                    border: "1px solid #e6e1e1",
                    padding: "10px",
                    overflowY: "scroll",
                  }}
                >
                  <Grid container direction="column" spacing={1}>
                    <Grid item>
                      <Typography
                        component="h4"
                        style={{ fontSize: "14px", fontWeight: 600 }}
                      >
                        Field Details
                      </Typography>
                    </Grid>
                    {result && isSuccess ? (
                      <Grid item>
                        <pre>{JSON.stringify(result, null, 2)}</pre>
                      </Grid>
                    ) : (
                      /*<>
                        <Grid item xs={5} style={{ marginBottom: "10px" }}>
                          <CustomTabs
                            selectedTab={selTab}
                            tabItems={["Key Fields", "Table Fields"]}
                            handleTabChange={handleTabChange}
                          />
                        </Grid>
                        <Grid item>
                          <Grid container direction="column" spacing={2}>
                            <Grid item>
                              <SearchBox
                                width="250px"
                                onSearchChange={handleSearchData}
                              />
                            </Grid>
                          </Grid>
                        </Grid>
                        {selTab === "Key Fields" &&
                          totalPagesData[pageTab]["KeyField"].map((item) => (
                            <Grid item>
                              <Grid container spacing={2}>
                                <Grid item xs={4}>
                                  <Typography className={classes.label}>
                                    {item.FN || ""}
                                  </Typography>
                                </Grid>
                                <Grid item xs>
                                  <Typography>{item.FD || ""}</Typography>
                                </Grid>
                              </Grid>
                            </Grid>
                          ))}
                        {selTab === "Table Fields" &&
                          totalPagesData[pageTab]["TableField"].map((obj) => {
                            return (
                              <div
                                style={{
                                  display: "inline-table",
                                  padding: "10px",
                                }}
                              >
                                {obj["FieldData"].map((item, index) => (
                                  <div
                                    style={{
                                      display: "table-cell",
                                      // paddingLeft: "10px",
                                      padding: "5px",
                                    }}
                                  >
                                    <Grid
                                      container
                                      direction="column"
                                      spacing={2}
                                    >
                                      <Grid item xs={6}>
                                        <Typography className={classes.label}>
                                          {item.FN || ""}
                                        </Typography>
                                      </Grid>
                                      <Grid item xs>
                                        <Grid
                                          container
                                          direction="column"
                                          spacing={2}
                                        >
                                          {item.Row.map((row, i) => (
                                            <Grid item xs key={i}>
                                              <Typography>
                                                {row.RD || ""}
                                              </Typography>
                                            </Grid>
                                          ))}
                                        </Grid>
                                      </Grid>
                                    </Grid>
                                  </div>
                                ))}
                              </div>
                            );
                          })}
                        {selTab === "Table Fields" &&
                          totalPagesData[pageTab]["TableField"] && (
                            <Grid item style={{ marginTop: "10px" }}>
                              <Pagination
                                numberOfPages={totalPagesData.length}
                                selectedPage={pageTab}
                                handleOpenPage={handlePageTabChange}
                              />
                            </Grid>
                          )}
                          </>*/
                      <Grid item>
                        <Typography component="div">
                          Click on{"    "} Test button
                          {/* <Button
                            variant="contained"
                            color="primary"
                            onClick={() => handleTestExtraction()}
                            disabled={isButtonDisable()}
                          >
                            <Typography className={classes.btn_title}>
                              Test
                            </Typography>
                         </Button>*/}
                          {"    "}
                          to extract
                        </Typography>
                      </Grid>
                    )}
                  </Grid>
                </div>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </div>
    );
  }
  return (
    <div style={{ marginTop: "16px" }}>
      <Typography>Please Connect to Extraction Server.</Typography>
    </div>
  );
};

const extractedDataDummy = {
  /* vendorName: "Newgen Software",
  invoiceDate: "21/10/16",
  PAN: "FGTR7887H",
  "P.O Number": "g18293",
  Address: "ABhijay Enterprise,Tower E,sector 174,Noida,Uttar Pradesh 201303",
  Fax: "+91-11-2023 4411",*/
};
/**
 *  {keyFieldsList.length > 0 && (
              <>
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    Key Fields
                  </Typography>
                </Grid>
                {keyFieldsList.map((key, index) => (
                  <Grid
                    item
                    container
                    className={classes.padding}
                    spacing={2}
                    key={index}
                  >
                    <Grid item xs={5}>
                      <Typography className={classes.text_12}>
                        {truncateString(key.Name)}
                      </Typography>
                    </Grid>

                    <Grid item xs>
                      <Select
                        native
                        variant="outlined"
                        fullWidth={true}
                        className={classes.input}
                        value={key.RPAVar ? key.RPAVar : ""}
                        onChange={(e) => {
                          mapRPAWithKeyFields(key, e.target.value);
                        }}
                        open={openRole === index}
                        onClose={() => handleCloseColumn(index)}
                        onOpen={() => handleOpenColumn(index)}
                        SelectDisplayProps={{ shrink: true }}
                        style={{ width: "190px" }}
                      >
                        <option value="" hidden selected>
                          -Select-
                      </option>*/
{
  /*****************************************************************************************
   * @author asloob.ali BUG ID : 101111  Description :  iBPS activity: Variable Mapping - RPA variable list should show only the variable matching with Process variable data types
   *  Resolution : now filtering rpa variables on the bases of type of process variable
   *  Date : 16/09/2021             ***************************************************************************************/
}
{
  /*allVariables &&
                          allVariables
                            .filter(
                              (item) => item.variableObjType === 1 //only string variables can be mapped
                            )
                            .map((obj) => {
                              return {
                                name: obj.variableName,
                                value: obj.variableName,
                              };
                            })
                            .map((item) => (
                              <option value={item.value} key={item.name}>
                                {item.name}
                              </option>
                            ))}
                      </Select>
                    </Grid>
                  </Grid>
                ))}
              </>
                            )}
            {tableFieldsList.length > 0 && (
              <>
                <Grid item>
                  <Typography component="h5" className={classes.GroupTitle}>
                    Table Fields
                  </Typography>
                </Grid>
                {tableFieldsList.map((key, index) => (
                  <Grid
                    item
                    container
                    className={classes.padding}
                    spacing={2}
                    key={index}
                  >
                    <Grid item xs={5}>
                      <Typography className={classes.text_12}>
                        {truncateString(key.Name)}
                      </Typography>
                    </Grid>

                    <Grid item xs>
                      <Select
                        native
                        variant="outlined"
                        fullWidth={true}
                        className={classes.input}
                        value={key.RPAVar ? key.RPAVar : ""}
                        onChange={(e) => {
                          mapRPAWithTableFields(key, e.target.value);
                        }}
                        open={openRole1 === index}
                        onClose={() => handleCloseColumn1(index)}
                        onOpen={() => handleOpenColumn1(index)}
                        SelectDisplayProps={{ shrink: true }}
                        style={{ width: "190px" }}
                      >
                        <option value="" hidden selected>
                          -Select-
                        </option>
                      
                        {allVariables &&
                          allVariables
                            .filter(
                              (item) => item.variableObjType === 6 //only dataTable variables can be mapped
                            )
                            .map((obj) => {
                              return {
                                name: obj.variableName,
                                value: obj.variableName,
                              };
                            })
                            .map((item) => (
                              <option value={item.value} key={item.name}>
                                {item.name}
                              </option>
                            ))}
                      </Select>
                    </Grid>
                  </Grid>
                ))}
              </>
            )}
                            */
}
const dummyData = [
  {
    NUM: null,
    ERRORCODE: null,
    KeyField: [
      {
        LineData: null,
        ID: "32",
        FCO: "87",
        FN: null,
        FC: "297,1656,555,2958",
        CN: "0",
        LegendCoords: "0,0,0,0",
        MatchedLegend: null,
        RuleID: "32",
        LookupID: null,
        TimeStamp: null,
        FD: null,
        CI: null,
      },
      {
        LineData: null,
        ID: "31",
        FCO: "87",
        FN: "invoicedate",
        FC: "2067,942,2273,1003",
        CN: "10",
        LegendCoords: "1712,941,2001,1002",
        MatchedLegend: "INVOICE DATE",
        RuleID: "31",
        LookupID: null,
        TimeStamp: "2021-12-09 12:37:51",
        FD: "21/10/2016",
        CI: null,
      },
    ],
    TableField: [
      {
        FieldData: [
          {
            ID: "33",
            FCO: "88",
            FN: "date",
            FC: "297,2898,555,2958",
            CN: "0",
            RuleID: "33",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "305,1656,508,1717",
                RCO: "305,1656,508,1717",
                RD: "14/10/2016",
              },
              {
                NUM: "2",
                RC: "305,1943,508,2004",
                RCO: "305,1943,508,2004",
                RD: "14/10/2016",
              },
              {
                NUM: "3",
                RC: "305,2231,508,2292",
                RCO: "305,2231,508,2292",
                RD: "17/10/2016",
              },
              {
                NUM: "4",
                RC: "305,2518,508,2579",
                RCO: "305,2518,508,2579",
                RD: "17/10/2016",
              },
              {
                NUM: "5",
                RC: "297,2898,555,2958",
                RCO: "297,2898,555,2958",
                RD: "011 26963571",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1656,708,1719",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "571,1656,708,1719",
                RCO: "571,1656,708,1719",
                RD: "16972S",
              },
              {
                NUM: "2",
                RC: "571,1943,706,2003",
                RCO: "571,1943,706,2003",
                RD: "12344F",
              },
              {
                NUM: "3",
                RC: "571,2231,709,2291",
                RCO: "571,2231,709,2291",
                RD: "12346H",
              },
              {
                NUM: "4",
                RC: "571,2518,690,2578",
                RCO: "571,2518,690,2578",
                RD: "134561",
              },
              {
                NUM: "5",
                RC: "545,2898,555,2958",
                RCO: "545,2898,555,2958",
                RD: "1",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1655,1386,1714",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "836,1655,1386,1714",
                RCO: "836,1655,1386,1714",
                RD: "Delivery from Scalzo Foods to",
              },
              {
                NUM: "2",
                RC: "836,1942,1386,2001",
                RCO: "836,1942,1386,2001",
                RD: "Delivery from Scalzo Foods to",
              },
              {
                NUM: "3",
                RC: "836,2230,1485,2287",
                RCO: "836,2230,1485,2287",
                RD: "From Enzyme Solutions to Unilever",
              },
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
        ],
      },

      /*  {
        FieldData: [
          {
            ID: "33",
            FCO: "88",
            FN: "date",
            FC: "297,2898,555,2958",
            CN: "0",
            RuleID: "33",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "305,1656,508,1717",
                RCO: "305,1656,508,1717",
                RD: "14/10/2016",
              },
              {
                NUM: "2",
                RC: "305,1943,508,2004",
                RCO: "305,1943,508,2004",
                RD: "14/10/2016",
              },
              {
                NUM: "3",
                RC: "305,2231,508,2292",
                RCO: "305,2231,508,2292",
                RD: "17/10/2016",
              },
              {
                NUM: "4",
                RC: "305,2518,508,2579",
                RCO: "305,2518,508,2579",
                RD: "17/10/2016",
              },
              {
                NUM: "5",
                RC: "297,2898,555,2958",
                RCO: "297,2898,555,2958",
                RD: "011 26963571",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1656,708,1719",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "571,1656,708,1719",
                RCO: "571,1656,708,1719",
                RD: "16972S",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1943,706,2003",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "571,1943,706,2003",
                RCO: "571,1943,706,2003",
                RD: "12344F",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2231,709,2291",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "571,2231,709,2291",
                RCO: "571,2231,709,2291",
                RD: "12346H",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2518,690,2578",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "571,2518,690,2578",
                RCO: "571,2518,690,2578",
                RD: "134561",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "545,2898,555,2958",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "5",
                RC: "545,2898,555,2958",
                RCO: "545,2898,555,2958",
                RD: "1",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1655,1386,1714",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "836,1655,1386,1714",
                RCO: "836,1655,1386,1714",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1942,1386,2001",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "836,1942,1386,2001",
                RCO: "836,1942,1386,2001",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2230,1485,2287",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "836,2230,1485,2287",
                RCO: "836,2230,1485,2287",
                RD: "From Enzyme Solutions to Unilever",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
        ],
      },
    ],
  },
  {
    NUM: null,
    ERRORCODE: null,
    KeyField: [
      {
        LineData: null,
        ID: "32",
        FCO: "87",
        FN: null,
        FC: "297,1656,555,2958",
        CN: "0",
        LegendCoords: "0,0,0,0",
        MatchedLegend: null,
        RuleID: "32",
        LookupID: null,
        TimeStamp: null,
        FD: null,
        CI: null,
      },
      {
        LineData: null,
        ID: "31",
        FCO: "87",
        FN: "invoicedate",
        FC: "2067,942,2273,1003",
        CN: "10",
        LegendCoords: "1712,941,2001,1002",
        MatchedLegend: "INVOICE DATE",
        RuleID: "31",
        LookupID: null,
        TimeStamp: "2021-12-09 12:37:51",
        FD: "21/10/2016",
        CI: null,
      },
    ],
    TableField: [
      {
        FieldData: [
          {
            ID: "33",
            FCO: "88",
            FN: "date",
            FC: "297,2898,555,2958",
            CN: "0",
            RuleID: "33",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "305,1656,508,1717",
                RCO: "305,1656,508,1717",
                RD: "14/10/2016",
              },
              {
                NUM: "2",
                RC: "305,1943,508,2004",
                RCO: "305,1943,508,2004",
                RD: "14/10/2016",
              },
              {
                NUM: "3",
                RC: "305,2231,508,2292",
                RCO: "305,2231,508,2292",
                RD: "17/10/2016",
              },
              {
                NUM: "4",
                RC: "305,2518,508,2579",
                RCO: "305,2518,508,2579",
                RD: "17/10/2016",
              },
              {
                NUM: "5",
                RC: "297,2898,555,2958",
                RCO: "297,2898,555,2958",
                RD: "011 26963571",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1656,708,1719",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "571,1656,708,1719",
                RCO: "571,1656,708,1719",
                RD: "16972S",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1943,706,2003",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "571,1943,706,2003",
                RCO: "571,1943,706,2003",
                RD: "12344F",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2231,709,2291",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "571,2231,709,2291",
                RCO: "571,2231,709,2291",
                RD: "12346H",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2518,690,2578",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "571,2518,690,2578",
                RCO: "571,2518,690,2578",
                RD: "134561",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "545,2898,555,2958",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "5",
                RC: "545,2898,555,2958",
                RCO: "545,2898,555,2958",
                RD: "1",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1655,1386,1714",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "836,1655,1386,1714",
                RCO: "836,1655,1386,1714",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1942,1386,2001",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "836,1942,1386,2001",
                RCO: "836,1942,1386,2001",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2230,1485,2287",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "836,2230,1485,2287",
                RCO: "836,2230,1485,2287",
                RD: "From Enzyme Solutions to Unilever",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
        ],
      },
      {
        FieldData: [
          {
            ID: "33",
            FCO: "88",
            FN: "date",
            FC: "297,2898,555,2958",
            CN: "0",
            RuleID: "33",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "305,1656,508,1717",
                RCO: "305,1656,508,1717",
                RD: "14/10/2016",
              },
              {
                NUM: "2",
                RC: "305,1943,508,2004",
                RCO: "305,1943,508,2004",
                RD: "14/10/2016",
              },
              {
                NUM: "3",
                RC: "305,2231,508,2292",
                RCO: "305,2231,508,2292",
                RD: "17/10/2016",
              },
              {
                NUM: "4",
                RC: "305,2518,508,2579",
                RCO: "305,2518,508,2579",
                RD: "17/10/2016",
              },
              {
                NUM: "5",
                RC: "297,2898,555,2958",
                RCO: "297,2898,555,2958",
                RD: "011 26963571",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1656,708,1719",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "571,1656,708,1719",
                RCO: "571,1656,708,1719",
                RD: "16972S",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1943,706,2003",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "571,1943,706,2003",
                RCO: "571,1943,706,2003",
                RD: "12344F",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2231,709,2291",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "571,2231,709,2291",
                RCO: "571,2231,709,2291",
                RD: "12346H",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2518,690,2578",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "571,2518,690,2578",
                RCO: "571,2518,690,2578",
                RD: "134561",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "545,2898,555,2958",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "5",
                RC: "545,2898,555,2958",
                RCO: "545,2898,555,2958",
                RD: "1",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1655,1386,1714",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "836,1655,1386,1714",
                RCO: "836,1655,1386,1714",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1942,1386,2001",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "836,1942,1386,2001",
                RCO: "836,1942,1386,2001",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2230,1485,2287",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "836,2230,1485,2287",
                RCO: "836,2230,1485,2287",
                RD: "From Enzyme Solutions to Unilever",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
        ],
      },*/
    ],
  },
  {
    NUM: null,
    ERRORCODE: null,
    KeyField: [
      {
        LineData: null,
        ID: "32",
        FCO: "87",
        FN: null,
        FC: "297,1656,555,2958",
        CN: "0",
        LegendCoords: "0,0,0,0",
        MatchedLegend: null,
        RuleID: "32",
        LookupID: null,
        TimeStamp: null,
        FD: null,
        CI: null,
      },
      {
        LineData: null,
        ID: "31",
        FCO: "87",
        FN: "invoicedate",
        FC: "2067,942,2273,1003",
        CN: "10",
        LegendCoords: "1712,941,2001,1002",
        MatchedLegend: "INVOICE DATE",
        RuleID: "31",
        LookupID: null,
        TimeStamp: "2021-12-09 12:37:51",
        FD: "21/10/2016",
        CI: null,
      },
    ],
    TableField: [
      {
        FieldData: [
          {
            ID: "33",
            FCO: "88",
            FN: "date",
            FC: "297,2898,555,2958",
            CN: "0",
            RuleID: "33",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "305,1656,508,1717",
                RCO: "305,1656,508,1717",
                RD: "14/10/2016",
              },
              {
                NUM: "2",
                RC: "305,1943,508,2004",
                RCO: "305,1943,508,2004",
                RD: "14/10/2016",
              },
              {
                NUM: "3",
                RC: "305,2231,508,2292",
                RCO: "305,2231,508,2292",
                RD: "17/10/2016",
              },
              {
                NUM: "4",
                RC: "305,2518,508,2579",
                RCO: "305,2518,508,2579",
                RD: "17/10/2016",
              },
              {
                NUM: "5",
                RC: "297,2898,555,2958",
                RCO: "297,2898,555,2958",
                RD: "011 26963571",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1656,708,1719",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "571,1656,708,1719",
                RCO: "571,1656,708,1719",
                RD: "16972S",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1943,706,2003",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "571,1943,706,2003",
                RCO: "571,1943,706,2003",
                RD: "12344F",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2231,709,2291",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "571,2231,709,2291",
                RCO: "571,2231,709,2291",
                RD: "12346H",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2518,690,2578",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "571,2518,690,2578",
                RCO: "571,2518,690,2578",
                RD: "134561",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "545,2898,555,2958",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "5",
                RC: "545,2898,555,2958",
                RCO: "545,2898,555,2958",
                RD: "1",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1655,1386,1714",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "836,1655,1386,1714",
                RCO: "836,1655,1386,1714",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1942,1386,2001",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "836,1942,1386,2001",
                RCO: "836,1942,1386,2001",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2230,1485,2287",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "836,2230,1485,2287",
                RCO: "836,2230,1485,2287",
                RD: "From Enzyme Solutions to Unilever",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
        ],
      },
      {
        FieldData: [
          {
            ID: "33",
            FCO: "88",
            FN: "date",
            FC: "297,2898,555,2958",
            CN: "0",
            RuleID: "33",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "305,1656,508,1717",
                RCO: "305,1656,508,1717",
                RD: "14/10/2016",
              },
              {
                NUM: "2",
                RC: "305,1943,508,2004",
                RCO: "305,1943,508,2004",
                RD: "14/10/2016",
              },
              {
                NUM: "3",
                RC: "305,2231,508,2292",
                RCO: "305,2231,508,2292",
                RD: "17/10/2016",
              },
              {
                NUM: "4",
                RC: "305,2518,508,2579",
                RCO: "305,2518,508,2579",
                RD: "17/10/2016",
              },
              {
                NUM: "5",
                RC: "297,2898,555,2958",
                RCO: "297,2898,555,2958",
                RD: "011 26963571",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1656,708,1719",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "571,1656,708,1719",
                RCO: "571,1656,708,1719",
                RD: "16972S",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,1943,706,2003",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "571,1943,706,2003",
                RCO: "571,1943,706,2003",
                RD: "12344F",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2231,709,2291",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "571,2231,709,2291",
                RCO: "571,2231,709,2291",
                RD: "12346H",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "571,2518,690,2578",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "571,2518,690,2578",
                RCO: "571,2518,690,2578",
                RD: "134561",
              },
            ],
          },
          {
            ID: "34",
            FCO: "87",
            FN: "code",
            FC: "545,2898,555,2958",
            CN: "0",
            RuleID: "34",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "5",
                RC: "545,2898,555,2958",
                RCO: "545,2898,555,2958",
                RD: "1",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1655,1386,1714",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "1",
                RC: "836,1655,1386,1714",
                RCO: "836,1655,1386,1714",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,1942,1386,2001",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "2",
                RC: "836,1942,1386,2001",
                RCO: "836,1942,1386,2001",
                RD: "Delivery from Scalzo Foods to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2230,1485,2287",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "3",
                RC: "836,2230,1485,2287",
                RCO: "836,2230,1485,2287",
                RD: "From Enzyme Solutions to Unilever",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
          {
            ID: "35",
            FCO: "86",
            FN: "description",
            FC: "836,2517,1409,2576",
            CN: "0",
            RuleID: "35",
            LookupID: null,
            MatchedLegend: null,
            Row: [
              {
                NUM: "4",
                RC: "836,2517,1409,2576",
                RCO: "836,2517,1409,2576",
                RD: "Dehire Pallets From Unilever to",
              },
            ],
          },
        ],
      },
    ],
  },
];
