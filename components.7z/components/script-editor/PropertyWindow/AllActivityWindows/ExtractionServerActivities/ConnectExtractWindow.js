import React, { useState, useContext, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

import PropertyField from "./../../PropertyFields/PropertyField";
import { Email } from "@mui/icons-material";
import { Button, Grid, Typography, CircularProgress } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { AddVariableIcon } from "../../../../../utils/AllImages";
import {
  mapFieldObjWithValueByName,
  logsState,
  getOptionsForVariable,
  getVariableTypeById,
  getExtractVersion,
} from "./../Common/CommonMethods";
import { NotificationContext } from "./../../../../../contexts/NotificationContext";
import {
  createInstance,
  handleNetworkRequestError,
} from "../../../../../utils/common";
import {
  OMNIXTRACT_CONNECT,
  OMNIEXTRACT_CONNECT_4_VERSION,
} from "./../../../../../config/index";
import {
  setSelectedTab,
  setErrorType,
  setOxServerValues,
} from "../../../../../redux/actions";
import ErrorsWindow from "../Common/ErrorsWindow";
import { useHistory } from "react-router";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import secureLocalStorage from "react-secure-storage";
const ConnectExtractWindow = (props) => {
  const classes = useStyles();
  const history = useHistory();

  const {
    selectedActivity,
    addParamsToSelAct,
    updateDisplayNameSelAct,
  } = props;

  const { params } = selectedActivity;
  console.log(params);

  const { setValue: setNotification } = useContext(NotificationContext);

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [serverURL, setServerURL] = useState(
    mapFieldObjWithValueByName(params, "oxServerUrl", "")
  );

  const [apiKey, setAPIKey] = useState(
    mapFieldObjWithValueByName(params, "oxApiKey", "")
  );
  const [clientId, setClientId] = useState(
    mapFieldObjWithValueByName(params, "clientId", "")
  );
  const [clientSecret, setClientSecret] = useState(
    mapFieldObjWithValueByName(params, "clientSKey", "")
  );

  const [token, setToken] = useState(
    mapFieldObjWithValueByName(params, "token", "")
  );

  const [extractVersion, setExtractVersion] = useState(
    mapFieldObjWithValueByName(params, "version", "")
  );

  const [isConnecting, setIsConnecting] = useState(false);
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setServerURL(mapFieldObjWithValueByName(params, "oxServerUrl", ""));
    setAPIKey(mapFieldObjWithValueByName(params, "oxApiKey", ""));
    setToken(mapFieldObjWithValueByName(params, "token", ""));
    setExtractVersion(mapFieldObjWithValueByName(params, "version", 3.2));
    setClientId(mapFieldObjWithValueByName(params, "clientId", ""));
    setClientSecret(mapFieldObjWithValueByName(params, "clientSKey", ""));
    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      case "oxServerUrl":
        setServerURL((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "oxApiKey":
        setAPIKey((prevState) => ({ ...prevState, paramValue: value }));
        break;

      case "token":
        setToken((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "version":
        setExtractVersion((prevState) => ({
          ...prevState,
          paramValue: +value,
        }));
        setClientId((prevState) => ({ ...prevState, paramValue: "" }));
        setClientSecret((prevState) => ({ ...prevState, paramValue: "" }));
        setAPIKey((prevState) => ({ ...prevState, paramValue: "" }));
        setServerURL((prevState) => ({ ...prevState, paramValue: "" }));
        break;
      case "clientId":
        setClientId((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "clientSKey":
        setClientSecret((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  const handleConnect = async () => {
    setIsConnecting(true);
    const axiosInstance = createInstance();
    try {
      let inputBody = {
        oxServerUrl: serverURL.paramValue,
        oxApiKey: apiKey.paramValue,
        version: extractVersion.paramValue,
        clientId: clientId.paramValue,
        clientSKey: clientSecret.paramValue,
      };

      let apiUrl = OMNIXTRACT_CONNECT;
      if (extractVersion.paramValue == 4.0) {
        apiUrl = OMNIEXTRACT_CONNECT_4_VERSION;
      }
      let response = await axiosInstance.post(apiUrl, {
        ...inputBody,
      });
      if (response.status === 200) {
        setIsConnecting(false);
        const oxToken =
          response.data && response.data.data && response.data.data[0];
        if (oxToken) {
          secureLocalStorage.setItem("oxToken", oxToken);
          dispatch(setOxServerValues({ ...inputBody, token: oxToken }));
          setNotification({
            isOpen: true,
            title: "Extraction",
            message: "server connected successfully.",
            notificationType: "SUCCESS",
          });
        } else {
          console.log(token);
          setNotification({
            isOpen: true,
            title: "Extraction",
            message: "server connection failed.",
            notificationType: "ERROR",
          });
        }
      }
    } catch (error) {
      setIsConnecting(false);
      handleNetworkRequestError({
        error,
        history,
        onError: (err) => {
          setNotification({
            isOpen: true,
            message: err,
            notificationType: "ERROR",
          });
        },
      });
    }
  };

  useEffect(() => {
    updateParams();
  }, [
    invisibleInLogs,
    serverURL,
    apiKey,
    token,
    extractVersion,
    clientId,
    clientSecret,
  ]);

  const updateParams = () => {
    const allParams = [
      invisibleInLogs,
      serverURL,
      apiKey,
      token,
      extractVersion,
      clientId,
      clientSecret,
    ];
    addParamsToSelAct(allParams);
  };

  const changeParamTypeToVorC = (paramName, changeToValue) => {
    switch (paramName) {
      case "oxServerUrl":
        setServerURL({ ...serverURL, paramType: changeToValue });
        break;

      case "oxApiKey":
        setAPIKey({ ...apiKey, paramType: changeToValue });
        break;

      case "version":
        setExtractVersion({ ...extractVersion, paramType: changeToValue });
        break;
      case "clientId":
        setClientId({ ...clientId, paramType: changeToValue });
        break;
      case "clientSKey":
        setClientSecret({ ...clientSecret, paramType: changeToValue });
        break;
      default:
        break;
    }
  };
  return (
    <>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={Email}
        helperText={
          selectedActivity.description || "Connect to Extraction Server"
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_version`}
                dropdown={true}
                paramObj={extractVersion}
                options={getExtractVersion()}
                name="version"
                label="Extract Version"
                value={extractVersion.paramValue}
                onChange={handleChange}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                // error={
                //   vaildateParamValue(serverURL.paramValue.toString())
                //     .errorStatus
                // }
                // helperText={
                //   vaildateParamValue(serverURL.paramValue.toString()).msg
                // }
              />
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_OxServerUrl`}
                combo={true}
                dropdown={serverURL.paramType === "V"}
                paramObj={serverURL}
                labelBtn1OnClick={changeParamTypeToVorC}
                labelBtn2OnClick={changeParamTypeToVorC}
                options={getOptionsForVariable(serverURL)}
                labelBtn1={true}
                labelBtn2={true}
                name="oxServerUrl"
                label="Server URL"
                value={serverURL.paramValue}
                onChange={handleChange}
                error={
                  vaildateParamValue(serverURL.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(serverURL.paramValue.toString()).msg
                }
              />
            </Grid>
            {extractVersion.paramValue == 3.2 && (
              <Grid item>
                <PropertyField
                  id={`${props.id}_oxApiKey`}
                  combo={true}
                  dropdown={apiKey.paramType === "V"}
                  paramObj={apiKey}
                  secret={true}
                  labelBtn1OnClick={changeParamTypeToVorC}
                  labelBtn2OnClick={changeParamTypeToVorC}
                  options={getOptionsForVariable(apiKey)}
                  labelBtn1={true}
                  labelBtn2={true}
                  name="oxApiKey"
                  label="API Key"
                  value={apiKey.paramValue}
                  onChange={handleChange}
                  error={
                    vaildateParamValue(apiKey.paramValue.toString()).errorStatus
                  }
                  helperText={
                    vaildateParamValue(apiKey.paramValue.toString()).msg
                  }
                />
              </Grid>
            )}
            {extractVersion.paramValue == 4.0 && (
              <>
                <Grid item>
                  <PropertyField
                    id={`${props.id}_clientId`}
                    combo={true}
                    dropdown={clientId.paramType === "V"}
                    paramObj={clientId}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    labelBtn1={true}
                    labelBtn2={true}
                    infoMessage="Contact your OmniXtract administrator for the Client ID and the Client Server of the OmniXtract server."
                    options={getOptionsForVariable(clientId)}
                    name="clientId"
                    label="Client Id"
                    value={clientId.paramValue}
                    onChange={handleChange}
                    error={
                      vaildateParamValue(clientId.paramValue.toString())
                        .errorStatus
                    }
                    helperText={
                      vaildateParamValue(clientId.paramValue.toString()).msg
                    }
                  />
                </Grid>
                <Grid item>
                  <PropertyField
                    id={`${props.id}_clientSecret`}
                    combo={true}
                    dropdown={clientSecret.paramType === "V"}
                    paramObj={clientSecret}
                    secret={true}
                    labelBtn1OnClick={changeParamTypeToVorC}
                    labelBtn2OnClick={changeParamTypeToVorC}
                    labelBtn1={true}
                    labelBtn2={true}
                    infoMessage="Contact your OmniXtract administrator for the Client ID and the Client Server of the OmniXtract server."
                    options={getOptionsForVariable(clientSecret)}
                    name="clientSKey"
                    label="Client Secret"
                    value={clientSecret.paramValue}
                    onChange={handleChange}
                    error={
                      vaildateParamValue(clientSecret.paramValue.toString())
                        .errorStatus
                    }
                    helperText={
                      vaildateParamValue(clientSecret.paramValue.toString()).msg
                    }
                  />
                </Grid>
              </>
            )}
            <Grid item>
              {isConnecting ? (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleConnect()}
                  disableRipple
                  id={`${props.id}_ConnectingBtn`}
                >
                  <CircularProgress
                    // color="#FFFFFF"
                    style={{
                      height: "15px",
                      width: "15px",
                      marginRight: "8px",
                      color: "#FFFFFF",
                    }}
                  ></CircularProgress>{" "}
                  <Typography className={classes.btn_title}>
                    Connecting..
                  </Typography>
                </Button>
              ) : (
                <Button
                  variant="contained"
                  color="primary"
                  onClick={() => handleConnect()}
                  disableRipple
                  id={`${props.id}_ConnectBtn`}
                >
                  <Typography className={classes.btn_title}>Connect</Typography>
                </Button>
              )}
            </Grid>
          </Grid>
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>

            <Grid item>
              <PropertyField
                id={`${props.id}_Token`}
                combo={true}
                dropdown={true}
                paramObj={token}
                btnIcon={
                  <AddVariableIcon
                    className={classes.btnIcon + " " + classes.colorPrimary}
                  />
                }
                name="token"
                label={`Token (${getVariableTypeById(
                  token.paramObjectTypeId
                )})`}
                value={token.paramValue}
                options={getOptionsForVariable(token)}
                onChange={handleChange}
                error={
                  vaildateParamValue(token.paramValue.toString()).errorStatus
                }
                helperText={vaildateParamValue(token.paramValue.toString()).msg}
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : null}
      </div>
    </>
  );
};

export default ConnectExtractWindow;
