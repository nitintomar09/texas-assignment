import React, { useState, useEffect } from "react";

import { WebAsset } from "@mui/icons-material";

import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import { logsState } from "./../Common/CommonMethods";
import ErrorsWindow from "../Common/ErrorsWindow";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "./../Common/commonOutput";
import CommonInput from "../Common/CommonInput";

const ExitWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs]);

  const updateParams = () => {
    let allParams = [invisibleInLogs];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={selectedActivity.description || "Terminates the flow."}
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <CommonInput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : null}
      </div>
    </div>
  );
};

export default ExitWindow;
