import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  mapFieldObjWithValueByName,
  logsState,
} from "./../Common/CommonMethods";
import ErrorsWindow from "../Common/ErrorsWindow";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "./../Common/commonOutput";
import { vaildateParamValue } from "../../../../../utils/validations/validations";

const RetryWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [retryCount, setRetryCount] = useState(
    mapFieldObjWithValueByName(params, "RetryCount", 3)
  );
  const [retryDuration, setRetryDuration] = useState(
    mapFieldObjWithValueByName(params, "RetryDuration", "")
  );
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    setRetryCount(mapFieldObjWithValueByName(params, "RetryCount", 3));
    setRetryDuration(mapFieldObjWithValueByName(params, "RetryDuration", ""));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, retryCount, retryDuration]);

  const updateParams = () => {
    let allParams = [invisibleInLogs, retryCount, retryDuration];
    addParamsToSelAct(allParams);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "RetryCount":
        setRetryCount((prevState) => ({ ...prevState, paramValue: value }));
        break;
      case "RetryDuration":
        setRetryDuration((prevState) => ({ ...prevState, paramValue: value }));
        break;
      default:
        break;
    }
  };

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          "Conditional Activity which upon True executes the inner activities."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_RetryCount`}
                combo={true}
                dropdown={true}
                labelBtn1={true}
                labelBtn2={true}
                name="RetryCount"
                label="Retry Count"
                value={retryCount.paramValue}
                options={optionsForRetryCount}
                onChange={handleChange}
                error={
                  vaildateParamValue(retryCount.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(retryCount.paramValue.toString()).msg
                }
              />
            </Grid>
            <Grid item>
              <PropertyField
                id={`${props.id}_RetryDuration`}
                combo={true}
                dropdown={true}
                labelBtn1={true}
                labelBtn2={true}
                name="RetryDuration"
                label="Interval(in seconds)"
                value={retryDuration.paramValue}
                options={optionsForDuration}
                onChange={handleChange}
                error={
                  vaildateParamValue(retryDuration.paramValue.toString())
                    .errorStatus
                }
                helperText={
                  vaildateParamValue(retryDuration.paramValue.toString()).msg
                }
              />
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : null}
      </div>
    </div>
  );
};

export default RetryWindow;
const optionsForRetryCount = [
  { name: 3, value: 3 },
  { name: 4, value: 4 },
  { name: 5, value: 5 },
];
const optionsForDuration = [
  { name: 5, value: 5 },
  { name: 10, value: 10 },
  { name: 15, value: 15 },
  { name: 20, value: 20 },
  { name: 25, value: 25 },
  { name: 30, value: 30 },
];
