import React, { useState, useEffect } from "react";
import PropertyField from "./../../PropertyFields/PropertyField";
import { WebAsset } from "@mui/icons-material";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
import {
  mapFieldObjWithValueByName,
  logsState,
} from "./../Common/CommonMethods";
import ErrorsWindow from "../Common/ErrorsWindow";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonOutput from "./../Common/commonOutput";
import { DeleteIcon } from "../../../../../utils/AllImages";
import {
  createInstance,
  handleNetworkRequestError,
} from "./../../../../../utils/common";
import { ERROR_HANDLING } from "../../../../../config";
import { useHistory } from "react-router-dom";
import { stubTrue } from "lodash";
import { vaildateParamValue } from "../../../../../utils/validations/validations";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";

const ConditionOfWindow = (props) => {
  const classes = useStyles();
  const history = useHistory();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  const { params } = selectedActivity;
  const dispatch = useDispatch();

  const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );

  const [conditionStr, setConditionStr] = useState(
    mapFieldObjWithValueByName(params, "conditionList", "")
  );
  const [allErrorCodes, setAllErrorCodes] = useState([]);

  const [conditionList, setConditionList] = useState([]);

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  const getErrorCodes = async () => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${ERROR_HANDLING}`);
      console.log(res);
      const codes = res.data["data"];
      if (codes) {
        setAllErrorCodes(
          codes.map((item) => ({
            name: item.errorCode,
            value: item.errorCode,
            description: item.errorDescription,
          }))
        );
      }
    } catch (error) {
      console.log(error);
      handleNetworkRequestError({ error, history });
    }
  };
  useEffect(() => {
    getErrorCodes();
  }, []);
  useEffect(() => {
    setActivityName(selectedActivity ? selectedActivity.displayName : "");
    setInvisibleInLogs(logsState(params, false));
    const conditions = mapFieldObjWithValueByName(
      params,
      "conditionList",
      "${RPA_ERROR_CODE} eq "
    );
    setConditionStr(conditions);
    const condArr = conditions?.paramValue?.split(" OR ") || [];
    setConditionList(condArr);

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);
  useEffect(() => {
    updateParams();
  }, [invisibleInLogs, conditionList]);

  const updateParams = () => {
    //  console.log(conditionList);
    const newConditionStr = {
      ...conditionStr,
      paramValue: conditionList.join(" OR "),
    };

    let allParams = [invisibleInLogs, newConditionStr];
    // console.log(allParams);
    addParamsToSelAct(allParams);
  };
  // console.log(conditionStr);
  const handleChange = (e, index) => {
    const { name, value } = e.target;

    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;
      case "ErrorCode":
        // setConditionStr((prevState) => ({ ...prevState, paramValue: value }));
        const list = [...conditionList];
        const ele = list[index];
        // console.log(ele);
        if (ele) {
          const newArr = ele.split(" eq ");
          //  console.log(newArr);
          newArr[1] = value;
          const newEle = newArr.join(" eq ");
          // console.log(newEle);
          list.splice(index, 1, newEle);
          setConditionList(list);
        }
        break;

      default:
        break;
    }
  };
  const handleCondDelete = (index) => {
    //  console.log(index);
    const list = [...conditionList];
    list.splice(index, 1);
    setConditionList(list);
  };
  const handleAddCond = () => {
    const list = [...conditionList];
    const newEle = "${RPA_ERROR_CODE} eq ";
    list.push(newEle);
    setConditionList(list);
  };
  //console.log(conditionList);

  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={selectedActivity.activityType === "S"}
        activityName={activityName}
        selectedActivity={selectedActivity}
        handleChange={handleChange}
        makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          selectedActivity.description ||
          "Conditional Activity which upon True executes the inner activities."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <Grid container direction="column" spacing={2}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                INPUT
              </Typography>
            </Grid>
            <Grid item>
              <Typography component="h5" className={classes.label1}>
                If RPA_ERROR_CODE is Equals to
              </Typography>
            </Grid>
            <Grid item>
              {/*****************************************************************************************
               * @author asloob_ali BUG ID : 106548 Description : Error handling-Condition Of- I am able to delete the default Input dropdown
               *  Reason:in check was not added for default condition to not to be deleted.
               * Resolution : added check, user will not be able to delete default condition field.
               *  Date : 10/03/2022             ***************************************************************************************/}
              {conditionList.map((item, index) => {
                const items = item.split(" eq ");

                return (
                  <Grid container spacing={1} alignItems="center" key={index}>
                    <Grid item xs>
                      <PropertyField
                        id={`${props.id}_ErrorCode`}
                        combo={true}
                        dropdown={true}
                        canType={true}
                        width={240}
                        type="number"
                        name="ErrorCode"
                        value={items[1]}
                        options={allErrorCodes}
                        onChange={(e) => handleChange(e, index)}
                        error={
                          vaildateParamValue(items[1].toString()).errorStatus
                        }
                        helperText={vaildateParamValue(items[1].toString()).msg}
                      />
                    </Grid>
                    {index > 0 && (
                      <Grid item>
                        <UniqueIDGenerator>
                          <DeleteIcon
                            className={classes.deleteBtn}
                            style={{
                              marginBottom: "5px",
                              marginLeft:
                                index === conditionList.length - 1
                                  ? "1px"
                                  : "auto",
                              //marginLeft: "auto",

                              cursor: "pointer",
                            }}
                            onClick={() => handleCondDelete(index)}
                            tabIndex={0}
                            onKeyPress={(e) =>
                              e.key === "Enter" && handleCondDelete(index)
                            }
                            role="button"
                            aria-label="Delete"
                            id={`${props.id}_DeleteIcon`}
                          />
                        </UniqueIDGenerator>
                      </Grid>
                    )}
                    {index === conditionList.length - 1 ? (
                      <Grid
                        item
                        style={{
                          marginTop: "-6px",
                          cursor: "pointer",
                          //marginLeft: "auto",
                        }}
                        onClick={() => handleAddCond()}
                        tabIndex={0}
                        onKeyPress={(e) => e.key === "Enter" && handleAddCond()}
                        role="button"
                        aria-label="+OR"
                        id={`${props.id}_AddCond`}
                      >
                        <Typography style={{ color: "#0072C6" }}>
                          +OR
                        </Typography>
                      </Grid>
                    ) : (
                      <Grid item style={{ marginTop: "-6px" }}>
                        <Typography>OR</Typography>
                      </Grid>
                    )}
                  </Grid>
                );
              })}
            </Grid>
          </Grid>
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : selectedTab === "output" ? (
          <CommonOutput />
        ) : null}
      </div>
    </div>
  );
};

export default ConditionOfWindow;
const allOptions = [
  { name: "103", value: 103 },
  { name: "104", value: 104 },
  { name: "105", value: 105 },
  { name: "106", value: 106 },
];
