import React, { useEffect } from "react";

import { WebAsset } from "@mui/icons-material";

import { useStyles } from "../Common/CommonStyles";
import CommonFields from "./../Common/CommonFields";
//import { logsState } from "./../Common/CommonMethods";
import ErrorsWindow from "../Common/ErrorsWindow";
import { useSelector, useDispatch } from "react-redux";
import { setSelectedTab, setErrorType } from "../../../../../redux/actions";
import CommonInput from "../Common/CommonInput";
import { Typography, Grid } from "@mui/material";

const OnErrorWindow = (props) => {
  const classes = useStyles();
  const { selectedActivity, addParamsToSelAct, updateDisplayNameSelAct } =
    props;
  // const { params } = selectedActivity;
  const dispatch = useDispatch();

  /* const [activityName, setActivityName] = useState(
    (selectedActivity && selectedActivity.displayName) || ""
  );
  const [invisibleInLogs, setInvisibleInLogs] = useState(
    logsState(params, false)
  );*/

  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);

  useEffect(() => {
    // setActivityName(selectedActivity ? selectedActivity.displayName : "");
    // setInvisibleInLogs(logsState(params, false));

    dispatch(setErrorType("Throw"));
    dispatch(setSelectedTab("input"));
  }, [selectedActivity]);

  /* useEffect(() => {
    updateParams();
  }, [invisibleInLogs]);

  const updateParams = () => {
    let allParams = [invisibleInLogs];
    addParamsToSelAct(allParams);
  };*/

  /*  const handleChange = (e) => {
    const { name, value } = e.target;
    switch (name) {
      case "ActivityName":
        setActivityName(value);
        updateDisplayNameSelAct(value);
        break;
      case "MakeLogsPrivate":
        setInvisibleInLogs({
          ...invisibleInLogs,
          paramValue: !invisibleInLogs.paramValue,
        });
        break;

      default:
        break;
    }
  };
*/
  return (
    <div>
      <CommonFields
        id={props.id}
        ScopeActivity={true}
        activityName={"OnError"}
        selectedActivity={{ ...selectedActivity, activityName: "OnError" }}
        //  handleChange={handleChange}
        //  makeLogsPrivate={invisibleInLogs.paramValue}
        ActivityIcon={WebAsset}
        helperText={
          "Conditional Activity which upon True executes  the inner activities."
        }
      />
      <div
        className={classes.scrollDiv + " " + classes.focusVisible}
        tabIndex={0}
      >
        {selectedTab === "input" ? (
          <CommonInput />
        ) : selectedTab === "error" ? (
          <ErrorsWindow />
        ) : selectedTab === "output" ? (
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography component="h5" className={classes.GroupTitle}>
                OUTPUT
              </Typography>
            </Grid>
            <Grid item>
              <Typography>
                On error, below variable would be set with error code
              </Typography>
            </Grid>
            <Grid item>
              <Typography className={classes.label1}>
                Error Variable- RPA_Error_Code
              </Typography>
            </Grid>
          </Grid>
        ) : null}
      </div>
    </div>
  );
};

export default OnErrorWindow;
