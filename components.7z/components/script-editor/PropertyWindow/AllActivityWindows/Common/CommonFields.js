import React from "react";
import { Grid, IconButton, Typography } from "@mui/material";
import { useStyles } from "./CommonStyles";
import PropertyField from "./../../PropertyFields/PropertyField";
import { EditIcon, CloseIcon, InfoIcon } from "../../../../../utils/AllImages";
import { API_BASE_URL, ICONS } from "./../../../../../config/index";
import { handleSelectedActivity } from "../../../../../redux/actions";
import { useDispatch } from "react-redux";
import { truncateStringValues } from "../../../../../utils/common";
import { UniqueIDGenerator } from "../../../../../utils/UniqueIDGenerator";
import { CustomActivityTooltipComponent } from "../../../../microFlowRepresentation/TooltipContent";
const CommonFields = ({
  activityName,
  handleChange = () => {
    console.log("handleChange not provided.");
  },
  makeLogsPrivate,
  ActivityIcon,
  helperText,
  ScopeActivity,
  selectedActivity,
  id,
}) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };
  return (
    <div className={classes.common}>
      <Grid container direction="column" spacing={1}>
        <Grid item>
          <Grid container spacing={1} alignItems={"center"}>
            <Grid item>
              <span>
                <Typography className={classes.label}>Type :</Typography>
              </span>{" "}
            </Grid>
            <Grid item>
              <span>
              {/* Bug 155559 - properties tab UI is not in sync with the figma design */}
                <Typography sx={{ fontSize:"12px",color:"#000000",fontWeight: "400", }}>
                  {selectedActivity?.activityName}
                </Typography>
              </span>
            </Grid>
            {/* Bug 155559 - properties tab UI is not in sync with the figma design */}
            <Grid item style={{ marginLeft: "auto" }}>
              <CustomActivityTooltipComponent
            
              label={activityName}
              helperText={helperText}
              >
              <InfoIcon/>
              </CustomActivityTooltipComponent>
              

  
            </Grid>
            <Grid
              item

            //  //WCAG Keyboard Accessibility : [19-06-2023] Added tabIndex and onKeyPress
            // tabIndex={0}
            /* onKeyPress={(e) =>
               e.key === "Enter" && dispatch(handleSelectedActivity(null))
             }
             id={`${id}_Close`}*/
            >

              <IconButton aria-label="Close Property Window"
                onClick={() => dispatch(handleSelectedActivity(null))}
                id={`${id}_CloseBtn`}
                // className={classes.closeIcon}
                title="Close"
              >
                <CloseIcon
                  className={classes.closeWindowIcon}
                //  title="Close"
                />
              </IconButton>

            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          <PropertyField
            id={id}
            ActivityTitle={true}
            ActivityName={activityName}
            ScopeActivity={ScopeActivity}

            ActivityIcon={
              <img
                src={getImage(selectedActivity?.activityName)}
                className={classes.activityIcon}
                alt={`${selectedActivity?.activityName} Icon`}
              />
            }
            value={activityName}
            endAdornment={
              activityName !== "OnError" && (
                <Typography className={classes.editBtn}>
                  <UniqueIDGenerator>
                    <EditIcon />
                  </UniqueIDGenerator>
                </Typography>
              )
            }
            // helperText={
            //   helperText
            //     ? truncateStringValues({
            //       str: helperText,
            //       min: 40,
            //       max: 55,
            //     })
            //     : ""
            // }
            helperTitle={helperText ? helperText : ""}
            onChange={handleChange}
          />
        </Grid>
        {activityName !== "OnError" && (
          <Grid item>
            <PropertyField
              id={`${id}_InvisibleInLogs`}
              checkbox={true}
              name="MakeLogsPrivate"
              label="Invisible in Logs"
              value={makeLogsPrivate}
              onChange={handleChange}
              
            />
          </Grid>
        )}
      </Grid>
    </div>
  );
};

export default CommonFields;
