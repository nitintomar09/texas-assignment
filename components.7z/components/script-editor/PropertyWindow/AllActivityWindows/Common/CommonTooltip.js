import React from "react";
import Tooltip from "@mui/material/Tooltip";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/material/styles";


const CustomTooltip = styled(({ className, ...props }) => (
  
<Tooltip {...props} classes={{ popper: className, tooltip: className }} arrow  />
))(({ theme }) => ({
  [`& .MuiTooltip-tooltip`]: {
    backgroundColor: "#fff",
    color: "rgba(0, 0, 0, 0.87)",
    boxShadow: theme.shadows[1],
    fontSize: 11,
    border: "1px solid #ddd",
    padding: "10px",
  },
  [`& .MuiTooltip-arrow`]: {
    color: "#fff",
    "&::before": {
      border: "1px solid #ddd",
    },
   
    
  },
}));

const TooltipContent = ({ label}) => {
  

  return (
    <Grid container style={{ background: "white", width: "200px" }}>
      
      <Grid item xs={12} container alignItems="center">
        <Grid item xs>
          <Typography variant="body1" style={{ color: "GrayText" }}>
            {label}
          </Typography>
        </Grid>
      </Grid>
    </Grid>
  );
};

const CommonCustomTooltip = ({ children, ...props }) => (
  <CustomTooltip title={<TooltipContent {...props} />} placement="top">
    {children}
  </CustomTooltip>
);

export default CommonCustomTooltip;
