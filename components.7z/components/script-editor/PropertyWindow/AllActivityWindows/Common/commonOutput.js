import React from "react";
import { Grid, Typography } from "@mui/material";
const CommonOutput = () => {
  return (
    <Grid container spacing={1}>
      <Grid item>
        <Typography
          style={{
            fontStyle: "italic",
            fontWeight: "600",
            color: "#606060",
          }}
        >
          It does not have output.
        </Typography>
      </Grid>
    </Grid>
  );
};

export default CommonOutput;
