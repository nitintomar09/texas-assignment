import React from "react";
import { Grid, Typography } from "@mui/material";
const CommonInput = () => {
  return (
    <Grid container spacing={1}>
      <Grid item>
        <Typography
          style={{
            fontStyle: "italic",
            fontWeight: "600",
            color: "#606060",
          }}
        >
          It does not have any input.
        </Typography>
      </Grid>
    </Grid>
  );
};

export default CommonInput;
