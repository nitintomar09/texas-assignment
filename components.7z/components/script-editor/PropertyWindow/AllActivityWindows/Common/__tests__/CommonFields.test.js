import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import CommonFields from "./../CommonFields";
import userEvent from "@testing-library/user-event";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  const handleChange = jest.fn();

  ReactDom.render(
    <CommonFields
      ScopeActivity={true}
      activityName="Test"
      handleChange={handleChange}
      makeLogsPrivate={false}
      helperText="Common Fields"
    />,
    div
  );
});

it("handle change name", () => {
  const handleChange = jest.fn();

  render(
    <CommonFields
      ScopeActivity={true}
      activityName="Test"
      handleChange={handleChange}
      makeLogsPrivate={false}
      helperText="Common Fields"
    />
  );

  userEvent.type(screen.getByRole("textbox"), "Activity Name");
  expect(handleChange).toBeCalledTimes(13);
});

it("matches snapshot", () => {
  const handleChange = jest.fn();

  const tree = renderer
    .create(
      <CommonFields
        ScopeActivity={true}
        activityName="Test"
        handleChange={handleChange}
        makeLogsPrivate={false}
        helperText="Common Fields"
      />
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
