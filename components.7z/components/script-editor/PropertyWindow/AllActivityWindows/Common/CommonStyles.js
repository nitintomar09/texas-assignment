import makeStyles from '@mui/styles/makeStyles';
import { getCssRgbFromHexByDiff } from "../../../../../utils/HexToFilter";
export const useStyles = makeStyles((theme) => ({
  visuallyhidden: {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: "0px",
    margin: "-1px",
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    width: "0px",
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  focusPrimary: {
    "&:focus": {
      background: `${getCssRgbFromHexByDiff(`${theme.palette.primary.main}`)}`,
    },
  },
  colorPrimary: {
    color: "white",
    backgroundColor: `${theme.palette.primary.main}`,
    borderRadius: "2px",
    //filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  textColorPrimary: {
    color: `${theme.palette.primary.main}`,
    fontWeight: 600,
  },
  btnIcon: {
    cursor: "pointer",
    height: "28px",
    width: "28px",
    // paddingLeft: "3px",
  },

  GroupTitle: {
    fontWeight: "bold",
    marginTop: "10px",
    fontSize: "10px",
  },
  // Bug 155559 - properties tab UI is not in sync with the figma design
  label: { fontSize: 12, color: "#606060", fontWeight: 400 },
  scrollDiv: {
    //width: "100%",
    height: "435px",
    //  height: "520px",
    height: window?.innerHeight - 300 || "405px",

    overflowY: "scroll",
    overflowX: "hidden",
    paddingLeft: "14px",
    paddingRight: "8px",
    paddingTop: "10px",
    paddingBottom: "20px",
    position: "relative",
    paddingBottom: "20px",
  },
  // Bug 156156 - UX Padding issue in properties panel
  common: {
    // paddingLeft: "14px",
    // paddingRight: "18px",
    // paddingTop: "15px",
    // paddingBottom: "8px",
    padding:"12px",
    boxShadow: "0px 2px 6px #00000029",
  },
  btn_title: {
    fontSize: 12,
    color: "#FFFFFF",
  },
  input: {
    height: 24,
    backgroundColor: "white",
    fontSize: 12,
  },
  multilineInput: {
    backgroundColor: "white",
    fontSize: 12,
    color: "#2979ff",
    "& ::selection": {
      backgroundColor: "yellow",
      color: "#0072C6",
    },
  },

  label1: { fontSize: 12, color: "#00000", fontWeight: 700 },

  text_12: {
    fontSize: "12px",
  },
  selectedTab: {
    fontWeight: 600,
    borderBottom: `2px solid ${theme.palette.primary.main}`,
    color: `${theme.palette.primary.main}`,
    filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  tabs: {
    cursor: "pointer",
    color: "#606060",
  },
  items: {
    fill: "#FFFFFF",
    height: "16px",
    width: "16px",
  },
  errorCondItem: {
    backgroundColor: "#F0F0F0",
    marginBottom: "12px",
    marginLeft: "8px",
    //paddingRight: 0,
  },
  errorCondItemChild: {
    paddingLeft: "20px",
  },
  addIcon: {
    backgroundColor: "#FFFFFF",
    height: "20px",
    width: "20px",
    border: `1px solid ${theme.palette.primary.main}`,
  },
  removeIcon: {
    backgroundColor: "#FFFFFF",
    height: "20px",
    width: "20px",
    border: `1px solid #FF0000`,
  },
  closeIcon: {
    height: "12px",
    width: "12px",
    cursor: "pointer",
    marginRight: "2px",
    marginTop: "5px",
  },
  selBtn: {
    cursor: "pointer",
    backgroundColor: "#FFFFFF",
    color: "#000000",
    paddingLeft: 5,
    paddingRight: 5,
    paddingTop: 2,
    paddingBottom: 2,
    borderLeft: "1px solid #ECECEC",
    borderTop: "1px solid #ECECEC",
    fontWeight: 700,
  },
  simpleBtn: {
    cursor: "pointer",
    backgroundColor: "#c7c7c7",
    color: "#000000",
    paddingLeft: 5,
    paddingRight: 5,
    paddingTop: 2,
    paddingBottom: 2,
    border: "1px solid #ECECEC",
  },
  addBtn: {
    width: "20px",
    height: "20px",
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
    // filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  removeBtn: {
    width: "20px",
    height: "20px",
    color: "#FF0000",
    cursor: "pointer",
    // filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  editBtn: {
    width: "16px",
    height: "16px",
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
    filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  deleteBtn: {
    height: "18px",
    width: "18px",
    filter: `invert(17%) sepia(74%) saturate(5916%) hue-rotate(356deg) brightness(101%) contrast(118%)`,
  },
  root: {
    width: "100%",
    maxWidth: 216,

    backgroundColor: "#FFFFFF",
    height: "500px",
    overflow: "hidden",

    "&:hover": {
      overflowY: "auto",
    },
  },
  itemRoot: {
    paddingLeft: "25px",
  },
  list_item: {
    height: "40px",
    backgroundColor: "#FFFFFF",
  },
  list_item_nested: {
    height: "25px",
    paddingLeft: "25px",
  },
  text_light: {
    fontSize: "12px",
    fontWeight: 600,
    color: "#606060",
  },
  nested: {
    paddingLeft: theme.spacing(2),
    height: "25px",
  },
  chevronIcon: {
    marginRight: "10px",
    color: "#606060",
  },
  listTitle: {
    fontSize: "12px",
    fontWeight: 700,
  },
  listSubTitle: {
    fontSize: "12px",
    fontWeight: 600,
  },
  helperText: {
    fontSize: "10px",
    color: (props) => props.helperTextColor || "#606060",
  },
  helperTextErr: {
    fontSize: "10px",
    color: "#D53D3D",
  },
  rootAssignment: {
    width: "100%",
    // maxWidth: 216,
    backgroundColor: "#FFFFFF",
    height: "150px",
    overflow: "hidden",

    "&:hover": {
      overflowY: "auto",
    },
  },
  activityIcon: {
    // Bug 155559 - properties tab UI is not in sync with the figma design
    height: "16px",
    width: "16px",
    marginTop: "3px",
  },
  expandCollapseIcon: {
    border: "1px solid #e5e5e5",
    paddingTop: 1,
    paddingBottom: 1,
    paddingLeft: 5,
    paddingRight: 5,
    marginTop: 18,
  },
  secondary_btn_title: {
    fontSize: 12,
    color: `${theme.palette.primary.main}`,
  },
  secondary_btn_circular_progress: {
    fontSize: 12,
    color: `${theme.palette.primary.main}`,
    marginRight: '8px'
  },
  deleteCrossIcon: {
    height: "12px",
    width: "12px",
    // marginBottom:'10px',
    cursor: 'pointer',
    marginLeft: '10px'
  },
  tertiary_add_btn_title: {
    fontSize: 12,
    color: `${theme.palette.primary.main}`,
    fontWeight: 600,
    cursor: 'pointer'
  },
  addColumnBtn: {
    width: "18px",
    height: "18px",
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
    // filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  iconBtnMediumSize: {
    width: '20px'
  },
  closeWindowIcon: {
    height: "12px",
    width: '12px',
    cursor:'pointer'
  }
}));
