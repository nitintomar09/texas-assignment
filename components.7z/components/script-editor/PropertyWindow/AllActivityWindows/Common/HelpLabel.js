import React from "react";

import IconButton from "@mui/material/IconButton";
import Grid from "@mui/material/Grid";
import { HelpIcon } from "../../../../../utils/AllImages";
import CommonCustomTooltip from "./CommonTooltip";

const HelpLabel = ({ label,style={marginTop:'-5px'}}) => {
    return (
        <CommonCustomTooltip label={label} >
            <IconButton style={{...style}}><HelpIcon style={{height:'14px',width:'14px'}}/></IconButton>
        </CommonCustomTooltip>
    );
};

export default HelpLabel;