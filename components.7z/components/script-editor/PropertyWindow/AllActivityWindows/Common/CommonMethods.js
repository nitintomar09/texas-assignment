import { useContext } from "react";
import {
  InputIcon,
  PropOutputIcon,
  ErrorHandlingIcon,
} from "../../../../../utils/AllImages";
import { VariablesContext } from "./../../../../../contexts/VariablesListContext";
export const mapFieldObjWithValue = (obj, value, name) => {
  if (obj) {
    //because we are storing params values as string in backend(database).bool values are also in string.
    if (obj.paramObjectTypeId === 3) {
    }
    const defVal =
      obj.paramValue !== false && obj.paramValue != null
        ? obj.paramValue
        : value;

    return {
      ...obj,
      // paramValue: obj.paramValue? obj.paramValue : value,
      paramValue: defVal,
      paramName: name || "",
    };
  }
  return { paramValue: value || "", paramType: "C", paramName: name || "" };
};

export const makeOptionsFromVariables = (variables) => {
  return variables.map((variable) => {
    const { variableName } = variable;
    return { name: variableName, value: variableName };
  });
};

//for common field invisible in logs
export const logsState = (params, value) => {
  if (params) {
    return mapFieldObjWithValue(
      params.find((obj) => obj.paramName === "invisiblelogs"),
      value,
      "invisiblelogs"
    );
  } else {
    return { paramValue: false };
  }
};

export const getDefaultValueForVar = (param) => {
  const type = param?.paramObjectTypeId || 1;
  switch (type) {
    case 1:
      return "";
    case 2:
      return "";
    case 3:
      return false;
    default:
      return "";
  }
};
export const mapFieldObjWithValueByName = (params, name, value) => {
  if (params && name) {
    const param = params.find((obj) => obj.paramName === name);
    return mapFieldObjWithValue(
      param,
      value || getDefaultValueForVar(param),
      name
    );
  } else {
    return { paramValue: value || "", paramType: "C", paramName: name || "" };
  }
};

export const getAllOptions = function GetAllOptions() {
  const { value } = useContext(VariablesContext);
  const { allVariables } = value;

  const allOptions = makeOptionsFromVariables(allVariables);
  return allOptions || [];
};
export const getAllVariables = function GetAllVariables() {
  const { value } = useContext(VariablesContext);
  const { allVariables } = value;

  return allVariables || [];
};

//variableObjType
export const getAllOptionsForGeneralIf = function GetAllOptionsForGeneralIf() {
  const allVariables = getAllVariables();
  /*****************************************************************************************
   * @author asloob_ali BUG ID : 103449 Description : 103449 -  Control Flow: If Else Activity: Comparison operator is not coming for float and list type variable
   *  Reason:operators was not decided for some of types of variables.
   * Resolution :As per the discussion, in general if condition only few types(text,integer,float,boolean,date and dateTime) of variables will be available to select.user can give general if condition on these types of variables only.
   *  Date : 03/01/2022             ****************************************/
  const filteredVars = allVariables.filter(
    (item) =>
      item.variableObjType === 1 ||
      item.variableObjType === 2 ||
      item.variableObjType === 3 ||
      item.variableObjType === 4 ||
      item.variableObjType === 8 ||
      item.variableObjType === 9
  );

  const allOptions = makeOptionsFromVariables(filteredVars);
  return allOptions || [];
};
export const getOptionsForVariable = function GetOptionsForVar(param) {
  const allVariables = getAllVariables();

  /*****************************************************************************************
   * @author asloob.ali BUG ID : 101089 Description : RPA:  Variable : List variable is not showing in the output properties drop down list
   *  Resolution : fixed property name mismatch. 'paramObjectTypeId'
   *  Date : 07/09/2021             ***************************************************************************************/

  if (param) {
    const varType = param?.paramObjectTypeId || param?.variableObjType || 1;
    return allVariables
      .filter((obj) => obj.variableObjType === varType)
      .map((item) => {
        return { name: item.variableName, value: item.variableName };
      });
  } else {
    return [];
  }
};

export const truncateString = (str) => {
  if (str && str instanceof String) {
    return str.trim().length > 25 ? str.substring(0, 23) + ".." : str;
  } else if (str) {
    return str;
  }
  return "";
};
export const getTabs = () => {
  return [
    { name: "Input", value: "input", icon: InputIcon },
    { name: "Output", value: "output", icon: PropOutputIcon },
    //{ name: "Error Handling", value: "error", icon: ErrorHandlingIcon },
  ];
};

export const getExtractVersion = () => {
  return [
    { name: "3.2", value: 3.2 },
    { name: "4.0", value: 4.0 },
  ];
};

export const getVariableTypeById = (id) => {
  let variableType = null;
  switch (id) {
    case 1:
      variableType = "Text";
      break;
    case 2:
      variableType = "Integer";
      break;

    case 3:
      variableType = "Boolean";
      break;
    case 4:
      variableType = "Date";
      break;

    case 5:
      variableType = "List";
      break;
    case 6:
      variableType = "DataTable";
      break;
    case 7:
      variableType = "DataRecord";
      break;
    case 8:
      variableType = "Float";
      break;

    case 9:
      variableType = "DateTime";
      break;
    case 10:
      variableType = "MailMessage";
      break;
    case 11:
      variableType = "JSONObject";
      break;
    case 12:
      variableType = "JSONArray";
      break;
    default:
      break;
  }
  return variableType;
};

export const isVar = (str) => {
  let newStr = "" + str;
  if (
    newStr.charAt(0) === "$" &&
    newStr.charAt(1) === "{" &&
    newStr.charAt(str.length - 1) === "}"
  ) {
    return true;
  }
  return false;
};
export const changeVarFormToConst = (str) => {
  return str.slice(2, str.length - 1);
};
export const handeParseValuesForVarType = ({ stringyfiedObject }) => {
  try {
    const jsonObj = JSON.parse(stringyfiedObject);
    if (jsonObj) {
      return Object.keys(jsonObj).map((key) => {
        const valueAtKey = jsonObj[key];
        return {
          key,
          value: isVar(valueAtKey)
            ? changeVarFormToConst(valueAtKey)
            : valueAtKey,
          paramType: isVar(valueAtKey) ? "V" : "C",
        };
      });
    }
  } catch (error) {
    console.log(error);
  }
};

export const handeParseValuesForVarTypeSingleObj = ({ stringyfiedObject }) => {
  try {
    const jsonObj = JSON.parse(stringyfiedObject);
    if (jsonObj) {
      const newArr = Object.keys(jsonObj).map((key) => {
        const valueAtKey = jsonObj[key];
        console.log(valueAtKey);
        return {
          key,
          value: isVar(valueAtKey)
            ? changeVarFormToConst(valueAtKey)
            : valueAtKey,
          paramType: isVar(valueAtKey) ? "V" : "C",
        };
      });
      if (Array.isArray(newArr) && newArr.length > 0) {
        return newArr[0];
      }
    }
  } catch (error) {
    console.log(error);
  }
};


export const mapFieldObjWithValue2 = (obj, value, name) => {
  if (obj) {
    const defVal =
      obj.paramValue !== false && obj.paramValue != null
        ? obj.paramValue
        : value;

    return {
      ...obj,

      paramValue: defVal,
      paramName: name || "",
    };
  }
  return { paramValue: value || "", paramType: "C", paramName: name || "" };
};
export const mapFieldObjWithValueByName2 = (params, name, value) => {
  if (params && name) {
    const param = params.find((obj) => obj.paramName === name);
    return mapFieldObjWithValue2(
      param,
      value || getDefaultValueForVar(param),
      name
    );
  } else {
    return { paramValue: value || "", paramType: "C", paramName: name || "" };
  }
};

export const handleParseValuesForDatabaseColumnValues = ({ stringyfiedObject }) => {
  try {
    const jsonObj = JSON.parse(stringyfiedObject);
    if (jsonObj) {
      const newArr = Object.keys(jsonObj).map((key) => {
        const objValueAtKey = jsonObj[key];
        const valueAtKey=objValueAtKey?.columnValue
        const type=objValueAtKey?.columnType
        const dataType=objValueAtKey?.dataType
        const dataTypeLength=objValueAtKey?.dataTypeLength

        
        return {
          key,
          value: isVar(valueAtKey)
            ? changeVarFormToConst(valueAtKey)
            : valueAtKey,
          paramType: isVar(valueAtKey) ? "V" : "C",
          type,
          dataType,
          dataTypeLength

        };
      });
      if (Array.isArray(newArr) && newArr.length > 0) {
        return newArr[0];
      }
    }
  } catch (error) {
    console.log(error);
  }
};



export const getAllOptionsForWhereClause = function GetAllOptionsForWhereClause() {
  const allVariables = getAllVariables();
  const filteredVars = allVariables.filter(
    (item) =>
      item.variableObjType === 1 ||
      item.variableObjType === 2 ||
      item.variableObjType === 3 ||
      item.variableObjType === 4 ||
      item.variableObjType === 8 ||
      item.variableObjType === 9
  );

  const allOptions = makeOptionsFromVariables(filteredVars);
  return allOptions || [];
};