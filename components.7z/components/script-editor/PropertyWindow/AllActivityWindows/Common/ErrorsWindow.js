import React, { useState } from "react";
import { Grid, Typography } from "@mui/material";
import { useStyles } from "./CommonStyles";
import { useSelector, useDispatch } from "react-redux";

import { setErrorType } from "../../../../../redux/actions";
import PropertyField from "./../../PropertyFields/PropertyField";
import MenuPopper from "../../../../../utils/MenuPopper";
import { Add } from "@mui/icons-material";

const ErrorsWindow = (props) => {
  const classes = useStyles();

  const radioButtonsArray = [
    { label: "Throw", value: "Throw" },
    { label: "Continue", value: "Continue" },
  ];
  const cbArrayData = [
    { label: "On All Errors", value: false },
    { label: "Data type Mismatch", value: false },
    { label: "User Error", value: false },
    { label: "Workitem Error", value: false },
  ];
  const [cbArray, setCbArray] = useState(cbArrayData);
  const errorType = useSelector((state) => state.propertyWindow.errorType);
  const dispatch = useDispatch();

  const updateCbArr = ({ name, value }) => {
    const newCbArr = [...cbArray];
    const newItem = { label: name, value };
    const i = cbArray.findIndex((item) => item.label === name);

    if (i !== -1) {
      newCbArr.splice(i, 1, newItem);
    }
    setCbArray(newCbArr);
  };
  const handleChange = (e) => {
    const { name, value, checked } = e.target;

    switch (name) {
      case "OnEncounteringError":
        dispatch(setErrorType(value));
        break;
      case "On All Errors":
        updateCbArr({ name, value: checked });
        break;
      case "Data type Mismatch":
        updateCbArr({ name, value: checked });
        break;
      case "User Error":
        updateCbArr({ name, value: checked });
        break;
      case "Workitem Error":
        updateCbArr({ name, value: checked });
        break;

      default:
        break;
    }
  };

  return (
    <Grid container direction="column" spacing={2}>
      <Grid item>
        <Typography component="h5" className={classes.GroupTitle}>
          ERROR ENCOUNTER
        </Typography>
      </Grid>
      <Grid item>
        <PropertyField
          id="RPA_Error_OnEncounteringError"
          radio={true}
          ButtonsArray={radioButtonsArray}
          name="OnEncounteringError"
          label="On Encountering Error"
          value={errorType}
          onChange={handleChange}
        />
      </Grid>
      <Grid item>
        <Typography component="h5" className={classes.GroupTitle}>
          ERROR CONDITION
        </Typography>
      </Grid>
      {cbArray.map((cb, i) => (
        <Grid item className={classes.errorCondItem} key={i}>
          <div className={classes.errorCondItemChild}>
            <Grid container direction="row">
              <Grid item>
                <PropertyField
                  id={`RPA_Error_${cb.label}`}
                  checkbox={true}
                  name={cb.label}
                  label={cb.label}
                  value={cb.value}
                  onChange={handleChange}
                />
              </Grid>
              {cb.label === "On All Errors" && cb.value && (
                <>
                  <Grid item style={{ marginLeft: "auto" }}>
                    <MenuPopper
                      MenuIcon={Add}
                      items={items}
                      color="primary"
                      id={`RPA_Error_${cb.label}_MenuPopper`}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Typography
                      style={{
                        fontStyle: "italic",
                        fontWeight: "600",
                        color: "#606060",
                      }}
                    >
                      Add Action.
                    </Typography>
                  </Grid>
                </>
              )}
            </Grid>
          </div>
        </Grid>
      ))}
    </Grid>
  );
};

export default ErrorsWindow;
const items = [
  "Retry",
  "Set Variables",
  "Take Screenshot",
  "Send Email",
  "Apply Subscript",
];
