import React, { Fragment } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Paper, Grid } from "@mui/material";
import { getTabs } from "../PropertyWindow/AllActivityWindows/Common/CommonMethods";
import { setSelectedTab } from "../../../redux/actions";
import makeStyles from '@mui/styles/makeStyles';
import OpenExcelWindow from "./AllActivityWindows/ExcelActivities/OpenExcelWindow";
import GetSheetsWindow from "./AllActivityWindows/ExcelActivities/GetSheetsWindow";
import OpenSheetsWindow from "./AllActivityWindows/ExcelActivities/OpenSheetsWindow";
import ReadRowWindow from "./AllActivityWindows/ExcelActivities/ReadRowWindow";
import ForEachRowWindow from "./AllActivityWindows/ExcelActivities/ForEachRowWindow";
import FilterTableWindow from "./AllActivityWindows/ExcelActivities/FilterTableWindow";
import GetTableRangeWindow from "./AllActivityWindows/ExcelActivities/GetTableRangeWindow";
import DeleteColumnWindow from "./AllActivityWindows/ExcelActivities/DeleteColumnWindow";
import CopySheetWindow from "./AllActivityWindows/ExcelActivities/CopySheetWindow";
import WriteRangeWindow from "./AllActivityWindows/ExcelActivities/WriteRangeWindow";
import ReadColumnWindow from "./AllActivityWindows/ExcelActivities/ReadColumnWindow";
import WriteCellWindow from "./AllActivityWindows/ExcelActivities/WriteCellWindow";
import CreateTableWindow from "./AllActivityWindows/ExcelActivities/CreateTableWindow";
import DeleteRangeWindow from "./AllActivityWindows/ExcelActivities/DeleteRangeWindow";
import SaveMailWindow from "./AllActivityWindows/MailActivities/SaveMailWindow";
import SaveAttachmentsWindow from "./AllActivityWindows/MailActivities/SaveAttachmentsWindow";
import SendMailSMTPWindow from "./AllActivityWindows/MailActivities/SendMailSMTPWindow";
import DeleteMailExchangeWindow from "./AllActivityWindows/MailActivities/DeleteMailExchangeWindow";
import ConnectMainWindow from "./AllActivityWindows/MailActivities/Connect/ConnectMainWindow";
import GetMailWindow from "./AllActivityWindows/MailActivities/GetMailWindow";
import MoveMailMainWindow from "./AllActivityWindows/MailActivities/MoveMail/MoveMailMainWindow";
import AddDocumentWindow from "./AllActivityWindows/IBPSActivities/AddDocumentWindow";
import GetDocumentWindow from "./AllActivityWindows/IBPSActivities/GetDocumentWindow";
import AddDocumentToWorkitemWindow from "./AllActivityWindows/IBPSActivities/AddDocumentToWorkitemWindow";
import CompleteWorkitemWindow from "./AllActivityWindows/IBPSActivities/CompleteWorkitemWindow";
import ServerConnectWindow from "./AllActivityWindows/IBPSActivities/ServerConnectWindow";
import CreateWorkitemWindow from "./AllActivityWindows/IBPSActivities/CreateWorkitemWindow";
import WebActivityWindow from "./AllActivityWindows/WebActivities/WebActivityWindow";
import IfWindow from "./AllActivityWindows/ControlFlowActivities/IfWindow";
import AddGroupWindow from "./AllActivityWindows/AddGroupWindow";
import ExecuteMacroWindow from "./AllActivityWindows/ExcelActivities/ExecuteMacroWindow";
import CreateFolderWindow from "./AllActivityWindows/Files_Folders/CreateFolderWindow";
import RenameFolderWindow from "./AllActivityWindows/Files_Folders/RenameFolderWindow";
import DeleteFolderWindow from "./AllActivityWindows/Files_Folders/DeleteFolderWindow";
import MoveFolderWindow from "./AllActivityWindows/Files_Folders/MoveFolderWindow";
import DeleteFileWindow from "./AllActivityWindows/Files_Folders/DeleteFileWindow";
import RenameFileWindow from "./AllActivityWindows/Files_Folders/RenameFileWindow";
import MoveFileWindow from "./AllActivityWindows/Files_Folders/MoveFileWindow";
import SplitFilePathAndNameWindow from "./AllActivityWindows/Files_Folders/SplitFilePathAndNameWindow";
import GetFilesWindow from "./AllActivityWindows/Files_Folders/GetFilesWindow";
import OpenBrowserWindow from "./AllActivityWindows/WebActivities/OpenBrowserWindow";
import GetFileSizeWindow from "./AllActivityWindows/Files_Folders/GetFileSizeWindow";
import GetAllFoldersWindow from "./AllActivityWindows/PathActivities/GetAllFoldersWindow";
import GetDriveLetterWindow from "./AllActivityWindows/PathActivities/GetDriveLetterWindow";
import GetFileNameWindow from "./AllActivityWindows/PathActivities/GetFileNameWindow";
import GetPathWindow from "./AllActivityWindows/PathActivities/GetPathWindow";
import GetSeparatorWindow from "./AllActivityWindows/PathActivities/GetSeparatorWindow";
import GetHostWindow from "./AllActivityWindows/URLActivities/GetHostWindow";
import GetPortWindow from "./AllActivityWindows/URLActivities/GetPortWindow";
import GetProtocolHandlerWindow from "./AllActivityWindows/URLActivities/GetProtocolHandlerWindow";
import GetOSTypeWindow from "./AllActivityWindows/SystemInfoActivities/GetOSTypeWindow";
import GetOSVersionWindow from "./AllActivityWindows/SystemInfoActivities/GetOSVersionWindow";
import GetOSNameWindow from "./AllActivityWindows/SystemInfoActivities/GetOSNameWindow";
import GetFreeMemoryWindow from "./AllActivityWindows/SystemInfoActivities/GetFreeMemoryWindow";
import GetTotalMemoryWindow from "./AllActivityWindows/SystemInfoActivities/GetTotalMemoryWindow";
import GetUserHomeDirWindow from "./AllActivityWindows/SystemInfoActivities/GetUserHomeDirWindow";
import RepeatWindow from "./AllActivityWindows/ControlFlowActivities/RepeatWindow";
import AssignmentWindow from "./AllActivityWindows/ControlFlowActivities/AssignmentWindow";
import PrintOutPutWindow from "./AllActivityWindows/ControlFlowActivities/PrintOutputWindow";
import GetCurrentDate from "./AllActivityWindows/DateTimeActivities/GetCurrentDate";
import GetCurrentDateTime from "./AllActivityWindows/DateTimeActivities/GetCurrentDateTime";
import GetCurrentTime from "./AllActivityWindows/DateTimeActivities/GetCurrentTime";
import DateToString from "./AllActivityWindows/DateTimeActivities/DateToString";
import GetDiskSizeWindow from "./AllActivityWindows/SystemInfoActivities/GetDiskSizeWindow";
import GetUserInfoWindow from "./AllActivityWindows/SystemInfoActivities/GetUserInfoWindow";
import SoapWindow from "./AllActivityWindows/WebServicesActivities/SoapWindow";
import RestWindow from "./AllActivityWindows/WebServicesActivities/RestWindow";
import SubstringWindow from "./AllActivityWindows/StringActivities/SubStringWindow";
import StringAfterWindow from "./AllActivityWindows/StringActivities/StringAfterWindow";
import StringConcatWindow from "./AllActivityWindows/StringActivities/StringConcatWindow";
import StringCaseWindow from "./AllActivityWindows/StringActivities/StringCaseWindow";
import StringExistsWindow from "./AllActivityWindows/StringActivities/StringExistsWindow";
import GetFileExtensionWindow from "./AllActivityWindows/PathActivities/GetFileExtensionWindow";
import FTPUploadWindow from "./AllActivityWindows/FTPActivities/FTPUploadWindow";
import FTPDownloadWindow from "./AllActivityWindows/FTPActivities/FTPDownloadWindow";
import FTPConnectWindow from "./AllActivityWindows/FTPActivities/FTPConnectWindow";
import ReadCellWindow from "./AllActivityWindows/ExcelActivities/ReadCellWindow";
import ReadCellFormulaWindow from "./AllActivityWindows/ExcelActivities/ReadCellFormulaWindow";
import WriteCellFormulaWindow from "./AllActivityWindows/ExcelActivities/WriteCellFormulaWindow";
import ReadRowsWindow from "./AllActivityWindows/ExcelActivities/ReadRowsWindow";
import ForEachMailWindow from "./AllActivityWindows/MailActivities/ForEachMailWindow";
import ForEachWindow from "./AllActivityWindows/ControlFlowActivities/ForEachWindow";
import AddNewSheetWindow from "./AllActivityWindows/ExcelActivities/AddNewSheetWindow";
import FTPDeleteWindow from "./AllActivityWindows/FTPActivities/FTPDeleteWindow";
import FTPMoveWindow from "./AllActivityWindows/FTPActivities/FTPMoveWindow";
import FTPCreateWindow from "./AllActivityWindows/FTPActivities/FTPCreateWindow";
import ConnectExtractWindow from "./AllActivityWindows/ExtractionServerActivities/ConnectExtractWindow";
import ExtractionWindow from "./AllActivityWindows/ExtractionServerActivities/ExtractionWindow";
import ReadRangeWindow from "./AllActivityWindows/ExcelActivities/ReadRangeWindow";
import StringTokenizerWindow from "./AllActivityWindows/StringActivities/StringTokenizerWindow";
import CSVOpenWindow from "./AllActivityWindows/CSVActivities/CSVOpenWindow";
import CSVReadAllLinesWindow from "./AllActivityWindows/CSVActivities/CSVReadAllLinesWindow";
import CSVWriteLinesWindow from "./AllActivityWindows/CSVActivities/CSVWriteLinesWindow";
import CustomTooltip from "../../../utils/CustomTooltip";
import CustomActivityWindow from "./AllActivityWindows/CustomActivities/CustomActivityWindow";
import CommonWindowForWindows from "./AllActivityWindows/WindowsActivities/CommonWindowForWindows";
import CheckErrorWindow from "./AllActivityWindows/ErrorHandlingActivities/CheckErrorWindow";
import OnErrorWindow from "./AllActivityWindows/ErrorHandlingActivities/OnErrorWindow";
import ConditionOfWindow from "./AllActivityWindows/ErrorHandlingActivities/ConditionOfWindow";
import ExitWindow from "./AllActivityWindows/ErrorHandlingActivities/ExitWindow";
import RetryWindow from "./AllActivityWindows/ErrorHandlingActivities/RetryWindow";
import CommonWindowWithoutInOut from "./AllActivityWindows/Common/CommonWindowWithoutInOut";
import ChangeDateFormat from "./AllActivityWindows/DateTimeActivities/ChangeDateFormat";
import ConnectDatabaseWindow from "./AllActivityWindows/DatabaseActivities/ConnectDatabaseActivity";
import { UniqueIDGenerator } from "../../../utils/UniqueIDGenerator";
import AddRecordWindow from "./AllActivityWindows/DatabaseActivities/AddRecordsWindow";
import UpdateRecordWindow from "./AllActivityWindows/DatabaseActivities/UpdateRecordWindow";
import DeleteRecordWindow from "./AllActivityWindows/DatabaseActivities/DeleteRecords";
import FetchRecordWindow from "./AllActivityWindows/DatabaseActivities/FetchRecordsWindow";
import ExecuteProcedureWindow from "./AllActivityWindows/DatabaseActivities/ExecuteProcedureWindow";
import CodeBlockWindow from "./AllActivityWindows/CodeBlockActivities/CodeBlockActivity";
const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    backgroundColor: "white",
    width: (props) => props.width,
  },
  selectedTab: {
    fontWeight: 600,
    // borderRight: `2px solid ${theme.palette.primary.main}`,
    color: `${theme.palette.primary.main}`,
    filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
    '&::after': {
      content: '""',
      position: 'absolute',
      top: 6,
      right: -8,
      height: '100%',
      width: '2px',
      backgroundColor: `${theme.palette.primary.main}`,
    },
  },

  tabs: {
    cursor: "pointer",
    color: "#606060",
  },
  items: {
    // fill: "#FFFFFF",
    height: "16px",
    width: "16px",
  },

  mainWindow: {
    width: "100%",
  },
}));
const MainScreen = ({
  // selectedActivity,
  handleOpenModal,
  addParamsToSelAct,
  addCondArrToSelAct,
  updateDisplayNameSelAct,
  id,
}) => {
  const expandedPropWindow = useSelector(
    (state) => state.editorHomepage.expandedPropWindow
  );
  const selectedActivity = useSelector(
    (state) => state.editorHomepage.selectedActivity
  );

  const classes = useStyles({
    // width: expandedPropWindow ? "510px" : "384px",
    //width: expandedPropWindow ? "480px" : "364px",
    width: expandedPropWindow ? "480px" : "384px",
  });

  const showPropertyWindow = () => {
    let returnedWindow = null;
    const { activityId } = selectedActivity;
    if (
      (activityId > 2 && activityId < 32) ||
      (activityId >= 125 && activityId <= 195)
    ) {
      return (
        <WebActivityWindow
          id={id}
          selectedActivity={selectedActivity}
          addParamsToSelAct={addParamsToSelAct}
          updateDisplayNameSelAct={updateDisplayNameSelAct}
        />
      );
    }

    if (selectedActivity?.customActivity === 2) {
      return (
        <CustomActivityWindow
          id={id}
          selectedActivity={selectedActivity}
          addParamsToSelAct={addParamsToSelAct}
          updateDisplayNameSelAct={updateDisplayNameSelAct}
        />
      );
    }
    if (
      selectedActivity?.activityName === "CheckError" &&
      typeof selectedActivity?.ruleOrderId === "string" &&
      selectedActivity?.ruleOrderId?.includes("OnError")
    ) {
      return (
        <OnErrorWindow
          id={id}
          selectedActivity={selectedActivity}
          addParamsToSelAct={addParamsToSelAct}
          updateDisplayNameSelAct={updateDisplayNameSelAct}
        />
      );
    }

    switch (activityId) {
      case 1:
        returnedWindow = (
          <AddGroupWindow
            id={id}
            selectedActivity={selectedActivity}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 2:
        returnedWindow = (
          <OpenBrowserWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 32:
        returnedWindow = (
          <CommonWindowWithoutInOut
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 33:
      case 34:
        returnedWindow = (
          <MoveFileWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 35:
        returnedWindow = (
          <RenameFileWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 36:
        returnedWindow = (
          <DeleteFileWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 37:
        returnedWindow = (
          <GetFileSizeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 38:
        returnedWindow = (
          <SplitFilePathAndNameWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 39:
        returnedWindow = (
          <GetFilesWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 40:
        returnedWindow = (
          <CreateFolderWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 41:
      case 43:
        returnedWindow = (
          <MoveFolderWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 42:
        returnedWindow = (
          <RenameFolderWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 44:
        returnedWindow = (
          <DeleteFolderWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 45:
        returnedWindow = (
          <ConnectMainWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 46:
        returnedWindow = (
          <GetMailWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 47:
        returnedWindow = (
          <MoveMailMainWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 48:
        returnedWindow = (
          <SendMailSMTPWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 49:
        returnedWindow = (
          <DeleteMailExchangeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 50:
        returnedWindow = (
          <SaveAttachmentsWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 51:
        returnedWindow = (
          <SaveMailWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 52:
        returnedWindow = (
          <ServerConnectWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 53:
      case 106:
        returnedWindow = (
          <CreateWorkitemWindow
            id={id}
            selectedActivity={selectedActivity}
            handleOpenModal={handleOpenModal}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 54:
      case 57:
        returnedWindow = (
          <CompleteWorkitemWindow
            id={id}
            selectedActivity={selectedActivity}
            handleOpenModal={handleOpenModal}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 55:
        returnedWindow = (
          <AddDocumentWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 56:
        returnedWindow = (
          <GetDocumentWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      /* case 57:
        returnedWindow = (
          <AddDocumentToWorkitemWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
*/
      case 77:
      case 79:
        returnedWindow = (
          <IfWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
            addCondArrToSelAct={addCondArrToSelAct}
          />
        );
        break;
      case 78:
        returnedWindow = (
          <ForEachWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 80:
        returnedWindow = (
          <RepeatWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 83:
        returnedWindow = (
          <AssignmentWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 84:
        returnedWindow = (
          <PrintOutPutWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 88:
        returnedWindow = (
          <OpenExcelWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 90:
        returnedWindow = (
          <ReadRowWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 91:
        returnedWindow = (
          <GetSheetsWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 92:
        returnedWindow = (
          <WriteCellWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 93:
        returnedWindow = (
          <ReadCellWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 94:
        returnedWindow = (
          <AddNewSheetWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 95:
        returnedWindow = (
          <ForEachRowWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 96:
        returnedWindow = (
          <OpenSheetsWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 97:
        returnedWindow = (
          <FilterTableWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 98:
        returnedWindow = (
          <GetTableRangeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 99:
        returnedWindow = (
          <DeleteColumnWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 100:
        returnedWindow = (
          <ReadColumnWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 101:
        returnedWindow = (
          <ReadRangeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 102:
        returnedWindow = (
          <WriteRangeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 103:
        returnedWindow = (
          <CreateTableWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 104:
        returnedWindow = (
          <CopySheetWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 105:
        returnedWindow = (
          <DeleteRangeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 107:
        returnedWindow = (
          <ForEachMailWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 108:
        returnedWindow = (
          <ReadCellFormulaWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 109:
        returnedWindow = (
          <WriteCellFormulaWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 110:
        returnedWindow = (
          <ReadRowsWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 124:
        returnedWindow = (
          <ExecuteMacroWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 196:
        returnedWindow = (
          <GetCurrentDate
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 197:
        returnedWindow = (
          <GetCurrentDateTime
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 198:
        returnedWindow = (
          <GetCurrentTime
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 199:
        returnedWindow = (
          <DateToString
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 200:
        returnedWindow = (
          <GetOSNameWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 201:
        returnedWindow = (
          <GetOSTypeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 202:
        returnedWindow = (
          <GetOSVersionWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 203:
        returnedWindow = (
          <GetFreeMemoryWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 204:
        returnedWindow = (
          <GetTotalMemoryWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 205:
        returnedWindow = (
          <GetUserHomeDirWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 206:
        returnedWindow = (
          <GetAllFoldersWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
          />
        );
        break;
      case 207:
        returnedWindow = (
          <GetDriveLetterWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 208:
        returnedWindow = (
          <GetFileNameWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 209:
        returnedWindow = (
          <GetPathWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 210:
        returnedWindow = (
          <GetSeparatorWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 211:
        returnedWindow = (
          <GetHostWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 212:
        returnedWindow = (
          <GetPortWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 213:
        returnedWindow = (
          <GetProtocolHandlerWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 214:
        returnedWindow = (
          <GetDiskSizeWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 215:
        returnedWindow = (
          <GetUserInfoWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 216:
      case 241:
      case 242:
        returnedWindow = (
          <WebActivityWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 217:
        returnedWindow = (
          <RestWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 218:
        returnedWindow = (
          <SoapWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 219:
      case 220:
        returnedWindow = (
          <StringAfterWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 221:
      case 226:
        returnedWindow = (
          <StringConcatWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 222:
      case 223:
      case 224:
        returnedWindow = (
          <StringCaseWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;

      case 225:
        returnedWindow = (
          <SubstringWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 227:
        returnedWindow = (
          <StringExistsWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 228:
      /*  returnedWindow = (
          <LaunchWindow
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;*/
      case 229:
      case 230:
      case 231:
      case 232:
      case 233:
      case 234:
      case 235:
      case 236:
      case 258:
        returnedWindow = (
          <CommonWindowForWindows
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 237:
        returnedWindow = (
          <FTPConnectWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 238:
        returnedWindow = (
          <FTPDownloadWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 239:
        returnedWindow = (
          <FTPUploadWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 240:
        returnedWindow = (
          <GetFileExtensionWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 243:
        returnedWindow = (
          <FTPDeleteWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 244:
        returnedWindow = (
          <FTPMoveWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 245:
        returnedWindow = (
          <FTPCreateWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 246:
        returnedWindow = (
          <ConnectExtractWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 247:
        returnedWindow = (
          <ExtractionWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 248:
        returnedWindow = (
          <StringTokenizerWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 249:
        returnedWindow = (
          <CSVOpenWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 250:
        returnedWindow = (
          <CSVReadAllLinesWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 251:
        returnedWindow = (
          <CSVWriteLinesWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 252:
        returnedWindow = (
          <CheckErrorWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 253:
        returnedWindow = (
          <ConditionOfWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 254:
        returnedWindow = (
          <RetryWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 255:
        returnedWindow = (
          <ExitWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 256:
        returnedWindow = (
          <ChangeDateFormat
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 259:
        returnedWindow = (
          <ConnectDatabaseWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 260:
        returnedWindow = (
          <FetchRecordWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 261:
        returnedWindow = (
          <UpdateRecordWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 262:
        returnedWindow = (
          <DeleteRecordWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 263:
        returnedWindow = (
          <AddRecordWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 264:
        returnedWindow = (
          <ExecuteProcedureWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      case 265:
        returnedWindow = (
          <CodeBlockWindow
            id={id}
            selectedActivity={selectedActivity}
            addParamsToSelAct={addParamsToSelAct}
            updateDisplayNameSelAct={updateDisplayNameSelAct}
          />
        );
        break;
      default:
        break;
    }
    return returnedWindow;
  };
  const dispatch = useDispatch();
  const tabItems = getTabs();
  const selectedTab = useSelector((state) => state.editorHomepage.selectedTab);
  const handleSelectedTab = (tabName) => {
    dispatch(setSelectedTab(tabName));
  };

  return (
    <Paper className={classes.root} square>
      <Grid container direction="row">
        <Grid
          item
          xs={1}
          style={{
            backgroundColor: "#f1eeee",
            paddingTop: "12px",
            boxShadow: `-3px 1px 4px 1px #d9d9d3`,
          }}
        >
          <Grid
            container
            direction="column"
            alignItems="center"
            spacing={2}
            role="tablist"
          >
            {tabItems &&
              tabItems.map((tabItem) => (
                <Fragment key={tabItem.value}>
                  <CustomTooltip title={tabItem.name} placement="right-end">
                    <Grid
                      item
                      className={
                        selectedTab === tabItem.value
                          ? classes.selectedTab
                          : classes.tabs
                      }
                      onClick={() => handleSelectedTab(tabItem.value)}
                      //WCAG Keyboard Accessibility: [19-06-2023] Added tabIndex and onKeyPress
                      tabIndex={0}
                      onKeyPress={(e) =>
                        e.key === "Enter" && handleSelectedTab(tabItem.value)
                      }
                      role="tab"
                      aria-selected={selectedTab === tabItem.value}
                      aria-label={`${tabItem.name}`}
                      id={`${id}_${tabItem.name}_tab`}
                    >
                      <UniqueIDGenerator>
                        <tabItem.icon className={classes.items} />
                      </UniqueIDGenerator>
                    </Grid>
                  </CustomTooltip>
                </Fragment>
              ))}
          </Grid>
        </Grid>
        <Grid
          item
          xs={11}
          style={{
            boxShadow: "0px 2px 6px #00000029",
          }}
        >
          <div className={classes.mainWindow}>
            {selectedActivity && showPropertyWindow()}
          </div>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default MainScreen;

/**
 *  useEffect(() => {
    dispatch(
      getUsersList({
        OnCall: () => {
          setIsFetchingUsers(true);
        },
        OnSuccess: () => {
          setIsFetchingUsers(false);
        },
        OnError: () => {
          setIsFetchingUsers(false);
        },
      })
    );
  }, []);
 */
