import React, { useState } from "react";
import makeStyles from '@mui/styles/makeStyles';
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import { Grid, Checkbox, FormGroup, FormControlLabel } from "@mui/material";
const useStyles = makeStyles((theme) => ({
  CheckBoxIcon: {
    color: `${theme.palette.primary.main}`,
  },
  checkbox: {
    '&:focus-visible': {
      outline: `2px solid ${theme.palette.primary.main}`,
      borderRadius: '2px',
    },
  },
  icon: {
    //height: "12px",
    //width: "12px",
    // fontSize: "12px",
  },
  focusedIcon: {
    fill: `${theme.palette.primary.main}`
  },
  label: { fontSize: "12px", color: "#000000", opacity: 1, fontWeight: 600 },
  visuallyhidden: {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: "1px",
    margin: "-1px",
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    width: "1px",
  },
}));
const CheckboxField = (props) => {
  const { id, name, value, label, onChange, disabled, styleObj } = props;
  const [isFocused, setIsFocused] = useState(false);
  const handleFocusVisible = (event) => {
    setIsFocused(true);
  };

  const handleBlur = () => {
    setIsFocused(false);
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      // onChange(event, !value);
      onChange({ ...event, target: { ...event.target, name: event?.target?.name, checked: !value } }, !value);
    }
  };
  const classes = useStyles();
  return (
    <Grid container>
      <Grid item>
        <FormGroup>
          <FormControlLabel
            className={classes.label}
            control={
              <Checkbox
                aria-label={`${label !== undefined} ? ${label} : ${name}`}
                style={{
                  fontSize: styleObj?.fontSize || "13px",
                  paddingRight: styleObj?.paddingRight || "5px",
                  paddingBottom: styleObj?.paddingBottom || "3px",
                  paddingTop: styleObj?.paddingTop || "3px",
                }}
                checked={value}
                icon={
                  <CheckBoxOutlineBlankIcon
                    fontSize="small"
                    className={isFocused ? classes.focusedIcon : classes.icon}

                  />
                }
                checkedIcon={
                  <CheckBoxIcon
                    fontSize="small"
                    className={classes.icon + " " + classes.CheckBoxIcon}
                  />
                }
                name={name}
                value={value}
                onChange={onChange}
                disableRipple
                disabled={disabled}
                //WCAG Keyboard Accessibility : [19-06-2023] - Added tabIndex
                // tabIndex={0}
                onBlur={handleBlur}
                onFocus={handleFocusVisible}
                id={id}
                onKeyDown={handleKeyDown}
              />
            }
            label={
              label ? (
                <span style={{ fontSize: "12px", fontWeight: 600 }}>
                  {label}
                </span>
              ) : (
                <span className={classes.visuallyhidden}>{name}</span>
              )
            }
          />
        </FormGroup>
      </Grid>
    </Grid>
  );
};

export default CheckboxField;
