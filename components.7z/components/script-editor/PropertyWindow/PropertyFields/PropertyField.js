import React, { useState, useContext, useEffect } from "react";
import { useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import {
  Typography,
  TextField,
  Grid,
  Box,
  InputAdornment,
} from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import {
  FormatShapes,
  ExitToApp,
  AddBoxOutlined,
  Remove,
} from "@mui/icons-material";
import CheckboxField from "./CheckboxField";
import RadioButtonGroup from "./RadioButtonGroup";
import {
  truncateString,
  getAllVariables,
  getVariableTypeById,
} from "../AllActivityWindows/Common/CommonMethods";
import SimplePopover from "../../../../utils/Popover";
import Field from "../../../../utils/field";
import CustomTooltip from "../../../../utils/CustomTooltip";
import InfoIcon from "@mui/icons-material/Info";
import {
  isEmptyText,
  MaximumLengthText,
  MinimumLengthText,
  onlyLettersAndUnderscore,
  atleastContainsACharacter,
} from "../../../../utils/validations/validations";
import {
  createInstance,
  handleNetworkRequestError,
} from "../../../../utils/common";
import { VARIABLES } from "./../../../../config/index";
import { NotificationContext } from "./../../../../contexts/NotificationContext";
import { VariablesContext } from "./../../../../contexts/VariablesListContext";
import {
  InputTypeDropdownIcon,
  InputTypeTextIcon,
} from "../../../../utils/AllImages";
import { getCssFilterFromHex } from "../../../../utils/HexToFilter";
import SelectComboBox from "./../../../../utils/SelectComboBox/index";
import { UniqueIDGenerator } from "../../../../utils/UniqueIDGenerator";

const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};
const useStyles = makeStyles((theme) => ({
  visuallyhidden: {
    border: 0,
    clip: "rect(0 0 0 0)",
    height: "1px",
    margin: "-1px",
    overflow: "hidden",
    padding: 0,
    position: "absolute",
    width: "1px",
  },
  focusVisible: {
    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  root: {
    paddingBottom: "5px",
    width:(props)=>props.rootWidth||""
  },
  inputTitle: {
    height: 27,
    backgroundColor: "white",
    fontSize: "14px",
  },
  input: {
    height: (props) => props.height || 28,
    backgroundColor: (props) => props.disabled ? "#F0F0F0" : "white",
    fontSize: "12px",
  },

  multilineInput: {
    backgroundColor: "white",
    fontSize: 12,
    overflowY: "scroll",
  },
  label: { fontSize: 12, color: "#606060", fontWeight: 600 },
  labelCheckbox: {
    fontSize: "12px",
    color: "#686868",
    opacity: 1,
    fontWeight: 450,
  },
  helperText: {
    color: (props) => props.helperTextColor || "#606060",
    fontSize: "10px",
  },
  colorPrimary: {
    // filter: getCssFilterFromHex(`${theme.palette.primary.main}`),
    filter: `invert(29%) sepia(90%) saturate(5100%) hue-rotate(191deg) brightness(96%) contrast(101%)`,
    //backgroundColor: `${theme.palette.primary.main}`,
  },
  labelBtn: {
    border: "1px solid #c5c5c5",
    width: "23px",
    height: "16px",
    borderRadius: "2px",
  },
  labelBtnDisabled: {
    border: "1px solid #c5c5c5",
    width: "23px",
    height: "16px",
    borderRadius: "2px",
    opacity: 0.4,
  },
}));
const PropertyField = (props) => {
  const classes = useStyles({ height: props.height, helperTextColor: props.helperTextColor, disabled: props.disabled,rootWidth:props.rootWidth });
  const history = useHistory();
  const [varName, setVarName] = useState(makeFieldInputs(""));
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [formHasError, setFormHasError] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const { setValue } = useContext(NotificationContext);
  const allVariables = getAllVariables();
  const { setAllVariables: setAllVariablesInContext } = useContext(
    VariablesContext
  );

  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const versionId = scriptValues && scriptValues.versionId;
  const scriptId = scriptValues && scriptValues.scriptId;
  const handleClickOpen = (event) => {
    setAnchorEl(event?.currentTarget);
  };
  const [showMessage, setShowMessage] = useState(false);
  const showInfoMessage = () => {
    setShowMessage(true);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";

    switch (name) {
      case "variableName":
        errors =
          isEmptyText(value) ||
          onlyLettersAndUnderscore(value) ||
          atleastContainsACharacter(value) ||
          MinimumLengthText(value, 2) ||
          MaximumLengthText(value, 40);
        setVarName({
          ...varName,
          value,
          error: errors,
          helperText: errors,
        });
        break;
    }
  };
  useEffect(() => {
    if (varName?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [varName]);
  const validateFields = () => {
    const varNameErrors =
      isEmptyText(varName.value) ||
      onlyLettersAndUnderscore(varName.value) ||
      atleastContainsACharacter(varName.value) ||
      MinimumLengthText(varName.value, 2) ||
      MaximumLengthText(varName.value, 40);
    if (varNameErrors) {
      setVarName({
        ...varName,
        error: varNameErrors,
        helperText: varNameErrors,
      });
    }

    return varNameErrors ? false : true;
  };
  const onClick1 = () => {
    setVarName({ ...varName, value: "" });
    handleClose();
  };
  const onClick2 = async () => {
    if (!validateFields()) {
      return;
    }
    setIsProcessing(true);
    const axiosInstance = createInstance();

    let json = {
      scriptId: +scriptId,
      versionId: +versionId,
      variableName: varName.value,
      variableObjType: props.paramObj
        ? +props.paramObj?.paramObjectTypeId
        : null,

      variableType: "C",
      valueState: [],
    };

    try {
      let res = await axiosInstance.post(`${VARIABLES}`, {
        ...json,
      });

      if (res.status === 200) {
        let newVariables = [
          ...allVariables,
          { ...json, variableId: res.data.data[0]["variableId"] },
        ];
        setAllVariablesInContext({ allVariables: newVariables });
        setValue({
          isOpen: true,
          notificationType: "SUCCESS",
          message: res.data["message"] || "created Succefully.",
          title: varName.value,
        });
        handleClose();
        setIsProcessing(false);
        setVarName({ ...varName, value: "" });
      }
    } catch (error) {
      console.log(error.response);
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setValue({
            isOpen: true,
            notificationType: "ERROR",
            message: errMsg || "creation failed.",
            title: varName.value,
          });
        },
      });
      setIsProcessing(false);
    }
  };
  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;
  return (
    <div className={classes.root}>
      {/*for Activity Title/Name */}
      {props.ActivityTitle ? (
        <>
          <Grid container alignItems="center" spacing={1}>
            {props.ActivityIcon && <Grid item>{props.ActivityIcon}</Grid>}

            <Grid item xs>
              <TextField
                type={"text"}
                error={props.error}
                placeholder={props.placeholder || ""}
                name="ActivityName"
                size="small"
                fullWidth={true}
                InputProps={{
                  className: classes.inputTitle,
                  endAdornment: props.endAdornment || null,
                }}
                inputProps={{
                  "data-testid": "activityField",
                  "aria-labelledby": props.id,
                }}
                value={props.value}
                onChange={props.onChange}
                variant="outlined"
              />
            </Grid>
          </Grid>
          {props.helperText && (
            <Grid container>
              <Grid item xs style={{ marginRight: "5px" }}>
                <Typography
                  component="small"
                  className={classes.helperText}
                  title={props.helperTitle || ""}
                >
                  {props.helperText}
                </Typography>
              </Grid>
              {props.ScopeActivity && (
                <Grid item style={{ marginLeft: "auto" }}>
                  <Grid container spacing={1}>
                    <Grid item>
                      <Typography
                        component="small"
                        className={classes.helperText}
                      >
                        Scope Activity
                      </Typography>
                    </Grid>
                    <Grid item>
                      <Typography
                        component="small"
                        className={classes.helperText}
                      >
                        <FormatShapes fontSize="small" />
                      </Typography>
                    </Grid>
                  </Grid>
                </Grid>
              )}
            </Grid>
          )}
        </>
      ) : null}
      {props.checkbox && (
        <>
          <Grid container direction="row">
            <Grid item>
              <CheckboxField
                name={props.name}
                value={props.value}
                label={props.label}
                onChange={props.onChange}
                id={props.id}
              />
            </Grid>

            {props.labelBtn1 || props.labelBtn2 || props.labelCheckbox ? (
              <Grid item style={{ marginLeft: "auto", marginTop: 6 }}>
                <Grid container alignItems="center">
                  {props.labelCheckbox && (
                    <Grid item>{props.labelCheckbox}</Grid>
                  )}
                  {props.labelBtn1 && (
                    <Grid item style={{ cursor: "pointer" }}>
                      <UniqueIDGenerator>
                        <InputTypeTextIcon
                          onClick={() => {
                            !props.labelBtnDisabled && props.labelBtn1OnClick
                              ? props.labelBtn1OnClick(props.name, "C")
                              : console.log("provide function");
                          }}
                          className={
                            props.labelBtnDisabled
                              ? classes.colorPrimary +
                              " " +
                              classes.labelBtnDisabled
                              : props.paramObj?.paramType === "C"
                                ? classes.colorPrimary + " " + classes.labelBtn
                                : classes.labelBtn
                          }
                          id={`${props.id}_InputTypeTextIcon`}
                        />
                      </UniqueIDGenerator>
                    </Grid>
                  )}
                  {props.labelBtn2 && (
                    <Grid
                      item
                      style={{
                        marginLeft: "-1px",
                        cursor: "pointer",
                      }}
                    >
                      <UniqueIDGenerator>
                        <InputTypeDropdownIcon
                          onClick={() => {
                            !props.labelBtnDisabled && props.labelBtn2OnClick
                              ? props.labelBtn2OnClick(props.name, "V")
                              : console.log("provide function");
                          }}
                          className={
                            props.labelBtnDisabled
                              ? classes.labelBtnDisabled
                              : props.paramObj?.paramType === "V"
                                ? classes.colorPrimary + " " + classes.labelBtn
                                : classes.labelBtn
                          }
                          id={`${props.id}_InputTypeDropdown`}
                        />
                      </UniqueIDGenerator>
                    </Grid>
                  )}
                </Grid>
              </Grid>
            ) : null}
          </Grid>
          {props.helperText && (
            <Grid container>
              <Grid item>
                <Typography component="small" className={classes.helperText}>
                  {props.helperText}
                </Typography>
              </Grid>
            </Grid>
          )}
        </>
      )}

      {props.radio && (
        <RadioButtonGroup
          id={props.id}
          ButtonsArray={props.ButtonsArray}
          name={props.name}
          value={props.value}
          label={props.label}
          onChange={props.onChange}
          column={props.column}
        />
      )}
      {props.combo && (
        <SelectComboBox
          width={props.width}
          name={props.name}
          value={props.value}
          /*   label={
            props.paramObj
              ? `${props.label} (${getVariableTypeById(
                  props.paramObj.paramObjectTypeId
                )})`
              : props.label
          }*/
          placeholder={props.placeholder}
          label={props.label}
          infoMessage={props.infoMessage}
          canType={props.canType}
          dropdown={props.dropdown}
          readOnly={props.readOnly}
          secret={props.secret}
          type={props.type}
          varType={props.paramObj?.paramObjectTypeId || props.varType || 1}
          error={props.error}
          helperText={props.helperText}
          helperTextColor={props.helperTextColor}
          endAdornment={props.endAdornment}
          options={props.options || []}
          paramObj={props.paramObj}
          handleOnChange={(e, valueItem) => {
            if (props.windowProps) {
              const { value } = valueItem;
              const item = {
                target: { name: props.name, value: "${" + value + "}" },
              };
              props.onChange(item);
            } else {
              const { value } = valueItem;
              const item = { target: { name: props.name, value } };

              if (
                props.labelBtn2OnClick &&
                typeof props.labelBtn2OnClick === "function"
              ) {
                props.labelBtn2OnClick(props.name, "V");
              }
              props.onChange(item);
            }
          }}
          handleChange={(e) => {
            if (props.paramObj?.paramType === "V" || props.paramObj?.paramVariableType === "V") {
              if (
                props.labelBtn1OnClick &&
                typeof props.labelBtn1OnClick === "function"
              ) {
                props.labelBtn1OnClick(props.name, "C");
              }
            }
            props.onChange(e);
          }}
        />
      )}
      {!props.checkbox &&
        !props.ActivityTitle &&
        !props.radio &&
        !props.combo ? (
        <>
          <Grid container alignItems="center">
            {props.icon && (
              <Grid item>
                <Typography className={classes.label}>{props.icon}</Typography>
              </Grid>
            )}
            {props.labelWithCheckbox && (
              <Grid item>
                <CheckboxField
                  id={props.id}
                  name={props.labelCheckboxName}
                  value={props.labelCheckboxValue}
                  label={props.label}
                  onChange={props.onChange}
                />
              </Grid>
            )}
            {props.labelWithCheckbox ? null : (
              <Grid container alignItems="center" wrap="nowrap">
                {props.label ? (
                  <Grid item>
                    <Typography className={classes.label} id={props.id}>
                      {props.label ? props.label : null}
                    </Typography>
                  </Grid>
                ) : (
                  <Grid item>
                    <Typography
                      className={classes.visuallyhidden}
                      id={props.id}
                    >
                      {props.name ? props.name : "None"}
                    </Typography>
                  </Grid>
                )}

                {props.required && (
                  <Grid item>
                    <Typography className={classes.required}>*</Typography>
                  </Grid>
                )}
                {props.iconAfterLabel && (
                  <Grid item style={{ marginLeft: "4px" }}>
                    {props.iconAfterLabel}
                  </Grid>
                )}
              </Grid>
            )}

            {props.labelBtn1 || props.labelBtn2 || props.labelCheckbox ? (
              <Grid item style={{ marginLeft: "auto" }}>
                <Grid container alignItems="center">
                  {props.labelCheckbox && (
                    <Grid item>{props.labelCheckbox}</Grid>
                  )}
                  {props.labelBtn1 && (
                    <Grid item style={{ cursor: "pointer" }}>
                      <UniqueIDGenerator>
                        <InputTypeTextIcon
                          onClick={() => {
                            !props.labelBtnDisabled && props.labelBtn1OnClick
                              ? props.labelBtn1OnClick(props.name, "C")
                              : console.log("provide function");
                          }}
                          className={
                            props.labelBtnDisabled
                              ? classes.colorPrimary +
                              " " +
                              classes.labelBtnDisabled
                              : props.paramObj?.paramType === "C"
                                ? classes.colorPrimary + " " + classes.labelBtn
                                : classes.labelBtn
                          }
                          id={`${props.id}_InputTypeTextIcon`}
                        />
                      </UniqueIDGenerator>
                    </Grid>
                  )}
                  {props.labelBtn2 && (
                    <Grid
                      item
                      style={{
                        marginLeft: "-1px",
                        cursor: "pointer",
                      }}
                    >
                      <UniqueIDGenerator>
                        <InputTypeDropdownIcon
                          onClick={() => {
                            !props.labelBtnDisabled && props.labelBtn2OnClick
                              ? props.labelBtn2OnClick(props.name, "V")
                              : console.log("provide function");
                          }}
                          className={
                            props.labelBtnDisabled
                              ? classes.labelBtnDisabled
                              : props.paramObj?.paramType === "V"
                                ? classes.colorPrimary + " " + classes.labelBtn
                                : classes.labelBtn
                          }
                          id={`${props.id}_InputTypeDropdown`}
                        />
                      </UniqueIDGenerator>
                    </Grid>
                  )}
                </Grid>
              </Grid>
            ) : null}
          </Grid>

          <Box

            style={{ width: props.width }}>
            {props.range ? (
              <Grid container spacing={2}>
                <Grid item xs={5}>
                  <TextField
                    id={`${props.id}_Range1`}
                    type="text"
                    error={props.error1}
                    helperText={props.helperText1}
                    size="small"
                    name={props.name1}
                    InputProps={{
                      className: classes.input,
                    }}
                    value={props.value1}
                    onChange={props.onChange}
                    variant="outlined"
                    FormHelperTextProps={{
                      style: { marginLeft: 0, fontSize: "10px" },
                    }}
                    inputProps={{
                      "aria-labelledby": props.id,
                    }}
                  />
                </Grid>
                <Grid item xs={2}>
                  <Grid container justifyContent="center">
                    <Remove />
                  </Grid>
                </Grid>
                <Grid item xs={5}>
                  <TextField
                    type="text"
                    error={props.error2}
                    helperText={props.helperText2}
                    size="small"
                    name={props.name2}
                    InputProps={{
                      className: classes.input,
                    }}
                    value={props.value2}
                    onChange={props.onChange}
                    variant="outlined"
                    FormHelperTextProps={{
                      style: {
                        marginLeft: 0,
                        fontSize: "10px",
                      },
                    }}
                    inputProps={{
                      "aria-labelledby": props.id,
                    }}
                  />
                </Grid>
              </Grid>
            ) : (
              <Grid container>
                <Grid item xs>
                  <TextField
                    //id={props.id}
                    type={
                      props.secret
                        ? "password"
                        : props.type
                          ? props.type
                          : "text"
                    }
                    error={props.error}
                    helperText={props.helperText}
                    size="small"
                    multiline={props.multiline}
                    // rows={1}
                    maxrows={4}
                    fullWidth={true}
                    name={props.name || props.label}
                    inputProps={{
                      "aria-labelledby": props.id,
                    }}
                    /* InputProps={{
                      className: props.multiline
                        ? classes.multilineInput
                        : classes.input,
                     
                      endAdornment: props.endAdornment || null,
                      readOnly: props.readOnly || null,
                      spellCheck: false,
                    }}*/
                    InputProps={
                      props.InputProps
                        ? {
                          className: props.multiline
                            ? classes.multilineInput
                            : classes.input,
                          readOnly: props.readOnly || null,
                          endAdornment: props.endAdornment || null,
                          startAdornment: props.startAdornment ? (
                            <InputAdornment position="start">
                              {props.startAdornment}
                            </InputAdornment>
                          ) : null,

                          spellCheck: false,
                          ...props.InputProps,
                        }
                        : {
                          className: props.multiline
                            ? classes.multilineInput
                            : classes.input,
                          readOnly: props.readOnly || null,
                          endAdornment: props.endAdornment || null,
                          startAdornment: props.startAdornment ? (
                            <InputAdornment position="start">
                              {props.startAdornment}
                            </InputAdornment>
                          ) : null,
                          spellCheck: false,
                        }
                    }
                    value={props.value}
                    onChange={props.onChange}
                    variant="outlined"
                    // id="outlined-adornment-password"
                    FormHelperTextProps={{
                      style: {
                        marginLeft: 0,
                        fontSize: "10px",
                        color: props.error ? "#D53D3D" : "#606060",
                      },
                    }}
                    disabled={
                      props.disabled ||
                      (props.dropdown && props.options.length == 0)
                    }
                    select={props.dropdown}
                    SelectProps={{
                      native: true,
                    }}
                  >
                    <option hidden defaultValue>
                      -select-
                    </option>
                    {props.dropdown ? (
                      props.options.length > 0 ? (
                        props.options.map((item) => (
                          <option
                            value={item.value}
                            key={item.name}
                            title={item.name}
                          >
                            {item?.name && truncateString(item.name)}
                          </option>
                        ))
                      ) : (
                        /* Issue: WCAG[1.3.1] :Container element is empty 
                        Solution: 1) An option is provided in case there is no option available.
                                  2) Simultaneously, disabled the Select as well so that user cannot select it.*/
                        <option>-select-</option>
                      )
                    ) : null}
                  </TextField>
                </Grid>
                {props.btnIcon && (
                  <Grid
                    item
                    style={{
                      marginLeft: "-2px",
                      zIndex: 1,
                    }}
                    onClick={
                      props.btnIconDefaultHandler ? null : handleClickOpen
                    }
                    aria-describedby={id}
                    tabIndex={props.btnIconDefaultHandler ? -1 : 0}
                    onKeyPress={(e) => {
                      if (e.key === "Enter" && !props.btnIconDefaultHandler) {
                        handleClickOpen(e);
                      }
                    }}
                    className={classes.focusVisible}
                  >
                    {props.btnIcon}
                  </Grid>
                )}
              </Grid>
            )}
            <SimplePopover
              id={id}
              handleClose={handleClose}
              Content={
                <Content varName={varName} handleChange={handleChange} />
              }
              open={open}
              anchorEl={anchorEl}
              paramObj={props?.paramObj}
              btn1Title="Cancel"
              onClick1={onClick1}
              onClick2={onClick2}
              isProcessing={isProcessing}
              btn2Disabled={formHasError}
              btn2Title="Save"
            />
          </Box>
        </>
      ) : null}
    </div>
  );
};

export default PropertyField;
const Content = ({ varName, handleChange }) => {
  return (
    <>
      <div style={{ padding: "15px" }}>
        <Field
          name="variableName"
          label="Variable Name"
          {...varName}
          required={true}
          width={242}
          onChange={handleChange}
        />
      </div>
    </>
  );
};
