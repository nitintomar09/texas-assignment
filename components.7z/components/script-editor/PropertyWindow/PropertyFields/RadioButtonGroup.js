import React from "react";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import makeStyles from '@mui/styles/makeStyles';
import { RedefineEventTarget } from "../../../../utils/common";
const useStyles = makeStyles((theme) => ({
  label: { fontSize: "12px", color: "#686868", opacity: 1, fontWeight: 450 },
  focusVisible: {
    outline: "none",
    "&:focus-visible": {
      "& svg": {
        outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
        borderRadius: "10px",
      },
    },
  },
}));

const RadioButtonGroup = ({
  ButtonsArray,
  name,
  value,
  label,
  onChange,
  column,
  id,
}) => {
  const classes = useStyles();
  return (
    <FormControl variant="standard" component="fieldset">
      <FormLabel component="legend" className={classes.label}>
        {label || ""}
      </FormLabel>
      <RadioGroup
        row={column ? false : true}
        aria-label={label || "Label"}
        name={name || "radios"}
        value={value || ""}
        onChange={onChange}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            const child = e.target.querySelector("input");
            onChange(RedefineEventTarget(e, child));
          }
        }}
        id={`${id}_RadioButtons`}
      >
        {ButtonsArray &&
          ButtonsArray.map((button) => (
            <FormControlLabel
              tabIndex={0}
              key={button.label}
              className={[classes.label, classes.focusVisible].join(" ")}
              value={button.value}
              control={<Radio color="primary" tabIndex={-1} />}
              label={
                <span style={{ fontSize: "12px" }}>{button.label || ""}</span>
              }
              role="radio"
              aria-checked
              id={`${id}_${button.label}`}
            />
          ))}
      </RadioGroup>
    </FormControl>
  );
};
export default RadioButtonGroup;
