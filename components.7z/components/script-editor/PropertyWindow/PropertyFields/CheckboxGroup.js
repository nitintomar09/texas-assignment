import React, { useState } from "react";
import makeStyles from '@mui/styles/makeStyles';
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import { Grid, Checkbox, FormGroup, FormControlLabel } from "@mui/material";
const useStyles = makeStyles((theme) => ({
  CheckBoxIcon: {
    color: `${theme.palette.primary.main}`,
  },
  checkbox: {
    '&:focus-visible': {
      outline: `2px solid ${theme.palette.primary.main}`,
      borderRadius: '2px',
    },
  },
  focusedIcon: {
    fill: `${theme.palette.primary.main}`
  },
  icon: {
    // height: "16px",
    //width: "16px",
    // fontSize: "12px",
  },
  label: { fontSize: "12px", color: "#686868", opacity: 1, fontWeight: 450 },
}));
const CheckboxGroup = (props) => {
  const classes = useStyles();
  const { checkboxArray } = props;
  const [isFocused, setIsFocused] = useState("");
  const handleFocusVisible = (name) => {
    setIsFocused(name);
  };

  const handleBlur = () => {
    setIsFocused("");
  };

  const handleKeyDown = (event, onChangeFn, value) => {
    if (event.key === 'Enter') {
      onChangeFn({...event,target:{...event.target,name:event?.target?.name,checked:!value}}, !value);
    }
  };

  return (
    <Grid container direction="column" spacing={1}>
      {checkboxArray &&
        checkboxArray.map((item, index) => {
          const { name, value, onChange, label } = item;
          return (
            <Grid item key={name || index}>
              <FormGroup>
                <FormControlLabel
                  className={classes.label}
                  control={
                    <Checkbox
                      style={{
                        fontSize: "12px",
                        paddingRight: "5px",
                        paddingBottom: "3px",
                        paddingTop: "3px",
                      }}
                      icon={
                        <CheckBoxOutlineBlankIcon
                          fontSize="small"
                          className={(isFocused === name || isFocused === label) ? classes.focusedIcon : classes.icon}
                        />
                      }
                      checkedIcon={
                        <CheckBoxIcon
                          fontSize="small"
                          className={classes.icon + " " + classes.CheckBoxIcon}
                        />
                      }
                      checked={value}
                      name={name}
                      value={value}
                      onChange={onChange}
                      disableRipple
                      id={`${props.id}_${name || label || ""}_CheckBox`}
                      onBlur={handleBlur}
                      onFocus={() => handleFocusVisible(name || label)}
                      onKeyDown={(e) => handleKeyDown(e, onChange, value)}
                    />
                  }
                  label={
                    <span style={{ fontSize: "12px" }}>
                      {label || name || ""}
                    </span>
                  }
                />
              </FormGroup>
            </Grid>
          );
        })}
    </Grid>
  );
};

export default CheckboxGroup;
