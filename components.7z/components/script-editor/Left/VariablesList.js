import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import { ChevronRight, ExpandLess } from "@mui/icons-material";
import { Divider, Grid, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import { truncateStringValues } from "../../../utils/common";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 240,
    backgroundColor: "#FFFFFF",
    maxHeight: "450px",
    overflowY: "scroll",
  },
  itemRoot: {
    paddingLeft: "30px",
    paddingRight: "15px",
  },
  list_item: {
    minHeight: "50px",
    backgroundColor: "#FFFFFF",
    display: "flex",
    flexGrow: 1,

    //width: "216px",
  },
  list_item_nested: {
    height: "25px",
    paddingLeft: "25px",
    display: "flex",
    flexGrow: 1,
    //width: "216px",
  },
  text_light: {
    fontSize: "12px",
    fontWeight: 600,
    color: "#606060",
  },
  nested: {
    paddingLeft: theme.spacing(2),
    height: "25px",
  },
  nestedClose: {
    paddingLeft: theme.spacing(1),
    height: "15px",
  },
  img: {
    width: "12px",
    height: "12px",
    marginTop: "3px",
  },
  chevronIcon: {
    marginTop: "6px",
    cursor: "pointer",
  },
  variableName: {
    fontSize: "12px",
    fontWeight: "bold",
  },
}));

const VariableListItem = (props) => {
  const { variable, openedListVariables, handleOpenListVariables, id } = props;
  const classes = useStyles();

  const handleClick = (variableName) => {
    let list = [...openedListVariables];
    const index = list.findIndex((variable1) => variable1 === variableName);
    if (index !== -1) {
      list.splice(index, 1);
    } else {
      list.push(variableName);
    }
    handleOpenListVariables(list);
  };

  const truncateString = (str) => {
    return str.trim().length > 18 ? str.substring(0, 14) + ".." : str;
  };

  return (
    <React.Fragment>
      <ListItem button className={classes.list_item} id={`${id}`}>
        <Grid container alignItems="center" direction="column" spacing={1}>
          <Grid item container direction="row" spacing={1}>
            {openedListVariables &&
            openedListVariables.includes(`${variable.variableName}`) ? (
              <ExpandLess
                fontSize="small"
                className={classes.chevronIcon}
                onClick={() => handleClick(variable.variableName)}
                id={`${id}_ExpandLessBtn`}
              />
            ) : (
              <ChevronRight
                fontSize="small"
                className={classes.chevronIcon}
                onClick={() => handleClick(variable.variableName)}
                id={`${id}_ChevronRightBtn`}
              />
            )}

            <Grid item>
              <Typography className={classes.variableName}>
                {variable.variableName &&
                  truncateString(variable.variableName || "")}
              </Typography>
            </Grid>
            {/* <Grid item>
              <Typography className={classes.text_light}>
                ({variable.variableType})
              </Typography>
           </Grid>*/}
          </Grid>
          {openedListVariables &&
            openedListVariables.includes(`${variable.variableName}`) && (
              <Grid
                item
                container
                direction="row"
                spacing={1}
                style={{ paddingLeft: "18px" }}
              >
                <Grid item>
                  <Typography className={classes.text_light}>
                    Current Value
                  </Typography>
                </Grid>
                <Grid item xs title={variable.currentValue || ""}>
                  <Typography>
                    {" "}
                    {truncateStringValues({
                      str: variable.currentValue || "",
                      max: 30,
                      min: 25,
                    })}
                  </Typography>
                </Grid>
              </Grid>
            )}
        </Grid>
      </ListItem>
      {/*<div className={classes.itemRoot}>
        {variable.variableDetails &&
          openedListVariables &&
          openedListVariables.includes(`${variable.variableName}`) && (
            <>
              <Grid container direction="row" spacing={2}>
                <Grid item xs={4}>
                  <Typography className={classes.text_light}>
                    Line No.
                  </Typography>
                </Grid>
                <Grid item xs={4}>
                  <Typography> Value</Typography>
                </Grid>
              </Grid>

              <Grid container direction="column" spacing={1}>
                {variable.variableDetails.map((varDetail, index) => (
                  <Grid item key={index}>
                    <Grid container direction="row" spacing={2}>
                      <Grid item xs={4}>
                        <Typography className={classes.text_light}>
                          {" "}
                          {varDetail.lineNumber}
                        </Typography>
                      </Grid>
                      <Grid item xs={4}>
                        <Typography> {varDetail.value}</Typography>
                      </Grid>
                    </Grid>
                  </Grid>
                ))}
              </Grid>
            </>
          )}
      </div>*/}
    </React.Fragment>
  );
};

const VariablesList = (props) => {
  const classes = useStyles();
  const { variablesList, openedListVariables, handleOpenListVariables } = props;
  const runScriptModal = useSelector(
    (state) => state.editorHomepage.runScriptModal
  );
  return (
    variablesList &&
    variablesList.length > 0 && (
      <List
        component="nav"
        aria-labelledby="variables-list"
        className={classes.root}
        style={{
          cursor: "default",
          maxHeight: runScriptModal ? "260px" : "500px",
        }}
      >
        {variablesList.map((variable) => (
          <React.Fragment key={variable.variableName}>
            <VariableListItem
              id={`${props.id}_${variable.variableName}`}
              variable={variable}
              openedListVariables={openedListVariables}
              handleOpenListVariables={handleOpenListVariables}
            />
            <Divider variant="fullWidth" />
          </React.Fragment>
        ))}
      </List>
    )
  );
};
export default VariablesList;
