/**
 *  activities={
                selectedTab === "Favourites"
                  ? activities.filter((activity) => activity.favourite)
                  : selectedTab === "Recents"
                  ? recentActivities
                  : activities
              }
              leftPanelOpen={leftPanelOpen}
              handleLeftPanel={handleLeftPanel}
              activitiesIcons={listOfActivities}
              openedListGroup={openedListGroup}
              handleOpenListGroup={handleOpenListGroup}
              handleDrag={handleDrag}
 */

import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "../../../../utils/CustomAppComp";
import ActivityList from "./../ActivityList";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  const leftPanelOpen = jest.fn();
  const handleLeftPanel = jest.fn();
  const handleDrag = jest.fn();
  ReactDom.render(
    <CustomAppComp>
      <ActivityList
        activities={activities}
        leftPanelOpen={leftPanelOpen}
        handleLeftPanel={handleLeftPanel}
        handleDrag={handleDrag}
      />
    </CustomAppComp>,
    div
  );
});

it("matches snapshot", () => {
  const leftPanelOpen = jest.fn();
  const handleLeftPanel = jest.fn();
  const handleDrag = jest.fn();
  const tree = renderer
    .create(
      <CustomAppComp>
        <ActivityList
          activities={activities}
          leftPanelOpen={leftPanelOpen}
          handleLeftPanel={handleLeftPanel}
          handleDrag={handleDrag}
        />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
const activities = [
  {
    activities: [],
    groupIcon: null,
    groupId: 3,
    groupName: "File and Folder",
  },
];
