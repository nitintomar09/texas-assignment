import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import CustomAppComp from "../../../../utils/CustomAppComp";
import MainLeft from "./../MainLeft";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  ReactDom.render(
    <CustomAppComp>
      <MainLeft />
    </CustomAppComp>,
    div
  );
});

it("matches snapshot", () => {
  const leftPanelOpen = jest.fn();
  const handleLeftPanel = jest.fn();
  const handleDrag = jest.fn();
  const tree = renderer
    .create(
      <CustomAppComp>
        <MainLeft
          leftPanelOpen={leftPanelOpen}
          handleLeftPanel={handleLeftPanel}
          handleDrag={handleDrag}
          recentActivities={recentActivities}
        />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
const recentActivities = [];
