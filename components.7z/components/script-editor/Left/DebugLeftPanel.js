import React, { useState } from "react";
import makeStyles from '@mui/styles/makeStyles';
import { Grid, Paper, Typography } from "@mui/material";
import { ExpandMore } from "@mui/icons-material";

import MenuPopper from "../../../utils/MenuPopper";
import SearchBox from "../../../utils/Search-Component";
import VariablesList from "./VariablesList";
import VariablesList1 from "./VariableList1";
import { useSelector } from "react-redux";
import { useTranslation } from "react-i18next";

const useStyles = makeStyles((theme) => ({
  rootClosePanel: {
    height: "630px",
    display: "flex",
    backgroundColor: "#FFFFFF",
    width: "240px",
    /* [theme.breakpoints.down("lg")]: {
      paddingTop: "30px",
    },*/
  },
  root: {
    height: "630px",
    display: "flex",
    backgroundColor: "#FFFFFF",
    width: "400px",
    /* [theme.breakpoints.down("lg")]: {
      paddingTop: "30px",
    },*/
  },
  item: {
    paddingLeft: "20px",
    marginTop: "16px",
  },
  searchBox: {
    paddingLeft: "20px",
    marginTop: "8px",
    marginBottom: "8px",
  },
  text_light: {
    fontSize: "12px",
    // fontWeight: 600,
    color: "#606060",
  },
  icon: {
    marginTop: "2px",
  },

  chevronIcon: {
    paddingRight: "2px",
    height: "20px",
    width: "20px",
  },
  text_12: {
    fontSize: "12px",
  },
  bold: {
    fontWeight: "bold",
  },
  shownListType: {
    color: `${theme.palette.primary.main}`,
  },
}));
const DebugLeftPanel = (props) => {
  const classes = useStyles();
  const {t} = useTranslation()
  const leftPanelOpen = useSelector(
    (state) => state.editorHomepage.leftPanelOpen
  );

  const debugDetails = useSelector(
    (state) => state.editorHomepage.debugDetails
  );
  const [searchText, setSearchText] = useState("");
  const [openedListVariables, setOpenedListVariables] = useState([]);

  const [shownListType, setShownListType] = useState("Variables");

  const handleSearch = (searchText) => {
    setSearchText(searchText);
  };
  const handleSelectedType = (e, item) => {
    setShownListType(item);
  };
  const handleOpenListVariables = (selectedList) => {
    setOpenedListVariables(selectedList);
  };

  return (
    <Paper
      className={leftPanelOpen ? classes.root : classes.rootClosePanel}
      square
      elavation={1}
    >
      <Grid container direction="column">
        <Grid item className={classes.item} style={{ marginTop: "10px" }}>
          <Grid container direction="row" spacing={2} justifyContent="flex-start">
            <Grid item>
              <Typography className={classes.text_light}>
                {t("Activity Logs")}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        <Grid item className={classes.searchBox}>
          <SearchBox
            id="RPA_ScriptEditor_Left_SearchBox"
            width={leftPanelOpen ? "380px" : "212px"}
            onSearchChange={handleSearch}
          />
        </Grid>
        <Grid item className={classes.item}>
          <Grid container direction="row" spacing={2}>
            <Grid item>
              <Typography className={classes.text_light}>
                {t("Current Line Number")}
              </Typography>
            </Grid>
            <Grid item>
              <Typography className={classes.bold}>
                {debugDetails && debugDetails.currentLineNo}
              </Typography>
            </Grid>
          </Grid>
        </Grid>

        <Grid item className={classes.item}>
          <Grid container direction="row" spacing={1}>
            <Grid item>
              <Typography className={classes.text_12}>
                According to{" "}
                <span className={classes.shownListType}>{shownListType}</span>
              </Typography>
            </Grid>
            <Grid item style={{ color: "#707070" }}>
              <MenuPopper
                id="RPA_ScriptEditor_DebugLeft"
                MenuIcon={ExpandMore}
                items={["Variables"]}
                handleSelectedItem={handleSelectedType}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          {shownListType === "Variables" ? (
            <VariablesList
              id="RPA_ScriptEditor_Left_Variables"
              variablesList={debugDetails && debugDetails.variables}
              openedListVariables={openedListVariables}
              handleOpenListVariables={handleOpenListVariables}
            />
          ) : (
            <VariablesList1
              id="RPA_ScriptEditor_Left_Variables1"
              itemList={resDummy.executionDetails}
              openedListVariables={openedListVariables}
              handleOpenListVariables={handleOpenListVariables}
            />
          )}
        </Grid>
      </Grid>
    </Paper>
  );
};

export default DebugLeftPanel;

const variables = [
  {
    variableName: "Data_Grid1",
    variableType: "Number",
    currentValue: 345,
    /* variableDetails: [
      { lineNumber: "01", value: 260 },
      { lineNumber: "03", value: 370 },
    ],*/
  },
  {
    variableName: "passIDgen",
    variableType: "Text",
    currentValue: "D45f6",
    /* variableDetails: [
      { lineNumber: "01", value: "Er56F" },
      { lineNumber: "03", value: "D45f6" },
    ],*/
  },
];
const resDummy = {
  scriptId: 23,
  versionId: 234,
  executionDetails: [
    {
      lineNumber: "01",
      activityName: "Connect Mail",
      variables: [
        {
          variableName: "Data_Grid1",
          variableType: "Number",
          currentValue: 345,
          variableDetails: [
            { lineNumber: "01", value: 260 },
            { lineNumber: "03", value: 370 },
          ],
        },
        {
          variableName: "passIDgen",
          variableType: "Text",
          currentValue: "D45f6",
          variableDetails: [
            { lineNumber: "01", value: "Er56F" },
            { lineNumber: "03", value: "D45f6" },
          ],
        },
        {
          variableName: "username",
          variableType: "Text",
          currentValue: "asloob@gmail.com",
          variableDetails: [
            { lineNumber: "01", value: "" },
            { lineNumber: "03", value: "asloob@gmail.com" },
          ],
        },
        {
          variableName: "mailList_e",
          variableType: "List",
          currentValue: "asloob1@gmail.com",
          variableDetails: [
            { lineNumber: "01", value: "" },
            { lineNumber: "03", value: "asloob1@gmail.com" },
          ],
        },
      ],
    },
    {
      lineNumber: "02",
      activityName: "Get Mail",
      variables: [
        {
          variableName: "Data_Grid2",
          variableType: "Number",
          currentValue: 345,
          variableDetails: [
            { lineNumber: "01", value: 260 },
            { lineNumber: "03", value: 370 },
          ],
        },
        {
          variableName: "passIDgen",
          variableType: "Text",
          currentValue: "D45f6",
          variableDetails: [
            { lineNumber: "01", value: "Er56F" },
            { lineNumber: "03", value: "D45f6" },
          ],
        },
        {
          variableName: "mailList_gmail",
          variableType: "List",
          currentValue: "asloob@gmail.com",
          variableDetails: [
            { lineNumber: "01", value: "" },
            { lineNumber: "03", value: "asloob@gmail.com" },
          ],
        },
      ],
    },
  ],
};
