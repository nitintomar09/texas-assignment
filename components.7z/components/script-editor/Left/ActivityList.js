import React, { useState } from "react";
import makeStyles from "@mui/styles/makeStyles";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import { ChevronRight, ExpandLess } from "@mui/icons-material";
import { Divider, Grid, Typography } from "@mui/material";
import { API_BASE_URL, ICONS } from "./../../../config/index";
import { useSelector } from "react-redux";
import { WarningIcon } from "../../../utils/AllImages";
import {
  highlightActivity,
  highlightActivityBorder,
  applyFontColor,
} from "../Right/HighlightActivity";
import { ReactSVG } from "react-svg";
const useStyles = makeStyles((theme) => ({
  root: {
    //width: "100%",
    maxWidth: "240 px", //New Width
    backgroundColor: "#FFFFFF",
    maxHeight: (props) => props.windowInnerHeight - 212 || "450px",
    overflowY: "auto",
    overflowX: "hidden",
    "&::-webkit-scrollbar-thumb": {
      background: "transparent",
      borderRadius: "10px",
    },
    "&:hover::-webkit-scrollbar": {
      width: "6px",
      color: "#606060",
      opacity: "50%",
    },
    "&:hover::-webkit-scrollbar-thumb": {
      background: "#c4c4c4  0% 0% no-repeat padding-box",
      borderRadius: "10px",
    },

    /**
     * @author sanya.mahajan For Bug 156023 - UX Scroll bar position in activities panel
     * Reason: To shift the scrollbar 2px to the right
     * Date : 04/02/2025
     * */
    paddingRight: "2px",
  },
  itemRoot: {
    paddingLeft: "25px",
  },
  singleActivity: {
    paddingLeft: "16px",
  },
  list_item: {
    height: "40px",
    backgroundColor: "#FFFFFF",
    marginLeft: "10px",
  },
  list_item_nested: {
    height: "28px",
    paddingLeft: "12px",
  },
  text_light: {
    fontSize: "12px",
    fontWeight: 600,
  },
  nested: {
    paddingLeft: theme.spacing(2),
    height: "25px",
  },
  nestedClose: {
    paddingLeft: theme.spacing(1),
    height: "15px",
  },
  img: {
    width: "12px",
    height: "12px",
    marginTop: "3px",
  },
  draged: {
    //border: `1px solid black`,
    width: "100% !important",
    height: "28px",
    borderRadius: "4px",
  },
  chevronIcon: {
    marginRight: "10px",
    color: "#606060",
  },
}));

const ActivityListItem = (props) => {
  const {
    activity,
    leftPanelOpen,

    handleLeftPanel,
    openedListGroup,
    handleDrag,
    handleOpenListGroup,
  } = props;
  const windowInnerHeight = useSelector(
    (state) => state.appGlobalState.windowInnerHeight
  );
  const classes = useStyles({ windowInnerHeight });

  const handleClick = (GroupId) => {
    const list = { ...openedListGroup };
    if (list[`${GroupId}`] && !leftPanelOpen) {
      handleLeftPanel();
    } else if (list[`${GroupId}`]) {
      delete list[`${GroupId}`];
    } else {
      if (leftPanelOpen) {
        list[`${GroupId}`] = {};
      } else {
        handleLeftPanel();
        list[`${GroupId}`] = {};
      }
    }
    handleOpenListGroup(list);
  };

  const handleSubListGroup = (GroupId, selectedList) => {
    const list = { ...openedListGroup };
    list[`${GroupId}`] = selectedList;
    handleOpenListGroup(list);
  };
  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };

  const truncateString = (str) => {
    if (leftPanelOpen) {
      return str.trim().length > 16 ? str.substring(0, 12) + ".." : str;
    }
    return str.trim().length > 12 ? str.substring(0, 6) + ".." : str;
  };
  const [isDrag, setIsDrag] = useState(false);
  const GetColorImage = ({ name, color }) => {
    let src = `${API_BASE_URL}${ICONS}/${name}color`;

    return <ReactSVG src={src} />;
  };
  return (
    <React.Fragment sx={{ ":hover": { backgroundColor: "#F2F8FC" } }}>
      <ListItem
        button
        onClick={() => {
          activity.groupId
            ? handleClick(activity.groupId)
            : console.log("not Group");
        }}
        className={
          activity.groupId ? classes.list_item : classes.list_item_nested
        }
        disableFocusRipple
        disableTouchRipple
        disableRipple
        sx={{
          "&:hover": {
            backgroundColor: "#F2F8FC",
            cursor: "grab",
          },
          "&:Mui-active": {
            backgroundColor: "none",
          },
        }}
        tabIndex={0}
        id={`${props.id}`}
      >
        <Grid
          container
          alignItems="center"
          spacing={leftPanelOpen ? 1 : 2}
          draggable={!activity.groupId}
          onDragEnd={(e) => {
            setIsDrag(false);
            e.currentTarget.classList.remove(`${classes.draged}`);
            e.currentTarget.style.backgroundColor = "";
            e.currentTarget.style.border = "";
            e.currentTarget.style.color = "";
          }}
          onDragStart={(e) => {
            setIsDrag(true);
            e.currentTarget.classList.add(`${classes.draged}`);
            e.currentTarget.style.backgroundColor = highlightActivity(
              activity.activityName
            );
            e.currentTarget.style.border = highlightActivityBorder(
              activity.activityName
            );
            e.currentTarget.style.color = applyFontColor(activity.activityName);
            handleDrag(e, activity);
          }}
          title={activity.groupId ? activity.groupName : activity.displayName}
        >
          {activity.groupId &&
            activity.isCustomActivity &&
            activity.isDeprecated && (
              <Grid item title="This Activity Group version is Deprecated">
                <WarningIcon className={classes.img} />
              </Grid>
            )}
          <Grid item>
            {isDrag ? (
              <GetColorImage name={activity.activityName} />
            ) : (
              <img
                src={getImage(
                  activity.groupId ? activity.groupName : activity.activityName
                )}
                className={classes.img}
                alt={`${
                  activity.groupId ? activity.groupName : activity.activityName
                } Icon`}
              />
            )}
          </Grid>

          {leftPanelOpen ? (
            <Grid item>
              <Typography
                className={classes.text_light}
                sx={{
                  color: isDrag
                    ? applyFontColor(activity.activityName)
                    : "#606060",
                }}
              >
                {(activity.groupId || activity.activityId) &&
                  truncateString(
                    activity.groupId ? activity.groupName : activity.displayName
                  )}
              </Typography>
            </Grid>
          ) : null}
        </Grid>
        <Grid item sx={{ marginLeft: "auto" }}>
          {activity.groupId ? (
            openedListGroup &&
            Object.keys(openedListGroup).includes(`${activity.groupId}`) &&
            leftPanelOpen ? (
              <ExpandLess className={classes.chevronIcon} />
            ) : (
              <ChevronRight className={classes.chevronIcon} />
            )
          ) : null}
        </Grid>
      </ListItem>
      <div className={classes.itemRoot}>
        {activity.activities &&
          openedListGroup &&
          Object.keys(openedListGroup).includes(`${activity.groupId}`) && (
            <>
              {activity.activities.map((subActivity, index) => (
                <React.Fragment
                  key={
                    subActivity.groupId
                      ? subActivity.groupId
                      : subActivity.activityId
                  }
                >
                  <ActivityListItem
                    id={`${props.id}_${subActivity.displayName}`}
                    activity={subActivity}
                    leftPanelOpen={leftPanelOpen}
                    handleLeftPanel={handleLeftPanel}
                    openedListGroup={openedListGroup[`${activity.groupId}`]}
                    handleOpenListGroup={(selectedList) =>
                      handleSubListGroup(activity.groupId, selectedList)
                    }
                    handleDrag={handleDrag}
                  />
                </React.Fragment>
              ))}
            </>
          )}
      </div>
    </React.Fragment>
  );
};

const ActivityList = (props) => {
  const classes = useStyles();
  const windowInnerHeight = useSelector(
    (state) => state.appGlobalState.windowInnerHeight
  );
  const {
    activities,
    leftPanelOpen,
    handleLeftPanel,
    openedListGroup,
    handleDrag,
    handleOpenListGroup,
  } = props;
  const runScriptModal = useSelector(
    (state) => state.editorHomepage.runScriptModal
  );
  const recentAct =
    activities && activities.find((act) => act.groupName === "Recents");

  const filterdAct =
    activities &&
    activities
      .filter(
        (item) =>
          (item.isCustomActivity && item.isActive) ||
          (!item.isCustomActivity && item.groupName !== "Recents")
      )
      .sort((a, b) => a.groupName.localeCompare(b.groupName));
  return (
    activities &&
    activities.length > 0 && (
      <List
        component="nav"
        aria-label="activities-list"
        className={classes.root}
        //runScriptModal is the output window .which is used to show the logs while executing script.so we want to see activities present on left panel.thats why we decrease the height of left panel.
        //style={{ maxHeight: runScriptModal ? "340px" : "500px" }}
        //  style={{ maxHeight: runScriptModal ? windowInnerHeight - 372 || "340px" : windowInnerHeight - 232 || "468px" }}
      >
        {(recentAct ? [recentAct, ...filterdAct] : filterdAct)
          .sort((a, b) => {
            //Bug 151147 - Activity panel
            //Author: nitin_tomar
            //Date: 6 JAN 2025
            //Description: Panel has been updated. Single activity will appear on Top of the list
            if (a.groupName === "Recents" && b.groupName !== "Recents")
              return -1;
            if (b.groupName === "Recents" && a.groupName !== "Recents")
              return 1;

            if (a.activities.length === 1 && b.activities.length > 1) return -1;
            if (b.activities.length === 1 && a.activities.length > 1) return 1;

            return 0;
          })
          .map((activity, index) => {
            return (
              <React.Fragment
                key={activity.groupId ? activity.groupId : activity.activityId}
              >
                {activity.activities.length !== 1 ||
                activity.groupName == "Recents" ? (
                  <>
                    <ActivityListItem
                      id={`${props.id}_${activity.groupName}`}
                      activity={activity}
                      leftPanelOpen={leftPanelOpen}
                      handleLeftPanel={handleLeftPanel}
                      openedListGroup={openedListGroup}
                      handleOpenListGroup={handleOpenListGroup}
                      handleDrag={handleDrag}
                    />
                    <Divider variant="fullWidth" />
                  </>
                ) : (
                  <>
                    <Grid
                      container
                      alignItems={"flex-end"}
                      className={classes.singleActivity}
                      sx={{
                        height: "40px",
                        ":hover": { backgroundColor: "#F2F8FC" },
                      }}
                    >
                      <ActivityListItem
                        id={`${props.id}_${activity.groupName}`}
                        activity={activity.activities[0]}
                        leftPanelOpen={leftPanelOpen}
                        handleLeftPanel={handleLeftPanel}
                        openedListGroup={openedListGroup}
                        handleOpenListGroup={handleOpenListGroup}
                        handleDrag={handleDrag}
                      />
                    </Grid>
                    <Divider variant="fullWidth" />
                  </>
                )}
              </React.Fragment>
            );
          })}
      </List>
    )
  );
};
export default ActivityList;
