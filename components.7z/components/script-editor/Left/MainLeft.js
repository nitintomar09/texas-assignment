import React, { useEffect, useState } from "react";
import makeStyles from '@mui/styles/makeStyles';
import { Grid, Paper, Typography } from "@mui/material";
import { ChevronLeft, ChevronRight, MenuOpen } from "@mui/icons-material";
import ActivityList from "./ActivityList";
import LoadingIndicator from "./../../../utils/loadingIndicator";
import MenuPopper from "../../../utils/MenuPopper";
import SearchBox from "../../../utils/Search-Component";
import { useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { getAllActivitiesGroups } from "../../../redux/actions";
import { useTranslation } from "react-i18next";
import { ActCollapseIcon, ActExpandIcon } from "../../../utils/AllImages";

const useStyles = makeStyles((theme) => ({
  root: {
    height: "559px",
    backgroundColor: "#FFFFFF",
    //maxWidth: "240px",
    /* [theme.breakpoints.down("lg")]: {
      paddingTop: "30px",
    },*/
    paddingTop:"12px",
    boxShadow: "3px 0px 8px 0px #00000014",
    borderRadius:"0px",
  },

  rootClose: {
    height: "640px",
    //display: "flex",
    backgroundColor: "#FFFFFF",
    //width: "80px",
  },
  item: {
    paddingLeft: "20px",
  },
  searchBox: {
    paddingLeft: "20px",
    marginTop: "8px",
    marginBottom: "8px",
  },
  text_light: {
    fontSize: "12px",
    fontWeight: 600,
    color: "#606060",
  },
  icon: {
    marginTop: "2px",
  },
  tabs: {
    fontSize: "12px",
    cursor: "pointer",
  },
  active: {
    fontSize: "12px",
    cursor: "pointer",
    fontWeight: 600,
    color: theme.palette.primary.main,
    borderBottom: `2px solid ${theme.palette.primary.main}`,
  },
  badge: {
    marginRight: "-10px",
    height: "20px",
    width: "20px",
    border: "1px solid #c4c4c4",
    borderRadius: "50px",
  },
  chevronIcon: {
    paddingRight: "2px",
    height: "20px",
    width: "20px",
  },
}));
const MainLeft = (props) => {
  const classes = useStyles();
  const { t } = useTranslation()
  const history = useHistory();
  const dispatch = useDispatch();
  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const activities = useSelector(
    (state) => state.editorLeftPanel.activitiesGroup
  );
  const errorFetchingActivityGroup = useSelector(
    (state) => state.editorLeftPanel.errorWhileFetching
  );
  const isLoading = useSelector((state) => state.editorLeftPanel.isLoading);

  const { handleLeftPanel, leftPanelOpen, handleDrag, recentActivities, activeTab } =
    props;

  const [openedListGroup, setOpenedListGroup] = useState({});

  const [shownActivities, setShownActivities] = useState([]);
  const [selectedTab, setSelectedTab] = useState("All");
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    if (activities) {
      const recentActivitiesObj = {
        groupName: "Recents",
        groupId: "Recents",
        isActive: true,
        activities: [],
      };
      const favActivitiesObj = {
        groupName: "Favourites",
        groupId: "Favourites",
        //  isActive: true,

        activities: [],
      };

      setShownActivities([
        recentActivitiesObj,
        // favActivitiesObj,
        ...activities,
      ]);
    }
  }, [activities]);
  useEffect(() => {
    if (scriptValues && scriptValues?.scriptId && scriptValues?.versionId) {
      dispatch(getAllActivitiesGroups({ history }));
    }
  }, [scriptValues]);
  useEffect(() => {
    const recentActivitiesObj = {
      groupName: "Recents",
      groupId: "Recents",
      isActive: true,
      activities: [...recentActivities],
    };
    const favActivitiesObj = {
      groupName: "Favourites",
      groupId: "Favourites",
      // isActive: true,

      activities: [],
    };

    if (searchText) {
      const newAct = getSearchedActivities(activities, searchText);
      setShownActivities([
        recentActivitiesObj,
        // favActivitiesObj,
        ...newAct,
      ]);
    } else {
      setShownActivities([
        recentActivitiesObj,
        // favActivitiesObj,
        ...activities,
      ]);
    }
  }, [recentActivities]);
  const handleChange = (value) => {
    setSelectedTab(value);
    const recentActivitiesObj = {
      groupName: "Recents",
      groupId: "Recents",
      isActive: true,
      activities: [...recentActivities],
    };
    const favActivitiesObj = {
      groupName: "Favourites",
      groupId: "Favourites",
      // isActive: true,

      activities: [],
    };
    if (value === "Recents") {
      setShownActivities([recentActivitiesObj]);
    } else if (value === "Favourites") {
      setShownActivities([favActivitiesObj]);
    } else if (value === "All") {
      setShownActivities([
        recentActivitiesObj,
        // favActivitiesObj,
        ...activities,
      ]);
    }
  };
  const handleOpenListGroup = (selectedList) => {
    setOpenedListGroup(selectedList);
  };
  const showSelectedActivities = (e, item) => {
    handleChange(item);
  };

  const getSearchedActivities = (activities, searchText) => {
    // so that it cant mutute state
    function copy(obj) {
      return Object.assign({}, obj);
    }
    function filterActivity(activity) {
      if (
        activity.groupId &&
        activity.groupName.toLowerCase().includes(searchText.toLowerCase())
      )
        return true;
      if (
        activity.activityId &&
        activity.displayName.toLowerCase().includes(searchText.toLowerCase())
      )
        return true;
      if (activity.activities) {
        return (activity.activities = activity.activities
          .map(copy)
          .filter(filterActivity)).length;
      }
    }

    return activities.map(copy).filter(filterActivity);
  };

  const handleSearchActivities = (searchText) => {
    const recentActivitiesObj = {
      groupName: "Recents",
      groupId: "Recents",
      isActive: true,
      activities: [...recentActivities],
    };
    const favActivitiesObj = {
      groupName: "Favourites",
      groupId: "Favourites",
      // isActive: true,

      activities: [],
    };
    if (searchText) {
      const newActivities = getSearchedActivities(
        [
          recentActivitiesObj,
          //favActivitiesObj,
          ...activities,
        ],
        searchText
      );
      setShownActivities(newActivities);
    } else {
      setShownActivities([
        recentActivitiesObj,
        //favActivitiesObj,
        ...activities,
      ]);
    }
    setSearchText(searchText);
  };

  if (leftPanelOpen) {

    return (<Paper className={classes.root} elevation={24} sx={{ display: activeTab === "Script" ? 'block' : 'none', }}>
      <Grid container >
        <Grid item sx={{width:leftPanelOpen?"240px":"24px"}}  >
      <Grid container direction="column" >
        {/* className={classes.item} */}
        <Grid item xs paddingLeft={"20px"} paddingBottom={"8px"}>
          {/* <Grid container direction="row" spacing={1} justifyContent="flex-start" alignItems={"center"}> */}
            {/* <Grid item xs> */}
              <Typography className={classes.text_light}>
                {t("Activities")}
              </Typography>
            {/* </Grid> */}
            {/* <Grid
              item
            // style={{
            //   marginLeft: "auto",
            //   zIndex: 1,
            //   cursor: "pointer",
            //   marginRight: "25px",
            // }}
            > */}
              {/* <Grid container> */}
                {/* <Grid item>
                  <MenuPopper
                    id={`${props.id}_Activity`}
                    MenuIcon={MenuOpen}
                    items={[
                      "All",
                      "Recents",
                      //"Favourites"
                    ]}
                    handleSelectedItem={showSelectedActivities}
                  />
                </Grid> */}
                {/* <Grid item>
                    <Paper
                      className={classes.badge}
                      onClick={() => handleLeftPanel()}
                    >
                      {leftPanelOpen ? (
                        <ChevronLeft className={classes.chevronIcon} />
                      ) : (
                        <ChevronRight className={classes.chevronIcon} />
                      )}
                    </Paper>
                      </Grid> */}
              {/* </Grid> */}
            {/* </Grid> */}
          {/* </Grid> */}
        </Grid>
        {/* className={classes.searchBox} */}
        <Grid item paddingLeft={"20px"}>
          <SearchBox
            id={`${props.id}_Activities_SearchBox`}
            sx={{ width:"208px",
              height:"28px"}}
            onSearchChange={handleSearchActivities}
          />
        </Grid>

        {errorFetchingActivityGroup ? (
          <Grid container justifyContent="center">
            <Grid item>
              <Typography
                variant="subtitle2"
                style={{ color: "red", paddingLeft: "10px" }}
              >
                {errorFetchingActivityGroup}
              </Typography>
            </Grid>
          </Grid>
        ) : null}

        {isLoading ? (
          <Grid
            container
            justifyContent="center"
            alignItems="center"
            data-testid="loaderLeft"
          >
            <Grid item>
              <LoadingIndicator style={{ width: "12px", height: "12px" }} />
            </Grid>
          </Grid>
        ) : searchText && shownActivities.length === 0 ? (
          /*****************************************************************************************
           * @author asloob.ali BUG ID : 100983 Description : "No result found" msg should be displayed in search activity if no matching activity found
           *  Resolution : added message,when no activity found based on search.
           *  Date : 02/09/2021             ***************************************************************************************/
          <Grid container justifyContent="center">
            <Grid item>
              <Typography variant="subtitle2" style={{ paddingLeft: "10px" }}>
                {t("No Result Found.")}
              </Typography>
            </Grid>
          </Grid>
        ) : (
          <ActivityList
            id={`${props.id}_ActivityList`}
            activities={shownActivities}
            leftPanelOpen={leftPanelOpen}
            handleLeftPanel={handleLeftPanel}
            openedListGroup={openedListGroup}
            handleOpenListGroup={handleOpenListGroup}
            handleDrag={handleDrag}
          />
        )}
      </Grid>
      </Grid>

      <Grid item sx={{alignItems:"center", display:"flex",marginLeft:"-10px"}}>
          <Grid container>
            <Grid item style={{ marginLeft: "auto", zIndex: 1, cursor: "pointer" }}>
              <Paper
                className={classes.badge}
                style={{}}
                onClick={() => handleLeftPanel()}
              >
                {leftPanelOpen ? (
                  // <ChevronLeft className={classes.chevronIcon} />
                  <ActCollapseIcon className={classes.chevronIcon} />
                ) : (
                  // <ChevronRight className={classes.chevronIcon} />
                  <ActExpandIcon className={classes.chevronIcon} />
                )}
              </Paper>
            </Grid>
          </Grid>
      
      </Grid>
      </Grid>
    </Paper>
    );
  }
  return (
    <Paper className={classes.rootClose} square>
      <Grid container>
        <Grid item sx={{width:"70px"}}>
      <Grid container direction="column">
        <Grid item className={classes.item} style={{ marginTop: "8px" }}>
          <Grid container direction="row" justifyContent="flex-start">
            <Grid item>
              <Typography className={classes.text_light}>Activit..</Typography>
            </Grid>

          </Grid>
        </Grid>
        <Grid item className={classes.item}>
          <Grid container direction="row" spacing={1} justifyContent="flex-start">
            <Grid
              item
              onClick={() => handleChange(selectedTab)}
              id={`${props.id}_${selectedTab}`}
            >
              <Typography className={classes.active}>{selectedTab}</Typography>
            </Grid>
          </Grid>
        </Grid>

        {isLoading ? (
          <Grid container justifyContent="center" alignItems="center">
            <Grid item>
              <LoadingIndicator />
            </Grid>
          </Grid>
        ) : (
          <ActivityList
            id={`${props.id}_ActivityList`}
            activities={shownActivities}
            leftPanelOpen={leftPanelOpen}
            handleLeftPanel={handleLeftPanel}
            openedListGroup={openedListGroup}
            handleOpenListGroup={handleOpenListGroup}
            handleDrag={handleDrag}
          />

        )}
        {errorFetchingActivityGroup ? (
          <Grid container>
            <Grid item>
              <Typography variant="subtitle2" style={{ color: "red" }}>
                {errorFetchingActivityGroup}
              </Typography>
            </Grid>
          </Grid>
        ) : null}
        
      </Grid>
      </Grid>
      <Grid item sx={{alignItems:"center", display:"flex"}}>
          <Grid container>
            <Grid item style={{ marginLeft: "auto", zIndex: 1, cursor: "pointer" }}>
              <Paper
                className={classes.badge}
                onClick={() => handleLeftPanel()}
              >
                {leftPanelOpen ? (
                  // <ChevronLeft className={classes.chevronIcon} />
                  <ActCollapseIcon className={classes.chevronIcon} />
                ) : (
                  // <ChevronRight className={classes.chevronIcon} />
                  <ActExpandIcon className={classes.chevronIcon} />
                )}
              </Paper>
            </Grid>
          </Grid>
      </Grid>
      </Grid>
    </Paper>
  );
};

export default MainLeft;
