import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import { ChevronRight, ExpandLess } from "@mui/icons-material";
import { Divider, Grid, Typography } from "@mui/material";
import { useSelector, useDispatch } from "react-redux";

import { setLeftPanelOpen } from "../../../redux/actions";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
    maxWidth: 400,
    backgroundColor: "#FFFFFF",
    maxHeight: "450px",
    overflowY: "scroll",
  },
  itemRoot: {
    paddingLeft: "30px",
    paddingRight: "15px",
  },
  list_item: {
    height: "25px",
    backgroundColor: "#FFFFFF",

    //width: "216px",
  },
  list_item_nested: {
    height: "25px",
    paddingLeft: "25px",
    //width: "216px",
  },
  text_light: {
    fontSize: "12px",
    fontWeight: 500,
    color: "#606060",
  },
  nested: {
    paddingLeft: theme.spacing(2),
    height: "25px",
  },
  nestedClose: {
    paddingLeft: theme.spacing(1),
    height: "15px",
  },
  img: {
    width: "12px",
    height: "12px",
    marginTop: "3px",
  },
  chevronIcon: {
    marginTop: "6px",
    cursor: "pointer",
  },
  variableName: {
    fontSize: "12px",
    fontWeight: "bold",
  },
  viewList: {
    fontSize: "12px",
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
  },
}));

const LineDetailsItem = (props) => {
  const { item, openedListVariables, handleOpenListVariables } = props;
  const classes = useStyles();
  const leftPanelOpen = useSelector(
    (state) => state.editorHomepage.leftPanelOpen
  );
  const dispatch = useDispatch();

  const handleClick = (lineNumber) => {
    let list = [...openedListVariables];
    const index = list.findIndex((str) => str === lineNumber);
    if (index === -1) {
      list.push(lineNumber);
    } else {
      list.splice(index, 1);
    }
    handleOpenListVariables(list);
  };

  const truncateString = (str) => {
    if (str) {
      return str.trim().length > 18 ? str.substring(0, 14) + ".." : str;
    } else {
      return "";
    }
  };

  return (
    <React.Fragment>
      <ListItem
        button
        className={classes.list_item}
        style={{ cursor: "default" }}
        id={`${props.id}_List`}
      >
        <Grid container alignItems="center" direction="column" spacing={1}>
          <Grid item container direction="row" spacing={1}>
            {openedListVariables &&
            openedListVariables.includes(`${item.lineNumber}`) ? (
              <ExpandLess
                fontSize="small"
                className={classes.chevronIcon}
                onClick={() => handleClick(item.lineNumber)}
                id={`${props.id}_ExpandLessBtn`}
              />
            ) : (
              <ChevronRight
                fontSize="small"
                className={classes.chevronIcon}
                onClick={() => handleClick(item.lineNumber)}
                id={`${props.id}_ChevronRightBtn`}
              />
            )}
            <Grid item>
              <Typography>{item.lineNumber}</Typography>
            </Grid>
            <Grid item>
              <Typography className={classes.variableName}>
                {item.activityName && truncateString(item.activityName)}
              </Typography>
            </Grid>
            <Grid item style={{ marginLeft: "auto" }}>
              <Typography className={classes.text_light}>
                Total Var {item.variables && item.variables.length}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </ListItem>
      <div className={classes.itemRoot}>
        {openedListVariables &&
          openedListVariables.includes(`${item.lineNumber}`) && (
            <>
              <Grid container direction="row" spacing={2}>
                <Grid item xs={5}>
                  <Typography className={classes.text_light}>
                    Variable
                  </Typography>
                </Grid>
                {leftPanelOpen ? (
                  <Grid item xs={3}>
                    <Typography>Type</Typography>
                  </Grid>
                ) : null}
                <Grid item xs={4}>
                  <Typography> Value</Typography>
                </Grid>
              </Grid>

              <Grid container direction="column" spacing={1}>
                {item.variables.map((varDetail, index) => (
                  <Grid item key={index}>
                    <Grid container direction="row" spacing={2}>
                      <Grid item xs={5}>
                        <Typography className={classes.text_light}>
                          {" "}
                          {varDetail.variableName}
                        </Typography>
                      </Grid>
                      {leftPanelOpen ? (
                        <Grid item xs={3}>
                          <Typography>{varDetail.variableType}</Typography>
                        </Grid>
                      ) : null}

                      <Grid item xs={4}>
                        {varDetail.variableType === "List" ? (
                          <Typography
                            className={classes.viewList}
                            onClick={() => {
                              dispatch(setLeftPanelOpen(!leftPanelOpen));
                            }}
                            id={`${props.id}_${varDetail.variableName}`}
                          >
                            View List
                          </Typography>
                        ) : (
                          <Typography>{varDetail.currentValue}</Typography>
                        )}
                      </Grid>
                    </Grid>
                  </Grid>
                ))}
              </Grid>
            </>
          )}
      </div>
    </React.Fragment>
  );
};

const VariablesList1 = (props) => {
  const classes = useStyles();
  const { itemList, openedListVariables, handleOpenListVariables } = props;
  const runScriptModal = useSelector(
    (state) => state.editorHomepage.runScriptModal
  );

  return (
    itemList &&
    itemList.length > 0 && (
      <List
        component="nav"
        aria-labelledby="variables-list"
        className={classes.root}
        style={{
          cursor: "default",
          maxHeight: runScriptModal ? "260px" : "500px",
        }}
      >
        {itemList.map((item) => (
          <React.Fragment key={item.lineNumber}>
            <LineDetailsItem
              id={`${props.id}_${item.lineNumber}`}
              item={item}
              openedListVariables={openedListVariables}
              handleOpenListVariables={handleOpenListVariables}
            />
            <Divider variant="fullWidth" />
          </React.Fragment>
        ))}
      </List>
    )
  );
};
export default VariablesList1;
