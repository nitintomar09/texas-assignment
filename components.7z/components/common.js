import React, { useState } from "react";
import axios from "axios";
import moment from "moment";
import { useDispatch } from "react-redux";
import i18next from "i18next";
import cookies from "js-cookie";
import secureLocalStorage from "react-secure-storage";
// Form input fuction
export function UseFormInput(initialValue) {
  const [value, setValue] = useState(initialValue);
  const dispatch = useDispatch();
  const handleChange = (e, check) => {
    console.log(e, "ljjjjj");
    setValue(check ? e : e.target.value);
  };
  return {
    value,
    onChange: handleChange,
    error: false,
    helperText: "",
    setValue,
  };
}

export function checkDeviceType() {
  const width = window.screen.width;
  const height = window.screen.height;
  const isMobile = width <= 768 && height <= 1024;
  const isTablet =
    width > 768 && height > 1024 && width <= 1366 && height <= 1024;
  if (isMobile) {
    return "Mobile";
  } else if (isTablet) {
    return "Tablet";
  } else {
    return "Desktop";
  }
}
export function isBetween(value, lowerLimit, upperLimit) {
  return value >= lowerLimit && value <= upperLimit;
}
export function getDeviceOrientation() {
  return window.innerWidth > window.innerHeight ? "Landscape" : "Portrait";
}

export const deviceOrientation =
  window.innerWidth > window.innerHeight ? "Landscape" : "Portrait";

export function getDynamicWidth(xs, sm, md, lg, xl) {
  const isPortrait = getDeviceOrientation() === "Portrait";
  // extra small
  if (isBetween(isPortrait ? window.innerHeight : window.innerWidth, 0, 599)) {
    return `${xs}${isPortrait ? "vw" : "vh"}`;
  }
  // small
  else if (
    isBetween(isPortrait ? window.innerHeight : window.innerWidth, 600, 799)
  ) {
    return `${sm ? sm : xs}${isPortrait ? "vw" : "vh"}`;
  }
  // medium
  else if (
    isBetween(isPortrait ? window.innerHeight : window.innerWidth, 800, 949)
  ) {
    return `${md ? md : xs}${isPortrait ? "vw" : "vh"}`;
  }
  // large
  else if (
    isBetween(isPortrait ? window.innerHeight : window.innerWidth, 950, 1099)
  ) {
    return `${lg ? lg : xs}${isPortrait ? "vw" : "vh"}`;
  }
  // extra large
  else if (
    isBetween(isPortrait ? window.innerHeight : window.innerWidth, 1100, 15000)
  ) {
    return `${xl ? xl : xs}${isPortrait ? "vw" : "vh"}`;
  }
}

// return the user data from the session storage
export const getUser = () => {
  const userStr = secureLocalStorage.getItem("user");
  if (userStr) return JSON.parse(userStr);
  else return null;
};

export const getDateAndTimeStr = (dateStr) => {
  let date = "";
  if (dateStr) {
    date = moment(dateStr, "DD-MM-yyyy HH:mm:ss").format(
      "DD MMM YYYY, hh:mm A"
    );
  }
  return date;
};
export const getUserId = () => {
  const userId = secureLocalStorage.getItem("user-id");
  if (userId) return userId;
  else return null;
};
export const getIsLicenseActive = () => {
  const license = secureLocalStorage.getItem("user-license");
  if (license) return parseInt(license);
  else return null;
};
export const getUserRights = (componentId) => {
  const user = getUser();
  const compDetails =
    (user && user[0]?.rolePermissionsDto?.permissionList) || [];
  const component = compDetails.find(
    (comp) => comp.componentId === componentId
  );

  if (component) {
    const { consumerPermissionRights, ownerPermissionRights } = component;

    return { consumerPermissionRights, ownerPermissionRights };
  }
  return null;
};
/**
 @author - akshat.pokhriyal
 @Date - 07/12/2021
  @Bug Id - 101702,101703,101704,101705,102889
 @Bug Description - user was able to access without having permissions
 @Bug Reason of occurence -   user permissions were not implemented for various actions
 @Solution - implemented user permissions
**/

export const doesUserHavePermission = ({
  isShared,
  permissionNum,
  componentId,
}) => {
  const permissionRights = getUserRights(componentId);

  if (permissionRights) {
    const { ownerPermissionRights, consumerPermissionRights } =
      permissionRights;
    const permissionStr = isShared
      ? consumerPermissionRights
      : ownerPermissionRights;
    return permissionStr.charAt(permissionNum) === "1";
  }
};
export const truncateStringValues = ({ str, min = 5, max = 10 }) => {
  if (str && typeof str === "string") {
    return str.trim().length > max ? str.substring(0, min) + ".." : str;
  } else if (str) {
    return str;
  }
  return "";
};

export const getUserRole = () => {
  const userStr = secureLocalStorage.getItem("user-role");
  if (userStr) return JSON.parse(userStr);
  else return null;
};

// return the token from the session storage
export const getToken = () => {
  return secureLocalStorage.getItem("x-access-token") || null;
};

export const getAppDirection = () => {
  const currentLanguageCode = cookies.get("i18next") || "en";
  const languages = getAppLanguages();
  const currentLanguage = languages.find((l) => l.code === currentLanguageCode);
  return currentLanguage.dir || "ltr";
};

export const getAppLanguages = () => {
  const languages = [
    {
      code: "fr",
      value: "fr",
      name: "Français",
      country_code: "fr",
      dir: "ltr",
    },
    {
      code: "en",
      value: "en",
      name: "English",
      country_code: "gb",
      dir: "ltr",
    },
    {
      code: "ar",
      value: "ar",
      name: "العربية",
      dir: "rtl",
      country_code: "sa",
    },
  ];
  return languages;
};

// remove the token and user from the session storage
export const removeUserSession = () => {
  secureLocalStorage.removeItem("x-access-token");
  secureLocalStorage.removeItem("user");
  secureLocalStorage.removeItem("user-role");
  secureLocalStorage.removeItem("user-id");
  secureLocalStorage.removeItem("x-access-key");
  secureLocalStorage.removeItem("iBPS-key");
};
// set the token and user from the session storage
export const setUserSession = (token, user) => {
  const permissions = user[0].rolePermissionsDto.permissionList
    .filter((item) =>
      (item.consumerPermissionRights + item.ownerPermissionRights)
        .split("")
        .map((i) => parseInt(i))
        .includes(1)
    )
    .map((item) => item.componentId);
  console.log(
    ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>Permissions",
    permissions
  );
  console.log("token set", token);
  console.log("user", JSON.stringify(user[0]));
  secureLocalStorage.setItem("x-access-token", token);
  secureLocalStorage.setItem("user", JSON.stringify(user));
  secureLocalStorage.setItem("user-permissions", JSON.stringify(permissions));
  secureLocalStorage.setItem("user-license", user[0].licenseExpired);
  secureLocalStorage.setItem("user-role", JSON.stringify(user[0].currentRole));
  secureLocalStorage.setItem("user-id", JSON.stringify(user[0].authUser.userIndex));
};

export const handleNetworkRequestError = ({
  error,
  history,
  OnError,
  parseErrorMssage,
}) => {
  console.log("error", error);
  if (!error) {
    console.log("Network error");
  } else if (error.response) {
    // Request made and server responded
    // 400 , 403 , 500 ,
    // unauthorised request
    if ([401].includes(error.response.status)) {
      console.log("handleNetworkRequestError", history);
      history.push("/Error");
    } else if ([400].includes(error.response.status)) {
      if (error?.response?.data?.data[0]?.errorMessage === "Token Expired") {
        history.push("/Error");
      }
      OnError
        ? OnError(error?.response?.data?.data[0]?.errorMessage)
        : console.log("400,403", error?.response?.data?.data[0]?.errorMessage);
    } else if ([403].includes(error.response.status)) {
      OnError
        ? OnError(error?.response?.data?.data[0]?.errorMessage)
        : console.log("400,403");
    } else if (error.response.status === 500) {
      OnError
        ? OnError("Something Went Wrong")
        : console.log("Bad Request:Internal Server Error");
    }

    console.log("this", error.response.data);
    console.log(error.response.status);
    console.log(error.response.headers);
  } else if (error.request) {
    // The request was made but no response was received
    OnError
      ? OnError("No response from server")
      : console.log("No response from server");
  } else {
    // Something happened in setting up the request that triggered an Error
    OnError
      ? OnError(
          "Something happened in setting up the request that triggered an Error:" +
            error.message
        )
      : console.log(
          "Something happened in setting up the request that triggered an Error:" +
            error.message
        );
    console.log("Error", error.message);
  }
};
// axios instance


export const DownloadTextFile = (data) => {
  const element = document.createElement("a");
  const file = new Blob([data], {
    type: "octet/stream",
  });
  element.href = URL.createObjectURL(file);
  element.download = "AuditLogs.txt";
  document.body.appendChild(element);
  element.click();
};


export const ConvertLtrRtl = (StringArray) => {
  console.log("StringArray",StringArray)
  let targetArray = StringArray;
  if (getAppDirection() === "rtl") {
    targetArray = StringArray.reverse()
  }
  return targetArray.join(" ")
}
