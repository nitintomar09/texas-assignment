import React, { useState, useEffect, useContext } from "react";
import { useHistory } from "react-router-dom";

import {
  Typography,
  Button,
  Grid,
  Box,
  InputAdornment,
  CircularProgress,
  Divider,
} from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import Field from "../../utils/field";
import { UseFormInput } from "../../utils/common";
import ModalForm from "../../utils/modalForm";
import customStyle from "../../assets/css/customStyle";
import { isEmpty } from "../../utils/validations/validations";
import { useTranslation } from "react-i18next";
import Loader from "../loader/loader";
import {
  userLogin,
  setUserAlreadyLoggedIn,
  setUserDetailIsLoading,
  userLogout,
  getSSORights,
  userRedirectToHomeOrCreateNew,
} from "../../redux/actions";
import { useDispatch, useSelector } from "react-redux";
import { NotificationContext } from "../../contexts/NotificationContext";
import { getUser } from "./../../utils/common";
import {
  NewgenOneLogo,
  Login_Hide,
  Login_Password,
  Login_Show,
  Login_Username,
  RPADESIGNERLOGINIcon,
} from "../../utils/AllImages";
import CheckboxField from "./../script-editor/PropertyWindow/PropertyFields/CheckboxField";
import secureLocalStorage from "react-secure-storage";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";
import { getEncryptedString } from "../../utils/encryptions";
const useStyles = makeStyles(() => ({
  text: { fontSize: 14, color: "#606060", opacity: 1, fontWeight: 600 },
  smallText: { fontSize: 11, color: "#111111" },
  loginText: {
    fontSize: 16,
    color: "#1B1B1B",
    marginRight: 5,
    borderBottom: "2px solid #0072C6",
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#FF6600",
    paddingBottom: 40,
  },
  forgot: { fontSize: 11, color: "#0072C6", fontWeight: 600, opacity: 1 },
  boldText: {
    fontSize: 18,
    marginTop: "-5px",
    //color: "#FF6600",
    //fontWeight: 600,
  },
  box: { width: 220, paddingBottom: "10px", paddingTop: "8px" },
  container: {
    paddingTop: "10px",
    height: 528,
    width: 389,
    //width: "330px",
    backgroundColor: "#FFFFFF",
    opacity: 1,
    boxShadow: "0px 0px 10px #C4C4C4",
  },
  test: { padding: 0 },
  icon: { height: 20, width: 20, paddingLeft: 0, paddingRight: 0 },
  copyrightText: {
    fontSize: "10px",
    //fontWeight: 700,
  },
}));

export default function Login(props) {
  const classes = useStyles();
  const { setValue: setNotification } = useContext(NotificationContext);
  const { t } = useTranslation();
  const history = useHistory();
  const isLoggedIn = useSelector((state) => state.userDetails.isLoggedIn);

  const userDetailLoading = useSelector(
    (state) => state.userDetails.userDetailLoading
  );

  const dispatch = useDispatch();
  /*  
 //----------------------------------------------------------------------------------------------------
 // Changed By: akshat_pokhriyal
           // Date :13/02/2024
 // Reason / Cause (Bug No if Any):Hotfix RPA_1.0_00_00_01
 //  Hotfix changes merged into main baseline
 //----------------------------------------------------------------------------------------------------
 */
  const queryParams = new URLSearchParams(props.location.search);
  const authtoken = queryParams.get("authtoken");
  const sslflag = queryParams.get("sslflag");
  const _username = queryParams.get("username");
  const [loading, setLoading] = useState(true);
  const [validateFields, setValidateFields] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(
    secureLocalStorage.getItem("rpaRemMe") || false
  );
  const applicationDetails = queryParams.get("applicationDetails");
  const newParams = new URLSearchParams();
  if (applicationDetails) {
    newParams.set("applicationDetails", applicationDetails);
  }

  const username = UseFormInput(secureLocalStorage.getItem("rpaUser") || "");
  const password = UseFormInput("");
  // const config = UseFormInput(localStorage.getItem("publickey") || "");

  const handleRedirect = ({ token, history }) => {
    dispatch(
      userRedirectToHomeOrCreateNew({
        token,
        history: history,
        OnSuccess: (response) => {
          if (
            response.data.data[0] == null ||
            response.data.data[0] == "HOME"
          ) {
            history.push("/Dashboard");
          } else {
            const jsonObj = { launchpadNew: JSON.parse(response.data.data[0]) };
            const actionFromLaunchpad = getEncryptedString(
              JSON.stringify(jsonObj)
            );
            newParams.set("applicationDetails", actionFromLaunchpad);
            history.push(`/Dashboard?${newParams.toString()}`);
          }
          dispatch(setUserDetailIsLoading(false));
        },
        onError: (errorMessage) => {
          setNotification({
            isOpen: true,
            message: errorMessage || "Error in login.",
            notificationType: "ERROR",
          });
        },
      })
    );
  };
  // handle login
  const handleLogin = ({
    username,
    password,
    userType,
    forcedLogin,
    token,
  }) => {
    if (rememberMe) {
      secureLocalStorage.setItem("rpaRemMe", rememberMe);
      secureLocalStorage.setItem("rpaUser", username);
    } else {
      secureLocalStorage.removeItem("rpaRemMe");
      secureLocalStorage.removeItem("rpaUser");
    }

    dispatch(
      userLogin({
        username,
        password,
        userType,
        forcedLogin,
        token,
        history: history,

        OnSuccess: () => {
          const user = getUser();

          dispatch(setUserDetailIsLoading(false));
          /*  setNotification({
              isOpen: true,
              message: "User has been logged in successfully.",
              notificationType: "SUCCESS",
  
            });*/

          const compDetails =
            (user && user[0]?.rolePermissionsDto?.permissionList) || [];
          const scriptAndPkgsComp = compDetails.find(
            (comp) => comp.componentId === 7
          );

          if (scriptAndPkgsComp) {
            const { memberPermissionRights, ownerPermissionRights } =
              scriptAndPkgsComp;
            if (
              memberPermissionRights.split("").some((item) => item === "1") ||
              ownerPermissionRights.split("").some((item) => item === "1")
            ) {
              if (applicationDetails) {
                history.push(`/Dashboard?${newParams.toString()}`);
              } else {
                //check the redirection page
                handleRedirect({ token, history });
                //history.push("/Dashboard");
              }
            } else {
              setNotification({
                isOpen: true,
                message: "This User does not have permission to Login.",
                notificationType: "ERROR",
              });
              dispatch(userLogout({ history }));
            }
          } else {
            setNotification({
              isOpen: true,
              message: "This User does not have permission to Login.",
              notificationType: "ERROR",
            });
            dispatch(userLogout({ history }));
          }
        },
        onError: (errorMessage) => {
          setNotification({
            isOpen: true,
            message: errorMessage || "Error in login.",
            notificationType: "ERROR",
          });
          dispatch(setUserDetailIsLoading(false));
        },
      })
    );
  };
  const onLoginClick = (values) => {
    handleLogin({ ...values, forcedLogin: false });
  };
  const forceLogin = () => {
    handleLogin({ ...isLoggedIn, forcedLogin: true });
  };
  const dontLogin = () => {
    dispatch(setUserAlreadyLoggedIn(false));
  };

  const OnClick = (e) => {
    e.preventDefault();
    dispatch(setUserDetailIsLoading(true));
    setValidateFields(true);
    const hasError =
      isEmpty(username.value).status || isEmpty(password.value).status;

    if (hasError) {
      console.log("form has error");
      dispatch(setUserDetailIsLoading(false));
    } else {
      onLoginClick({
        username: username.value,
        password: password.value,
        userType: true,
      });
    }
  };

  const handleKeyDown = (e) => {
    /*****************************************************************************************
     * @author asloob.ali BUG ID : 100880 Description : Login: Enter button is not working after entering username and password
     *  Resolution : added event listner for keys.
     *  Date : 02/09/2021             ***************************************************************************************/
    if (e.keyCode === 13) {
      OnClick(e);
    }
  };
  useEffect(() => {
    //listening for 'Enter key' so that on press of enter we can login
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  useEffect(() => {
    // const launchpadKey = JSON.parse(secureLocalStorage.getItem("launchpadKey"));
    if (secureLocalStorage.getItem("launchpadKey")) {
      const launchpadKey = JSON.parse(
        secureLocalStorage.getItem("launchpadKey")
      );

      //let publicKeyAutomationStudio=localStorage.getItem("publickey");
      if (launchpadKey != null) {
        //login
        const publicKeyAutomationStudio = launchpadKey.token;
        handleLogin({ token: publicKeyAutomationStudio });
      }
    } else {
      setLoginFromAutomationStudio(false);
    }

    //return () => document.removeEventListener("keydown", handleKeyDown);
  }, []);

  const [loginFromAutomationStudio, setLoginFromAutomationStudio] =
    useState(true);
  const handleChange = (e) => {
    const { name, checked } = e.target;

    if (name === "RememberMe") {
      setRememberMe(checked);
    }
  };
  // useEffect(()=>{
  //   handleLogin(
  //     {
  //       username: "divya",
  //       password: "system123#",
  //       forcedLogin: true
  //     }
  //   )

  // },[])

  const text1 = t(
    "This site is best viewed in Microsoft Edge 103.x, Chrome 102.x , Chromium 103.x, Firefox 101.x , Safari 15.x and Screen resolution 1366 * 768."
  );

  /*  
 //----------------------------------------------------------------------------------------------------
 // Changed By: akshat_pokhriyal
           // Date :13/02/2024
 // Reason / Cause (Bug No if Any):Hotfix RPA_1.0_00_00_01
 //  Hotfix changes merged into main baseline
 //----------------------------------------------------------------------------------------------------
 */
  useEffect(() => {
    if (authtoken && sslflag && _username) {
      // console.log("home props", props, authtoken, sslflag, username)
      // const _authtoken = decodeString(authtoken)
      const binaryString = atob(String(_username));
      const uint8Array = new Uint8Array(binaryString.length);

      for (let i = 0; i < binaryString.length; i++) {
        uint8Array[i] = binaryString.charCodeAt(i);
      }

      // Decode the Uint8Array to string with Unicode characters
      const decoder = new TextDecoder("utf-8");
      const decodedString = decoder.decode(uint8Array);
      dispatch(
        getSSORights({
          username: decodedString,
          authtoken,
          history: props.history,
          OnSuccess: () => {
            setLoading(false);
            history.push("/Dashboard");
          },
          OnError: (errorMessage) => {
            setNotification({
              isOpen: true,
              message: errorMessage,
              notificationType: "ERROR",
            });
          },
        })
      );
    } else {
      setLoading(false);
    }
  }, []);
  if (loading) {
    return (
      <div style={{ padding: 20, backgroundColor: "#F8F8F8" }}>
        <Loader size={30} />
      </div>
    );
  }
  return (
    /*<div style={{ padding: "10px" }}>*/

    <Grid
      container
      alignItems="center"
      justifyContent={loginFromAutomationStudio ? "center" : "flex-start"}
      style={{
        //height: "88vh",
        minHeight: "88vh",
        flexWrap: "wrap-reverse",
      }}
    >
      {loginFromAutomationStudio === false ? (
        /**Bug 144275 - Regrassion: Designer >>Login field is not visible properly
         * @nitin_tomar
         * Date: 02 MARCH 2024
         * Responsive Login page
         */
        <>
          <Grid item>
            <Grid
              container
              direction="column"
              //style={{ height: "100%", width: "100%" }}
              //spacing={2}
              //alignItems="center"
              justifyContent="center"
            >
              <Grid item xs>
                <RPADESIGNERLOGINIcon
                  style={{
                    height: "400px",
                    width: "64vw",
                    //alignItems: "center",
                  }}
                />
              </Grid>
              <Grid item xs style={{ width: "64vw" }}>
                <Grid
                  container
                  direction="column"
                  spacing={1}
                  alignItems="center"
                >
                  <Grid item>
                    <Typography className={classes.copyrightText}>
                      {text1}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Grid container direction="row">
                      <Grid item>
                        <span className={classes.copyrightText}>
                          {t("Copyright")}
                        </span>
                      </Grid>
                      <Grid item style={{ paddingRight: 4, paddingLeft: 4 }}>
                        <span
                          className={classes.copyrightText}
                          dangerouslySetInnerHTML={{ __html: "&copy;" }}
                        />
                      </Grid>
                      <Grid item>
                        <span className={classes.copyrightText}>
                          2024 Newgen Software Technologies Limited.
                        </span>
                      </Grid>
                      <Grid item>
                        <span className={classes.copyrightText}>
                          {t("All rights reserved.")}
                        </span>
                      </Grid>
                    </Grid>
                    {/* <span className={classes.copyrightText}>
                      {t("Copyright")}
                      <span dangerouslySetInnerHTML={{ __html: "&copy;" }} /> All rights reserved.
                    </span> */}
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs>
            <ModalForm
              id="RPA_LoginModal"
              title={t("User already  active in another session")}
              containerHeight={160}
              isOpen={isLoggedIn ? true : false}
              closeModal={dontLogin}
              Content={
                <Typography>{t("Do you still want to login?")}</Typography>
              }
              btn1Title="No"
              onClick1={dontLogin}
              headerCloseBtn={true}
              onClickHeaderCloseBtn={dontLogin}
              btn2Title="Yes"
              onClick2={forceLogin}
            />

            <Grid container justifyContent="center">
              <Grid item>
                <Grid
                  container
                  className={classes.container}
                  alignItems="center"
                  direction="column"
                >
                  {/* control center label  */}
                  <Grid
                    item
                    container
                    justifyContent="center"
                    alignItems="center"
                    style={{ marginTop: 60, marginBottom: "12px" }}
                    spacing={1}
                  >
                    {/* {BugId:Bug 144094 - In Designer : Logo should be NewgenONE
                    AuthorName:Dixita Ruhela
                    Date: 26 feb 2024
                    } */}
                    <Grid item>
                      <img
                        src={NewgenOneLogo}
                        style={{ height: 40, width: 207 }}
                        alt="NewgenOneLogo"
                      />
                    </Grid>
                    {/*<Grid item>
                    <Typography className={classes.boldText}>RPA</Typography>
  </Grid>*/}
                  </Grid>
                  <Grid item>
                    <Typography className={classes.text}>
                      {t("Login to Service Flow Designer")}
                    </Typography>
                  </Grid>

                  {/* login input fields */}
                  <Grid item xs>
                    <Box className={classes.box}>
                      <Field
                        id="RPA_Login_Username"
                        paddingTop={"0px"}
                        height={36}
                        fontSize={14}
                        {...username}
                        placeholder={t("Username")}
                        error={
                          validateFields
                            ? isEmpty(username.value).status
                            : false
                        }
                        helperText={
                          validateFields ? isEmpty(username.value).msg : ""
                        }
                        InputProps={{
                          startAdornment: (
                            <>
                              <InputAdornment
                                className={classes.icon}
                                position="start"
                              >
                                <UniqueIDGenerator>
                                  <Login_Username
                                    id="RPA_LoginUsername_Img"
                                    className={classes.icon}
                                  />
                                </UniqueIDGenerator>
                              </InputAdornment>
                              <Divider
                                orientation="vertical"
                                flexItem
                                style={{ marginRight: "5px" }}
                              />
                            </>
                          ),
                        }}
                      />

                      <Field
                        id="RPA_Login_Password"
                        {...password}
                        height={36}
                        fontSize={14}
                        placeholder={t("Password")}
                        type={showPassword ? "text" : "Password"}
                        error={
                          validateFields
                            ? isEmpty(password.value).status
                            : false
                        }
                        helperText={
                          validateFields ? isEmpty(password.value).msg : ""
                        }
                        InputProps={{
                          startAdornment: (
                            <>
                              <InputAdornment
                                className={classes.icon}
                                position="start"
                              >
                                <UniqueIDGenerator>
                                  <Login_Password
                                    id="RPA_LoginPassword_Img"
                                    className={classes.icon}
                                  />
                                </UniqueIDGenerator>
                              </InputAdornment>
                              <Divider
                                orientation="vertical"
                                flexItem
                                style={{ marginRight: "5px" }}
                              />
                            </>
                          ),
                          /* endAdornment: (
                              <InputAdornment
                        onClick={() => setShowPassword(!showPassword)}
                        style={{ cursor: "pointer" }}
                        className={classes.icon}
                        position="end"
                        >
                        {showPassword ? <Login_Hide /> : <Login_Show />}
                      </InputAdornment>
                      ),*/
                        }}
                      />

                      <Grid container>
                        {userDetailLoading ? (
                          <Button
                            size="small"
                            variant="contained"
                            style={{
                              ...customStyle.btnFilled,
                              marginTop: 10,
                              flex: 1,
                              fontWeight: 600,
                              height: "36px",
                              fontSize: 14,
                            }}
                            id="RPA_LoginBtn"
                            disableRipple
                          >
                            <CircularProgress
                              // color="#FFFFFF"
                              style={{
                                height: "20px",
                                width: "20px",
                                marginRight: "8px",
                                color: "#FFFFFF",
                              }}
                            ></CircularProgress>
                            {t("Login")}
                          </Button>
                        ) : (
                          <Button
                            size="small"
                            variant="contained"
                            style={{
                              ...customStyle.btnFilled,
                              marginTop: 10,
                              flex: 1,
                              fontWeight: 600,
                              height: "36px",
                              fontSize: 14,
                            }}
                            onClick={(e) => OnClick(e)}
                            disableRipple
                            id="RPA_LoginBtn"
                          >
                            {t("Login")}
                          </Button>
                        )}
                      </Grid>
                      <div style={{ marginTop: "8px" }}>
                        <Grid
                          container
                          alignItems="center"
                          justifyContent="space-between"
                        >
                          <Grid item>
                            <CheckboxField
                              id="RPA_RememberMeCheckbox"
                              label={t("Remember me")}
                              size="small"
                              onChange={handleChange}
                              name={t("LOGIN_remember")}
                              value={rememberMe}
                            />
                          </Grid>
                          {/* <Grid item>
                      <Typography className={classes.forgot}>
                        Forgot Password?
                      </Typography>
                </Grid>*/}
                        </Grid>
                      </div>
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </>
      ) : (
        <Grid item xs style={{ paddingLeft: "45vw" }}>
          {/* //  BugId:Bug 155115 - On launching the tool loader size should be consistent like other modules
  //   Author: Dixita.ruhela
  //    Date: 8 jan 2025
  //   RCA: The styling is not proper of the loader. */}
          <CircularProgress size={20} />
        </Grid>
      )}
    </Grid>
    /*</div>*/
  );
}
