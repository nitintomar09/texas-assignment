import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import Sidebar from "../Sidebar";
import CustomAppComp from "./../../utils/CustomAppComp";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  ReactDom.render(
    <CustomAppComp>
      <Sidebar />
    </CustomAppComp>,
    div
  );
});
it("Dashboard tab in sidebar ", () => {
  render(
    <CustomAppComp>
      <Sidebar />
    </CustomAppComp>
  );
  expect(screen.getByText("Dashboard")).toBeInTheDocument();
});

it("matches snapshot", () => {
  const tree = renderer
    .create(
      <CustomAppComp>
        <Sidebar />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
