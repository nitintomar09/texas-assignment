import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";
import renderer from "react-test-renderer";
import "@testing-library/jest-dom/extend-expect";
import Navbar from "../Navbar";
import CustomAppComp from "./../../utils/CustomAppComp";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");

  ReactDom.render(
    <CustomAppComp>
      <Navbar />
    </CustomAppComp>,
    div
  );
});
it("checking title of navbar", () => {
  render(
    <CustomAppComp>
      <Navbar />
    </CustomAppComp>
  );
  expect(screen.getByText("SCRIPT DESIGNER")).toBeInTheDocument();
});
it("matches snapshot", () => {
  const tree = renderer
    .create(
      <CustomAppComp>
        <Navbar />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
