export default {
  get: jest.fn().mockResolvedValue(),
};
