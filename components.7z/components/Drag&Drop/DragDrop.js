import { Box, Typography } from "@mui/material"
import { makeStyles } from "@mui/styles"
import { useState, useCallback } from "react"
 
// Styles using makeStyles
const useStyles = makeStyles((theme) => ({
  dropZone: {
    // border: (props) => `2px dashed ${props.isDragging ? theme.palette.primary.main : "#6b63b5"}`,
    border:"2px dashed rgba(0, 114, 198)",
    borderRadius: theme.shape.borderRadius,
    backgroundColor: "rgba(0, 114, 198, .03)",
    textAlign: "center",
    cursor: "pointer",
    transition: "all 0.2s ease",
    minHeight: "60px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    color: "#6b63b5",
    marginBottom: theme.spacing(2),
  },
  label: {
    fontSize: 12,
    color: "#606060",
    opacity: 1,
    fontWeight: 600,
    marginBottom: "4px",
  },
}))




export default function DragDrop({titleStyles = "", title = "",dragDropDesc= null,dragDropSubDesc= null,supportedFormats=[]}) {
  const [isDragging, setIsDragging] = useState(false)
  const [file, setFile] = useState(null)
 
  // Pass the isDragging state to useStyles
  const classes = useStyles({ isDragging })

  const acceptedFormats  = supportedFormats.join(", ");
 
  const handleFileSelect = useCallback((e) => {
    const selectedFile = e.target.files[0]
    if (selectedFile) {
      setFile(selectedFile)
    }
  }, [])
 
  return (
    <Box className={classes.container}>
      <Typography variant="h6" className={classes.label}>
        {title}
      </Typography>
      <input  type="file" id="file-input" style={{ display: "none" }} accept={acceptedFormats} onChange={handleFileSelect} />
      <label htmlFor="file-input">
        <Box
          className={classes.dropZone}
          component="div"
        >
            {
            dragDropDesc ?  dragDropDesc :
             <Typography variant="body1" sx={{ mb: 1 }}>
             {file ? `Selected file: ${file.name}` : "Drag and drop here or Browse"}
           </Typography>
            }

            {dragDropSubDesc ? dragDropSubDesc :
            <Typography variant="caption" color="text.secondary">
            Sub Text for Format or any other information
          </Typography>
            }
        </Box>
      </label>
    </Box>
  )
}
 
 