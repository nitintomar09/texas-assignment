import React, { useEffect, useState } from "react";
import theme from "../assets/theme/theme";
import {
  AppBar,
  Grid,
  Typography,
  Divider,
  Tabs,
  Tab,
  IconButton,
  useMediaQuery,
  useTheme,
} from "@mui/material";

import makeStyles from "@mui/styles/makeStyles";

import {
  HelpIcon,
  NotificationIcon,
  ActivityIcon,
  NewgenLogoIcon,
  NewgenOneLogo,
  MainScript,
  ScriptIcon,
  CloseIcon,
} from "../utils/AllImages";
import { withRouter } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";

import UserProfile from "./ProfileMenu/UserProfile";
import {
  setAllOpenScripts,
  setOpenScriptDetails,
  setSelectedTab,
  setActiveTab,
} from "../redux/actions";
import { useHistory } from "react-router-dom";
import MenuPopper from "../utils/MenuPopper";
import _ from "lodash";
import { truncateStringValues } from "./common";

const useStyles = makeStyles((AppTheme) => ({
  layout: {
    backgroundColor: "#FFFFFF",
    padding: "0 16px",
    height: 50,
    display: "flex",
    alignItems: "center",
    //justifyContent: 'space-between',
    overflow: "hidden",
  },
  title: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#34754A",
    paddingLeft: 10,
  },
  text: {
    fontSize: 16,
    color: "#1B1B1B",
    marginRight: 5,
  },
  boldText: {
    fontSize: 16,
    color: "#1B1B1B",
    fontWeight: "bold",
  },
  divider: {
    color: "#70707075",
    fontSize: 30,
    marginLeft: 5,
    marginRight: 5,
  },
  padding: {
    paddingLeft: 5,
    paddingRight: 5,
  },
  icons: {
    paddingLeft: 5,
    paddingRight: 5,
    color: "#000000",
  },
  appbar: {
    zIndex: AppTheme.zIndex.drawer + 1,
    backgroundColor: "transparent",
    borderBottom: `2px solid ${AppTheme.palette.secondary.main}`,
  },
  toolbarMargin: {
    ...theme.mixins.toolbar,
    //marginBottom: "3em"
  },
  iconSizes: {
    //filter: `invert(0%) sepia(59%) saturate(0%) hue-rotate(65deg) brightness(99%) contrast(103%)`,
    height: "24px",
    width: "24px",
    cursor: "pointer",
  },
  iconFocusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "10px",
    },
    "&:focus": {
      backgroundColor: "#f0f0f0",
    },
  },
  selectedTabStyle: {
    borderTop: `3px solid ${theme.palette.secondary.main}`,
    background: "#f36a101a",
  },
  // rootTab: {
  //   marginLeft: "12px",
  // },
  fullHomeTab: {
    display: "flex",
    alignItems: "center",
    boxSizing: "border-box",
    marginRight: 0,
  },
  homeTabTitle: {
    fontSize: 16,
    fontWeight: 600,
    color: "#000000",
  },
  tabIconSize: {
    width: "18px",
    height: "18px",
  },
  closeIconContainer: {
    marginLeft: "auto",
  },
  tabCloseIconSize: {
    width: "12px",
    height: "12px",
  },
  tabTitle: {
    fontSize: 14,
    fontWeight: 600,
    color: "#000000",
    flexGrow: "1",
  },
  fixedTab: {
    width: 190,
    overflow: "hidden",
    textOverflow: "ellipsis",
    whiteSpace: "nowrap",
    paddingRight: "24",
    boxSizing: "border-box",
  },
  tabContainer: {
    display: "flex",
    flexWrap: "nowrap",
    gap: 0,
    margin: 0,
    padding: 0,
  },
  tab: {
    minWidth: "auto",
    flexShrink: 0,
    margin: 0,
    padding: 0,
  },

  // [theme.breakpoints.down("md")]: {
  //   fixedTab: {
  //     width: 140,
  //   },
  //   homeTabTitle: {
  //     fontSize: 12,
  //   },
  //   tabTitle: {
  //     fontSize: 11,
  //   },
  //   tabCloseIconSize: {
  //     width: "10px",
  //     height: "10px",
  //   },
  // },
  // [theme.breakpoints.down("sm")]: {
  //   fixedTab: {
  //     width: 120,
  //   },
  //   homeTabTitle: {
  //     fontSize: 11,
  //   },
  //   tabTitle: {
  //     fontSize: 10,
  //   },
  //   tabCloseIconSize: {
  //     width: "9px",
  //     height: "9px",
  //   },
  // },
}));
const Navbar = (props) => {
  console.log(props,"actievTabb")
  const classes = useStyles();
  const dispatch = useDispatch();
  const history = useHistory();
  const handleHelp = () => {
    let element = document.createElement("a");
    element.setAttribute(
      "href",
      `http://${window.location.host}/designerdocs/index.htm#t=Introducing_RPA_Script_Designer.htm`
    );
    element.setAttribute("target", "_blank");
    element.setAttribute("rel", "noopener noreferrer");
    element.click();
  };
  const allOpenScripts = useSelector((state) => state.script.allOpenScripts);
  const openScriptDetails = useSelector(
    (state) => state.script.openScriptDetails
  );

  /*const [userData, setUserData] = useState({});

  useEffect(() => {
    getUserProfile();
  }, []);*/

  useEffect(() => {
    if (openScriptDetails && Object.keys(openScriptDetails).length > 0) {
      setOpenedHomeTab(false);
    }
  }, [openScriptDetails]);

  //Handling Responsiveness
  const theme = useTheme();
  const isLg = useMediaQuery("(min-width:1293px)");
  const isMd = useMediaQuery("(min-width:1048px)");
  const isSm = useMediaQuery("(min-width:700px)");
  const isMdLg = useMediaQuery("(max-width:1292px)");
  const isSmMd=useMediaQuery("(max-width:1048px)");
  const isXs=useMediaQuery("(max-width:700px)");

  let maxTabsToShow = 3; //Default for large screens
  if (isLg) {
    maxTabsToShow = 3;
  } else if (isMdLg && isMd) {
    maxTabsToShow = 2;
  } else if (isSmMd && isSm) {
    maxTabsToShow = 1;
  } else if(isXs) {
    maxTabsToShow = 0;
  }

  const tabsToShow = allOpenScripts.slice(0, maxTabsToShow);
  const menuItems = allOpenScripts.slice(maxTabsToShow);

  //Defining state to handle the home tab highlighting
  const [openedHomeTab, setOpenedHomeTab] = useState(false);
  
  const handleTab = (e, newValue) => {
  
    const selectedScript = allOpenScripts.find(
      (script) => `${script.scriptName}_${script.versionName}` === newValue
    );
    if (selectedScript) {
      
      dispatch(setOpenScriptDetails(_.cloneDeep(selectedScript)));
      dispatch(setActiveTab('Script'));//Setting state
      history.push(`/serviceflow`);
      setOpenedHomeTab(false); //Setting the state false
    }
  };
   /**
     * @author sanya.mahajan BUG ID :  Bug 155762 - UX header interaction not correct
     * Reason:Home tab was clickable even when no script tabs were opened and no hover state was defined
     * Resolution :fixed, made home tab clickable only when script tabs are opened and added hover state
     * Date : 28/01/2025             
     * */
  const isHomeTabDisabled = allOpenScripts.length === 0;
  const [hoveredTab, setHoveredTab] = useState(null);
  const handleHomeTab = (e) => {
    if (isHomeTabDisabled) return;
    dispatch(setOpenScriptDetails({}));
    dispatch(setActiveTab('Script')); //state='Script' when switching to home tab
    history.push(`/Dashboard`);
    setOpenedHomeTab(true); //Setting the state true
  };

  const handleSelectedItem = (e, script) => {
  
    const { name, versionName } = script;
    const selectedScript = allOpenScripts.find(
      (script) =>
        script.scriptName === name && script.versionName === versionName
    );
    const selectedScriptIndex = allOpenScripts.findIndex(
      (script) =>
        script.scriptName === name && script.versionName === versionName
    );

    if (selectedScript) {
      dispatch(
        setOpenScriptDetails({
          ...selectedScript,
          notUpdateAllOpenScripts: true,
        })
      );
      let newAllOpenScripts = _.cloneDeep(allOpenScripts);
      newAllOpenScripts.splice(selectedScriptIndex, 1);
      newAllOpenScripts = [selectedScript, ...newAllOpenScripts];
      dispatch(setAllOpenScripts(_.cloneDeep(newAllOpenScripts)));
      dispatch(setActiveTab('Script'));//When selecting tab from Menu Popper
      history.push(`/serviceflow`);
      setOpenedHomeTab(false); //Setting the state false
    }
  };
  const handleRemoveScriptTab = (e, removedScript) => {
    e.stopPropagation();
    let newSelectedScript;
    const removedScriptIndex = allOpenScripts.findIndex(
      (script) =>
        script.scriptName === removedScript.scriptName &&
        script.versionName === removedScript.versionName
    );
    if (removedScriptIndex !== -1) {
      if (
        openScriptDetails.scriptName !== removedScript.scriptName ||
        (openScriptDetails.scriptName === removedScript.scriptName &&
          openScriptDetails.versionName !== removedScript.versionName)
      ) {
        let newAllOpenScripts = allOpenScripts.filter(
          (item, i) => i !== removedScriptIndex
        );
        dispatch(setAllOpenScripts(_.cloneDeep(newAllOpenScripts)));
        return;
      } else {
        if (allOpenScripts.length === 1) {
          //Resetting the state
          dispatch(setAllOpenScripts([]));
          dispatch(setOpenScriptDetails({}));
          dispatch(setActiveTab('Script'));
          //Bug 156486 - User should have the back button on the canvas page to go back on the serviceflow tab
          //Author: nitin_tomar
          //Date: 05 FEB 2025
          //User must be redirect to serviceflows instead of dashboard when closing any opened serviceflow
          //history.push(`/Dashboard`);
          history.push('/serviceflows')
          setOpenedHomeTab(false); 
          return;
        }
        let newAllOpenScripts = allOpenScripts.filter(
          (item, i) => i !== removedScriptIndex
        );
        if (removedScriptIndex === 0) {
          dispatch(setActiveTab('Script'));
          newSelectedScript =
            newAllOpenScripts.length > 0 ? newAllOpenScripts[0] : {};
        } else {
          newSelectedScript =
            newAllOpenScripts.length >= 1
              ? newAllOpenScripts[removedScriptIndex - 1]
              : {};
        }
        dispatch(setAllOpenScripts(_.cloneDeep(newAllOpenScripts)));
        dispatch(
          setOpenScriptDetails({
            ...newSelectedScript,
            notUpdateAllOpenScripts: true,
          })
        );
        dispatch(setActiveTab('Script'));
        history.push(`/serviceflow`);
        setOpenedHomeTab(false); //Setting the state false
      }
    }
  };
 

  /**
 * const getUserProfile = async () => {
    const userIndex = secureLocalStorage.getItem("user_id");
    try {
      const res = await axios.get(
        `${ENDPOINT_USER_DATA}/${userIndex}?requiredProfileImage=true`
      );
      if (res.status === 200) {
        setUserData(res?.data);
      }
    } catch (err) {
      console.log(err);
    }
  };
 */
  return (
    <>
      <AppBar position="fixed" className={classes.appbar}>
        <Grid
          container
          alignItems="center"
          justifyContent="space-between"
          className={classes.layout}
        >
          {/* logo and company name */}
          <Grid item>
            <Grid
              container
              alignItems="center"
              className={classes.tabContainer}
            >
              <Grid item>
                <img
                  src={NewgenOneLogo}
                  alt="Logo"
                  style={{
                    height: 30,
                    width: 155,
                    marginLeft: 14,
                    marginTop: "3px",
                  }}
                  // style={{ marginLeft: 20 }}
                />
                {/* <NewgenLogoIcon
                style={{ height: 29, width: 28, marginLeft: 21 }}
/>*/}
              </Grid>
              <Grid item>
                {/* <Typography variant="h6" className={classes.boldText} style={{marginLeft:"4px",marginTop:"2px"}}>
                RPA
              </Typography> */}
              </Grid>
              {/* Divider */}
              {/*<Grid item>
              <Typography variant="h6" className={classes.divider}>
                |
              </Typography>
</Grid>*/}
              <Divider
                orientation="vertical"
                flexItem="fullWidth"
                style={{
                  width: "2px",
                  marginLeft: "20px",
                  color: "#000000",

                  fontWeight: 600,
                }}
              />
              {/*<Grid item>
              <Typography variant="h6" className={classes.text}>
                RPA
              </Typography>
            </Grid>*/}
              <Grid item onClick={handleHomeTab} style={{ cursor: "pointer" }}>
                <Tab
                  tabIndex={0}
                  key="homeTab"
                  id="homeTab"
                  value="homeTab"
                  textColor="primary"
                  label={
                    <div className={classes.fullHomeTab}>
                      <Typography
                        className={classes.homeTabTitle}
                        title="Service Flow Designer"
                        variant="h6"
                      >
                        Service Flow Designer
                      </Typography>
                    </div>
                  }
                  classes={{
                    root: openedHomeTab
                      ? classes.selectedTabStyle
                      : classes.tabs,
                  }}
                  disabled={isHomeTabDisabled}
                />
              </Grid>
              <Tabs
                value={`${openScriptDetails.scriptName}_${openScriptDetails.versionName}`}
                onChange={(event, newValue) => handleTab(event, newValue)}
                // indicatorColor="primary"
                TabIndicatorProps={{ hidden: true }}
                textColor="primary"
                aria-label="Opened Service flow Tabs"
                classes={{ root: classes.rootTab }}
                variant="standard"
              >
                {/* {(allOpenScripts.length > 3 ? allOpenScripts.slice(0, 3) : allOpenScripts).map((item, index) => ( */}
                {tabsToShow.map((item, index) => (
                  <Tab
                    tabIndex={1}
                    key={`${item.scriptId}_Tab_${index}`}
                    id={`${item.scriptName}_Tab`}
                    value={`${item.scriptName}_${item.versionName}`}
                    icon={<ScriptIcon className={classes.tabIconSize} />}
                    iconPosition="start"
                    sx={{ "&:not(.Mui-selected):hover": {
                      backgroundColor: "#F8F8F8",  
                      borderLeft: "2px solid #D9D9D9",  
                      borderRight: "2px solid #D9D9D9", 
                     
                      
                    },}}
                    onMouseEnter={() => setHoveredTab(item.scriptId)} 
                    onMouseLeave={() => setHoveredTab(null)} 
                    label={
                      <div
                        className={classes.fixedTab}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          cursor: "pointer",
                          gap: "8px",
                        }}
                       
                      >
                        <Typography
                          className={classes.tabTitle}
                          title={item.scriptName}
                        >
                          {`${truncateStringValues({
                            str: item.scriptName,
                            min: 10,
                            max: 13,
                          })} (${item.versionName})`}
                        </Typography>
                        {(hoveredTab === item.scriptId || `${item.scriptName}_${item.versionName}` === `${openScriptDetails.scriptName}_${openScriptDetails.versionName}`)  && (
                          <IconButton
                            aria-label="Remove Tab"
                            onClick={(e) => {
                              handleRemoveScriptTab(e, item);
                            }
                            }
                            className={classes.closeIconContainer}
                          >
                                  <CloseIcon className={classes.tabCloseIconSize} />
                          </IconButton>
                        )}
                      </div>
                    }
                    classes={{ selected: classes.selectedTabStyle }}
                  />
                ))}
              </Tabs>
              {/* {allOpenScripts.length > 3 */}
              {menuItems.length > 0 && (
                <MenuPopper
                  id={`RPA_ScriptDesigner_Navbar_MenuPopper`}
                  // MenuIcon={MoreVerticalIcon}
                  //  className={[classes.icon, classes.focusVisible].join(
                  //    " "
                  //  )}
                  handleSelectedItem={handleSelectedItem}
                  // items={
                  //   allOpenScripts.slice(3).map(item => ({ name: item.scriptName, versionName: item.versionName }))
                  // }
                  items={menuItems.map((item) => ({
                    name: item.scriptName,
                    versionName: item.versionName,
                  }))}
                  placement="bottom"
                  returnSelectedObject={true}
                />
              )}
            </Grid>
          </Grid>
          {/* user and notification */}
          {!["/Error"].includes(props.location.pathname) && (
            <Grid item>
              <Grid container alignItems="center">
                <Grid item className={classes.icons}>
                  <HelpIcon
                    className={
                      classes.iconSizes + " " + classes.iconFocusVisible
                    }
                    onClick={() => handleHelp()}
                    title="Help"
                    //WCAG Keyboard Guidelines
                    role="button"
                    tabIndex={0}
                    onKeyPress={(e) => e.key === "Enter" && handleHelp()}
                    id="RPA_Navbar_HelpIcon"
                  />
                </Grid>
                {/*<Grid item className={classes.icons}>
                <ActivityIcon className={classes.iconSizes} />
              </Grid>
              <Grid item className={classes.icons}>
                <NotificationIcon className={classes.iconSizes} />
        </Grid>*/}
                <Grid item className={classes.icons}>
                  <UserProfile />
                </Grid>
              </Grid>
            </Grid>
          )}
        </Grid>
      </AppBar>
    </>
  );
};
export default withRouter(Navbar);
