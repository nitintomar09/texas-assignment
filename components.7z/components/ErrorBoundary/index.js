import React, { useState, useEffect } from 'react';
import ErrorMessage from './ErrorMessage';

const ErrorBoundary = ({ children }) => {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    const handleError = (error, errorInfo) => {
      // You can log the error to a logging service
      console.error('Error caught by error boundary:', error, errorInfo);
      setHasError(true);
    };

    // Attach the error handler to the global error event
    window.addEventListener('error', handleError);

    // Cleanup the event listener when the component unmounts
    return () => {
      window.removeEventListener('error', handleError);
    };
  }, []);

  if (hasError) {
    // You can render a fallback UI here
    return <ErrorMessage>Something went wrong. Please try again.</ErrorMessage>;
  }

  return children;
};

export default ErrorBoundary;
