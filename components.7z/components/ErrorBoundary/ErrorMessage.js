import React from 'react';
import styled, { keyframes } from 'styled-components';

const fadeIn = keyframes`
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
`;

const WarningContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(255, 0, 0, 0.1);
  animation: ${fadeIn} 1s ease-in-out;
`;

const WarningBox = styled.div`
  background-color: #ffdddd;
  color: #d8000c;
  padding: 40px;
  border-radius: 10px;
  border: 2px solid #d8000c;
  font-size: 24px;
  font-weight: bold;
  text-align: center;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  max-width: 80%;
  margin: 20px;
  position: relative;
`;

const WarningIcon = styled.div`
  position: absolute;
  top: -20px;
  left: 50%;
  transform: translateX(-50%);
  background-color: #d8000c;
  color: #fff;
  border-radius: 50%;
  padding: 10px;
  font-size: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
`;

const ErrorMessage = () => (
  <WarningContainer>
    <WarningBox>
      <WarningIcon>⚠️</WarningIcon>
      Something went wrong. Please try again.
    </WarningBox>
  </WarningContainer>
);

export default ErrorMessage;
