import React from "react";
import { Typography } from "@mui/material";
const ScriptStore = () => {
  return (
    <div style={{ paddingLeft: "20px" }}>
      <Typography>Coming soon...</Typography>
    </div>
  );
};

export default ScriptStore;
