import React, { useState, useEffect, useContext, useRef } from "react";
import { useHistory } from "react-router-dom";
import makeStyles from "@mui/styles/makeStyles";
import withStyles from "@mui/styles/withStyles";

import {
  Typography,
  Popover,
  CircularProgress,
  Grid,
  Button,
  Divider,
  Badge,
  IconButton,
  Collapse,
  Menu,
  MenuItem,
} from "@mui/material";

import ModalForm from "./../../utils/modalForm";
import { Check } from "@mui/icons-material";
import Field from "./../../utils/field";
import { createInstance, handleNetworkRequestError } from "../../utils/common";
import { VARIABLES } from "./../../config/index";
import CheckboxField from "./../script-editor/PropertyWindow/PropertyFields/CheckboxField";
import { NotificationContext } from "./../../contexts/NotificationContext";
import { VariablesContext } from "./../../contexts/VariablesListContext";
import { useSelector } from "react-redux";
import LoadingIndicator from "../../utils/loadingIndicator";
import {
  GET_MDM_GLOBAL_CATEGORIES,
  GET_MDM_VARIABLES,
  GET_PORTAL_VARIABLES,
  GET_PROCESS_VARIABLES,
  GET_MDM_GLOBAL_CATEGORY_DATA_OBJECTS,
  PROJECT,
  SCRIPT,
} from "./../../config/index";
import {
  getCssFilterFromHex,
  getCssRgbFromHexByDiff,
  getRgbafromHex,
} from "../../utils/HexToFilter";
import {
  EditIcon,
  DeleteIcon,
  SortingZtoAIcon,
  SortingAtoZIcon,
  ForwardTailRightIcon,
  FilterIcon,
  ExpandDataIcon,
  DeleteAction,
  CloseIcon,
  AddVaribaleIcon,
  VariableIcon,
  NoVariableIcon,
  NoVariableFoundIcon,
} from "../../utils/AllImages";
import {
  isEmptyText,
  MaximumLengthText,
  MinimumLengthText,
  onlyLettersAndUnderscore,
  atleastContainsACharacter,
} from "../../utils/validations/validations";
import SearchBox from "../../utils/Search-Component";

import customStyles from "../../assets/css/customStyle";
import CheckboxGroup from "../script-editor/PropertyWindow/PropertyFields/CheckboxGroup";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";
import LoadingButton from "../common/Button/index";
import {
  DropDownVariableOption,
  DropDownArrowIcon,
  ActionsMenu,
} from "../../utils/AllImages";
import { setVariablesFunctionList } from "../../redux/actions";
import MultiSelectWithSearchForMDMCategories from "../../utils/MultiSelectWithSearchForMDMCategories";
import { ListboxComponent } from "../../utils/MultiSelectWithSearchForMDMCategories";
import NestedSelect from "../common/MDMSelectComponent";
import TabsButton from "../../utils/Tab/TabsButton";
import { forEach } from "lodash";

const CancelButton = withStyles((theme) => ({
  root: {
    ...customStyles.btn1,
    color: customStyles?.btn1?.color,
    // color: "#df5a5a",
    backgroundColor: customStyles?.btn1?.background,
    "&:hover": {
      backgroundColor: "#F8F8F8",
    },
    "&:focus-visible": {
      background: `#F8F8F8`,
      outline: `1px solid ${theme.palette.tabFocus.mainColor}`,
    },
    height: "32px",
  },
}))(Button);
const FilterPopover = ({
  anchorEl,
  handleClose,
  id,
  open,
  filterByType = [],
  filterByOther = [],
  // onApply,
  //onCancel,
  // onClearAll,
  handleChangeFilters,
}) => {
  const [filtersByType, setFiltersByType] = useState(
    filterByType.map((item) => ({ ...item }))
  );
  const [filtersByOther, setFiltersByOther] = useState(
    filterByOther.map((item) => ({ ...item }))
  );

  useEffect(() => {
    setFiltersByOther(filterByOther.map((item) => ({ ...item })));
    setFiltersByType(filterByType.map((item) => ({ ...item })));
  }, [filterByOther, filterByType]);

  const classes = useStyles();
  const { t } = useTranslation();
  const handleChangeFiltersLocal = (e) => {
    const { name, checked, value } = e.target;
    const newFilterByOther = [...filtersByOther];
    const newFilterByType = [...filtersByType];
    if (name === "Fixed" || name === "Dynamic") {
      const itemIndex = filtersByOther.findIndex((it) => it.name === name);
      if (itemIndex != -1) {
        const item = filtersByOther.find((it) => it.name === name);
        item.value = checked;
        newFilterByOther.splice(itemIndex, 1, item);
      }
    } else {
      const itemIndex = filtersByType.findIndex((it) => it.name === name);
      if (itemIndex !== -1) {
        const item = filtersByType.find((it) => it.name === name);
        item.value = checked;
        newFilterByType.splice(itemIndex, 1, item);
      }
    }
    setFiltersByType(newFilterByType);
    setFiltersByOther(newFilterByOther);
  };
  const onApplyLocal = () => {
    handleChangeFilters({
      newFilterByType: [...filtersByType],
      newFilterByOther: [...filtersByOther],
    });
  };
  const onClearAllLocal = () => {
    setFiltersByType(filtersByType.map((it) => ({ ...it, value: false })));
    setFiltersByOther(filtersByOther.map((it) => ({ ...it, value: false })));
  };
  const handleCancel = () => {
    setFiltersByOther(filterByOther.map((item) => ({ ...item })));
    setFiltersByType(filterByType.map((item) => ({ ...item })));
    handleClose();
  };
  return (
    <div>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        PaperProps={{
          style: {
            width: "250px",
            overflow: "hidden",
            alignItems: "center",
            boxShadow: "0px 3px 6px #00000029",
          },
        }}
        //style={{ padding: "20px" }}
      >
        <Grid
          container
          alignItems="center"
          style={{
            paddingRight: "16px",
            paddingLeft: "16px",
            paddingTop: "10px",
            paddingBottom: "10px",
            height: "40px",
          }}
        >
          <Grid item>
            <Typography className={classes.header1}>{t("Filters")}</Typography>
          </Grid>
          <Grid
            item
            style={{ marginLeft: "auto" }}
            tabIndex={0}
            onKeyDown={(e) => e.key === "Enter" && onClearAllLocal()}
            role="button"
            id={`${id}_ClearBtnDiv`}
          >
            <Typography
              className={classes.clearBtn}
              onClick={() => onClearAllLocal()}
              id={`${id}_ClearBtn`}
            >
              {t("Clear")}
            </Typography>
          </Grid>
        </Grid>
        <Divider variant="fullWidth" />

        <div className={classes.content}>
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography className={classes.subHeader}>
                {t("Filter by type")}
              </Typography>
            </Grid>

            <Grid
              item
              container
              spacing={2}
              style={{
                paddingRight: "16px",
                paddingLeft: "24px",
              }}
            >
              <Grid item>
                <CheckboxGroup
                  id={id}
                  checkboxArray={filtersByType.slice(0, 6).map((item) => ({
                    ...item,
                    onChange: handleChangeFiltersLocal,
                  }))}
                />
              </Grid>
              <Grid item>
                <CheckboxGroup
                  id={id}
                  checkboxArray={filtersByType.slice(6, 12).map((item) => ({
                    ...item,
                    onChange: handleChangeFiltersLocal,
                  }))}
                />
              </Grid>
            </Grid>
            <Divider variant="fullWidth" />
            <Grid
              item
              container
              spacing={1}
              justifyContent="flex-start"
              style={{
                paddingRight: "16px",
                paddingLeft: "24px",
                paddingTop: "8px",
                paddingBottom: "8px",
              }}
            >
              <Grid item>
                <CheckboxGroup
                  id={id}
                  checkboxArray={filtersByOther.slice(0, 1).map((item) => ({
                    ...item,
                    onChange: handleChangeFiltersLocal,
                  }))}
                />
              </Grid>
              <Grid item style={{ marginLeft: "5px" }}>
                <CheckboxGroup
                  id={id}
                  checkboxArray={filtersByOther.slice(1, 2).map((item) => ({
                    ...item,
                    onChange: handleChangeFiltersLocal,
                  }))}
                />
              </Grid>
            </Grid>
          </Grid>
        </div>
        <Divider variant="fullWidth" />

        <Grid
          container
          justifyContent="flex-end"
          alignItems="center"
          style={{
            paddingRight: "16px",
            height: "40px",
            backgroundColor: "#f8f8f8",
          }}
        >
          <Grid item style={{ marginRight: "12px" }}>
            <CancelButton
              onClick={handleCancel}
              disableRipple
              // className={classes.focusTertiary}
              id={`${id}_CancelBtn`}
            >
              {t("Cancel")}
            </CancelButton>
          </Grid>
          <Grid item>
            <Button
              variant="contained"
              // size="small"
              color="primary"
              onClick={onApplyLocal}
              disableRipple
              className={classes.focusPrimary}
              id={`${id}_ApplyBtn`}
            >
              {t("Apply")}
            </Button>
          </Grid>
        </Grid>
      </Popover>
    </div>
  );
};

const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};
const VariableListModal = (props) => {
  const { applicationDetails } = props;
  const [open, setOpen] = useState(props.isOpen ? true : false);
  const { t } = useTranslation();
  const history = useHistory();
  const varFieldRef = useRef(null);

  const [allVariablesOrg, setAllVariablesOrg] = useState([]);
  const [allVariables, setAllVariables] = useState([]);
  const [isCreateVariable, setIsCreateVariable] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [menu, setMenu] = useState(null);
  const [actionMenu, setActionMenu] = useState(null);
  const [variableData, setVariableData] = useState([]);

  const [variableName, setVariableName] = useState(makeFieldInputs(""));
  const [variableDefaultValue, setVariableDefaultValue] = useState("");
  const [variableType, setVariableType] = useState(makeFieldInputs("")); //DataType
  const [type, setType] = useState(makeFieldInputs("")); //Variable State-I,O,T,F,D
  const [isFixedChecked, setIsFixedChecked] = useState(false);
  const [isDynamicChecked, setIsDynamicChecked] = useState(false);
  const [globalCategoryName, setGlobalCategoryName] = useState(
    makeFieldInputs("")
  );
  const [isMaskChecked, setIsMaskedChecked] = useState(false);
  const [isInputChecked, setIsInputChecked] = useState(false);
  const [isOutputChecked, setIsOutputChecked] = useState(false);
  const [selectedVariables, setSelectedVariables] = useState([]);
  const [importMDMVariable, setImportMDMVariable] = useState(false);
  const [isEditingVar, setIsEditingVar] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedRow, setSelectedRow] = useState(-1);
  const [formHasError, setFormHasError] = useState(true);
  const [sortType, setSortType] = useState("Asc");
  const [expandedVars, setExpandedVars] = useState([]);
  const [filterByType, setFilterByType] = useState(optionsForFilterType);
  const [filterByOther, setFilterByOther] = useState(optionsForFilter);
  const [categories, setCategories] = useState([]);
  const [subVariables, setSubVariables] = useState([]);
  const [subList, setSubList] = useState([]);
  const [variableDataValue, setVariableDataValue] = useState([]);
  const [dataObjectMDM, setDataObjectMDM] = useState([]);
  const [createVariableObject, setCreateVariableObject] = useState([]);
  const [mdmFlag, setMdmFlag] = useState(false);
  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const versionId = scriptValues && scriptValues.versionId;
  const scriptId = scriptValues && scriptValues.scriptId;
  const recordsToFetch = 2;
  const { setValue } = useContext(NotificationContext);
  const { setAllVariables: setAllVariablesInContext } =
    useContext(VariablesContext);
  const [selTab, setSelTab] = useState("All");

  const getAllCategories = async () => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${GET_MDM_GLOBAL_CATEGORIES}`);
      if (res.status === 200) {
        setCategories(res.data?.data || []);
      }
    } catch (error) {
      console.log(error);
    }
  };
  const fetchDataObjects = async (payload, e) => {
    const axiosInstance = createInstance();
    let page_no = 1;
    let dataObject = payload.filter(
      (item) => item.categoryId == e.target.value
    );

    if (subVariables[payload.categoryId]) {
      const len = subVariables[payload.categoryId].length;
      page_no = len / recordsToFetch + 1;
    }
    try {
      const res = await axiosInstance.post(
        `${GET_MDM_GLOBAL_CATEGORY_DATA_OBJECTS}`,
        {
          records_to_fetch: `${recordsToFetch}`,
          page_no: page_no,
          parent_id: dataObject[0]?.categoryId,
          ...dataObject[0],
        }
      );
      if (res.status === 200) {
        setSubVariables(res.data?.data);

        // setSubVariables((prev) => ({ ...prev, [dataObject[0].categoryId]: dataObject[0].map(item => ({ ...item, variableType: "C" })) }));
        return res.data?.data;
      }
    } catch (error) {
      console.log(error);
    }
  };

  const fetchVariablesOfDataObjects = async (payload) => {
    const axiosInstance = createInstance();

    try {
      const res = await axiosInstance.post(`${GET_MDM_VARIABLES}`, {
        variableType: "C",
        ...payload[0],
      });
      if (res.status === 200) {
        //  setSubList(res.data?.data);

        setSubVariables((prevState) => {
          let newState = prevState.map((item) => {
            if (item.dataObjectId == payload[0].dataObjectId) {
              return {
                ...item,
                subList: res.data?.data,
              };
            } else {
              return item;
            }
          });

          return newState;
        });

        // return res.data?.data;
        //setAllVariables(res.data?.data)
      }
    } catch (error) {
      console.log(error);
    }
  };

  const getAllVariables = async () => {
    const axiosInstance = createInstance();
    if (versionId) {
      setIsLoading(true);
      try {
        let res = await axiosInstance.get(`${VARIABLES}/${versionId}`);
        setAllVariables(res.data.data ? res.data.data : []);
        setAllVariablesOrg(res.data.data ? res.data.data : []);
        setIsLoading(false);
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "",
              title: "",
              notificationType: "ERROR",
            });
          },
        });
        setIsLoading(true);
      }
    } else {
      console.log("version id is not available", versionId);
    }
  };

  useEffect(() => {
    if (versionId) {
      getAllVariables();
    }
  }, [versionId]);

  const handleClickOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleCloseFilter = () => {
    setAnchorEl(null);
  };

  const handleSelect = (e, data) => {
    setVariableDataValue(e);
    const element = data.filter((el) => el.variableName == e.split(".")[1]);
    setDataObjectMDM(element);
  };

  const handleChange = (e, id) => {
    const { name, value } = e.target;

    let errors = "";

    switch (name) {
      case "variableName":
        // setVariableName({
        //   ...variableName,
        //   value,
        //   error: errors ? true : false,
        //   helperText: errors,
        // });
        setCreateVariableObject((prev, index) => {
          return prev.map((item, idx) => {
            if (idx === id) {
              return {
                ...item,
                variableName: {
                  value,
                  error: errors ? true : false,
                  helperText: errors || "", // You can set an empty string if no errors
                },
              };
            }
            return item;
          });
        });
        break;
      case "globalCategoryName":
        setGlobalCategoryName({
          ...globalCategoryName,
          value,
          error: errors ? true : false,
          helperText: errors,
        });
        break;
      case "catergoryName":
        setCreateVariableObject((prev, index) => {
          return prev.map((item, idx) => {
            if (idx === id) {
              return {
                ...item,
                categoryName: {
                  value,
                  error: errors ? true : false,
                  helperText: errors || "", // You can set an empty string if no errors
                },
              };
            }
            return item;
          });
        });
        break;
      case "type":
        // setType({
        //   ...type,
        //   value,
        //   error: errors ? true : false,
        //   helperText: errors,
        // });

        setCreateVariableObject((prev, index) => {
          return prev.map((item, idx) => {
            if (idx === id) {
              return {
                ...item,
                type: {
                  value,
                  error: errors ? true : false,
                  helperText: errors || "", // You can set an empty string if no errors
                },
              };
            }
            return item;
          });
        });
        break;

      case "variableType":
        //  errors = isEmptyText("" + value);
        // setVariableType({
        //   ...variableType,
        //   value,
        //   error: errors ? true : false,
        //   helperText: errors,
        // });
        setCreateVariableObject((prev, index) => {
          return prev.map((item, idx) => {
            if (idx === id) {
              return {
                ...item,
                variableType: {
                  value,
                  error: errors ? true : false,
                  helperText: errors || "", // You can set an empty string if no errors
                },
              };
            }
            return item;
          });
        });
        break;
      case "variableDefaultValue":
        // setVariableDefaultValue(value);
        setCreateVariableObject((prev, index) => {
          return prev.map((item, idx) => {
            if (idx === id) {
              return {
                ...item,
                variableDefaultValue: value,
              };
            }
            return item;
          });
        });
        break;

      case "fixed":
        // setIsFixedChecked(!isFixedChecked);
        setCreateVariableObject((prev, index) => {
          return prev.map((item, idx) => {
            if (idx === id) {
              return {
                ...item,
                isFixedChecked: value,
              };
            }
            return item;
          });
        });

        break;
      case "dynamic":
        // setIsDynamicChecked(!isDynamicChecked);
        setCreateVariableObject((prev, index) => {
          return prev.map((item, idx) => {
            if (idx === id) {
              return {
                ...item,
                isDynamicChecked: value,
              };
            }
            return item;
          });
        });
        break;
      case "mask":
        setIsMaskedChecked(!isMaskChecked);
        break;
      case "Input":
        setIsInputChecked(!isInputChecked);
        break;
      case "Output":
        setIsOutputChecked(!isOutputChecked);
        break;
      default:
        break;
    }
  };
  const handleChangeFilters = ({ newFilterByType, newFilterByOther }) => {
    setFilterByType(newFilterByType);
    setFilterByOther(newFilterByOther);
    const filteredTypes = newFilterByType.filter((item) => item.value);

    const types = filteredTypes.map((item) => item.type);

    const filteredTypesOther = newFilterByOther.filter((item) => item.value);
    const typesOther = filteredTypesOther.map((item) => item.type);

    let newAllVars = [...allVariablesOrg];
    if (types.length > 0) {
      newAllVars = allVariablesOrg.filter((varItem) => {
        if (types.includes(varItem.variableObjType)) {
          return varItem;
        }
      });
    }
    if (typesOther.length > 0) {
      newAllVars = newAllVars.filter((varItem) => {
        if (
          typesOther.find((item) => varItem.valueState.indexOf(item) !== -1)
        ) {
          return varItem;
        }
      });
    }
    if (filteredTypes.length === 0 && filteredTypesOther.length === 0) {
      setAllVariables(allVariablesOrg);
    } else {
      setAllVariables(newAllVars);
    }
    handleCloseFilter();
  };

  const expandVar = (variableId) => {
    const newExpandedVars = [...expandedVars];
    const isAlreadyExpanded = expandedVars.findIndex(
      (item) => item === variableId
    );
    if (isAlreadyExpanded !== -1) {
      newExpandedVars.splice(isAlreadyExpanded, 1);
    } else {
      newExpandedVars.push(variableId);
    }
    setExpandedVars(newExpandedVars);
  };
  const onCancel = (item, id) => {
    setIsEditingVar(null);
    setIsCreateVariable(false);
    //setIsCreateVariable(createVariableObject.length > 0 ? true : false);
    // setVariableName(makeFieldInputs(""));
    // setVariableDefaultValue("");
    // setVariableType(makeFieldInputs(""));
    // setType(makeFieldInputs(""));
    // setIsFixedChecked(false);
    // setIsDynamicChecked(false);
    // setIsInputChecked(false);
    // setIsOutputChecked(false);
    // setIsMaskedChecked(false);
    setImportMDMVariable(false);
    setCreateVariableObject((prev, index) =>
      prev.filter((itemA) => itemA !== item)
    );
    
  };
  useEffect(() => {
    if (variableName?.error || variableType?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [variableName, variableType]);
  const validateFields = () => {
    const varNameErrors =
      isEmptyText(variableName.value) ||
      onlyLettersAndUnderscore(variableName.value) ||
      atleastContainsACharacter(variableName.value) ||
      MinimumLengthText(variableName.value, 2) ||
      MaximumLengthText(variableName.value, 40);

    //converting int to string ant then check value
    const varTypeErrors = isEmptyText("" + variableType.value);
    if (varNameErrors) {
      setVariableName({
        ...variableName,
        error: varNameErrors ? true : false,
        helperText: varNameErrors,
      });
    }
    if (varTypeErrors) {
      setVariableType({
        ...variableType,
        error: varTypeErrors ? true : false,
        helperText: varTypeErrors,
      });
    }

    return varNameErrors || varTypeErrors ? false : true;
  };

  const onCreate = async (item, id) => {
    const newArrOfCb = [];
    if (item.isDynamicChecked) {
      newArrOfCb.push("D");
    }
    if (item.isFixedChecked) {
      newArrOfCb.push("F");
    }
    // if (isMaskChecked) {
    //   newArrOfCb.push("M");
    // }
    if (item.type.value == "I") {
      newArrOfCb.unshift("I");
    }
    if (item.type.value == "O") {
      newArrOfCb.unshift("O");
    }

    setIsProcessing(true);
    setSelectedRow(id);
    const axiosInstance = createInstance();

    if (isEditingVar) {
      let variableId = isEditingVar.variableId;
      let variablePreviousValue = allVariables.find(
        (varObj) => varObj.variableId === variableId
      );
      let newVariables = [...allVariables];
      let newVariablesOrg = [...allVariablesOrg];
      let json = {
        scriptId: +scriptId,
        versionId: +versionId,
        variableName: variableName.value,
        variableObjType: variableType.value ? +variableType.value : null,
        varDefaultValue: variableDefaultValue,
        variableType: isEditingVar.variableType,
        valueState: newArrOfCb.length > 0 ? newArrOfCb : [],
      };

      let variableIndex = allVariables.findIndex(
        (varObj) => varObj.variableId === variableId
      );
      let variableIndexOrg = allVariablesOrg.findIndex(
        (varObj) => varObj.variableId === variableId
      );

      newVariables.splice(variableIndex, 1, {
        ...json,
        variableId,
      });
      newVariablesOrg.splice(variableIndexOrg, 1, {
        ...json,
        variableId,
      });
      setAllVariables(newVariables);
      setAllVariablesOrg(newVariablesOrg);

      try {
        let res = await axiosInstance.put(`${VARIABLES}/${variableId}`, {
          ...json,
        });

        /*****************************************************************************************
         * @author asloob_ali BUG ID : 102370 Description : Getting white screen after creating a variable in all the activities
         *  Resolution : now sending correct value as a string in notification title.
         * Reason: the value was going as an object in notification title.
         *  Date : 03/11/2021             ***************************************************************************************/
        if (res.status === 200) {
          setValue({
            isOpen: true,
            notificationType: "SUCCESS",
            message: res.data["message"] || "updated Succefully.",
            title: variableName.value,
          });
          setAllVariablesInContext({ allVariables: newVariables });
          setIsEditingVar(null);
          setIsProcessing(false);
          setSelectedRow(-1);
          setIsCreateVariable(false);
          //   setVariableName(makeFieldInputs(""));
          //   setVariableDefaultValue("");
          //   setVariableType(makeFieldInputs(""));
          //   setType(makeFieldInputs(""));
          //   setIsFixedChecked(false);
          //   setIsDynamicChecked(false);
          //   setIsInputChecked(false);
          //   setIsOutputChecked(false);
          //   setIsMaskedChecked(false);
          setCreateVariableObject([]);
        }
      } catch (error) {
        console.log(error.response);
        setIsProcessing(false);

        newVariables.splice(variableIndex, 1, variablePreviousValue);
        setAllVariables(newVariables);
        newVariablesOrg.splice(variableIndexOrg, 1, variablePreviousValue);
        setAllVariablesOrg(newVariablesOrg);
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              notificationType: "ERROR",
              message: errMsg || "update failed.",
              title: variableName.value,
            });
          },
        });
      }
    } else {
      //here
      let json = {
        scriptId: +scriptId,
        versionId: +versionId,
        variableName: item.variableName.value.replaceAll(".", "$"),
        variableObjType: item.variableType.value
          ? +item.variableType.value
          : null,
        varDefaultValue: item.variableDefaultValue,
        // variableDisplayName:item.variable.value,
        // variableType:
        //   importMDMVariable == true ? "N" : isCreateVariable ? "V" : "C",
        variableType: isCreateVariable ? "V" : "C",
        valueState: newArrOfCb.length > 0 ? newArrOfCb : [],
      };

      try {
        let res = await axiosInstance.post(`${VARIABLES}`, {
          ...json,
        });

        if (res.status === 200) {
          let newVariables = [
            { ...json, variableId: res.data.data[0]["variableId"] },
            ...allVariables,
          ];
          setAllVariables(newVariables);
          let newVariablesOrg = [
            { ...json, variableId: res.data.data[0]["variableId"] },
            ...allVariablesOrg,
          ];

          setAllVariablesOrg(newVariablesOrg);
          setAllVariablesInContext({ allVariables: newVariables });
          setValue({
            isOpen: true,
            notificationType: "SUCCESS",
            message: res.data["message"] || "created Succefully.",
            title: variableName.value,
          });
        }
        setIsProcessing(false);
        setSelectedRow(-1);
        setIsCreateVariable(false);
      //  setIsCreateVariable(createVariableObject.length > 0 ? true : false);
        //setVariableName(makeFieldInputs(""));
        //setVariableDefaultValue("");
        //setVariableType(makeFieldInputs(""));
        //setType(makeFieldInputs(""));
        //setIsFixedChecked(false);
        // setIsDynamicChecked(false);
        // setIsInputChecked(false);
        // setIsOutputChecked(false);
        // setIsMaskedChecked(false);
        setImportMDMVariable(false);
        setCreateVariableObject((prev, index) =>
          prev.filter((itemA) => itemA !== item)
        );
      } catch (error) {
        console.log(error.response);
        setIsProcessing(false);

        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              notificationType: "ERROR",
              message: errMsg || "creation failed.",
              title: variableName.value,
            });
          },
        });
      }
    }
  };

  const handleDelete = async (variableId) => {
    const axiosInstance = createInstance();

    if (variableId) {
      try {
        let res = await axiosInstance.delete(`${VARIABLES}/${variableId}`);

        if (res.status === 200) {
          let variable = allVariables.find(
            (variableObj) => variableObj.variableId === variableId
          );
          let newVariables = allVariables.filter(
            (variable1) => variable1.variableId !== variableId
          );
          setAllVariables(newVariables);
          let newVariablesOrg = allVariablesOrg.filter(
            (variable2) => variable2.variableId !== variableId
          );
          setAllVariablesOrg(newVariablesOrg);
          setValue({
            isOpen: true,
            notificationType: "SUCCESS",
            message: res.data["message"]
              ? res.data["message"]
              : "deleted successfully",
            title: variable && variable.variableName,
          });
          setAllVariablesInContext({ allVariables: newVariables });
        }
      } catch (error) {
        console.log(error);
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              notificationType: "ERROR",
              message: errMsg || "deletion failed.",
              title: "",
            });
          },
        });
      }
    } else {
      console.log("invalid variableId", variableId);
    }
  };

  const handleEdit = (variable) => {
    console.log(variable, "variablellle", type);
    if (variable) {
      setVariableName({ value: variable.variableName });
      setVariableType(makeFieldInputs(variable.variableObjType));
      setVariableDefaultValue(variable.varDefaultValue);
      if (variable.valueState.indexOf("F") !== -1) {
        setIsFixedChecked(true);
      }
      if (variable.valueState.indexOf("D") !== -1) {
        setIsDynamicChecked(true);
      }
      if (variable.valueState.indexOf("M") !== -1) {
        setIsMaskedChecked(true);
      }
      if (variable.valueState.indexOf("I") !== -1) {
        setType(makeFieldInputs((type.value = "I")));
      }
      if (variable.valueState.indexOf("O") !== -1) {
        setType(makeFieldInputs((type.value = "O")));
      }
      setIsEditingVar(variable);
      setIsCreateVariable(false);
    }
  };
  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    handleClose();
  };

  const onClick2Header = () => {
    setIsCreateVariable(true);
    setIsEditingVar(false);
    setImportMDMVariable(false);
    setCreateVariableObject([
      ...createVariableObject,
      {
        variableName: makeFieldInputs(""),
        variableDefaultValue: "",
        variableType: makeFieldInputs(""),
        type: makeFieldInputs(""),
        isDynamicChecked: false,
        isFixedChecked: false,
      },
    ]);
  };
  const handleSelectedInputVariables = (arrOfSelectedItems) => {
    setSelectedVariables(arrOfSelectedItems);
  };
  const onClickImportMDMCategories = () => {
    setImportMDMVariable(true);
    setCreateVariableObject([
      ...createVariableObject,
      {
        variableName: makeFieldInputs(""),
        categoryName: makeFieldInputs(""),
        variableDefaultValue: "",
        variableType: makeFieldInputs(""),
        type: makeFieldInputs(""),
        isDynamicChecked: false,
        isFixedChecked: false,
      },
    ]);
  };
  const handleSearchChange = (searchText) => {
    if (searchText) {
      const newVars = allVariablesOrg.filter((variable) => {
        if (
          variable.variableName.toLowerCase().includes(searchText.toLowerCase())
        ) {
          return variable;
        }
      });
      setAllVariables(newVars);
    } else {
      setAllVariables(allVariablesOrg);
    }
  };

  const handleSort = () => {
    if (sortType === "Asc") {
      setSortType("Desc");
    } else if (sortType === "Desc") {
      setSortType("Asc");
    }
  };
  const handleSortByName = (a, b) => {
    if (sortType === "Asc") {
      return a.variableName.localeCompare(b.variableName);
    } else if (sortType === "Desc") {
      return b.variableName.localeCompare(a.variableName);
    }
  };

  const openFilterMenu = Boolean(anchorEl);
  const openMenu = Boolean(menu);
  const idFilterMenu = openFilterMenu ? "simple-popover" : undefined;
  const handleTabChange = (tabItem) => {
    console.log(tabItem, "tabItemmmm");
    setSelTab(tabItem);
  };
  const handleMenuClick = (event) => {
    setMenu(event.currentTarget);
  };

  const handleMenuClose = () => {
    setMenu(null);
  };

  const handleActionsMenuClick = (event, variable) => {
    setActionMenu(event.currentTarget);
    setVariableData(variable, type.value);
  };
  const handleActionsMenuClose = () => {
    setActionMenu(null);
  };

  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={t("Variables")}
      selTab={selTab}
      Content={
        <Content
          id={props.id}
          isLoading={isLoading}
          handleChange={handleChange}
          handleDelete={handleDelete}
          ref={varFieldRef}
          handleEdit={handleEdit}
          allVariables={allVariables}
          allVariablesOrg={allVariablesOrg}
          isCreateVariable={isCreateVariable}
          isEditingVar={isEditingVar}
          variableType={variableType}
          variableName={variableName}
          globalCategoryName={globalCategoryName}
          variableDefaultValue={variableDefaultValue}
          onCreate={onCreate}
          onCancel={onCancel}
          isFixedChecked={isFixedChecked}
          isDynamicChecked={isDynamicChecked}
          isMaskChecked={isMaskChecked}
          isInputChecked={isInputChecked}
          isOutputChecked={isOutputChecked}
          formHasError={formHasError}
          handleSortByName={handleSortByName}
          handleSort={handleSort}
          sortType={sortType}
          onClick2Header={onClick2Header}
          onClickImportMDMCategories={onClickImportMDMCategories}
          handleSearchChange={handleSearchChange}
          expandedVars={expandedVars}
          expandVar={expandVar}
          handleChangeFilters={handleChangeFilters}
          handleCloseFilter={handleCloseFilter}
          idFilterMenu={idFilterMenu}
          openFilterMenu={openFilterMenu}
          filterByType={filterByType}
          filterByOther={filterByOther}
          anchorEl={anchorEl}
          handleClickOpen={handleClickOpen}
          isProcessing={isProcessing}
          selectedRow={selectedRow}
          handleMenuClick={handleMenuClick}
          handleMenuClose={handleMenuClose}
          menu={menu}
          handleActionsMenuClick={handleActionsMenuClick}
          handleActionsMenuClose={handleActionsMenuClose}
          actionMenu={actionMenu}
          variableData={variableData}
          setVariableData={setVariableData}
          selTab={selTab}
          getAllCategories={getAllCategories}
          applicationDetails={applicationDetails}
          fetchDataObjects={fetchDataObjects}
          importMDMVariable={importMDMVariable}
          categories={categories}
          selectedVariables={selectedVariables}
          handleSelectedInputVariables={handleSelectedInputVariables}
          subVariables={subVariables}
          fetchVariablesOfDataObjects={fetchVariablesOfDataObjects}
          subList={subList}
          handleSelect={handleSelect}
          variableDataValue={variableDataValue}
          setVariableDataValue={setVariableDataValue}
          dataObjectMDM={dataObjectMDM}
          setDataObjectMDM={setDataObjectMDM}
          handleTabChange={handleTabChange}
          type={type}
          createVariableObject={createVariableObject}
          setCreateVariableObject={setCreateVariableObject}
          mdmFlag={mdmFlag}
          setMdmFlag={setMdmFlag}
        />
      }
      btn1Title={t("Close")}
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      onClick1={onClick1}
      closeModal={handleClose}
      containerHeight={550}
      containerWidth={1085}
      overflowHidden
    />
  );
};
export default VariableListModal;

{
  /* content of the modal */
}
const useStyles = makeStyles((theme) => ({
  focusVisible: {
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  header: {
    paddingTop: "2vh",
    paddingBottom: "2vh",
    paddingLeft: "1vh",
    // paddingRight: "1vh",

    // marginBottom: "1vh",
    // marginTop: "2vh",
    backgroundColor: "#F0F0F0",
  },
  varRow: {
    // paddingLeft: "26px",
    paddingTop: "1vh",
    paddingBottom: "1vh",
    // height: "40px",
    //marginBottom: "12px",
    backgroundColor: "#FFFFFF",
    // paddingRight: "26px",
    paddingLeft: "1vh",
    // paddingRight: "1vh",
    borderRight: "1px Solid #D3D3D3",
    borderLeft: "1px Solid #D3D3D3",
    //transition: "all 100ms ease-in",
    borderBottom: "1px solid #F0F0F0",

    "&:hover": {
      boxShadow: "0px 3px 6px #00000029",
    },
  },
  varRowEdit: {
    paddingLeft: "1vh",
    paddingTop: "1vh",
    paddingBottom: "2vh",
    // marginTop: "1vh",
    // marginBottom: "3vh",
    // minHeight: "40px",
    // marginBottom: "8px",
    // marginTop: "8px",
    backgroundColor: "#FFFFFF",
    // paddingRight: "26px",
    borderRight: "1px Solid #D3D3D3",
    borderLeft: "1px Solid #D3D3D3",
    //transition: "all 100ms ease-in",
    borderBottom: "1px solid #F0F0F0",
    "&:hover": {
      boxShadow: "0px 3px 6px #00000029",
    },
  },
  sortIcon: { width: "16px", height: "16px" },

  sticky: {
    position: "fixed",

    width: "100%",
    paddingTop: "100px",
  },
  item: {
    // paddingTop: "10px",
    // paddingBottom: "10px",
    fontSize: "12px",
  },

  item2: {
    // paddingTop: "5px",
    // paddingBottom: "5px",
    fontSize: "12px",
  },
  fontBold: {
    color: "#000000",
    fontWeight: 600,
    fontSize: "12px",
  },
  editIcon: {
    height: "16px",
    width: "16px",
    filter: `${getCssFilterFromHex("#0072C6")}`,
    "&:focus-visible": {
      filter: `${getCssFilterFromHex(`${theme.palette.tabFocus.mainColor}`)}`,
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
    cursor: "pointer",
  },
  deleteBtn: {
    height: "16px",
    width: "16px",
    filter: `${getCssFilterFromHex("#D42323")}`,
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
    cursor: "pointer",
  },
  verticalLine: {
    height: "27px",
    width: "1px",
    backgroundColor: "#0072C6",
  },
  addVarBtn: {
    position: "relative",
    width: "auto",
    minWidth: "50px",
    gap: "8px",
    border: "1px solid #0072C6",
    height: "28px",
    paddingRight: "8px",
    paddingLeft: "8px",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
  },
  dropDownBtn: {
    height: "7px",
    width: "12px",
    cursor: "pointer",
  },
  // variableMenu:{
  //   height:"60px",
  //   width:"127px",
  //   padding:"2px",
  //   border:"1px solid #E7E7E7",
  //   radius:"2px",
  //   boxShadow:"0px 3px 6px 0px #00000029",

  // },
  scrollDiv: {
    height: "370px",
    width: "100%",
    "&:hover": {
      overflowX: "hidden",
      overflowY: "auto",
    },
  },
  sort: {
    //height: "28px",
    padding: "5px",
    borderRadius: "2px",
    background: "#FFFFFF 0% 0% no-repeat padding-box",
    border: "1px solid #C4C4C4",
    cursor: "pointer",
  },

  icon: {
    width: "12px",
    height: "10px",
    //marginTop: "6px",
  },
  rotatedIcon: {
    width: "12px",
    height: "10px",
    marginTop: "6px",
    transform: "rotate(180deg)",
  },
  tools: {
    marginTop: "16px",
  },
  focusPrimary: {
    "&:focus": {
      background: `${getCssRgbFromHexByDiff(`${theme.palette.primary.main}`)}`,
    },
  },
  focusSecondary: {
    "&:focus": {
      //filter: "brightness(0.9)",
      background: `${getRgbafromHex(`${theme.palette.primary.main}`, 0.04)}`,
    },
  },
  focusTertiary: {
    "&:hover": {
      backgroundColor: "#F8F8F8",
    },
    "&:focus-visible": {
      background: `#F8F8F8`,
      outline: `1px solid ${theme.palette.tabFocus.mainColor}`,
    },
  },
  margin: {
    margin: `${theme.spacing(1)}`,
  },
  expandIcon: {
    // marginTop: "16px",
    cursor: "pointer",
  },
  typography: {
    padding: theme.spacing(2),
  },
  header1: {
    fontSize: "14px",
    fontWeight: 600,
    color: "#3D3D3D",
  },
  content: {
    marginTop: "12px",
    paddingBottom: "4px",
    paddingTop: "4px",
    height: "250px",

    "&:hover": {
      overflowY: "auto",
    },
    overflowX: "hidden",
  },
  subHeader: {
    fontSize: "12px",

    paddingLeft: "16px",
    fontWeight: 600,
  },
  closeIcon: {
    height: "12px",
    width: "12px",
  },
  clearBtn: {
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
  },
  tableContainer: {
    //overflow: "hidden",
    position: "relative",
    maxWidth: "100%",
    height: "62vh",
    overflowY:'scroll'
    // [theme.breakpoints.down("md")]: {
    //   height: "35vh",
    // },
    // [theme.breakpoints.down("sm")]: {
    //   height: "25vh",
    // },
    // [theme.breakpoints.down('xs')]: {
    //   height: "10vh",

    // },
  },
  // table:{
  //   tableLayout:"auto",
  //   width:"100%",
  //   borderCollapse:"collapse",
  //   whiteSpace:"nowrap"
  // },
  tableHeader: {
    border: "1px solid #C4C4C4",
    borderBottom: "none",
    marginTop: "1rem",
    position: "sticky",
    borderRadius: "2px",
    top: "0",
    zIndex: 1,
    width: "100%",
    display: "table",
    tableLayout: "fixed",
    [theme.breakpoints.down("md")]: {
      fontSize: "12px",
    },
    [theme.breakpoints.down("sm")]: {
      fontSize: "8px",
    },
    // [theme.breakpoints.down('xs')]: {
    //   fontSize: "6px",
    // },
  },
  // tableCell: {
  //   overflow: "hidden",
  //   textOverflow: "ellipsis",
  //   padding: "8px",
  //   border: "1px solid #C4C4C4",
  //   width:"150px"
  // },
  variableDataDiv: {
    tableLayout: "fixed",
    borderCollapse: "collapse",
    overflowY: "scroll",
    width: "101%",
    height: "calc(100% - 1rem)",
    //border:"3px solid red"
  },
}));

const Content = React.forwardRef((props, ref) => {
  const {
    id,
    handleChange,
    allVariables,
    handleSortByName,
    allVariablesOrg,
    variableName,
    globalCategoryName,
    handleSelect,
    isCreateVariable,
    isEditingVar,
    variableType,
    type,
    variableDefaultValue,
    onCreate,
    onCancel,
    isDynamicChecked,
    isFixedChecked,
    isInputChecked,
    isOutputChecked,
    isMaskChecked,
    handleDelete,
    handleEdit,
    isLoading,
    formHasError,
    sortType,
    handleSort,
    handleSearchChange,
    onClick2Header,
    onClickImportMDMCategories,
    expandedVars,
    expandVar,
    idFilterMenu,
    handleChangeFilters,
    handleCloseFilter,
    openFilterMenu,
    filterByOther,
    filterByType,
    anchorEl,
    menu,
    handleMenuClick,
    handleMenuClose,
    handleClickOpen,
    isProcessing,
    selectedRow,
    backgroundColor,
    handleActionsMenuClick,
    handleActionsMenuClose,
    actionMenu,
    variableData,
    setVariableData,
    selTab,
    getAllCategories,
    getPortalVariables,
    getProcessVariables,
    applicationDetails,
    importMDMVariable,
    setImportMDMVariable,
    categories,
    selectedVariables,
    fetchDataObjects,
    handleSelectedInputVariables,
    subVariables,
    fetchVariablesOfDataObjects,
    subList,
    variableDataValue,
    setVariableDataValue,
    dataObjectMDM,
    setDataObjectMDM,
    handleTabChange,
    createVariableObject,
    setCreateVariableObject,
    mdmFlag,
    setMdmFlag,
  } = props;

  const classes = useStyles();
  const { t } = useTranslation();
  const getTotalFilters = () => {
    const filteredTypes = filterByType.filter((item) => item.value);

    const filteredTypesOther = filterByOther.filter((item) => item.value);
    return filteredTypes.length + filteredTypesOther.length || "0";
  };

  const filteredVariables =
    allVariables?.length > 0
      ? allVariables.filter((variable) => {
          if (selTab === "All") return true;
          if (selTab === "Input") return variable.valueState?.[0] === "I";
          if (selTab === "Output") return variable.valueState?.[0] === "O";
          return false;
        })
      : [];

  const getType = (type) => {
    let variableType = null;
    switch (type) {
      case 2:
        variableType = "Integer";
        break;
      case 1:
        variableType = "Text";
        break;
      case 8:
        variableType = "Float";
        break;
      case 4:
        variableType = "Date";
        break;
      case 3:
        variableType = "Boolean";
        break;
      case 5:
        variableType = "List";
        break;
      case 7:
        variableType = "DataRecord";
        break;
      case 6:
        variableType = "DataTable";
        break;
      case 9:
        variableType = "DateTime";
        break;
      case 10:
        variableType = "MailMessage";
        break;
      case 11:
        variableType = "JSONObject";
        break;
      case 12:
        variableType = "JSONArray";
        break;
      default:
        break;
    }
    return variableType;
  };

  const truncateString = (str) => {
    if (str) {
      // return str.trim().length > 38 ? str.substring(0, 34) + ".." : str;
      return str.trim().length > 20 ? str.substring(0, 16) + ".." : str;
    }
    return "";
  };

  if (isLoading) {
    return <LoadingIndicator />;
  }
  return (
    <Grid>
      <Grid container spacing={1} alignItems="center">
        <Grid item>
          <SearchBox
            id={`${id}_SearchBox`}
            width="230px"
            height="28px"
            onSearchChange={handleSearchChange}
            placeholder={t("Search by Name")}
          />
        </Grid>
        <Grid item>
          <Badge
            id={`${id}_Badge`}
            badgeContent={getTotalFilters()}
            color="primary"
            className={classes.focusVisible}
            tabIndex={0}
            onKeyDown={(e) => e.key === "Enter" && handleClickOpen(e)}
            role="button"
          >
            <Typography className={classes.sort}>
              <FilterIcon
                className={classes.sortIcon}
                onClick={(e) => handleClickOpen(e)}
                id={`${id}_FilterIcon`}
              />
            </Typography>
          </Badge>
        </Grid>
        <Grid item>
          <TabsButton
            tabItems={["All", "Input", "Output", "Transient"]}
            selectedTab={selTab}
            handleTabChange={handleTabChange}
            id="example-tabs"
          />
        </Grid>
        <Grid item xs>
          <Grid container justifyContent={"flex-end"}>
            <Grid item>
              <LoadingButton
                title={t("Add Variable")}
                onClick={() => props.onClick2Header()}
                btnType={
                  allVariablesOrg.length != 0
                    ? "BUTTON-OUTLINED"
                    : "BUTTON-FILLED"
                }
                disabled={props.isCreateVariable}
              />
            </Grid>
            <Grid
              item
              sx={{
                marginLeft: "-2px",
                background: allVariablesOrg.length != 0 ? "#FFFFFF" : "#0072C6",
                color: "#0072C6",
                borderWidth: "1px 1px 1px 0px",
                borderColor: "#0072C6",
                borderStyle: "solid",
                borderLeft: "3px Solid white",
                opacity: 1,
                borderBottomRightRadius: 0.5,
                borderTopRightRadius: 0.5,
                fontSize: 12,
                height: 28,
                "&.focus-visible": {
                  background: "#FFFFFF",
                  color: "#0072C6",
                  fontWeight: 600,
                },
              }}
            >
              <IconButton
                color="primary"
                aria-label="Add Variable MDM"
                onClick={(e) => {
                  e.stopPropagation();
                  handleMenuClick(e);
                }}
              >
                {allVariablesOrg.length == 0 ? (
                  <DropDownArrowIcon />
                ) : (
                  <DropDownVariableOption />
                )}
              </IconButton>
            </Grid>
          </Grid>
        </Grid>

        <Menu
          anchorEl={menu}
          open={Boolean(menu)}
          onClose={handleMenuClose}
          anchorOrigin={{
            vertical: "bottom",
            horizontal: "right",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
          MenuListProps={{
            "aria-labelledby": "add-variable-dropdown",
            style: { padding: "0px" },
          }}
          sx={{
            "& .MuiPaper-root": {
              // Styles for the Menu container
              height: "60px",
              width: "129px",

              padding: "2px",
              border: "1px solid #E7E7E7",
              borderRadius: "2px",
              overflow: "none",
              boxShadow: "0px 3px 6px 0px #00000029",
              // marginTop: "12px",
            },
          }}
        >
          <MenuItem
            sx={{
              fontFamily: "Open Sans",
              fontSize: "12px",
              fontWeight: 400,
              color: "#000000",
              height: "28px",
            }}
            onClick={() => {
              getAllCategories();
              props.onClickImportMDMCategories();
              handleMenuClose();
            }}
          >
            Import from MDM
          </MenuItem>
          <MenuItem
            onClick={() => {
              props.onClick2Header();
              handleMenuClose();
            }}
            sx={{
              fontFamily: "Open Sans",
              fontSize: "12px",
              fontWeight: 400,
              color: "#000000",
              height: "28px",
            }}
          >
            Create New
          </MenuItem>
        </Menu>
      </Grid>
      <FilterPopover
        id={idFilterMenu}
        handleClose={handleCloseFilter}
        open={openFilterMenu}
        filterByType={filterByType}
        filterByOther={filterByOther}
        handleChangeFilters={handleChangeFilters}
        anchorEl={anchorEl}
      />
      <Grid item className={classes.tableContainer}>
        <Grid className={classes.tableHeader}>
          <TableHead
            isCreateVariable={isCreateVariable}
            isEditingVar={isEditingVar}
            id={id}
            onClick2Header={onClick2Header}
            onClickImportMDMCategories={onClickImportMDMCategories}
          />
        </Grid>
        <Grid>
          {
            (isCreateVariable || importMDMVariable) &&
              createVariableObject.map((item, index) => {
                return (
                  <Grid container>
                    <TableEditableItem
                      onCancel={onCancel}
                      fields={item}
                      typeOptions={typeOptions}
                      optionType={optionType}
                      onCreate={onCreate}
                      handleChange={handleChange}
                      isFixedChecked={item.isFixedChecked}
                      isDynamicChecked={item.isDynamicChecked}
                      //isInputChecked={isInputChecked}
                      //isOutputChecked={isOutputChecked}
                      isEditingVar={isEditingVar}
                      isProcessing={isProcessing}
                      selectedRow={selectedRow}
                      formHasError={formHasError}
                      //id={id}
                      id={index} //Object index
                      handleActionsMenuClick={handleActionsMenuClick}
                      handleActionsMenuClose={handleActionsMenuClose}
                      actionMenu={actionMenu}
                      variableData={variableData}
                      setVariableData={setVariableData}
                      getAllCategories={getAllCategories}
                      applicationDetails={applicationDetails}
                      getPortalVariables={getPortalVariables}
                      getProcessVariables={getProcessVariables}
                      importMDMVariable={importMDMVariable}
                      selectedVariables={selectedVariables}
                      fetchDataObjects={fetchDataObjects}
                      categories={categories}
                      handleSelectedInputVariables={
                        handleSelectedInputVariables
                      }
                      subVariables={subVariables}
                      fetchVariablesOfDataObjects={fetchVariablesOfDataObjects}
                      subList={subList}
                      handleSelect={handleSelect}
                      variableDataValue={variableDataValue}
                      setVariableDataValue={setVariableDataValue}
                      dataObjectMDM={dataObjectMDM}
                      setDataObjectMDM={setDataObjectMDM}
                      setCreateVariableObject={setCreateVariableObject}
                      mdmFlag={mdmFlag}
                      globalCategoryName={globalCategoryName}
                      setMdmFlag={setMdmFlag}
                    />
                  </Grid>
                );
              })
            // here
          }

          {allVariablesOrg.length > 0 ? (
            <>
              {filteredVariables.length > 0 ? (
                <Grid container>
                  {filteredVariables.map((variable, index) =>
                    isEditingVar &&
                    isEditingVar.variableId === variable.variableId ? (
                      <TableEditableItem
                        onCancel={onCancel}
                        fields={{
                          variableName,
                          variableType,
                          variableDefaultValue,
                          type,
                          globalCategoryName,
                        }}
                        typeOptions={typeOptions}
                        optionType={optionType}
                        onCreate={onCreate}
                        handleChange={handleChange}
                        isFixedChecked={isFixedChecked}
                        isDynamicChecked={isDynamicChecked}
                        isInputChecked={isInputChecked}
                        isOutputChecked={isOutputChecked}
                        isEditingVar={isEditingVar}
                        isProcessing={isProcessing}
                        selectedRow={selectedRow}
                        formHasError={formHasError}
                        id={id}
                        handleActionsMenuClick={handleActionsMenuClick}
                        handleActionsMenuClose={handleActionsMenuClose}
                        actionMenu={actionMenu}
                        variableData={variableData}
                        setVariableData={setVariableData}
                        getAllCategories={getAllCategories}
                        applicationDetails={applicationDetails}
                        getPortalVariables={getPortalVariables}
                        getProcessVariables={getProcessVariables}
                        fetchDataObjects={fetchDataObjects}
                        handleSelectedInputVariables={
                          handleSelectedInputVariables
                        }
                        categories={categories}
                        subVariables={subVariables}
                        subList={subList}
                        fetchVariablesOfDataObjects={
                          fetchVariablesOfDataObjects
                        }
                        handleSelect={handleSelect}
                        variableDataValue={variableDataValue}
                        setVariableDataValue={setVariableDataValue}
                        dataObjectMDM={dataObjectMDM}
                        setDataObjectMDM={setDataObjectMDM}
                        mdmFlag={mdmFlag}
                        setMdmFlag={setMdmFlag}
                      />
                    ) : (
                      // here

                      <TableItem
                        variableObj={variable}
                        truncateString={truncateString}
                        getType={getType}
                        expandedVars={expandedVars}
                        expandVar={expandVar}
                        handleEdit={handleEdit}
                        handleDelete={handleDelete}
                        id={id}
                        handleActionsMenuClick={handleActionsMenuClick}
                        handleActionsMenuClose={handleActionsMenuClose}
                        actionMenu={actionMenu}
                        variableData={variableData}
                        setVariableData={setVariableData}
                        selTab={selTab}
                        getAllCategories={getAllCategories}
                        applicationDetails={applicationDetails}
                        getPortalVariables={getPortalVariables}
                        getProcessVariables={getProcessVariables}
                        fetchDataObjects={fetchDataObjects}
                        categories={categories}
                        subVariables={subVariables}
                        subList={subList}
                        fetchVariablesOfDataObjects={
                          fetchVariablesOfDataObjects
                        }
                        importMDMVariable={importMDMVariable}
                        variableDataValue={variableDataValue}
                        setVariableDataValue={setVariableDataValue}
                        dataObjectMDM={dataObjectMDM}
                        setDataObjectMDM={setDataObjectMDM}
                        mdmFlag={mdmFlag}
                        setMdmFlag={setMdmFlag}
                      />
                    )
                  )}
                </Grid>
              ) : (
                // <div>
                //   <Typography style={{ fontSize: "12px" }}>
                //     {t("No variable found based on the search")}
                //   </Typography>
                // </div>
                <Grid container alignItems={"center"} justifyContent={"center"}>
                  <NoVariableFoundIcon size={100} />
                </Grid>
              )}
            </>
          ) : (
            // <div style={{ margin: "16px" }}>
            //   <Typography style={{ fontSize: "12px" }}>
            //     {t("There are no variables created yet.")}
            //   </Typography>
            // </div>
            <Grid container alignItems={"center"} justifyContent={"center"}>
              <NoVariableIcon size={100} />
            </Grid>
          )}
        </Grid>
      </Grid>
    </Grid>
  );
});

// TableHead
const TableHead = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  return (
    // <div className={classes.header}>
    <Grid
      container
      //spacing={1}
      //justifyContent={"space-evenly"}
      className={classes.header}
    >
      <Grid item xs={6}>
        <Grid container spacing={1}>
          <Grid item sx={{ display: "flex", gap: 2 }}>
            <AddVaribaleIcon />
            <Typography
              // className={classes.item2 + " " + classes.fontBold}
              className={`${classes.fontBold} ${classes.tableCell}`}
              //  onClick={() => handleSort()}
              style={{ cursor: "pointer", paddingLeft: 5 }}
            >
              {t("Name")}
            </Typography>
          </Grid>

          <Grid item>
            <Typography
              className={classes.tableCell}
              // onClick={() => handleSort()}
            >
              <UniqueIDGenerator>
                <ForwardTailRightIcon className={classes.icon} />
              </UniqueIDGenerator>
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs>
        <Typography className={`${classes.fontBold} ${classes.tableCell}`}>
          Type
        </Typography>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent="flex-start">
          <Grid item>
            <Typography className={`${classes.fontBold} ${classes.tableCell}`}>
              {t("Data Type")}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent="center">
          <Grid item>
            <Typography
              className={`${classes.fontBold} ${classes.tableCell}`}
              style={{ marginLeft: "-10px" }}
            >
              {t("Fixed")}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent="center">
          <Grid item>
            <Typography
              className={`${classes.fontBold} ${classes.tableCell}`}
              //  className={classes.item2 + " " + classes.fontBold}
              // style={{ marginLeft: "-12px" }}
            >
              {t("Dynamic")}
            </Typography>
          </Grid>
        </Grid>
      </Grid>

      <Grid item xs>
        <Typography
          className={`${classes.fontBold} ${classes.tableCell}`}
          //  className={classes.item2 + " " + classes.fontBold}
          // style={{ marginLeft: "-20px" }}
        >
          {t("Default Value")}
        </Typography>
      </Grid>
      {/* {(!props.isCreateVariable && !props.isEditingVar)&& ( */}
      <Grid item xs>
        <Grid
          container
          justifyContent={"flex-end"}
          sx={{ paddingRight: "10px" }}
        >
          <Grid item>
            <Typography className={`${classes.fontBold} ${classes.tableCell}`}>
              Actions
            </Typography>
          </Grid>
        </Grid>
        {/* <Button
            variant="contained"
            size="small"
            color="primary"
            onClick={() => props.onClick2Header()}
            style={{ height: "28px" }}
            disableRipple
            // className={classes.focusPrimary}
            id={`${props.id}_AddVariableBtn`}
          >
            {t("+Variable")}
          </Button> */}
      </Grid>
      {/* )} */}
    </Grid>
    // </div>
  );
};

const TableEditableItem = (props) => {
  console.log(props, "TableEdiatbleItem");
  const classes = useStyles();
  const { t } = useTranslation();

  const { selectedVariables, id } = props;
  const item = props.fields;
  const [categoryOptions, setCategoriesOptions] = useState([]);

  useEffect(() => {
    setCategoriesOptions(
      props.categories?.map((item) => ({
        name: item.categoryDisplayName,
        value: item.categoryId,
      }))
    );
  }, [props.categories]);

  const isMultilineDesc = () => {
    return (
      +item.variableType.value === 5 ||
      +item.variableType.value === 6 ||
      +item.variableType.value === 7 ||
      +item.variableType.value === 11 ||
      +item.variableType.value === 12
    );
  };
  return (
    <Grid container direction="row" className={classes.varRowEdit}>
      <Grid item xs={6}>
        <Grid container direction="row" spacing={1}>
          <Grid item sx={{ display: "flex", gap: 2, alignItems: "center" }}>
            <AddVaribaleIcon />
            {props.importMDMVariable ? (
              <Field
                id={`${id}_categoryName`}
                placeholder={"Select Catagory"}
                name="globalCategoryName"
                value={props.globalCategoryName.value}
                {...props.globalCategoryName}
                onChange={(e) => {
                  props.handleChange(e, id);
                  props.fetchDataObjects(props.categories, e);
                }}
                paddingTop={"0.1vh"}
                dropdown={true}
                width={"135px"}
                options={categoryOptions}
                readOnly={props.mdmFlag}
              />
            ) : (
              <Field
                id={`${id}_variableName`}
                placeholder={"Type Variable Name"}
                name="variableName"
                value={item.variableName.value}
                {...item.variableName}
                onChange={(e) => {
                  props.handleChange(e, id);
                }}
                paddingTop={"0.1vh"}
                width={"400px"}
              />
            )}
          </Grid>

          {props.importMDMVariable && !props.mdmFlag ? (
            <Grid item xs>
              <NestedSelect
                {...item.variableName}
                placeholder="Select Data Object"
                onSelectionChange={(e) =>
                  props.handleSelect(e[0], props.subList)
                }
                fetchObjectsMDM={(index, dataObjectId) =>
                  props.fetchVariablesOfDataObjects(
                    props.subVariables.filter(
                      (item) => item.dataObjectId === dataObjectId
                    )
                  )
                }
                subList={props.subList}
                subVariables={props.subVariables}
                setCreateVariableObject={props.setCreateVariableObject}
                globalCategoryName={props.globalCategoryName}
                setMdmFlag={props.setMdmFlag}
                typeOptions={typeOptions}
              />
            </Grid>
          ) : props.importMDMVariable && props.mdmFlag ? (
            <Grid item >
              <Field
                id={`${id}_variableName`}
                placeholder={"Type Variable Name"}
                name="variableName"
                value={item.variableName.value}
                {...item.variableName}
                // onChange={(e) => {
                //   props.handleChange(e, id);
                // }}
                readOnly={true}
                paddingTop={"0.1vh"}
                width={"300px"}
              />
            </Grid>
          ) : (
            <></>
          )}
        </Grid>
      </Grid>

      <Grid item xs>
        <Grid container justifyContent={"flex-start"}>
          <Grid item>
            <Field
              id={`${id}_type`}
              name="type"
              placeholder="Select Type"
              value={item.type.value}
              {...item.type}
              //readOnly={props.importMDMVariable}
              dropdown={true}
              options={
                props.importMDMVariable
                  ? optionType.filter((type) => type.value != "T")
                  : optionType
              }
              onChange={(e) => props.handleChange(e, id)}
              variant="standard"
              paddingTop={"0.1vh"}
              width={80}
            />
          </Grid>
        </Grid>
      </Grid>

      <Grid item xs>
        <Grid container justifyContent={"flex-start"}>
          <Grid item>
            <Field
              id={`${id}_variableType`}
              name="variableType"
              placeholder="Select Type"
              value={item.variableType.value}
              {...item.variableType}
              dropdown={true}
              options={typeOptions}
              readOnly={props.mdmFlag}
              onChange={(e) => props.handleChange(e, id)}
              variant="standard"
              paddingTop={"0.1vh"}
              width={90}
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent={"center"}>
          <Grid item>
            <CheckboxField
              id={`${id}_Fixed`}
              value={item.isFixedChecked}
              onChange={(e) => props.handleChange(e, id)}
              name="fixed"
              disabled={item.isDynamicChecked}
              styleObj={{ paddingTop: "10px" }}
            />
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent={"center"}>
          <Grid item>
            <CheckboxField
              id={`${id}_Dynamic`}
              value={item.isDynamicChecked}
              onChange={(e) => props.handleChange(e, id)}
              name="dynamic"
              disabled={item.isFixedChecked}
              styleObj={{ paddingTop: "10px" }}
            />
          </Grid>
        </Grid>
      </Grid>

      <Grid item xs>
        <Field
          id={`${id}_DefaultVal`}
          paddingTop={"0.1vh"}
          type={
            +item.variableType.value === 4
              ? "date"
              : +item.variableType.value === 9
              ? "datetime-local"
              : "text"
          }
          multiline={isMultilineDesc()}
          name="variableDefaultValue"
          //readOnly={props.importMDMVariable}
          value={item.variableDefaultValue}
          onChange={(e) => props.handleChange(e, id)}
          placeholder="e.g. 1234"
          helperText={
            +item.variableType.value === 5
              ? "Write `,` Separated Values."
              : null
          }
          width={70}
        />
      </Grid>
      <Grid item xs>
        <Grid
          container
          direction="row"
          justifyContent="flex-end"
          //alignItems={"flex-end"}
          sx={{ marginTop: isMultilineDesc() ? "0px" : "" }}
        >
          <Grid item>
            {props.isProcessing && props.selectedRow == id ? (
              <Button
                variant="outlined"
                size="small"
                color="primary"
                style={{
                  fontWeight: 600,
                  height: 25,
                  marginTop: "0.8vh",
                }}
                disableRipple
                id={`${id}_${props.isEditingVar ? "Update" : "Add"}_Btn`}
              >
                <CircularProgress
                  // color="#FFFFFF"
                  style={{
                    height: "15px",
                    width: "15px",
                    marginRight: "0.1vh",
                    color: "#FFFFFF",
                  }}
                ></CircularProgress>

                {props.isEditingVar ? "Update" : "Add"}
              </Button>
            ) : (
              <Button
                variant="outlined"
                size="small"
                color="primary"
                onClick={() => props.onCreate(item, id)}
                style={{
                  fontWeight: 600,
                  height: 25,
                  marginTop: "0.8vh",
                }}
                disabled={props.formHasError}
                disableTouchRipple
                disableRipple
                id={`${id}_${props.isEditingVar ? "Update" : "Add"}_Btn`}
              >
                {t(props.isEditingVar ? "Update" : "Add")}
              </Button>
            )}
          </Grid>
          <Grid item tabIndex={-1}>
            <IconButton
              aria-label="Delete Action"
              onClick={() => props.onCancel(item, id)}
              id={`${id}_CancelBtn`}
            >
              <DeleteAction />
            </IconButton>
          </Grid>
        </Grid>
      </Grid>
    </Grid>
  );
};
// here
const TableItem = (props) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const variable = props.variableObj;
  const {
    handleActionsMenuClick,
    handleActionsMenuClose,
    actionMenu,
    importMDMVariable,
  } = props;
  return (
    <Grid
      item
      container
      direction="row"
      //justifyContent={"space-evenly"}
      key={variable.variableName}
      className={classes.varRow}
      //spacing={1}
      // style={{ minWidth: "960px" }}
    >
      <Grid
        item
        xs={6}
        title={variable.variableName || ""}
        sx={{ display: "flex", gap: 2 }}
      >
        <VariableIcon />
        <Typography className={classes.item}>
          {variable.variableName}
        </Typography>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent={"flex-start"}>
          <Grid item>
            <Typography>
              {variable.valueState && variable.valueState.indexOf("I") !== -1
                ? "Input"
                : "Output"}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent={"flex-start"}>
          <Grid item>
            <Typography>{props.getType(variable.variableObjType)}</Typography>
          </Grid>
        </Grid>
      </Grid>
      {/* </Grid> */}
      <Grid item xs>
        <Grid container justifyContent={"center"}>
          <Grid item>
            {variable.valueState && variable.valueState.indexOf("F") !== -1 ? (
              <CheckboxField value={true} />
            ) : (
              <CheckboxField disabled />
            )}
          </Grid>
        </Grid>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent={"center"}>
          <Grid item>
            {variable.valueState && variable.valueState.indexOf("D") !== -1 ? (
              <CheckboxField value={true} />
            ) : (
              <CheckboxField disabled />
            )}
          </Grid>
        </Grid>
      </Grid>
      {/* <Grid item xs={1}>
        {variable.valueState && variable.valueState.indexOf("I") !== -1 && (
          <Check htmlColor="#0072C6" />
        )}
      </Grid>
      <Grid item xs={1}>
        {variable.valueState && variable.valueState.indexOf("O") !== -1 && (
          <Check htmlColor="#0072C6" />
        )}
      </Grid> */}
      <Grid
        item
        xs
        title={variable.varDefaultValue || ""}
        // style={{ position: "relative" }}
      >
        <Grid container spacing={1}>
          {props.expandedVars.includes(variable.variableId) ? (
            <Grid
              item
              style={{
                //   zIndex: 1,
                //  position: "absolute",
                backgroundColor: "#FFFFFF",
                //  marginTop: "-8px",
              }}
            >
              <Typography>
                <pre>{variable.varDefaultValue}</pre>
              </Typography>
            </Grid>
          ) : (
            <Grid item>
              <Typography className={classes.item}>
                {props.truncateString(variable.varDefaultValue || "")}
              </Typography>
            </Grid>
          )}
          {variable.varDefaultValue &&
            [5, 6, 7, 11, 12].includes(variable.variableObjType) && (
              <Grid
                item
                style={{
                  zIndex: props.expandedVars.includes(variable.variableId)
                    ? 5
                    : 1,
                  marginLeft: props.expandedVars.includes(variable.variableId)
                    ? "-10px"
                    : "0px",
                  marginTop: props.expandedVars.includes(variable.variableId)
                    ? "-8px"
                    : "0px",
                }}
              >
                <ExpandDataIcon
                  className={classes.expandIcon}
                  onClick={() => props.expandVar(variable.variableId)}
                />
              </Grid>
            )}
        </Grid>
      </Grid>
      <Grid item xs>
        <Grid container justifyContent={"flex-end"}>
          <IconButton
            aria-label="More Options"
            onClick={(e) => {
              e.stopPropagation();
              handleActionsMenuClick(e, variable);
            }}
            id={`${props.id}_${variable.variableId}_MoreOptions`}
          >
            <ActionsMenu />
          </IconButton>
          <Menu
            anchorEl={actionMenu}
            open={Boolean(actionMenu)}
            onClose={handleActionsMenuClose}
            PaperProps={{
              elevation: 3, // For shadow
              style: {
                borderRadius: "4px",
              },
            }}
          >
            <MenuItem
              onClick={() => {
                handleActionsMenuClose();
                props.handleEdit(props.variableData);
              }}
              id={`${props.id}_${variable.variableId}_EditBtn`}
            >
              Edit
            </MenuItem>
            <MenuItem
              onClick={() => {
                handleActionsMenuClose();
                props.handleDelete(props.variableData.variableId); // Call the delete function
              }}
              id={`${props.id}_${variable.variableId}_DeleteBtn`}
            >
              Remove
            </MenuItem>
          </Menu>
        </Grid>
      </Grid>
    </Grid>
  );
};

// {BugId:Bug 144057 - Variable Type dropdown is not correct
// AuthorName:Dixita Ruhela
// Date: 26 feb 2024
// }
const typeOptions = [
  { name: "Integer", value: 2 },
  { name: "Float", value: 8 },
  { name: "Text", value: 1 },
  { name: "Date", value: 4 },
  { name: "Boolean", value: 3 },
  { name: "List", value: 5 },
  { name: "DataRecord", value: 7 },
  { name: "DataTable", value: 6 },
  { name: "MailMessage", value: 10 },
  { name: "DateTime", value: 9 },
  { name: "JSONObject", value: 11 },
  { name: "JSONArray", value: 12 },
];

const optionType = [
  {
    name: "Input",
    value: "I",
  },
  { name: "Output", value: "O" },
  { name: "Transient", value: "T" },
];
const optionsForFilterType = [
  { name: "Integer", value: false, type: 2 },
  { name: "Float", value: false, type: 8 },
  { name: "Text", value: false, type: 1 },
  { name: "Date", value: false, type: 4 },
  { name: "Boolean", value: false, type: 3 },
  { name: "List", value: false, type: 5 },
  { name: "DataRecord", value: false, type: 7 },
  { name: "DataTable", value: false, type: 6 },
  { name: "MailMessage", value: false, type: 10 },
  { name: "DateTime", value: false, type: 9 },
  { name: "JSONObject", value: false, type: 11 },
  { name: "JSONArray", value: false, type: 12 },
];
const optionsForFilter = [
  { name: "Dynamic", value: false, type: "D" },
  { name: "Fixed", value: false, type: "F" },
];
