import React, { useState, useEffect, useContext } from "react";
import { useSelector } from "react-redux";
import JohnDoe from "../../assets/img/johnDoe1.jpg";
import ModalForm from "../../utils/modalForm";
import LoadingIndicator from "./../../utils/loadingIndicator";
import { makeStyles } from "@mui/styles";
import {
  getDateStr,
  createInstance,
  handleNetworkRequestError,
} from "../../utils/common";

import { Grid, Typography } from "@mui/material";
import { SCRIPT_HISTORY } from "../../config";
import { NotificationContext } from "../../contexts/NotificationContext";
import { useHistory } from "react-router-dom";
import { DocIcon } from "../../utils/AllImages";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";

const ScriptHistoryModal = (props) => {
  const classes = useStyles();
  const history = useHistory();
  const { t } = useTranslation()
  const { setValue: setNotification } = useContext(NotificationContext);

  const { selectedScript } = props;
  const [historyDetails, setHistoryDetails] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(props.isOpen ? true : false);
  useEffect(() => {
    getHistoryDetails();
  }, []);
  const getHistoryDetails = async () => {
    const { scriptId } = selectedScript;
    const axiosInstance = createInstance();
    setIsLoading(true);
    try {
      let res = await axiosInstance.get(`${SCRIPT_HISTORY}/${scriptId}`);
      if (res.status === 200) {
        const hDtls = res.data.data;

        setHistoryDetails(hDtls || []);
        setIsLoading(false);
      }
    } catch (error) {
      console.log(error);
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "could not fetch the history details.",
            title: "",
            notificationType: "ERROR",
          });
        },
      });

      setIsLoading(false);
    }
  };
  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    console.log("cancel clicked");
    handleClose();
  };
  const Loading = () => {
    return (
      <Grid container justifyContent="center" alignItems="center">
        <Grid item>
          <LoadingIndicator />
        </Grid>
      </Grid>
    );
  };
  const Header = () => {
    
    if (historyDetails.length > 0) {
      return (
        <Grid
          container
          direction="row"
          style={{
            //  marginTop: "13px",
            marginBottom: "15px",
            // paddingLeft: "20px",
          }}
          spacing={1}
          justifyContent="flex-start"
        >
          <Grid item xs={2}>
            <Typography className={classes.text_bold}>{t("Date")}</Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography className={classes.text_bold}>{t("Action")}</Typography>
          </Grid>
          <Grid item xs={1} style={{ marginLeft: "-8px" }}>
            <Typography className={classes.text_bold}>{t("Version")}</Typography>
          </Grid>
          <Grid
            item
            xs={3} //style={{ marginLeft: "8px" }}
          >
            <Typography className={classes.text_bold}>{t("Done by")}</Typography>
          </Grid>
          <Grid item xs={3}>
            <Typography className={classes.text_bold}>{t("Comments")}</Typography>
          </Grid>
        </Grid>
      );
    }
    return null;
  };
  if (isLoading) {
    return (
      <ModalForm
        id={props.id}
        isOpen={open}
        title={t("History")}
        name={selectedScript ? t("Service Flow : ") + selectedScript.scriptName : ""}
        icon={
          <UniqueIDGenerator>
            <DocIcon className={classes.icon} />
          </UniqueIDGenerator>
        }
        Content={<Loading />}
        btn1Title={t("Close")}
        onClick1={onClick1}
        headerCloseBtn={true}
        onClickHeaderCloseBtn={handleClose}
        closeModal={handleClose}
        containerHeight={533}
        containerWidth={800}
      />
    );
  }
  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={t("History")}
      name={selectedScript ? t("Service Flow : ") + selectedScript.scriptName : ""}
      icon={
        <UniqueIDGenerator>
          <DocIcon className={classes.icon} />
        </UniqueIDGenerator>
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      Content={
        <Content
          id={props.id}
          historyDetails={historyDetails}
          Header={<Header />}
        />
      }
      btn1Title={t("Close")}
      onClick1={onClick1}
      closeModal={handleClose}
      containerHeight={500}
      containerWidth={900}
    //Header={<Header />}
    />
  );
};

export default ScriptHistoryModal;

const useStyles = makeStyles({
  table: {
    minWidth: 900,
    overflow: "hidden",
  },
  profile: {
    height: "16px",
    width: "16px",
    borderRadius: "50px",
  },
  text_12: {
    fontSize: "12px",
    textAlign: "left",
  },
  text_bold: {
    color: "#606060",
    fontWeight: 600,
  },
  opacity_3: {
    opacity: 0.3,
  },
  icon: {
    marginTop: "3px",
    width: "12px",
    height: "14px",
  },
});

const Content = (props) => {
  const classes = useStyles();
  const allUsers = useSelector((state) => state.scriptsAndProjects.allUsers);

  const { historyDetails } = props;
  const getAction = (num) => {
    switch (num) {
      case 101:
        return "Created";
      case 102:
        return "Saved";
      case 103:
        return "Commited";
      case 104:
        return "Removed";
      case 105:
        return "Locked";
      case 106:
        return "Published";
      case 107:
        return "Modified";
      case 108:
        return "Imported";
      case 109:
        return "Exported";
      case 110:
        return "Shared";
      case 111:
        return "Moved";
      default:
        break;
    }
  };
  {
    /*****************************************************************************************
     * @author asloob_ali BUG ID :  103057  Description: Script History: Done by column value is always static "Rameshwar Singh"
     * Reason:information about who performed the action in script was not coming from server.
     *  Resolution :information added as actionTakenBy in database and now using that info to display doneby column details...
     *  Date : 06/12/2021             ***************************************************************************************/
  }
  const getUserDetails = (userId) => {
    if (allUsers) {
      const usr = allUsers.find((item) => item.userIndex === userId);
      if (usr) return usr;
    }
    return null;
  };
  return (
    <Grid
      tabIndex={0}
      role="scrollbar"
      aria-controls={`${props.id}`}
      aria-valuenow={0}
    >
      {historyDetails.length > 0 ? (
        <>
          <div>{props.Header}</div>
          <Grid container direction="column" spacing={2} id={props.id}>
            {historyDetails.map((item, i) => (
              <Grid item container direction="row" key={i}>
                <Grid item xs={2}>
                  <Typography>
                    {getDateStr(item.actionTakenOn || "")}
                  </Typography>
                </Grid>
                <Grid item xs={3}>
                  <Typography>{getAction(item.actionId)}</Typography>
                </Grid>
                <Grid item xs={1}>
                  <Typography>{item.versionName || "V1.0"}</Typography>
                </Grid>
                <Grid item xs={3}>
                  <Grid container spacing={1}>
                    <Grid item>
                      <img
                        className={classes.profile}
                        src={JohnDoe}
                        alt="profile"
                      />
                    </Grid>
                    <Grid item>
                      {/* {BugId:Bug 143346 - Not getting user name in History like which user have done activity on script
                      Author:Dixita Ruhela
                      Date:08 feb 2024
                      RCA:Proper mapping was not done.
                      } */}
                      <Typography>
                        {getUserDetails(item.actionTakenBy)?.userLoginId ||
                          "No Info."}
                      </Typography>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={3}>
                  <Typography
                    variant="subtitle2"
                    className={!item.comments ? classes.opacity_3 : null}
                    title={item.comments || ""}
                  >
                    {item.comments
                      ? item.comments.length > 25
                        ? item.comments.substring(0, 30) + ".."
                        : item.comments
                      : "No comment"}
                  </Typography>
                </Grid>
              </Grid>
            ))}
          </Grid>
        </>
      ) : (
        "History not available"
      )}
    </Grid>
  );
};

const allHistoryDetails = [
  {
    date: "08/09/2020",
    action: "Discard Changes",
    version: "v1.7",
    doneBy: { img: JohnDoe, name: "Rameshwar Singh" },
    comment:
      "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type",
  },
  {
    date: "04/09/2020",
    action: "Moved to customer loan",
    version: "v1.6",
    doneBy: { img: JohnDoe, name: "Harry Guerrero" },
    comment:
      "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type",
  },
  {
    date: "02/09/2020",
    action: "Publlished",
    version: "v1.6",
    doneBy: { img: JohnDoe, name: "Ronald Gilbert" },
    comment:
      "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type",
  },
  {
    date: "28/08/2020",
    action: "Commited",
    version: "v1.5",
    doneBy: { img: JohnDoe, name: "Jarry Oliver" },
    comment:
      "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type",
  },
  {
    date: "25/09/2020",
    action: "Reverted back",
    version: "v1.4",
    doneBy: { img: JohnDoe, name: "Alex Watkins" },
    /* comment:
      "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s when an unknown printer took a galley of type",
  */
  },
];
{
  /*<TableContainer component={Paper}>
<Table className={classes.table} size="small" aria-label="history table">
  <TableHead>
    <TableRow>
      <TableCell>Date</TableCell>
      <TableCell>Action</TableCell>
      <TableCell>Version</TableCell>
      <TableCell>Done By</TableCell>
      <TableCell>Comments</TableCell>
    </TableRow>
  </TableHead>
  <TableBody>
    {historyDetails.map((item, index) => (
      <TableRow key={index}>
        <TableCell component="th" scope="row">
          {item.date}
        </TableCell>
        <TableCell>{item.action}</TableCell>
        <TableCell>{item.version}</TableCell>
        <TableCell>
          {item.doneBy && (
            <Grid
              container
              spacing={2}
              alignItems="center"
              justify="flex-start"
            >
              <Grid item>
                <img
                  className={classes.profile}
                  src={item.doneBy["img"]}
                  alt="profile"
                />
              </Grid>
              <Grid item>{item.doneBy["name"]}</Grid>
            </Grid>
          )}
        </TableCell>
        <TableCell>{item.comment}</TableCell>
      </TableRow>
    ))}
  </TableBody>
</Table>
          </TableContainer>*/
}
