import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import { Grid, Typography } from "@mui/material";
import ModalForm from "./../../utils/modalForm";
import { useTranslation } from "react-i18next";
import { ConvertLtrRtl } from "../common";

const useStyles = makeStyles(() => ({
  container: {
    marginTop: "4rem",
  },
}));

const ConfirmDeleteModal = (props) => {
  const {
    id,
    title,
    description,
    onDelete,
    handleClose,
    handleCancel,
    isOpen,
    isDeleting = false,
    isProject,
  } = props;
  const onClick1 = () => {
    handleCancel();
  };
  const onClick2 = () => {
    onDelete();
  };
  const handleCloseMain = () => {
    handleClose();
  };

  return (
    <ModalForm
      id={id}
      isOpen={isOpen}
      title={`Deleting ${title}`}
      Content={
        <Content
          title={title}
          description={description}
          isProject={isProject}
        />
      }
      btn1Title="No"
      btn2Title={"Yes, Delete"}
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleCloseMain}
      isProcessing={isDeleting}
      onClick1={onClick1}
      onClick2={onClick2}
      closeModal={handleCloseMain}
      containerHeight={180}
      containerWidth={500}
    />
  );
};
export default ConfirmDeleteModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const { title, description, isProject } = props;
  const { t } = useTranslation()
  return (
    <>
      <Grid container direction="column" spacing={1}>
        <Grid item>

          <Typography>{ConvertLtrRtl([t("Are you sure you want to delete this"), t(isProject ? "folder" : "Service Flow"), "?"])}</Typography>
        </Grid>
        <Grid item>
          <Typography>{description}</Typography>
        </Grid>
      </Grid>
    </>
  );
};
