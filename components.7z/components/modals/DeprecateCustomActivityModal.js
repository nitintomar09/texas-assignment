import React, { useState, useContext, useEffect } from "react";
import { Grid, Typography } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import { DEPRECATE_CUSTOM_ACTIVITY } from "./../../config/index";
import { NotificationContext } from "../../contexts/NotificationContext";
import {
  createInstance,
  handleNetworkRequestError,
} from "./../../utils/common";
import { useHistory } from "react-router-dom";
import {
  isEmptyText,
  MaximumLengthText,
  isContainSpecialCharacters,
} from "../../utils/validations/validations";
import { useTranslation } from "react-i18next";

const useStyles = makeStyles(() => ({
  container: {
    marginTop: "4rem",
  },
  warning: {
    color: "#AD6503",
    fontWeight: 600,
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

const DeprecateCustomActivityModal = (props) => {
  const { setValue } = useContext(NotificationContext);
  const history = useHistory();
  const { t } = useTranslation();
  const { selectedCustomActivity, listOfActivities, updateActivities } = props;
  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [isDeprecating, setIsDeprecating] = useState(false);
  const [formHasError, setFormHasError] = useState(true);

  const [versionName, setVersionName] = useState(makeFieldInputs(""));
  const [versionList, setVersionList] = useState([]);
  const [isWantToDeprecate, setIsWantToDeprecate] = useState(false);

  const getAllVersions = () => {
    let versions = listOfActivities
      .filter(
        (grp) =>
          grp.groupName === selectedCustomActivity?.groupName &&
          !grp.isDeprecated
      )
      .map((item) => item.dependency);

    versions = versions.slice(1);
    versions = versions.map((item) => {
      return { name: item, value: item };
    });
    setVersionList([...versions]);
  };
  useEffect(() => {
    if (
      selectedCustomActivity &&
      selectedCustomActivity?.isCustomActivity &&
      listOfActivities
    ) {
      getAllVersions();
    } else {
      setVersionList([]);
    }
  }, [selectedCustomActivity, listOfActivities]);
  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";

    switch (name) {
      case "Version":
        errors = isEmptyText(value);
        setVersionName({
          ...versionName,
          value,
          error: errors,
          helperText: errors,
        });
        break;

      default:
        break;
    }
  };
  useEffect(() => {
    if (versionName?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [versionName]);
  const validateFields = () => {
    const verNameErrors = isEmptyText(versionName.value);

    if (verNameErrors) {
      setVersionName({
        ...versionName,
        error: verNameErrors,
        helperText: verNameErrors,
      });
    }

    if (verNameErrors) {
      return false;
    }
    return true;
  };

  const handleClose = () => {
    setOpen(false);

    props.handleClose();
  };
  const onClick1 = () => {
    handleClose();
    setIsWantToDeprecate(false);
  };
  const onClick2 = async () => {
    if (!validateFields()) {
      return;
    }
    setIsWantToDeprecate(true);
  };

  const onDeprecate = async () => {
    const axiosInstance = createInstance();
    setIsDeprecating(true);
    {
      /*****************************************************************************************
       * @author asloob_ali BUG ID :  105947  Custom activity: Getting Error" Invalid Response" while trying to deprecate a version
       * Reason:we did change the version/dependency type,thats why it was comparing versions with different data type.
       *  Resolution :changed the data type of versionName as we are getting in api response
       *  Date : 28/02/2022             ***************************************************************************************/
    }
    try {
      const groupObj = listOfActivities.find(
        (grp) =>
          grp.groupName === selectedCustomActivity.groupName &&
          grp.dependency === +versionName.value
      );
      const groupId = groupObj?.groupId || "";
      const res = await axiosInstance.put(
        `${DEPRECATE_CUSTOM_ACTIVITY}/${groupId}`
      );
      if (res.status === 200) {
        updateActivities({
          ...groupObj,
          isDeprecated: true,
          deprecating: true,
        });
        setIsDeprecating(false);
        //creating Notification
        setValue({
          isOpen: true,
          message: res.data?.message || "Depecated successfully.",
          notificationType: "SUCCESS",
          title: "",
        });
        setIsWantToDeprecate(false);
        props.handleClose();
      }
    } catch (error) {
      setIsDeprecating(false);

      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setValue({
            isOpen: true,
            message: errMsg || "Deprecation failed.",
            notificationType: "ERROR",
            title: "",
          });
        },
      });
    }
  };
  const cancelDeprecation = () => {
    setIsWantToDeprecate(false);
  };
  const goAheadDeprecation = () => {
    onDeprecate();
  };
  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={t("Deprecate a Version")}
      isProcessing={isDeprecating}
      Content={
        <Content
          id={props.id}
          versionName={versionName}
          handleChange={handleChange}
          versionList={versionList}
          cancelDeprecation={cancelDeprecation}
          goAheadDeprecation={goAheadDeprecation}
          isWantToDeprecate={isWantToDeprecate}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      btn1Title={t("Cancel")}
      btn2Title={t("Deprecate")}
      onClick1={onClick1}
      onClick2={onClick2}
      btn2Disabled={formHasError}
      closeModal={handleClose}
      containerHeight={250}
      containerWidth={490}
    />
  );
};
export default DeprecateCustomActivityModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {
    id,
    versionName,
    handleChange,
    versionList,
    cancelDeprecation,
    goAheadDeprecation,
    isWantToDeprecate,
  } = props;
  const classes = useStyles();
  const { t } = useTranslation();
  return (
    <>
      <div>
        <Field
          id={`${id}_Version`}
          name={t("Version")}
          label={t("Select a version")}
          dropdown={true}
          {...versionName}
          required={true}
          //  width={420}
          paddingTop={"0px"}
          onChange={handleChange}
          options={versionList || []}
        />
        <Grid container style={{ marginTop: "12px" }}>
          <Grid item>
            <Typography className={classes.warning}>
              {t("selected version will no longer be available to use.")}
            </Typography>
          </Grid>
        </Grid>
        {
          <ModalForm
            id={`${id}_2`}
            title={t("Deprecate Selected Version")}
            containerHeight={150}
            isOpen={isWantToDeprecate}
            closeModal={cancelDeprecation}
            Content={
              <Typography>
                {t("Are You Sure, you want to deprecate the selected version?")}
              </Typography>
            }
            btn1Title={t("No")}
            onClick1={cancelDeprecation}
            btn2Title={t("Yes")}
            onClick2={goAheadDeprecation}
          />
        }
      </div>
    </>
  );
};
