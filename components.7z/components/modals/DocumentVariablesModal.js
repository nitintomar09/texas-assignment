import React, { useState, useContext, useEffect } from "react";
import { Button, Grid, Typography, Modal, Fade, Backdrop, Select } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import { useSelector, useDispatch } from "react-redux";

import CircularProgress from "@mui/material/CircularProgress";
import Close from "@mui/icons-material/Close";
import PropertyField from "../script-editor/PropertyWindow/PropertyFields/PropertyField";
import {
  getAllOptions,
  getOptionsForVariable,
} from "./../script-editor/PropertyWindow/AllActivityWindows/Common/CommonMethods";
import { DeleteIcon } from "../../utils/AllImages";
import { createInstance, handleNetworkRequestError } from "../../utils/common";
import { OMNIFLOW, PROCESS_VARIABLES } from "./../../config/index";
import { iBPSContext } from "./../../contexts/iBPSContext";
import { NotificationContext } from "./../../contexts/NotificationContext";
import { truncateString } from "../script-editor/PropertyWindow/AllActivityWindows/Common/CommonMethods";
import { useHistory } from "react-router-dom";
import { setAllMappedDocuments } from "./../../redux/actions";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";

const useStyles = makeStyles((theme) => ({
  modal: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    outline: 0,
  },
  container: {
    width: 466,
    height: 610,
    backgroundColor: "white",
    display: "flex",
    flexDirection: "column",
    outline: 0,
  },
  title: { color: "#000000", opacity: 1, fontSize: 14, fontWeight: 600 },
  modalHeader: {
    paddingLeft: "10px",
    //paddingRight: "10px",
    boxShadow: "0px 2px 6px #00000029",
  },

  content: {
    paddingLeft: "10px",
    paddingRight: "10px",
    paddingTop: "16px",
    flex: 1,
    flexDirection: "coloumn",
    outline: 0,

    overflowY: "scroll",
    overflowX: "hidden",
  },
  padding: { paddingLeft: 15, paddingRight: 15, paddingTop: 5 },
  text_12: {
    fontSize: "12px",
  },
  lead: {
    fontSize: "12px",

    opacity: 0.4,
  },
  varTitle: {
    color: "#747474",
    fontSize: "12px",
  },
  input: {
    height: 24,
    backgroundColor: "white",
    fontSize: 12,
  },
  loading: {
    height: "300px",
    width: "300px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  btn_title: {
    fontSize: 12,
    color: "#FFFFFF",
  },
  deleteBtn: {
    // marginTop: "8px",
    height: "24px",
    width: "24px",
    filter: `invert(17%) sepia(74%) saturate(5916%) hue-rotate(356deg) brightness(101%) contrast(118%)`,
  },
}));
const DocumentVariablesModal = (props) => {
  const classes = useStyles();
const {t} = useTranslation()
  const { handleOpenModal } = props;

  const [putMappedColToTop, setPutMappedColToTop] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const [allDocumentsVariables, setAllDocumentsVariables] = useState([]);
  const [docMapDataValue, setDocMapDataValue] = useState([]);

  const allMappedDocuments = useSelector(
    (state) => state.editorHomepage.allMappedDocuments
  );
  const dispatch = useDispatch();

  useEffect(() => {
    if (allMappedDocuments) {
      setAllDocumentsVariables(allMappedDocuments);
      setDocMapDataValue(
        allMappedDocuments.length > 0
          ? allMappedDocuments
          : [{ docType: "", docPath: "", valueType: "C" }]
      );
    }
  }, []);
  useEffect(() => {
    if (docMapDataValue) {
      dispatch(setAllMappedDocuments(docMapDataValue));
    }
  }, [docMapDataValue]);
  const [openRole, setOpenRole] = useState(-1);

  //getting variables from context with name and value
  const allVariables = getAllOptions();

  const handleChange = (e) => {
    const { name } = e.target;
    switch (name) {
      case "columnToTop":
        setPutMappedColToTop(!putMappedColToTop);
        break;
      default:
        break;
    }
  };
  const closeModal = () => {
    props.handleClose();
  };

  const handleCloseColumn = (index) => {
    setOpenRole(index);
  };
  const handleOpenColumn = (index) => {
    setOpenRole(index);
  };

  const handleArrObjsValuesChange = (e, index, arr) => {
    const { name, value } = e.target;

    const newArr = [...arr];
    const obj = arr[index];
    if (name === "Key") {
      obj.docType = value;
    } else if (name === "Value") {
      obj.docPath = value;
    }
    newArr.splice(index, 1, obj);
    return newArr;
  };
  const handleArrObjsValuesDelete = (index, arr) => {
    const newArr = [...arr];
    newArr.splice(index, 1);
    return newArr;
  };
  const changeValueTypeToVorC = (
    paramName,
    changeToValue,
    index,
    nameOfField
  ) => {
    let obj = null;
    switch (nameOfField) {
      case "Documents":
        obj = docMapDataValue[index];
        obj.valueType = changeToValue;
        obj.docPath = "";
        const newDocValues = [...docMapDataValue];
        newDocValues.splice(index, 1, obj);
        setDocMapDataValue(newDocValues);
        break;

      default:
        break;
    }
  };
  const addDocs = () => {
    const newObj = { docType: "", docPath: "", valueType: "C" };
    const newArr = [...docMapDataValue, newObj];
    setDocMapDataValue(newArr);
  };
  const handleDocsValueChange = (e, index) => {
    const newArr = handleArrObjsValuesChange(e, index, docMapDataValue);
    setDocMapDataValue(newArr);
  };
  const handleDocsDelete = (index) => {
    const newArr = handleArrObjsValuesDelete(index, docMapDataValue);
    setDocMapDataValue(newArr);
  };

  console.log(docMapDataValue);
  console.log(allMappedDocuments);
  return (
    <Modal
      id={props.id}
      className={classes.modal}
      open={props.isOpen}
      onClose={closeModal}
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 50,
      }}
      disableScrollLock={true}
    >
      <Fade in={props.isOpen}>
        <div className={classes.container}>
          <div className={classes.modalHeader}>
            <Grid
              container
              className={classes.padding}
              spacing={2}
              alignItems="flex-end"
              style={{ marginTop: "5px" }}
            >
              <Grid item>
                <Typography className={classes.title}>
                  {t("Document Mapping")}
                </Typography>
              </Grid>

              {/*<Grid item>
                {allVariables && (
                  <Typography variant="subtitle2">
                    {allMapped ? allMapped.length : 0} of{" "}
                    {allVariables && allVariables.length} mapped.
                  </Typography>
                )}
                </Grid>*/}

              <Grid
                item
                style={{ marginLeft: "auto" }}
                onClick={closeModal}
                tabIndex={0}
                onKeyPress={(e) => e.key === "Enter" && closeModal()}
                id={`${props.id}_CloseBtn`}
              >
                <Close
                  style={{
                    marginTop: "5px",
                    height: "18px",
                    width: "18px",
                    color: "#707070",
                    cursor: "pointer",
                  }}
                />
              </Grid>
            </Grid>
            {/* <Grid container className={classes.padding} spacing={1}>
              <Grid item xs={7}>
                <PropertyField
                  checkbox={true}
                  name="columnToTop"
                  label="Put mapped columns to top"
                  value={putMappedColToTop}
                  onChange={handleChange}
                />
              </Grid>
              <Grid item>
                <Button
                  color="primary"
                  variant="contained"
                  size="small"
                  onClick={() => getAllDocumentsVariables()}
                >
                  <Typography className={classes.btn_title}>
                    Get documents variables
                  </Typography>
                </Button>
              </Grid>
                </Grid>*/}
            <Grid container className={classes.padding} spacing={2}>
              <Grid item xs={5}>
                <Typography className={classes.varTitle}>
                  {t("Document Type")}
                </Typography>
              </Grid>
              <Grid item xs>
                <Typography className={classes.varTitle}>
                  {t("Document Path")}
                </Typography>
              </Grid>
            </Grid>
          </div>

          {/* modal content  */}
          {isLoading ? (
            <div className={classes.loading}>
              <CircularProgress
                color="primary"
                style={{
                  height: "15px",
                  width: "15px",
                }}
              />
            </div>
          ) : (
            <div className={classes.content}>
              {docMapDataValue.map((doc, index) => (
                <>
                  <Grid
                    container
                    className={classes.padding}
                    spacing={2}
                    key={index}
                    alignItems="center"
                  >
                    <Grid item xs={5}>
                      <PropertyField
                        id={`${props.id}_Key_${index}`}
                        combo={true}
                        width={180}
                        name="Key"
                        //  label="Key"
                        value={doc.docType}
                        onChange={(e) => handleDocsValueChange(e, index)}
                      />
                    </Grid>
                    <Grid item xs={5}>
                      <PropertyField
                        id={`${props.id}_Value_${index}`}
                        name="Value"
                        combo={true}
                        width={180}
                        varType={1}
                        paramObj={doc}
                        labelBtn1={true}
                        labelBtn2={true}
                        dropdown={doc.valueType === "V"}
                        labelBtn1OnClick={(paramName, changeToValue) =>
                          changeValueTypeToVorC(
                            paramName,
                            changeToValue,
                            index,
                            "Documents"
                          )
                        }
                        labelBtn2OnClick={(paramName, changeToValue) =>
                          changeValueTypeToVorC(
                            paramName,
                            changeToValue,
                            index,
                            "Documents"
                          )
                        }
                        value={doc.docPath}
                        onChange={(e) => handleDocsValueChange(e, index)}
                        options={getOptionsForVariable({
                          paramObjectTypeId: 1,
                        })}
                      />
                    </Grid>
                    <Grid item xs={2}>
                      <UniqueIDGenerator>
                        <DeleteIcon
                          className={classes.deleteBtn}
                          style={{
                            // marginBottom: "5px",
                            cursor: "pointer",
                          }}
                          onClick={() => handleDocsDelete(index)}
                          onKeyPress={(e) =>
                            e.key === "Enter" && handleDocsDelete(index)
                          }
                          tabIndex={0}
                          id={`${props.id}_DeleteIcon_${index}`}
                        />
                      </UniqueIDGenerator>
                    </Grid>
                  </Grid>
                </>
              ))}
              <Button
                variant="contained"
                color="primary"
                onClick={() => addDocs()}
                style={{ marginLeft: "16px" }}
                id={`${props.id}_AddDocsBtn`}
                disableRipple
              >
                <Typography className={classes.btn_title}>
                  {t(docMapDataValue.length > 0 ? "Add More" : "Add")}
                </Typography>
              </Button>
              {docMapDataValue.length > 0 && (
                <div style={{ marginTop: "20px", paddingLeft: "16px" }}>
                  <Button
                    color="primary"
                    variant="contained"
                    size="small"
                    onClick={() => handleOpenModal("Save")}
                    id={`${props.id}_SaveDocsBtn`}
                    disableRipple
                  >
                    <Typography className={classes.btn_title}>{t("Save")}</Typography>
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default DocumentVariablesModal;
