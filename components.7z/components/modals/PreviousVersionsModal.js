import React, { useState, useEffect, useContext } from "react";
import JohnDoe from "../../assets/img/johnDoe1.jpg";
import ModalForm from "../../utils/modalForm";
import LoadingIndicator from "./../../utils/loadingIndicator";
import { makeStyles } from "@mui/styles";
import {
  createInstance,
  handleNetworkRequestError,
  getDateAndTimeStr,
  openScriptInNewTab,
  getToken,
  getUser,
  getUserId,
} from "../../utils/common";

import { Grid, Typography, Button, Divider } from "@mui/material";
import { VERSION } from "./../../config/index";
import { setOpenScriptDetails } from "../../redux/actions";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { NotificationContext } from "../../contexts/NotificationContext";
import { DocIcon } from "../../utils/AllImages";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";
import { getRgbafromHex } from "../../utils/HexToFilter";

const PreviousVersionsModal = (props) => {
  const { selectedScript } = props;
  const allUsers = useSelector((state) => state.scriptsAndProjects.allUsers);

  const history = useHistory();
  const { setValue } = useContext(NotificationContext);
  const [previousVersions, setPreviousVersions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [open, setOpen] = useState(props.isOpen ? true : false);
  useEffect(() => {
    getPreviousVersions();
  }, []);

  const classes = useStyles();
  const dispatch = useDispatch();

  const handleOpen = (versionId, versionName) => {
    const { scriptId, scriptName } = selectedScript;

    if (versionName && scriptId) {
      dispatch(setOpenScriptDetails({
        scriptId, scriptName, versionName
      }));
      //const user = getUser();

      //const token = getToken();
      //  openScriptInNewTab({ scriptId, versionName, token, user });
      history.push('/serviceflow')
    }
  };
  const getUserDetails = (userId) => {
    if (allUsers) {
      const usr = allUsers.find((item) => item.userIndex === userId);
      if (usr) return usr;
    }
    return null;
  };

  const getPreviousVersions = async () => {
    const { scriptId } = selectedScript;
    const axiosInstance = createInstance();
    if (scriptId) {
      setIsLoading(true);
      try {
        let res = await axiosInstance.get(`${VERSION}/${scriptId}`);
        console.log(res);
        const { data } = res.data;
        if (data) {
          const preVersions = data.map((obj) => {
            const date = getDateAndTimeStr(obj.createdOn);
            const userObj = getUserDetails(obj?.lastModifiedBy);
            /*   const currUserId = getUserId();
            let name = userObj?.fullName;
            if (currUserId == obj?.lastModifiedBy) {
              name = name + ` (You)`;
            }*/
            {
              /*****************************************************************************************
               * @author asloob_ali BUG ID :  102636   Description : Script versions: Changed by column does not have the correct value
               * Reason:information about who made the change in script was not coming from server.
               *  Resolution :information added as lastModifiedBy in database and now using that info to display changeby column details...
               *  Date : 03/12/2021             ***************************************************************************************/
            }
            return {
              ...obj,
              createdOn: date,
              createdBy: { img: JohnDoe, name: userObj?.fullName || "" },
            };
          });
          setPreviousVersions(preVersions);
          setIsLoading(false);
        }
      } catch (error) {
        setIsLoading(false);

        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
      }
    } else {
      console.log("scriptId not there");
    }
  };
  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    console.log("close clicked");
    handleClose();
  };
  const Loading = () => {
    return (
      <Grid container justifyContent="center" alignItems="center">
        <Grid item>
          <LoadingIndicator />
        </Grid>
      </Grid>
    );
  };
  if (isLoading) {
    return (
      <ModalForm
        id={props.id}
        isOpen={open}
        title="Versions"
        Content={<Loading />}
        btn1Title="Close"
        onClick1={onClick1}
        closeModal={handleClose}
        containerHeight={533}
        containerWidth={800}
      />
    );
  }
  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title="Versions"
      name={(selectedScript && "Service Flow : " + selectedScript.scriptName) || ""}
      icon={
        <UniqueIDGenerator>
          <DocIcon className={classes.icon} />
        </UniqueIDGenerator>
      }
      Content={
        <Content
          id={props.id}
          previousVersions={previousVersions}
          handleOpen={handleOpen}
        />
      }
      btn1Title="Close"
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      onClick1={onClick1}
      closeModal={handleClose}
      containerHeight={533}
      containerWidth={800}
    />
  );
};

export default PreviousVersionsModal;

const useStyles = makeStyles((theme) => ({
  text_Light: {
    fontSize: 12,
    color: "#606060",
    fontWeight: 600,
  },
  text_bold: {
    fontSize: 12,
    fontWeight: 450,
  },
  text_bold2: {
    //fontSize: 12,
    color: "#000000",
    fontWeight: 600,
  },
  bold2: {
    fontWeight: 600,
  },

  profile: {
    width: "24px",
    height: "24px",
    borderRadius: "50px",
  },
  icon: {
    marginTop: "3px",
    width: "12px",
    height: "14px",
  },
  subDesc: {
    color: "#767676",
    fontSize: 10,
  },
  published: {
    backgroundColor: "#389821",
    color: "#FFFFFF",
    borderRadius: 2,
  },
  focusSecondary: {
    "&:focus": {
      //filter: "brightness(0.90)",
      background: `${getRgbafromHex(`${theme.palette.primary.main}`, 0.04)}`,
    },
  },
}));

const Content = (props) => {
  const classes = useStyles();
  const { t } = useTranslation()
  const { previousVersions, handleOpen } = props;

  return (
    <div>
      {previousVersions.length > 0 ? (
        <div>
          <Grid
            container
            spacing={3}
            direction="row"
            alignItems="center"
            justifyContent="center"
          >
            <Grid item xs={6}>
              <Typography className={classes.text_Light}>{t("Versions")}</Typography>
            </Grid>
            <Grid item xs={3}>
              <Typography className={classes.text_Light}>{t("Changed By")}</Typography>
            </Grid>
            <Grid item xs={3}>
              <Typography className={classes.text_Light}>{t("Actions")}</Typography>
            </Grid>
          </Grid>
          <Grid
            container
            direction="row"
            spacing={2}
            justifyContent="center"
            alignItems="center"
          >
            {previousVersions.map((item, i) => (
              <React.Fragment key={i}>
                <Grid item xs={6}>
                  <Grid container direction="column" spacing={1}>
                    <Grid item container spacing={1}>
                      <Grid item xs={2}>
                        <Typography className={classes.text_bold2}>
                          {item.versionName}
                        </Typography>
                      </Grid>
                      {item.isPublished && (
                        // {BugId:Bug 143862 - Script :On UI published button is not correct
                        // Author Name:Dixita
                        // Date:22 feb 2024
                        // }
                        <Grid item>
                          <Grid container>
                            <Grid item className={classes.published}>
                              <Typography>{t("Published")}</Typography>
                            </Grid>
                          </Grid>

                        </Grid>
                      )}
                    </Grid>
                    <Grid item>
                      <Grid container direction="row" spacing={2}>
                        <Grid item>
                          <Typography
                            variant="subtitle2"
                            className={classes.subDesc}
                          >
                            {t("Date of creation :")}
                          </Typography>
                        </Grid>
                        {item.createdOn && (
                          <Grid item>
                            <Typography
                              variant="subtitle2"
                              className={classes.subDesc + " " + classes.bold2}
                            >
                              {item.createdOn}
                            </Typography>
                          </Grid>
                        )}
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={3}>
                  <Grid
                    item
                    container
                    direction="row"
                    spacing={1}
                    alignItems="flex-end"
                    style={{ marginTop: "12px" }}
                  >
                    <Grid item>
                      <Grid container justifyContent="center" spacing={1}>
                        <Grid item>
                          <img
                            src={item.createdBy["img"]}
                            alt="profile"
                            className={classes.profile}
                          />
                        </Grid>
                        <Grid item>
                          <Typography
                            style={{ marginTop: "3px", fontWeight: 620 }}
                          >
                            {item.createdBy && item.createdBy["name"]}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item xs={3}>
                  <Button
                    variant="outlined"
                    color="primary"
                    size="small"
                    style={{
                      marginTop: "20px",
                      // width: "40px",
                      fontSize: "12px",
                      fontWeight: 600,
                    }}
                    onClick={() => handleOpen(item.versionId, item.versionName)}
                    disableFocusRipple
                    className={classes.focusSecondary}
                    id={`${props.id}_${item.versionId ? item.versionId : ""
                      }_OpenBtn`}
                  >
                    {t("Open")}
                  </Button>
                </Grid>
                <Grid item xs={12}>
                  <Divider variant="fullWidth" />
                </Grid>
              </React.Fragment>
            ))}
          </Grid>
        </div>
      ) : (
        <Grid container alignItems="center" justifyContent="center">
          <Grid item>
            <Typography>
              {t("There is no information available about previous versions of this Service Flow.")}
            </Typography>
          </Grid>
        </Grid>
      )}
    </div>
  );
};
