import React, { useState, useContext, useEffect } from "react";
import makeStyles from '@mui/styles/makeStyles';
// import ModalForm from "./../../utils/modalForm";
// import { BOT, API_BASE_URL } from "./../../config/index";
// import { NotificationContext } from "../../contexts/NotificationContext";
// import {
//   createInstance,
//   handleNetworkRequestError,
// } from "./../../utils/common";
// import { useHistory } from "react-router-dom";
import { Button, Grid, IconButton, Typography } from "@mui/material";

import { CenterFocusStrong, Check } from "@mui/icons-material";
import { useSelector, useDispatch } from "react-redux";
import {
  NewgenLogoIcon,
  LaptopIcon,
  DownloadBotIcon,
  BotsIcon,
} from "../../utils/AllImages";
// import {
//   connectToRobot,
//   setConfigFlag,
//   setIsRobotAvailable,
//   setMachineName,
// } from "../../redux/actions";
import LoadingIndicator from "../../utils/loadingIndicator";
import { getCssFilterFromHex } from "./../../utils/HexToFilter";
import { useTranslation } from "react-i18next";
import { ConvertLtrRtl } from "../common";

const useStyles = makeStyles((theme) => ({
  container: {
    marginTop: "4rem",
  },
  incognitoContainer: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    width: "41px",
    height: "41px",
    borderRadius: "50px",
    backgroundColor: "#FFA40B",
  },
  incognitoIcon: {
    height: "32px",
    width: "32px",
  },
  title: {
    display: "none",
    fontSize: "12px",
    [theme.breakpoints.up("sm")]: {
      display: "block",
      color: "#01733a",
      fontWeight: 800,
    },
  },
  LaptopIcon: {
    width: "24px",
    height: "24px",
    marginTop: "5px",
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

// const RobotDownloadModal = (props) => {
//   const { setValue } = useContext(NotificationContext);
//   var checkBot = null;
//   const history = useHistory();
//   const dispatch = useDispatch();
//   const isRobotAvailable = useSelector((state) => state.robot.isRobotAvailable);

//   const [open, setOpen] = useState(props.isOpen ? true : false);

//   const [isProcessing, setIsProcessing] = useState(false);
//   const [percentDownloaded, setPercentDownloaded] = useState(0);
//   const [isDownloaded, setIsDownloaded] = useState(false);
//   const [forceFlag, setforceFlag] = useState(false);
//   const [downloadAgain, setDownloadAgain] = useState(false);
//   const getRoboStatus = () => {
//     if (!isRobotAvailable) {
//       dispatch(connectToRobot({}));
//     }
//   };
//   useEffect(() => {
//     checkBot = setInterval(getRoboStatus, 10000);
//   }, []);

//   useEffect(() => {
//     if (isRobotAvailable) {
//       clearInterval(checkBot);
//       setIsProcessing(false);
//     }
//   }, [isRobotAvailable]);

//   useEffect(() => {
//     if (downloadAgain) {
//       setforceFlag(true);
//     }
//   }, [downloadAgain]);

//   const handleClose = () => {
//     clearInterval(checkBot);

//     setOpen(false);
//     props.handleClose();
//   };
//   const onClickDownload = () => {
//     setIsProcessing(true);
//     dispatch(setConfigFlag(false));
//     dispatch(setIsRobotAvailable(false));
//     dispatch(setMachineName(null));

//     const axiosInstance = createInstance();
//     const config = {
//       responseType: "arraybuffer",
//       /*  onDownloadProgress: (ProgressEvent) => {
//         setPercentDownloaded((ProgressEvent.loaded * 100) / 88864581);
//         console.log(ProgressEvent);
//         // setPercentDownloaded((ProgressEvent.loaded * 100) /  ProgressEvent.total);
//         // if ((ProgressEvent.loaded * 100) / ProgressEvent.total === 100) {
//         if ((ProgressEvent.loaded * 100) / 88864581 === 100) {
//           setIsDownloaded(true);
//           setIsProcessing(false);
//         }
//       },*/
//     };
//     {
//       /*****************************************************************************************
//        * @author asloob_ali BUG ID :  102476  Description: Incorrect percentage of downloading is showing while download the bot in designer
//        * Reason:total size of the files which are being downloaded was not coming from server.
//        *  Resolution :As per discussion removed determinate loader and now showing a simple indeterminate loader.
//        *  Date : 06/12/2021             ***************************************************************************************/
//     }
//     axiosInstance
//       .get(`${API_BASE_URL}${BOT}?forceFlag=${forceFlag}`, config)
//       .then((response) => {
//         console.log(response);
//         if (response.status === 200) {
//           setIsDownloaded(true);
//           setIsProcessing(false);
//           //setforceFlag(true);
//           const url = window.URL.createObjectURL(new Blob([response.data]));
//           const link = document.createElement("a");
//           link.href = url;
//           link.setAttribute("download", `Bot-RPA.zip`);
//           document.body.appendChild(link);
//           link.click();
//         } else if (response.status === 202) {
//           setDownloadAgain(true);
//           setIsDownloaded(false);
//           setIsProcessing(false);
//         }
//       })
//       .catch((error) => {
//         console.log(error);
//         setIsProcessing(false);
//         handleNetworkRequestError({
//           error,
//           history,
//           onError: (err) => {
//             setValue({
//               isOpen: true,
//               message: err || "download server error.",
//               notificationType: "ERROR",
//               title: "",
//             });
//           },
//         });
//       });
//   };

//   return (
//     <ModalForm
//       id="RPA_RobotDownloadModal"
//       isOpen={open}
//       title="Connect your Machine"
//       Content={
//         <Content
//           id="RPA_RobotDownloadModal"
//           downloadAgain={downloadAgain}
//           isProcessing={isProcessing}
//           onClickDownload={onClickDownload}
//           isRobotAvailable={isRobotAvailable}
//           percentDownloaded={percentDownloaded}
//           isDownloaded={isDownloaded}
//         />
//       }
//       closeModal={handleClose}
//       headerCloseBtn={true}
//       onClickHeaderCloseBtn={handleClose}
//       containerHeight={400}
//       containerWidth={500}
//     />
//   );
// };
// export default RobotDownloadModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {
    onClickDownload,
    isProcessing,
    isRobotAvailable,
    percentDownloaded,
    isDownloaded,
    downloadAgain,
    id,
  } = props;
  const machineName = useSelector((state) => state.robot.machineName);
  const isConfigWrong = useSelector((state) => state.robot.isConfigWrong);
  const { t } = useTranslation()
  const classes = useStyles();
  const instructions = [
    t("Unzip downloaded file at any location."),
    t("Open that folder which comes after unzipping the file."),
    t("Click on the start.bat file."),
    //"Launch Command Prompt at that location.",
    //"Open Readme.txt file.",
    //"Execute given command in Command Prompt.",
    t("When the bot will start,this dialog will display connected status of the bot."),
  ];
  //<Check htmlColor="#0D6F08" />
  if (isProcessing) {
    return <>
      <Grid
        container
        direction="column"
        spacing={2}
        justifyContent="center"
        alignItems="center"
        style={{
          height: "330px",
          width: "440",
          backgroundColor: "#d5d5d5",
        }}
      >
        <Grid item>
          <Grid container spacing={1} alignItems="center">
            <Grid item>
              <img
                src={NewgenLogoIcon}
                alt="Logo"
                style={{ height: 28.11, width: 128.11 }}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          <Typography variant="h5">
            {t("You are downloading Bot Setup for Newgen RPA...")}
          </Typography>
        </Grid>
        <Grid item container alignItems="center" justifyContent="center">
          {/*<Grid item sm={10}>
            <LinearProgress
              variant="determinate"
              value={percentDownloaded}
              color="primary"
            />
          </Grid>
          <Grid item xs>
            <Typography variant="body2">{`${Math.round(
              percentDownloaded
            )}%`}</Typography>
            </Grid>*/}
          <Grid item>
            <LoadingIndicator
              // value={percentDownloaded}
              color="#4ef542"
              height="25px"
              width="25px"
            />
          </Grid>
        </Grid>
      </Grid>
    </>;
  } else if (isConfigWrong) {
    return (
      <Grid
        container
        direction="column"
        spacing={1}
        alignItems="center"
        justifyContent="center"
        alignContent="center"
      >
        <Grid item>
          <Typography style={{ fontWeight: 700 }}>
            {t("Robot Service is not available for this designer. Either download setup or Change robot Configuration for Current designer and restart service.")}
          </Typography>
        </Grid>
        <Grid item>
          <Button
            color="primary"
            variant="contained"
            endIcon={
              <DownloadBotIcon
                style={{
                  width: "16px",
                  height: "16px",
                  filter: getCssFilterFromHex("#FFFFFF"),
                  marginTop: "-3px",
                }}
              />
            }
            onClick={onClickDownload}
            disableRipple
            id={`${id}_DownloadBotRPABtn`}
          >
            {t("Download Bot RPA")}
          </Button>
        </Grid>
      </Grid>
    );
  } else if (isRobotAvailable) {
    return (
      <Grid
        container
        direction="column"
        spacing={2}
        justifyContent="center"
        alignItems="center"
        alignContent="center"
        style={{
          height: "330px",
          width: "440",
        }}
      >
        <Grid item>
          <Grid container spacing={1} alignItems="center">
            <Grid item>
              <Typography variant="h3" style={{ fontWeight: 600 }}>
                {t("CONNECTED")}
              </Typography>
            </Grid>
            <Grid item>
              <IconButton
                style={{ backgroundColor: "#619548" }}
                size="small"
                disableRipple
              >
                <Check htmlColor="#ffffff" />
              </IconButton>
            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          <Grid container spacing={1} alignItems="center">
            <Grid item>
              <LaptopIcon className={classes.LaptopIcon} />
            </Grid>
            <Grid item>
              <Typography
                variant="h5"
                style={{ fontWeight: 600, color: "#606060" }}
              >
                {machineName || ""}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    );
  } else if (isDownloaded) {
    return (
      <Grid
        container
        direction="column"
        spacing={1}
        alignItems="center"
        justifyContent="center"
        alignContent="center"
      >
        {instructions.map((item, i) => (
          <Grid item container spacing={1} key={i} alignItems="center">
            <Grid item>
              <Typography style={{ fontWeight: 700 }}>
                {ConvertLtrRtl([
                  `${i + 1}`,
                  ".",
                  item
                ])}
              </Typography>
            </Grid>
          </Grid>
        ))}
      </Grid>
    );
  }

  return <>
    <Grid
      container
      direction="column"
      spacing={2}
      justifyContent="center"
      alignItems="center"
      alignContent="center"
      style={{
        height: "330px",
        width: "440",
      }}
    >
      <Grid item>
        {downloadAgain ? (
          <>
            <Grid container justifyContent="flex-start" spacing={1}>
              <Grid item>
                <Typography
                  variant="subtitle1"
                  style={{ fontWeight: 600, color: "#000000" }}
                >
  {t("Bot is alreday downloaded in your machine please run the bot.")}
                </Typography>
              </Grid>
            </Grid>
            <Grid item>
              <Typography
                variant="h4"
                style={{ fontWeight: 600, marginLeft: 155 }}
              >
                 {t("OR")}
              </Typography>
            </Grid>
          </>
        ) : (
          <Grid container justifyContent="flex-start" spacing={1}>
            <Grid item>
              <div className={classes.incognitoContainer}>
                <BotsIcon className={classes.incognitoIcon} />
              </div>
            </Grid>
            <Grid item>
              <Typography variant="h3" style={{ fontWeight: 600 }}>
                Bot-Rpa
              </Typography>
            </Grid>
          </Grid>
        )}
      </Grid>
      <Grid item>
        <Button
          color="primary"
          variant="contained"
          endIcon={
            <DownloadBotIcon
              style={{
                width: "16px",
                height: "16px",
                filter: getCssFilterFromHex("#FFFFFF"),
                marginTop: "-3px",
              }}
            />
          }
          onClick={onClickDownload}
          disableRipple
          id={`${props.id}_DownloadBotAgainBtn`}
        >
          {downloadAgain ? "Download Bot Again" : "Download Bot RPA"}
        </Button>
      </Grid>
      {!downloadAgain && (
        <>
          <Grid item>
            <Typography variant="subtitle2" style={{ color: "#606060" }}>
              {t("The link will open in the default browser of the system.")}
            </Typography>
          </Grid>

          <Grid item>
            <Typography
              variant="subtitle1"
              style={{ fontWeight: 600, color: "#000000" }}
            >
              {t("Download and install this to run your script on your machine.")}
            </Typography>
          </Grid>
        </>
      )}
    </Grid>
  </>;
};


