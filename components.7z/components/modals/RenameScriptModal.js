import React, { useState, useContext, useEffect } from "react";
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";

import { Grid, Typography } from "@mui/material";
import { createInstance, handleNetworkRequestError } from "../../utils/common";
import {
  
  SCRIPT,
} from "./../../config/index";
import { NotificationContext } from "../../contexts/NotificationContext";

import { useDispatch } from "react-redux";

import { useHistory } from "react-router-dom";
import {
  isContainSpecialCharacters,
 
  isContainSpecialCharactersForServiceFlow,
  isEmptyText,
  MaximumLengthText,
} from "../../utils/validations/validations";
import { useTranslation } from "react-i18next";

import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  label: {
    fontSize: "12px",
    fontWeight: 600,
    opacity: "1",
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

const RenameScriptModal = (props) => {
  const {
    editedScript,
    applicationDetails,
    folderOptions,
    isOpenFromDashboard,
  } = props;
  const { setValue } = useContext(NotificationContext);
  const dispatch = useDispatch();
  const history = useHistory();

  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [isCreating, setIsCreating] = useState(false);
  const [formHasError, setFormHasError] = useState(true);

  const [scriptName, setScriptName] = useState(makeFieldInputs(""));
  const [folderName, setFolderName] = useState(makeFieldInputs(""));

  const [tags, setTags] = useState([]);

  useEffect(() => {
    if (editedScript) {
      const { scriptName: name, tagName } = editedScript;
      setScriptName({ ...scriptName, value: name });
      setTags([...tagName]);
    }
  }, [editedScript]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";
    switch (name) {
      case "Script Name":
        errors =
          isEmptyText(value) ||
          MaximumLengthText(value, 40) ||
          isContainSpecialCharactersForServiceFlow(value);
        setScriptName({
          ...scriptName,
          value,
          error: errors || false,
          helperText: errors,
        });
        break;
      case "Folder Name":
        setFolderName({
          ...folderName,
          value,
        });
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    if (scriptName?.error || folderName?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [scriptName, folderName]);
  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    handleClose();
  };
  const onClick2 = async () => {
    const errors =
      isEmptyText(scriptName.value) ||
      MaximumLengthText(scriptName.value, 40) ||
      isContainSpecialCharacters(scriptName.value);
    if (errors) {
      setScriptName({
        ...scriptName,
        error: errors || false,
        helperText: errors,
      });
      return;
    }

    const axiosInstance = createInstance();
    setIsCreating(true);

    const projectId =
      props.selectedProject?.projectId ||
      editedScript?.projectId ||
      folderName.value;

    if (editedScript) {
      try {
        let res = await axiosInstance.put(`${SCRIPT}`, {
          projectId,
          scriptName: scriptName.value,
          tagName: tags,

          scriptId: editedScript.scriptId,
          versionName: editedScript.versionName,
          createdOn: Date.now(),
        });

        if (res.status === 200) {
          props.updateScripts(res.data.data[0]);
          setIsCreating(false);
          //creating Notification
          setValue({
            isOpen: true,
            message: res.data.message,
            notificationType: "SUCCESS",
            title: scriptName.value,
          });

          props.handleClose();
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "updation failed.",
              notificationType: "ERROR",
              title: scriptName.value,
            });
          },
        });

        setIsCreating(false);
      }
    }
  };

  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={"Rename Service Flow"}
      isProcessing={isCreating}
      Content={
        <Content
          id={props.id}
          editedScript={editedScript}
          selectedProject={props.selectedProject}
          scriptName={scriptName}
          handleChange={handleChange}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      btn1Title="Cancel"
      btn2Title={"Save"}
      onClick1={onClick1}
      onClick2={onClick2}
      btn2Disabled={formHasError}
      closeModal={handleClose}
      containerHeight={200}
      containerWidth={400}
    />
  );
};
export default RenameScriptModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {
    id,
    scriptName,

    handleChange,
  } = props;
  const classes = useStyles();

  const { t } = useTranslation();

  return (
    <>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Field
            name={t("Script Name")}
            label={t("Service Flow Name")}
            id={`${id}_ScriptName`}
            {...scriptName}
            required={true}
            // width={442}
            paddingTop={"0px"}
            onChange={handleChange}
            height={32}
          />
        </Grid>
      </Grid>
    </>
  );
};
