import React, { useState, useRef } from "react";
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import { Grid } from "@mui/material";
import CustomChip from "../../utils/CustomChip";
import { useTranslation } from "react-i18next";
const ServiceFlowDetailsModal = (props) => {
    const { isOpen, endpointDetails } = props;
    // const { isOpen } = props;

    const [open, setOpen] = useState(isOpen ? true : false);
    const handleClose = () => {
        setOpen(false);
        props.handleClose();
    };

    return (
        <ModalForm
            id={props.id}
            isOpen={open}
            title={"Rest End Point Data"}
            Content={
                <Content
                    id={props.id}
                    endpointDetails={endpointDetails}
                />
            }
            headerCloseBtn={true}
            onClickHeaderCloseBtn={handleClose}
            btn2Title="Okay"
            onClick2={handleClose}
            closeModal={handleClose}
            containerHeight={550}
            containerWidth={650}
        />
    );
};
export default ServiceFlowDetailsModal;

{
    /*Fields, content of the modal */
}
const Content = (props) => {
    const {
        id,
        endpointDetails,
    } = props;

    const { t } = useTranslation()
    const handleCopyToClipboard = (id) => {
        const textInput = document.getElementById(id);
        textInput.select();
        document.execCommand('copy');
        alert('Copied to clipboard: ' + textInput.value);
    }
    return (
        <>
            <Grid container direction={'column'} spacing={2}>
                <Grid item>
                    <Field
                        name={t("Script Name")}
                        label={t("Service Flow Name")}
                        id={`${id}_ScriptName`}
                        value={endpointDetails?.scriptName}
                        disabled={true}
                        paddingTop={"0px"}
                        height={32}
                    />
                </Grid>
                <Grid item container alignItems='flex-start' spacing={1}>

                    <Grid item xs={6}>
                        <Field
                            name={t("Folder Name")}
                            label={t("Folder Name")}
                            id={`${id}_FolderName`}
                            value={endpointDetails?.projectName || ""}
                            disabled={true}
                            paddingTop={"0px"}
                            height={32}
                        />
                    </Grid>

                    <Grid item xs={6} style={{ maxWidth: '100%' }}>
                        <CustomChip
                            id={id}
                            tags={endpointDetails?.tag || []}
                            disabled={true}
                            tag={""}
                            label={t("Tags")}
                            name="Tag"
                            height={28}

                        />

                    </Grid>
                </Grid>

                <Grid item>
                    <Field
                        name={t("Endpoint Name")}
                        label={t("End Point Name")}
                        id={`${id}_endpointName`}
                        value={endpointDetails?.endpoint || ""}
                        disabled={true}
                        paddingTop={"0px"}
                        height={32}
                        copyToClipboard={true}
                    //handleCopyToClipboard={handleCopyToClipboard}
                    />
                </Grid>

                <Grid item container alignItems='flex-start' spacing={1}>

                    <Grid item xs={6}>
                        <Field
                            name={t("Request Method")}
                            label={t("Request Method")}
                            id={`${id}_RequestMethod`}
                            value={endpointDetails?.requestMethod || "POST"}
                            disabled={true}
                            paddingTop={"0px"}
                            height={32}
                        />
                    </Grid>

                    <Grid item xs={6} >
                        <Field
                            name={t("Version")}
                            label={t("Version")}
                            id={`${id}_Version`}
                            value={endpointDetails?.versionName || ""}
                            disabled={true}
                            paddingTop={"0px"}
                            height={32}
                        />

                    </Grid>
                </Grid>
                {/*<Grid item>
                    <Field
                        name={t("RequestQueryParameter")}
                        label={t("Request Query Parameter")}
                        id={`${id}_requestQueryParameter`}
                        value={endpointDetails?.requestQueryParameters || ""}
                        disabled={true}
                        paddingTop={"0px"}
                        height={32}
                    />
    </Grid>*/}
                <Grid item>
                    <Field
                        name={t("RequestBody")}
                        label={t("Request Body")}
                        id={`${id}_requestbody`}
                        value={JSON.stringify(endpointDetails?.requestBody, null, 2) || ""}
                        disabled={true}
                        paddingTop={"0px"}
                        multiline={true}
                        copyToClipboard={true}
                    //  handleCopyToClipboard={handleCopyToClipboard}
                    />
                </Grid>

                {/*<Grid item>
                    <Field
                        name={t("Authorization")}
                        label={t("Authorization")}
                        id={`${id}_Authorization`}
                        value={endpointDetails?.autorization || ""}
                        disabled={true}
                        paddingTop={"0px"}
                        height={32}
                    />
</Grid>*/}
            </Grid>
        </>
    );
};

/*const endpointDetails1 = {
    "publishedBy": 1,
    "requestQueryParameters": "executionId",
    "packagename": "mypkg_new",
    "description": "",
    "customLibs": false,
    "versionName": "V1.0",
    "scriptId": 1081,
    "versionId": 1089,
    "endpoint": "http://192.168.162.74:8080/serviceflow/execution/V1.0",
    "createdBy": 1,
    "requestBody": {
        "serviceFlowId": 24,
        "inputParameters": [
            {
                "employees": [
                    { "firstName": "John", "lastName": "Doe" },
                    { "firstName": "Anna", "lastName": "Smith" },
                    { "firstName": "Peter", "lastName": "Jones" }
                ]
            }
        ]
    },
    "scriptName": "ExcelNewCheck",
    "ccvariables": [],
    "tag": [],
    "projectName": "NewFolderDarta",
    "projectId": 1017,
    "status": 1
}*/
