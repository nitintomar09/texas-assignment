import React, { useState, useContext, useEffect } from "react";
import makeStyles from '@mui/styles/makeStyles';
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import { FolderIcon } from "../../utils/AllImages";
import { MOVE } from "./../../config/index";
import { NotificationContext } from "../../contexts/NotificationContext";
import {
  createInstance,
  handleNetworkRequestError,
} from "./../../utils/common";
import { useHistory } from "react-router-dom";
import {
  isEmptyText,
  MaximumLengthText,
} from "../../utils/validations/validations";
import { Typography } from "@mui/material";
import { useTranslation } from "react-i18next";
import { ConvertLtrRtl } from "../common";

const useStyles = makeStyles(() => ({
  container: {
    marginTop: "4rem",
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

const MoveToProjectModal = (props) => {
  const { setValue } = useContext(NotificationContext);
  const history = useHistory();

  const { projectList, selectedScript, updateScripts, fromDashboard } = props;
  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [isMoving, setIsMoving] = useState(false);
  const [formHasError, setFormHasError] = useState(true);

  const [projectName, setProjectName] = useState(makeFieldInputs(""));
  const [comment, setComment] = useState(makeFieldInputs(""));
  const [isWantToMove, setIsWantToMove] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";

    switch (name) {
      case "Project Name":
        errors = isEmptyText(value);
        setProjectName({
          ...projectName,
          value,
          error: errors,
          helperText: errors,
        });
        break;
      case "Comment":
        errors = MaximumLengthText(value, 2000);
        setComment({
          ...comment,
          value,
          error: errors,
          helperText: errors,
        });
        break;
      default:
        break;
    }
  };
  useEffect(() => {
    if (projectName?.error || comment?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [projectName, comment]);
  const validateFields = () => {
    const projectNameErrors = isEmptyText(projectName.value);
    if (projectNameErrors) {
      setProjectName({
        ...projectName,
        error: projectNameErrors,
        helperText: projectNameErrors,
      });
    }
    const desErr = MaximumLengthText(comment.value, 2000);
    if (desErr) {
      setComment({
        ...comment,
        error: desErr,
        helperText: desErr,
      });
    }
    if (desErr || projectNameErrors) {
      return false;
    } else {
      return true;
    }
  };
  /*****************************************************************************************
   * @author asloob_ali BUG ID : 104667 Description : 104667 - Script: Move To functionality is not working
   *  Reason:script move functionality was not discussed/implemented.
   * Resolution : implemented script move functionality.
   *  Date : 01/03/2022             ****************************************/
  const handleClose = () => {
    setOpen(false);

    props.handleClose();
  };
  const onClick1 = () => {
    handleClose();
  };
  const onClick2 = async () => {
    if (!validateFields()) {
      return;
    }
    setIsWantToMove(true);
  };

  const onMove = async () => {
    const axiosInstance = createInstance();
    setIsMoving(true);
    const proj = projectList.find(
      (projectItem) => projectItem.projectId === +projectName.value
    );
    try {
      const { scriptId, scriptName } = selectedScript;
      /* var res = await axiosInstance.post(
        `${MOVE}/${scriptName}/${scriptId}/${projectName.value}`
      );*/
      var res = await axiosInstance.post(`${MOVE}`, {
        scriptName,
        scriptId,
        projectId: +projectName.value,
        comments: comment.value || "",
      });

      if (res.status === 200) {
        if (fromDashboard) {
          if (proj) {
            updateScripts({ scriptId, projectName: proj?.projectName });
          }
        } else {
          updateScripts({ scriptId, lastVersion: true });
        }

        setIsMoving(false);

        //creating Notification
        setValue({
          isOpen: true,
          message: res.data?.message || "moved successfully.",
          notificationType: "SUCCESS",
          title: selectedScript?.scriptName || "",
        });
        props.handleClose();
      }
    } catch (error) {
      setIsMoving(false);

      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setValue({
            isOpen: true,
            message: errMsg || "failed to move.",
            notificationType: "ERROR",
            title: "",
          });
        },
      });
    }
  };
  const cancelMove = () => {
    setIsWantToMove(false);
  };
  const goAheadMove = () => {
    onMove();
  };
  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={"Move To"}
      isProcessing={isMoving}
      Content={
        <Content
          id={props.id}
          options={
            projectList
              ? projectList.filter(
                (item) => item.projectId !== selectedScript.projectId
              )
              : []
          }
          projectName={projectName}
          cancelMove={cancelMove}
          goAheadMove={goAheadMove}
          isWantToMove={isWantToMove}
          comment={comment}
          selectedScript={selectedScript}
          handleChange={handleChange}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      btn1Title="Cancel"
      btn2Title={"Move Service Flow"}
      onClick1={onClick1}
      onClick2={onClick2}
      btn2Disabled={formHasError}
      closeModal={handleClose}
      containerHeight={347}
      containerWidth={490}
    />
  );
};
export default MoveToProjectModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {
    id,
    options,
    projectName,
    comment,
    handleChange,
    selectedScript,
    isWantToMove,
    cancelMove,
    goAheadMove,
  } = props;
  const { t } = useTranslation()
  return (
    <>
      <div>
        <Field
          id={`${id}_ProjectName`}
          dropdown={true}
          name={t("Project Name")}
          
          label={t("Folder Name")}
          {...projectName}
          required={true}
          paddingTop={"0px"}
          onChange={handleChange}
          icon={FolderIcon}
          options={options.map((proj) => ({
            name: proj.projectName,
            value: proj.projectId,
          }))}
        />
        <Field
          label={t("Comment(Optional)")}
          id={`${id}_Comment(Optional)`}
          name="Comment"
          {...comment}
          multiline={true}
          onChange={handleChange}
        />
        <ModalForm
          title={t("Move Service Flow")}
          id={`${id}_MoveScript`}
          containerHeight={150}
          isOpen={isWantToMove}
          closeModal={cancelMove}
          Content={
            <Typography>
              {ConvertLtrRtl([
                t("Are You Sure, you want to move"),
                selectedScript?.scriptName || "",
                t("to the"),
                options.find((proj) => proj.projectId === +projectName.value)
                  ?.projectName || ""
              ])}
             
            </Typography>
          }
          btn1Title={t("No")}
          onClick1={cancelMove}
          btn2Title={t("Yes")}
          onClick2={goAheadMove}
        />
      </div>
    </>
  );
};
