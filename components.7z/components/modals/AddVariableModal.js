import React, { useState, useEffect, useContext, useRef } from "react";
import { useHistory } from "react-router-dom";
import makeStyles from '@mui/styles/makeStyles';
import { Typography, Button, Grid, CircularProgress } from "@mui/material";
import ModalForm from "../../utils/modalForm";
import { Check } from "@mui/icons-material";
import Field from "../../utils/field";
import {
  createInstance,
  generateUniqueId,
  handleNetworkRequestError,
} from "../../utils/common";
import { VARIABLES } from "../../config/index";
import CheckboxField from "../script-editor/PropertyWindow/PropertyFields/CheckboxField";
import { NotificationContext } from "../../contexts/NotificationContext";
import { VariablesContext } from "../../contexts/VariablesListContext";
import { useSelector } from "react-redux";
import LoadingIndicator from "../../utils/loadingIndicator";
import { getCssFilterFromHex } from "../../utils/HexToFilter";
import { EditIcon, DeleteIcon, ExpandDataIcon } from "../../utils/AllImages";
import {
  isEmptyText,
  MaximumLengthText,
  MinimumLengthText,
  onlyLettersAndUnderscore,
  atleastContainsACharacter,
} from "../../utils/validations/validations";
import { useTranslation } from "react-i18next";

const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};
const AddVariableModal = (props) => {
  const [open, setOpen] = useState(props.isOpen ? true : false);

  const history = useHistory();
  const varFieldRef = useRef(null);
  const {
    OnSuccess = () => {
      console.log("OnSucces() not provide");
    },
  } = props;

  const [allVariablesOrg, setAllVariablesOrg] = useState([]);
  const [allVariables, setAllVariables] = useState([]);
  const [isCreateVariable, setIsCreateVariable] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  const [variableName, setVariableName] = useState(makeFieldInputs(""));
  const [variableDefaultValue, setVariableDefaultValue] = useState("");
  const [variableType, setVariableType] = useState(
    makeFieldInputs(props.varType || 1)
  );
  const [isFixedChecked, setIsFixedChecked] = useState(false);
  const [isDynamicChecked, setIsDynamicChecked] = useState(false);
  const [isMaskChecked, setIsMaskedChecked] = useState(false);
  const [isEditingVar, setIsEditingVar] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [formHasError, setFormHasError] = useState(true);
  const [sortType, setSortType] = useState("Asc");
  const [expandedVars, setExpandedVars] = useState([]);

  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const versionId = scriptValues && scriptValues.versionId;
  const scriptId = scriptValues && scriptValues.scriptId;

  const { setValue } = useContext(NotificationContext);
  const { setAllVariables: setAllVariablesInContext } =
    useContext(VariablesContext);

  const getAllVariables = async () => {
    const axiosInstance = createInstance();
    if (versionId) {
      try {
        let res = await axiosInstance.get(`${VARIABLES}/${versionId}`);

        setAllVariablesOrg(res.data.data ? res.data.data : []);
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "",
              title: "",
              notificationType: "ERROR",
            });
          },
        });
      }
    } else {
      console.log("version id is not available", versionId);
    }
  };
  {
    /*****************************************************************************************
     * @author asloob_ali BUG ID :  108344  Variable Mapping through property window:Variable is not mapping properly in input properties
     * Reason:logic newly created variable was overriding the previous all variables list.
     *  Resolution :fixed, now adding new var into previous variables list.
     *  Date : 22/04/2022             ***************************************************************************************/
  }
  useEffect(() => {
    if (versionId) {
      getAllVariables();
    }
  }, [versionId]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";

    switch (name) {
      case "variableName":
        errors =
          isEmptyText(value) ||
          onlyLettersAndUnderscore(value) ||
          atleastContainsACharacter(value) ||
          MinimumLengthText(value, 2) ||
          MaximumLengthText(value, 40);
        setVariableName({
          ...variableName,
          value,
          error: errors ? true : false,
          helperText: errors,
        });
        break;

      case "variableType":
        setVariableType({ ...variableType, value });
        break;
      case "variableDefaultValue":
        setVariableDefaultValue(value);
        break;

      case "fixed":
        setIsFixedChecked(!isFixedChecked);
        break;
      case "dynamic":
        setIsDynamicChecked(!isDynamicChecked);
        break;
      case "mask":
        setIsMaskedChecked(!isMaskChecked);
        break;
      default:
        break;
    }
  };

  const expandVar = (variableId) => {
    const newExpandedVars = [...expandedVars];
    const isAlreadyExpanded = expandedVars.findIndex(
      (item) => item === variableId
    );
    if (isAlreadyExpanded !== -1) {
      newExpandedVars.splice(isAlreadyExpanded, 1);
    } else {
      newExpandedVars.push(variableId);
    }
    setExpandedVars(newExpandedVars);
  };
  const onCancel = () => {
    setIsEditingVar(null);

    setIsCreateVariable(false);
    setVariableName(makeFieldInputs(""));
    setVariableDefaultValue("");
    setVariableType({ ...variableType, value: props.varType || "" });
    setIsFixedChecked(false);
    setIsDynamicChecked(false);
    setIsMaskedChecked(false);
  };
  useEffect(() => {
    if (variableName?.error || variableType?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [variableName, variableType]);
  const validateFields = () => {
    const varNameErrors =
      isEmptyText(variableName.value) ||
      onlyLettersAndUnderscore(variableName.value) ||
      atleastContainsACharacter(variableName.value) ||
      MinimumLengthText(variableName.value, 2) ||
      MaximumLengthText(variableName.value, 40);

    //converting int to string ant then check value
    const varTypeErrors = isEmptyText("" + variableType.value);
    if (varNameErrors) {
      setVariableName({
        ...variableName,
        error: varNameErrors ? true : false,
        helperText: varNameErrors,
      });
    }
    if (varTypeErrors) {
      setVariableType({
        ...variableType,
        error: varTypeErrors ? true : false,
        helperText: varTypeErrors,
      });
    }

    return varNameErrors || varTypeErrors ? false : true;
  };
  const onCreate = async () => {
    if (!validateFields()) {
      return;
    }
    const newArrOfCb = [];
    if (isDynamicChecked) {
      newArrOfCb.push("D");
    }
    if (isFixedChecked) {
      newArrOfCb.push("F");
    }
    if (isMaskChecked) {
      newArrOfCb.push("M");
    }
    setIsProcessing(true);

    const axiosInstance = createInstance();

    if (isEditingVar) {
      let variableId = isEditingVar.variableId;
      let variablePreviosValue = allVariables.find(
        (varObj) => varObj.variableId === variableId
      );
      let newVariables = [...allVariables];
      let newVariablesOrg = [...allVariablesOrg];
      let json = {
        scriptId: +scriptId,
        versionId: +versionId,
        variableName: variableName.value,
        variableObjType: props.varType ? +props.varType : null,
        varDefaultValue: variableDefaultValue,
        variableType: isEditingVar.variableType,
        valueState: newArrOfCb.length > 0 ? newArrOfCb : [],
      };

      let variableIndex = allVariables.findIndex(
        (varObj) => varObj.variableId === variableId
      );
      let variableIndexOrg = allVariablesOrg.findIndex(
        (varObj) => varObj.variableId === variableId
      );

      newVariables.splice(variableIndex, 1, {
        ...json,
        variableId,
      });
      newVariablesOrg.splice(variableIndexOrg, 1, {
        ...json,
        variableId,
      });
      setAllVariables(newVariables);
      setAllVariablesOrg(newVariablesOrg);

      try {
        let res = await axiosInstance.put(`${VARIABLES}/${variableId}`, {
          ...json,
        });

        if (res.status === 200) {
          setValue({
            isOpen: true,
            notificationType: "SUCCESS",
            message: res.data["message"] || "updated Succefully.",
            title: variableName.value,
          });
          setAllVariablesInContext({ allVariables: newVariablesOrg });
          setIsProcessing(false);

          setIsEditingVar(null);

          setIsCreateVariable(false);
          setVariableName(makeFieldInputs(""));
          setVariableDefaultValue("");
          setVariableType(makeFieldInputs(props.varType || ""));
          setIsFixedChecked(false);
          setIsDynamicChecked(false);
          setIsMaskedChecked(false);
        }
      } catch (error) {
        console.log(error.response);
        setIsProcessing(false);

        newVariables.splice(variableIndex, 1, variablePreviosValue);
        setAllVariables(newVariables);
        newVariablesOrg.splice(variableIndexOrg, 1, variablePreviosValue);
        setAllVariablesOrg(newVariablesOrg);
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              notificationType: "ERROR",
              message: errMsg || "update failed.",
              title: variableName?.value,
            });
          },
        });
      }
    } else {
      let json = {
        scriptId: +scriptId,
        versionId: +versionId,
        variableName: variableName.value,
        // variableObjType: variableType.value ? +variableType.value : null,
        variableObjType: props.varType ? +props.varType : null,
        varDefaultValue: variableDefaultValue,
        variableType: isCreateVariable ? "V" : "C",
        valueState: newArrOfCb.length > 0 ? newArrOfCb : [],
      };

      try {
        let res = await axiosInstance.post(`${VARIABLES}`, {
          ...json,
        });

        if (res.status === 200) {
          let newVariables = [
            { ...json, variableId: res.data.data[0]["variableId"] },
            ...allVariables,
          ];
          setAllVariables(newVariables);
          let newVariablesOrg = [
            { ...json, variableId: res.data.data[0]["variableId"] },
            ...allVariablesOrg,
          ];

          setAllVariablesOrg(newVariablesOrg);
          setAllVariablesInContext({ allVariables: newVariablesOrg });
          setValue({
            isOpen: true,
            notificationType: "SUCCESS",
            message: res.data["message"] || "created Succefully.",
            title: variableName?.value,
          });

          setIsProcessing(false);

          setIsCreateVariable(false);
          setVariableName(makeFieldInputs(""));
          setVariableDefaultValue("");
          setVariableType(makeFieldInputs(props.varType || ""));
          setIsFixedChecked(false);
          setIsDynamicChecked(false);
          setIsMaskedChecked(false);
        }
      } catch (error) {
        console.log(error.response);
        setIsProcessing(false);

        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              notificationType: "ERROR",
              message: errMsg || "creation failed.",
              title: variableName.value,
            });
          },
        });
      }
    }
  };

  const handleDelete = async (variableId) => {
    const axiosInstance = createInstance();

    if (variableId) {
      try {
        let res = await axiosInstance.delete(`${VARIABLES}/${variableId}`);

        if (res.status === 200) {
          let variable = allVariables.find(
            (variableObj) => variableObj.variableId === variableId
          );
          let newVariables = allVariables.filter(
            (variable1) => variable1.variableId !== variableId
          );
          setAllVariables(newVariables);
          let newVariablesOrg = allVariablesOrg.filter(
            (variable2) => variable2.variableId !== variableId
          );
          setAllVariablesOrg(newVariablesOrg);
          setValue({
            isOpen: true,
            notificationType: "SUCCESS",
            message: res.data["message"]
              ? res.data["message"]
              : "deleted successfully",
            title: variable && variable.variableName,
          });
          setAllVariablesInContext({ allVariables: newVariablesOrg });
        }
      } catch (error) {
        console.log(error);
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              notificationType: "ERROR",
              message: errMsg || "deletion failed.",
              title: "",
            });
          },
        });
      }
    } else {
      console.log("invalid variableId", variableId);
    }
  };
  const handleEdit = (variable) => {
    if (variable) {
      setVariableName({ value: variable.variableName });
      setVariableType(makeFieldInputs(variable.variableObjType));
      setVariableDefaultValue(variable.varDefaultValue);
      if (variable.valueState.indexOf("F") !== -1) {
        setIsFixedChecked(true);
      }
      if (variable.valueState.indexOf("D") !== -1) {
        setIsDynamicChecked(true);
      }
      if (variable.valueState.indexOf("M") !== -1) {
        setIsMaskedChecked(true);
      }
      setIsEditingVar(variable);
      setIsCreateVariable(false);
    }
  };
  const handleClose = () => {
    setOpen(false);
    if (allVariables.length > 0) {
      OnSuccess(allVariables[0]);
    }
    props.handleClose();
  };
  const onClick1 = () => {
    handleClose();
  };

  const onClick2Header = () => {
    setIsCreateVariable(true);
    setIsEditingVar(false);
  };

  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title="Variables"
      Content={
        <Content
          id={props.id}
          isLoading={isLoading}
          handleChange={handleChange}
          handleDelete={handleDelete}
          ref={varFieldRef}
          handleEdit={handleEdit}
          allVariables={allVariables}
          allVariablesOrg={allVariablesOrg}
          isCreateVariable={isCreateVariable}
          isEditingVar={isEditingVar}
          variableType={variableType}
          variableName={variableName}
          variableDefaultValue={variableDefaultValue}
          onCreate={onCreate}
          onCancel={onCancel}
          isFixedChecked={isFixedChecked}
          isDynamicChecked={isDynamicChecked}
          isMaskChecked={isMaskChecked}
          formHasError={formHasError}
          onClick2Header={onClick2Header}
          expandedVars={expandedVars}
          expandVar={expandVar}
          isProcessing={isProcessing}
          varType={props.varType}
        />
      }
      btn1Title="Close"
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      onClick1={onClick1}
      closeModal={handleClose}
      containerHeight={350}
      containerWidth={1085}
      overflowHidden={true}
    />
  );
};
export default AddVariableModal;

{
  /* content of the modal */
}
const useStyles = makeStyles((theme) => ({
  header: {
    marginTop: "10px",
    paddingLeft: "26px",
    height: "32px",
    paddingRight: "14px",
    backgroundColor: "#F0F0F0",
  },
  varRow: {
    paddingLeft: "26px",

    height: "40px",
    marginBottom: "8px",
    backgroundColor: "#FFFFFF",
    paddingRight: "26px",
    transition: "all 100ms ease-in",

    "&:hover": {
      boxShadow: "0px 3px 6px #00000029",
    },
  },
  varRowEdit: {
    paddingLeft: "20px",

    minHeight: "40px",
    marginBottom: "8px",
    marginTop: "8px",
    backgroundColor: "#0072C61A",
    paddingRight: "26px",
    transition: "all 100ms ease-in",

    "&:hover": {
      boxShadow: "0px 3px 6px #00000029",
    },
  },
  sortIcon: { width: "16px", height: "16px" },

  sticky: {
    position: "fixed",

    width: "100%",
    paddingTop: "100px",
  },
  item: {
    paddingTop: "10px",
    paddingBottom: "10px",
    fontSize: "12px",
  },

  item2: {
    paddingTop: "5px",
    paddingBottom: "5px",
    fontSize: "12px",
  },
  fontBold: {
    color: "#000000",
    fontWeight: 600,
    fontSize: "12px",
  },
  editIcon: {
    height: "16px",
    width: "16px",

    filter: `${getCssFilterFromHex("#0072C6")}`,
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  deleteBtn: {
    height: "16px",
    width: "16px",
    filter: `${getCssFilterFromHex("#D42323")}`,
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  scrollDiv: {
    height: "170px",
    width: "100%",
    "&:hover": {
      overflowX: "hidden",
      overflowY: "auto",
    },
  },
  sort: {
    height: "28px",
    padding: "5px",
    borderRadius: "2px",
    background: "#FFFFFF 0% 0% no-repeat padding-box",
    border: "1px solid #C4C4C4",
    cursor: "pointer",
  },

  icon: {
    width: "12px",
    height: "10px",
    marginTop: "6px",
  },
  rotatedIcon: {
    width: "12px",
    height: "10px",
    marginTop: "6px",
    transform: "rotate(180deg)",
  },
  tools: {
    marginTop: "16px",
  },
  margin: {
    margin: `${theme.spacing(1)}`,
  },
  expandIcon: {
    marginTop: "16px",
    cursor: "pointer",
  },
}));

const Content = React.forwardRef((props, ref) => {
  const {
    handleChange,
    allVariables,

    allVariablesOrg,
    variableName,
    isCreateVariable,
    isEditingVar,

    variableType,
    variableDefaultValue,
    onCreate,
    onCancel,
    isDynamicChecked,
    isFixedChecked,

    handleDelete,
    handleEdit,
    isLoading,
    formHasError,
    onClick2Header,
    expandedVars,
    expandVar,
    isProcessing,
    varType,
    id,
  } = props;
  const classes = useStyles();
const {t} = useTranslation()
  const getType = (type) => {
    let variableType = null;
    switch (type) {
      case 2:
        variableType = "Integer";
        break;
      case 1:
        variableType = "Text";
        break;
      case 8:
        variableType = "Float";
        break;
      case 4:
        variableType = "Date";
        break;
      case 3:
        variableType = "Boolean";
        break;
      case 5:
        variableType = "List";
        break;
      case 7:
        variableType = "DataRecord";
        break;
      case 6:
        variableType = "DataTable";
        break;
      case 9:
        variableType = "DateTime";
        break;
      case 10:
        variableType = "MailMessage";
        break;
      case 11:
        variableType = "JSONObject";
        break;
      case 12:
        variableType = "JSONArray";
        break;
      default:
        break;
    }
    return variableType;
  };

  const truncateString = (str) => {
    if (str) {
      return str.trim().length > 38 ? str.substring(0, 34) + ".." : str;
    }
    return "";
  };

  if (isLoading) {
    return <LoadingIndicator />;
  }
  return (
    <>
      <div className={classes.header}>
        <Grid container alignItems="center">
          <Grid item xs={3}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <Typography
                  className={classes.item2 + " " + classes.fontBold}
                  style={{ cursor: "pointer" }}
                >
                  {t("Variable Name")}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={2}>
            <Grid container spacing={1} alignItems="center">
              <Grid item>
                <Typography
                  className={classes.item2 + " " + classes.fontBold}
                  style={{ marginLeft: "-6px" }}
                >
                  {t("Type")}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={1}>
            <Typography
              className={classes.item2 + " " + classes.fontBold}
              style={{ marginLeft: "-16px" }}
            >
              {t("Fixed")}
            </Typography>
          </Grid>
          <Grid item xs={1}>
            <Typography
              className={classes.item2 + " " + classes.fontBold}
              style={{ marginLeft: "-12px" }}
            >
              {t("Dynamic")}
            </Typography>
          </Grid>

          <Grid item xs={3}>
            <Typography
              className={classes.item2 + " " + classes.fontBold}
              style={{ marginLeft: "-20px" }}
            >
              {t("Default Value")}
            </Typography>
          </Grid>
          {!isCreateVariable && !isEditingVar && allVariables.length === 0 && (
            <Grid item style={{ marginLeft: "auto", marginTop: "2px" }} xs={1}>
              <Button
                variant="contained"
                size="small"
                color="primary"
                onClick={() => onClick2Header()}
                style={{ height: "28px" }}
                id={`${id}_+VariableBtn`}
                disableRipple
              >
                {t("+Variable")}
              </Button>
            </Grid>
          )}
        </Grid>
      </div>

      {isCreateVariable && (
        <>
          <Grid
            container
            direction="column"
            className={classes.varRowEdit}
            style={{ paddingTop: "5px" }}
          >
            <Grid item container direction="row">
              <Grid
                item
                xs={3}
                style={{
                  marginTop: "-8px",
                }}
              >
                <Field
                  id={`${id}_VariableName`}
                  paddingTop={"6px"}
                  name="variableName"
                  value={variableName.value}
                  {...variableName}
                  width={162}
                  onChange={handleChange}
                  height={28}
                  autoComplete="off"
                />
              </Grid>

              <Grid
                item
                xs={2}
                style={{
                  marginRight: "8px",
                  marginLeft: "-8px",
                  marginTop: "-8px",
                }}
              >
                <Field
                  id={`${id}_VariableType`}
                  paddingTop={"6px"}
                  name="variableType"
                  // value={variableType.value}
                  {...variableType}
                  value={
                    typeOptions.find((item) => item.value === +varType).name
                  }
                  // dropdown={true}
                  readOnly={true}
                  options={typeOptions}
                  onChange={handleChange}
                  startAdornment={
                    <div
                      item
                      style={{
                        height: "16px",
                        width: "16px",
                        border: "1px solid #C4C4C4",
                      }}
                    ></div>
                  }
                  width={160}
                  height={28}
                />
              </Grid>
              <Grid item xs={1}>
                <CheckboxField
                  id={`${id}_FixedCheckbox`}
                  styleObj={{ paddingTop: "10px" }}
                  value={isFixedChecked}
                  onChange={handleChange}
                  name="fixed"
                  disabled={isDynamicChecked}
                />
              </Grid>
              <Grid item xs={1} style={{ marginLeft: "5px" }}>
                <CheckboxField
                  id={`${id}_DynamicCheckbox`}
                  styleObj={{ paddingTop: "10px" }}
                  value={isDynamicChecked}
                  onChange={handleChange}
                  name="dynamic"
                  disabled={isFixedChecked}
                />
              </Grid>

              <Grid
                item
                style={{
                  marginTop: "-8px",
                  marginLeft: "-16px",
                }}
                xs={3}
              >
                <Field
                  id={`${id}_variableDefaultType`}
                  paddingTop={"6px"}
                  type={
                    +varType === 4
                      ? "date"
                      : +varType === 9
                      ? "datetime-local"
                      : "text"
                  }
                  multiline={
                    +varType === 5 ||
                    +varType === 6 ||
                    +varType === 7 ||
                    +varType === 11 ||
                    +varType === 12
                  }
                  name="variableDefaultValue"
                  value={variableDefaultValue}
                  width={221}
                  height={28}
                  onChange={handleChange}
                  helperText={
                    +varType === 5 ? "Write `,` Separated Values." : null
                  }
                />
              </Grid>
              <Grid
                item
                xs
              //  style={{ marginLeft: isProcessing ? "40px" : "68px" }}
              >
                <Grid container direction="row" spacing={1} alignItems="center">
                  <Grid item>
                    <Button
                      variant="outlined"
                      size="small"
                      color="primary"
                      onClick={() => onCancel()}
                      style={{
                        fontWeight: 600,
                        backgroundColor: "#FFFFFF",
                      }}
                      disableTouchRipple
                      disableRipple
                      className={classes.margin}
                      id={`${id}_CancelBtn`}
                    >
                      Cancel
                    </Button>
                  </Grid>
                  <Grid item>
                    {isProcessing ? (
                      <Button
                        variant="contained"
                        size="small"
                        color="primary"
                        style={{
                          fontWeight: 600,
                        }}
                        disableRipple
                      >
                        <CircularProgress
                          // color="#FFFFFF"
                          style={{
                            height: "15px",
                            width: "15px",
                            marginRight: "8px",
                            color:"#FFFFFF"
                          }}
                        ></CircularProgress>

                        {isEditingVar ? "Update" : "Add"}
                      </Button>
                    ) : (
                      <Button
                        variant="contained"
                        size="small"
                        color="primary"
                        onClick={() => onCreate()}
                        style={{
                          fontWeight: 600,
                        }}
                        disabled={formHasError}
                        disableTouchRipple
                        disableRipple
                        className={classes.margin}
                        id={`${id}_
                        ${isEditingVar ? "Update" : "Add"}Btn`}
                      >
                        {isEditingVar ? "Update" : "Add"}
                      </Button>
                    )}
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </>
      )}

      {allVariablesOrg.length > 0 ? (
        <div className={classes.scrollDiv}>
          {allVariables.length > 0 && (
            <Grid container direction="column">
              {allVariables.map((variable, index) =>
                isEditingVar &&
                isEditingVar.variableId === variable.variableId ? (
                  <Grid
                    container
                    direction="column"
                    spacing={1}
                    className={classes.varRowEdit}
                  >
                    <Grid item container direction="row">
                      <Grid item xs={3} style={{ marginTop: "-8px" }}>
                        <Field
                          id={`${props.id}_VariableName_${generateUniqueId()}`}
                          paddingTop={"6px"}
                          name="variableName"
                          value={variableName.value}
                          {...variableName}
                          width={162}
                          onChange={handleChange}
                          height={28}
                          autoComplete="off"
                        />
                      </Grid>
                      <Grid
                        item
                        xs={2}
                        style={{
                          marginRight: "8px",
                          marginLeft: "-8px",
                          marginTop: "-8px",
                        }}
                      >
                        <Field
                          id={`${props.id}_VariableType_${generateUniqueId()}`}
                          paddingTop={"6px"}
                          name="variableType"
                          {...variableType}
                          value={
                            typeOptions.find((item) => item.value === +varType)
                              .name
                          }
                          readOnly={true}
                          onChange={handleChange}
                          startAdornment={
                            <div
                              item
                              style={{
                                height: "16px",
                                width: "16px",
                                border: "1px solid #C4C4C4",
                              }}
                            ></div>
                          }
                          width={160}
                          height={28}
                        />
                      </Grid>
                      <Grid item xs={1}>
                        <CheckboxField
                          id={`${
                            props.id
                          }_fixedCheckbox_${generateUniqueId()}}`}
                          styleObj={{ paddingTop: "10px" }}
                          value={isFixedChecked}
                          onChange={handleChange}
                          name="fixed"
                          disabled={isDynamicChecked}
                        />
                      </Grid>
                      <Grid item xs={1} style={{ marginLeft: "5px" }}>
                        <CheckboxField
                          id={`${
                            props.id
                          }_dynamicCheckbox_${generateUniqueId()}}`}
                          styleObj={{ paddingTop: "10px" }}
                          value={isDynamicChecked}
                          onChange={handleChange}
                          name="dynamic"
                          disabled={isFixedChecked}
                        />
                      </Grid>

                      <Grid
                        item
                        style={{
                          marginTop: "-8px",
                          marginRight: "-15px",
                          marginLeft: "-16px",
                        }}
                        xs={3}
                      >
                        <Field
                          id={`${props.id}_defaultValue_${generateUniqueId()}}`}
                          paddingTop={"6px"}
                          type={
                            +varType === 4
                              ? "date"
                              : +varType === 9
                              ? "datetime-local"
                              : "text"
                          }
                          multiline={
                            +varType === 5 ||
                            +varType === 6 ||
                            +varType === 7 ||
                            +varType === 11 ||
                            +varType === 12
                          }
                          name="variableDefaultValue"
                          value={variableDefaultValue}
                          width={221}
                          height={28}
                          onChange={handleChange}
                          helperText={
                            +varType === 5
                              ? "Write `,` Separated Values."
                              : null
                          }
                        />
                      </Grid>

                      <Grid
                        item
                        xs
                    // style={{ marginLeft: isProcessing ? "40px" : "64px" }}
                      >
                        <Grid
                          container
                          direction="row"
                          spacing={1}
                          alignItems="center"
                        >
                          <Grid item>
                            <Button
                              variant="outlined"
                              size="small"
                              color="primary"
                              onClick={() => onCancel()}
                              style={{
                                fontWeight: 600,
                                backgroundColor: "#FFFFFF",
                              }}
                              disableTouchRipple
                              disableRipple
                              className={classes.margin}
                              id={`${props.id}_CancelBtn_${generateUniqueId()}`}
                            >
                              {t("Cancel")}
                            </Button>
                          </Grid>
                          <Grid item>
                            {isProcessing ? (
                              <Button
                                variant="contained"
                                size="small"
                                color="primary"
                                style={{
                                  fontWeight: 600,
                                }}
                                disableTouchRipple
                                disableRipple
                              >
                                <CircularProgress
                                  // color="#FFFFFF"
                                  style={{
                                    height: "15px",
                                    width: "15px",
                                    marginRight: "8px",
                                    color:"#FFFFFF"
                                  }}
                                ></CircularProgress>

                                {isEditingVar ? t("Update") : t("Add")}
                              </Button>
                            ) : (
                              <Button
                                variant="contained"
                                size="small"
                                color="primary"
                                onClick={() => onCreate()}
                                style={{
                                  fontWeight: 600,
                                }}
                                disabled={formHasError}
                                disableTouchRipple
                                disableRipple
                                className={classes.margin}
                                id={`${props.id}_${
                                  isEditingVar ? "Update" : "Add"
                                }_${generateUniqueId()}`}
                              >
                                {isEditingVar ? t("Update") : t("Add")}
                              </Button>
                            )}
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                ) : (
                  <Grid
                    item
                    container
                    direction="row"
                    alignItems="center"
                    key={variable.variableName}
                    className={classes.varRow}
                  >
                    <Grid item xs={3} title={variable.variableName || ""}>
                      <Typography className={classes.item}>
                        {truncateString(variable.variableName || "")}
                      </Typography>
                    </Grid>
                    <Grid item container alignItems="center" spacing={1} xs={2}>
                      <Grid
                        item
                        style={{
                          height: "16px",
                          width: "16px",
                          border: "1px solid #C4C4C4",
                          //  marginLeft: "8px",
                        }}
                      ></Grid>
                      <Grid item>
                        <Typography>
                          {getType(variable.variableObjType)}
                        </Typography>
                      </Grid>
                    </Grid>
                    <Grid item xs={1}>
                      {variable.valueState &&
                        variable.valueState.indexOf("F") !== -1 && (
                          <Check htmlColor="#0072C6" />
                        )}
                    </Grid>
                    <Grid item xs={1}>
                      {variable.valueState &&
                        variable.valueState.indexOf("D") !== -1 && (
                          <Check htmlColor="#0072C6" />
                        )}
                    </Grid>

                    <Grid
                      item
                      xs={3}
                      title={variable.varDefaultValue || ""}
                      style={{ position: "relative" }}
                    >
                      <Grid container spacing={1}>
                        {expandedVars.includes(variable.variableId) ? (
                          <Grid
                            item
                            style={{
                              zIndex: 1,
                              position: "absolute",
                              backgroundColor: "#FFFFFF",
                              marginTop: "-8px",
                            }}
                          >
                            <Typography>
                              <pre>{variable.varDefaultValue}</pre>
                            </Typography>
                          </Grid>
                        ) : (
                          <Grid item>
                            <Typography className={classes.item}>
                              {truncateString(variable.varDefaultValue || "")}
                            </Typography>
                          </Grid>
                        )}
                        {variable.varDefaultValue &&
                          [5, 6, 7, 11, 12].includes(
                            variable.variableObjType
                          ) && (
                            <Grid
                              item
                              style={{
                                zIndex: expandedVars.includes(
                                  variable.variableId
                                )
                                  ? 5
                                  : 1,
                                marginLeft: expandedVars.includes(
                                  variable.variableId
                                )
                                  ? "-10px"
                                  : "0px",
                                marginTop: expandedVars.includes(
                                  variable.variableId
                                )
                                  ? "-8px"
                                  : "0px",
                              }}
                            >
                              <ExpandDataIcon
                                className={classes.expandIcon}
                                onClick={() => expandVar(variable.variableId)}
                                id={`${
                                  props.id
                                }_ExpandDataIcon_${generateUniqueId()}`}
                              />
                            </Grid>
                          )}
                      </Grid>
                    </Grid>
                    <Grid item style={{ marginLeft: "auto" }}>
                      <Grid container spacing={3}>
                        <Grid
                          item
                          onClick={() => handleEdit(variable)}
                          //tabIndex={0}
                          onKeyDown={(e) =>
                            e.key === "Enter" && handleEdit(variable)
                          }
                        >
                          <EditIcon
                            className={classes.editIcon}
                            style={{
                              cursor: "pointer",
                            }}
                            tabIndex={0}
                            role="button"
                            id={`${props.id}_EditIcon_${generateUniqueId()}`}
                          />
                        </Grid>
                        <Grid
                          item
                          onClick={() => handleDelete(variable.variableId)}
                          onKeyPress={(e) =>
                            e.key === "Enter" &&
                            handleDelete(variable.variableId)
                          }
                          id={`${
                            props.id
                          }_ExpandDataIconDiv_${generateUniqueId()}`}
                        >
                          <DeleteIcon
                            className={classes.deleteBtn}
                            style={{
                              cursor: "pointer",
                            }}
                            tabIndex={0}
                            role="button"
                            id={`${props.id}_DeleteIcon_${generateUniqueId()}`}
                          />
                        </Grid>
                      </Grid>
                    </Grid>
                  </Grid>
                )
              )}
            </Grid>
          )}
        </div>
      ) : (
        <div style={{ margin: "16px" }}>
          <Typography style={{ fontSize: "12px" }}>
            {t("There are no variable created yet")}
          </Typography>
        </div>
      )}
    </>
  );
});
const typeOptions = [
  { name: "", value: "" },
  { name: "Integer", value: 2 },
  { name: "Float", value: 8 },
  { name: "Text", value: 1 },
  { name: "Date", value: 4 },
  { name: "Boolean", value: 3 },
  { name: "List", value: 5 },
  { name: "DataRecord", value: 7 },
  { name: "DataTable", value: 6 },
  { name: "MailMessage", value: 10 },
  { name: "DateTime", value: 9 },
  { name: "JSONObject", value: 11 },
  { name: "JSONArray", value: 12 },
];
