import React from "react";
import ReactDom from "react-dom";
import { cleanup } from "@testing-library/react";

import "@testing-library/jest-dom/extend-expect";
import * as components from "../AllModalComp";
import CustomAppComp from "../../../utils/CustomAppComp";
afterEach(cleanup);

const handleClose = jest.fn();
const updateScripts = jest.fn();
const selectedProject = { projectName: "Test", projectId: 2, scripts: [] };
Object.keys(components).forEach((componentName) => {
  const Component = components[componentName];
  const div = document.createElement("div");

  describe(`Component: ${componentName}`, () => {
    test(`${componentName} renders with default props`, () => {
      ReactDom.render(
        <CustomAppComp>
          <Component
            selectedProject={selectedProject}
            handleClose={handleClose}
            updateScripts={updateScripts}
            isOpen={true}
            options={[]}
          />
        </CustomAppComp>,
        div
      );
    });
  });
});
