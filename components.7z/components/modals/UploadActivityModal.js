import React, { useState, useEffect, useContext, useRef } from "react";
import makeStyles from '@mui/styles/makeStyles';
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import { useTranslation } from "react-i18next";
import { Grid, Typography, Button } from "@mui/material";

//import CrossIcon from "../../assets/images/Path 1804.svg";
//import UploadIcon from "../../assets/images/UploadIcon.svg";

import { NotificationContext } from "../../contexts/NotificationContext";
import {
  handleNetworkRequestError,
  createInstance,
} from "./../../utils/common";

import { useHistory } from "react-router";

import { CUSTOM_ACTIVITY } from "./../../config/index";

import {
  isEmptyText,
  MaximumLengthText,
  isContainSpecialCharacters3,
  isContainSpecialCharacters,
  atleastContainsACharacter1,
  onlyFloatNumbersWithOneDecPoint,
} from "../../utils/validations/validations";

import { getCssRgbFromHexByDiff } from "../../utils/HexToFilter";

// import DragDrop from "../Drag&Drop/DragDrop";

import { CrossPathIcon, UploadIcon, FileIcon2, UploadIcon2 } from "../../utils/AllImages";

const useStyles = makeStyles((theme) => ({
  container: {
    marginTop: "4rem",
  },
  dragDropDesc: {
    fontFamily: 'Open Sans',
    fontSize: '8px',
    fontWeight: 600,
    "& > span": {
      fontFamily: 'Open Sans',
      fontSize: '8px',
      fontWeight: 600,
      color: "#0072C6"
    }
  },

  dragDropSubDesc: {
    fontFamily: 'Open Sans',
    fontSize: '8px',
    fontWeight: 600,
    marginTop: "12px",
    color: "#606060",
  },

  item: {
    background: "#F8F8F8 0% 0% no-repeat padding-box",
    borderRadius: "2px",
    width: "362px",
    height: "319px",
    padding: "12px 21px 23px 16px",
    overflow: "hidden",
    "&:hover": {
      overflowY: "auto",
    },
  },
  addBtn: {
    width: "12px",
    height: "12px",
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
  },
  title: {
    fontWeight: 600,
    fontSize: "14px"
  },
  scrollDiv: {
    marginTop: "8px",
    height: "204px",
    overflow: "hidden",
    "&:hover": {
      overflowY: "auto",
    },
  },
  img: {
    height: "16px",
    width: "16px",
    borderRadius: 50,
  },
  owner: {
    color: "#606060",
    textAlign: "right",
  },
  input: {
    height: 24,
    paddingRight: "10px",
    fontSize: 12,
  },
  noBorder: {
    border: "none",
  },
  selectIcon: {
    color: "#0072C6",
    marginTop: "3px",
  },
  root: {
    color: "#0072C6",
  },
  opacityLow: {
    opacity: 0.3,
    pointerEvents: "none",
  },
  deleteBtn: {
    height: "12px",
    width: "12px",
    filter: `invert(17%) sepia(74%) saturate(5916%) hue-rotate(356deg) brightness(101%) contrast(118%)`,
  },
  icons: {
    height: "16px",
    width: "16px",
    // filter: `invert(17%) sepia(74%) saturate(5916%) hue-rotate(356deg) brightness(101%) contrast(118%)`,
  },
  focusPrimary: {
    "&:focus": {
      background: `${getCssRgbFromHexByDiff(`${theme.palette.primary.main}`)}`,
    },
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

const UploadActivityModal = (props) => {
  const { t } = useTranslation();
  const { editedActivity, updateActivities } = props;
  const [open, setOpen] = useState(props.isOpen ? true : false);
  const hiddenFileInput = useRef(null);
  const hiddenFileInputImage = useRef(null);
  const { setValue } = useContext(NotificationContext);
  const history = useHistory();
  const [formHasError, setFormHasError] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [iconFile, setIconFile] = useState(null);
  const [iconFilePreview, setIconFilePreview] = useState(null);
  const [documentationFile, setDocumentationFile] = useState(null);
  const [apiModuleFile, setApiModuleFile] = useState(null);
  //const [browseState, setBrowseState] = useState(false);
  const [apiModule, setApiModule] = useState(makeFieldInputs(""));
  const [activityName, setActivityName] = useState(makeFieldInputs(""));
  const [description, setDescription] = useState(makeFieldInputs(""));
  const [version, setVersion] = useState(makeFieldInputs(""));
  const [developedBy, setDevelopedBy] = useState(makeFieldInputs(""));
  const [icon, setIcon] = useState(makeFieldInputs(""));
  const [documentationFileName, setDocumentationFileName] = useState(
    makeFieldInputs("")
  );
  const [clickedBrowseItem, setClickedBrowseItem] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";
    switch (name) {
      case "ActivityName":
        errors =
          isEmptyText(value) ||
          MaximumLengthText(value, 40) ||
          isContainSpecialCharacters3(value) ||
          atleastContainsACharacter1(value);
        setActivityName({
          ...activityName,
          value,
          error: errors ? true : false,
          helperText: errors,
        });

        break;
      case "Description":
        errors = MaximumLengthText(value, 2000);
        setDescription({
          ...description,
          value,
          error: errors ? true : false,
          helperText: errors,
        });
        break;
      case "Version":
        errors =
          isEmptyText(value) || onlyFloatNumbersWithOneDecPoint("" + value);
        setVersion({
          ...version,
          value,
          error: errors ? true : false,
          helperText: errors,
        });
        break;
      case "DevelopedBy":
        errors = isEmptyText(value) || isContainSpecialCharacters(value);
        setDevelopedBy({
          ...developedBy,
          value,
          error: errors ? true : false,
          helperText: errors,
        });
        break;
      default:
        break;
    }
  };






  useEffect(() => {
    if (editedActivity) {
      const {
        groupName,
        description: editedDes,
        developedBy: devBy,
      } = editedActivity;

      setActivityName({ ...activityName, value: groupName });
      setDescription({ ...description, value: editedDes });
      setDevelopedBy({ ...developedBy, value: devBy });
    }
  }, [editedActivity]);

  useEffect(() => {
    if (
      activityName?.error ||
      developedBy?.error ||
      version?.error ||
      description?.error ||
      apiModule.error
    ) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [activityName, developedBy, version, description, apiModule]);

  const handleClose = () => {
    setOpen(false);
    // setBrowseState(false);
    props.handleClose();
  };

  const onClick1 = () => {
    console.log("cancel clicked");
    handleClose();
  };

  const validateFields = () => {
    const activityNameErrors =
      isEmptyText(activityName.value) ||
      MaximumLengthText(activityName.value, 40) ||
      isContainSpecialCharacters3(activityName.value) ||
      atleastContainsACharacter1(activityName.value);
    if (activityNameErrors) {
      setActivityName({
        ...activityName,
        error: activityNameErrors ? true : false,
        helperText: activityNameErrors,
      });
    }
    const desErr = MaximumLengthText(description.value, 2000);
    if (desErr) {
      setDescription({
        ...description,
        error: desErr ? true : false,
        helperText: desErr,
      });
    }
    const apiModErr = isEmptyText(apiModule.value);
    if (apiModErr) {
      setApiModule({
        ...apiModule,
        error: apiModErr ? true : false,
        helperText: apiModErr,
      });
    }
    const devByErr =
      isEmptyText(developedBy.value) ||
      isContainSpecialCharacters(developedBy.value);
    if (devByErr) {
      setDevelopedBy({
        ...developedBy,
        error: devByErr ? true : false,
        helperText: devByErr,
      });
    }
    const verErr =
      isEmptyText(version.value) ||
      onlyFloatNumbersWithOneDecPoint(version.value);
    if (verErr) {
      setVersion({
        ...version,
        error: verErr ? true : false,
        helperText: verErr,
      });
    }
    if (desErr || activityNameErrors || devByErr || verErr || apiModErr) {
      return false;
    }
    return true;
  };

  const onClick2 = async () => {
    if (!validateFields()) {
      return;
    }
    const axiosInstance = createInstance();
    setIsProcessing(true);
    const groupId = editedActivity?.groupId;

    if (editedActivity) {
      try {
        const bodyFormData = new FormData();
        bodyFormData.append("activityModule", apiModuleFile);
        bodyFormData.append("oldGroupId", groupId);
        bodyFormData.append("activityGroupName", activityName.value);
        bodyFormData.append("version", version.value);
        bodyFormData.append("developedBy", developedBy.value);
        bodyFormData.append("icon", iconFile);
        // bodyFormData.append("documentation", documentationFile);

        if (description) {
          bodyFormData.append("description", description.value);
        }
        const config = {
          headers: {
            "content-type": "multipart/form-data",
          },
        };

        let res = await axiosInstance.post(
          `${CUSTOM_ACTIVITY}`,
          bodyFormData,
          config
        );


        if (res.status === 200) {
          props.updateActivities(res.data.data[0]);
          setIsProcessing(false);
          //creating Notification
          setValue({
            isOpen: true,
            message: "updated successfully.",
            notificationType: "SUCCESS",
            title: activityName.value,
          });

          props.handleClose();

        }
      } catch (error) {

        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "updation failed.",
              notificationType: "ERROR",
              title: activityName.value,
            });
          },
        });
        setIsProcessing(false);
      }
    } else {
      try {
        const bodyFormData = new FormData();
        bodyFormData.append("activityModule", apiModuleFile);
        bodyFormData.append("activityGroupName", activityName.value);
        bodyFormData.append("version", version.value);
        bodyFormData.append("developedBy", developedBy.value);
        bodyFormData.append("icon", iconFile);
        //bodyFormData.append("documentation", documentationFile);
        if (description.value) {
          bodyFormData.append("description", description.value);
        }
        const config = {
          headers: {
            "content-type": "multipart/form-data",
          },
        };

        let res = await axiosInstance.post(
          `${CUSTOM_ACTIVITY}`,
          bodyFormData,
          config
        );

        if (res.status === 200) {
          props.updateActivities(res.data.data[0]);
          setIsProcessing(false);
          //creating Notification
          setValue({
            isOpen: true,
            message: "created successfully.",
            notificationType: "SUCCESS",
            title: activityName.value,
          });
          props.handleClose();
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "creation failed.",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
        setIsProcessing(false);
      }
    }
  };

  const handleFileInput = (e, clickedItem) => {

    if (hiddenFileInput && e.currentTarget.id == "RPA_ActivityMngmt_UploadActivity_BrowseBtn") {
      hiddenFileInput.current.click();
      if (clickedItem) {
        setClickedBrowseItem(clickedItem);
      }
      hiddenFileInput.current.value = '';
    }

    if (hiddenFileInputImage && e.currentTarget.id == "RPA_ActivityMngmt_UploadActivity_BrowseBtn01") {
      hiddenFileInputImage.current.click();
      if (clickedItem) {
        setClickedBrowseItem(clickedItem);
      }
      hiddenFileInputImage.current.value = '';
    }

    if (hiddenFileInput && e.target.id == "RPA_ActivityMngmt_UploadActivity_uploadIconApiModule") {
      hiddenFileInput.current.click();
      if (clickedItem) {
        setClickedBrowseItem(clickedItem);
      }
      hiddenFileInput.current.value = '';
    }

    if (hiddenFileInput && e.target.id == "RPA_ActivityMngmt_UploadActivity_uploadIconActivity") {
      hiddenFileInputImage.current.click();
      if (clickedItem) {
        setClickedBrowseItem(clickedItem);
      }
      hiddenFileInputImage.current.value = '';
    }


  };

  // to handle the user-selected file
  const handleChangeFile = (event, isFromDrop) => {
    if (isFromDrop === undefined) {
      const fileSelected = event.target.files[0];
      //setBrowseState(true);
      if (fileSelected) {
        if (clickedBrowseItem) {
          if (clickedBrowseItem === "ApiModule") {
            setApiModuleFile(fileSelected);
            if (fileSelected?.size > 1 * 1000 * 1000 * 10) {
              setApiModule({ ...icon, value: fileSelected.name, error: true, helperText: "File size should be smaller then 10MB" });
            } else {
              setApiModule({ ...icon, value: fileSelected.name, error: false, helperText: "" });
            }
          } else if (clickedBrowseItem === "ActivityIcon") {
            setIconFile(fileSelected);
            if (fileSelected?.size > 10000) {
              setIcon({ ...icon, value: fileSelected.name, error: true, helperText: "File size should be smaller then 10KB" });
            } else {
              setIcon({ ...icon, value: fileSelected.name, error: false, helperText: "" });
            }
            const preView = URL.createObjectURL(fileSelected);
            setIconFilePreview(preView);
          } else if (clickedBrowseItem === "DocumentationFile") {
            setDocumentationFile(fileSelected);
            setDocumentationFileName({
              ...documentationFileName,
              value: fileSelected.name,
            });
          }
        }
      }
    } else {
      const fileSelected = event?.dataTransfer?.files[0];
      if (fileSelected) {
        if (isFromDrop === "ApiModule") {
          let isZip = fileSelected?.type === "application/x-zip-compressed"
          if (isZip) {
            setApiModuleFile(fileSelected);
            setApiModule({
              ...apiModule,
              value: fileSelected.name,
              helperText: "",
              error: false,
            });
          }
        } else if (isFromDrop === "ActivityIcon") {
          let acceptedIcons = ["image/png", "image/jpg"];
          if (acceptedIcons?.includes(fileSelected?.type)) {
            setIconFile(fileSelected);
            if (fileSelected?.size > 10000) {
              setIcon({ ...icon, value: fileSelected.name, error: true, helperText: "File size should be smaller then 10KB" });
            } else {
              setIcon({ ...icon, value: fileSelected.name, error: false, helperText: "" });
            }
          }
        }
      }
    }
  };


  const handleClearFile = (type) => {
    if (type === "ApiModule") {
      setApiModuleFile(null);
      setApiModule({
        ...apiModule,
        value: "",
        helperText: "",
        error: false,
      });
      setActivityName({
        ...activityName,
        value: "",
        helperText: "",
        error: false,
      });
    } else if (type === "ActivityIcon") {
      setIconFile(null);
      setIcon(makeFieldInputs(""));
      setIconFilePreview(null);
    }
  }



  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={
        editedActivity
          ? t("Update Custom Activity")
          : t("Upload Custom Activity")
      }
      contentBackground={"#fff"}
      Content={
        <Content
          id={props.id}
          handleChange={handleChange}
          apiModule={apiModule}
          activityName={activityName}
          description={description}
          version={version}
          developedBy={developedBy}
          documentationFileName={documentationFileName}
          icon={icon}
          iconFile={iconFile}
          handleClearFile={handleClearFile}
          iconFilePreview={iconFilePreview}
          apiModuleFile={apiModuleFile}
          documentationFile={documentationFile}
          handleChangeFile={handleChangeFile}
          handleFileInput={handleFileInput}
          hiddenFileInput={hiddenFileInput}
          hiddenFileInputImage={hiddenFileInputImage}
          editedActivity={editedActivity}
        />
      }
      btn1Title={t("Cancel")}
      btn2Title={editedActivity ? t("Update") : t("Upload")}
      onClick1={onClick1}
      onClick2={onClick2}
      isProcessing={isProcessing}
      btn2Disabled={formHasError}
      closeModal={handleClose}
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      containerHeight={528}
      containerWidth={600}
    />
  );
};
export default UploadActivityModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {

  const classes = useStyles();
  const { t } = useTranslation();
  const {
    id,
    handleChange,
    apiModule,
    activityName,
    description,
    version,
    developedBy,
    documentationFileName,
    icon,
    iconFile,
    iconFilePreview,
    apiModuleFile,
    documentationFile,
    handleChangeFile,
    handleFileInput,
    hiddenFileInput,
    editedActivity,
    hiddenFileInputImage,
    handleClearFile
  } = props;

  const formatFileSize = function (fileSize) {
    let byteSize = (fileSize / 1000).toFixed(2);
    let str = "";

    if (byteSize < 1000) {
      str = `${byteSize} KB`;
    } else {
      str = `${(byteSize / 1000).toFixed(2)} MB`;
    }
    return str;
  }

  const handleDragOver = (event) => {
    event.preventDefault();
  };


  return (
    <Grid container direction="column" spacing={0.5}>
      <Grid item container spacing={0.5} alignItems="flex-end">
        <Grid item xs>
          <input
            aria-label="inputFile"
            name="inputFile"
            id={`${id}_inputFile`}
            type="file"
            accept=".zip"
            ref={hiddenFileInput}
            onChange={handleChangeFile}
            style={{
              display: "none",
            }} /* Make the file input element invisible */
          />

          {apiModuleFile != null ?
            <Field
              id={`${id}_ApiModule`}
              name="ApiModule"
              label={t("Activity API Module")}
              {...apiModule}
              // width={443}
              onChange={handleChange}
              readOnly={true}
              paddingTop={"0px"}
              startAdornment={<FileIcon2 />}
              endAdornment={
                <Grid container justifyContent={'flex-end'} spacing={1.5} alignItems={"center"}>
                  <Grid item>
                    <Typography sx={{ color: "#606060", fontSize: "7px", fontWeight: 400 }}>
                      {formatFileSize(apiModuleFile?.size)}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <UploadIcon
                      style={{ cursor: "pointer" }}
                      id={`${id}_uploadIconApiModule`}
                      onClick={(e) => handleFileInput(e, "ApiModule")}
                    />
                  </Grid>
                  <Grid item>
                    <CrossPathIcon
                      style={{ cursor: "pointer" }}
                      onClick={(e) => handleClearFile("ApiModule")}
                    />
                  </Grid>
                </Grid>
              }
            />
            :
            <Grid container item xs>
              <Typography sx={{ color: "#606060", fontWeight: 600 }} >
                Activity API Module
              </Typography>
              <Grid
                onDrop={(e) => {
                  e.preventDefault();
                  handleChangeFile(e, "ApiModule")
                }
                } onDragOver={handleDragOver}
                container direction={'column'} alignItems={'center'} justifyContent={'center'} sx={{
                  border: '1px dashed #0072C6',
                  background: "rgba(0, 114, 198, .04)",
                  borderRadius: '4px', height: "100px",
                  marginTop: "4px"
                  // backgroundImage:
                  //   `url("data:image/svg+xml,%3csvg width='100%25' height='100%25' xmlns='http://www.w3.org/2000/svg'%3e%3crect width='100%25' height='100%25' fill='none' stroke='%23333' stroke-width='2' stroke-dasharray='25' stroke-dashoffset='0' stroke-linecap='square'/%3e%3c/svg%3e")`
                }}
                spacing={.5}
              >
                <Grid item>
                  <UploadIcon2 />
                </Grid>
                <Grid item>
                  <Grid container alignItems={'center'}>
                    <Grid item>
                      <Typography className={classes.title}>Drag and Drop Here</Typography>
                    </Grid>
                    <Grid item>
                      <Button
                        style={{
                          fontSize: "14px",
                          height: "24px",

                        }}
                        variant="text"
                        size="small"
                        color="primary"
                        onClick={(e) => handleFileInput(e, "ApiModule")}
                        disableFocusRipple
                        className={classes.focusPrimary}
                        id={`${id}_BrowseBtn`}
                      >
                        {t("Browse")}
                      </Button>
                    </Grid>
                  </Grid>
                </Grid>
                <Grid item>
                  <Typography sx={{ color: "#606060", fontSize: "12px" }}>
                    Please upload valid zip file
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          }
        </Grid>

        {/* :
            <Grid item xs>
            <Field
              id={`${id}_ApiModule`}
              name="ApiModule"
              label={t("Browse Activity API Module")}
              {...apiModule}
              // width={443}
              onChange={handleChange}
              readOnly={true}
              paddingTop={"0px"}
            />
          </Grid> */}

        {/* <Grid item xs>
            <DragDrop
            title={
              "Activity API Module"
            }
            dragDropDesc={
              <Typography className={classes.dragDropDesc}>
              Drag and drop here{" "}
              <Typography component="span">
                Browse
              </Typography>
            </Typography>
            }
            dragDropSubDesc={
              <Typography className={classes.dragDropSubDesc}>
             zip file with valid custom activity structure
            </Typography>
            }
            />
            </Grid> */}
        {/* <Grid item xs>
              <Field
                id={`${id}_ApiModule`}
                name="ApiModule"
                label={t("Browse Activity API Module")}
                {...apiModule}
                // width={443}
                onChange={handleChange}
                readOnly={true}
                paddingTop={"0px"}
              />
            </Grid>
            <Grid item>
              <Button
                style={{
                  fontSize: "12px",
                  height: "24px",
                }}
                variant="contained"
                size="small"
                color="primary"
                onClick={(e) => handleFileInput(e, "ApiModule")}
                disableFocusRipple
                className={classes.focusPrimary}
                id={`${id}_BrowseBtn`}
              >
                {t("Browse")}
              </Button>
            </Grid> */}
      </Grid>
      <Grid item>
        <Field
          id={`${id}_ActivityName`}
          name="ActivityName"
          label={t("Activity Group Name")}
          {...activityName}
          // width={443}
          readOnly={editedActivity ? true : false}
          onChange={handleChange}
          helperText={
            editedActivity
              ? t("You can not update Activity Group Name")
              : activityName.helperText
                ? activityName.helperText
                : ""
          }
        />
      </Grid>
      <Grid item>
        <Field
          id={`${id}_Description`}
          name="Description"
          label={t("Description")}
          {...description}
          onChange={handleChange}
          multiline
        />
      </Grid>


      <Grid item xs>
        <input
          aria-label="inputFileImagae"
          name="inputFileImage"
          id={`${id}_inputFileImage`}
          type="file"
          accept=".jpg, .jpeg, .png"
          ref={hiddenFileInputImage}
          onChange={handleChangeFile}
          style={{
            display: "none",
          }} /* Make the file input element invisible */
        />
        {iconFile != null ?
          <Field
            name="Icon"
            startAdornment={<FileIcon2 />}
            endAdornment={
              <Grid container justifyContent={'flex-end'} spacing={1.5} alignItems={"center"}>
                <Grid item>
                  <Typography
                    sx={{ color: "#606060", fontSize: "7px", fontWeight: 400 }}
                  >
                    {formatFileSize(iconFile?.size)}
                  </Typography>
                </Grid>
                <Grid item>
                  {/* <img src={UploadIcon} alt={`${id}_uploadIcon`} id={`${id}_fileIcon`} /> */}
                  <UploadIcon
                    style={{ cursor: "pointer" }}
                    id={`${id}_uploadIconActivity`}
                    onClick={(e) => handleFileInput(e, "ActivityIcon")}
                  />
                </Grid>
                <Grid item>
                  {/* <img src={CrossIcon} alt={`${id}_crossIcon`} id={`${id}_fileIcon`}/> */}
                  <CrossPathIcon
                    style={{ cursor: "pointer" }}
                    onClick={(e) => handleClearFile("ActivityIcon")}
                  />
                </Grid>
              </Grid>
            }
            label="Icon"
            {...icon}
            // width={443}
            onChange={handleChange}
            readOnly={true}
          />
          :
          <Grid
            item xs container sx={{ marginTop: "10px" }}>
            <Typography sx={{
              color: "#606060",
              fontWeight: 600,
            }}>Icon</Typography>
            <Grid
              onDrop={(e) => {
                e.preventDefault();
                handleChangeFile(e, "ActivityIcon")
              }}
              spacing={.5}
              onDragOver={handleDragOver}
              container direction={'column'} alignItems={'center'} justifyContent={'center'} sx={{ border: '1px dashed #0072C6', borderRadius: '4px', height: "100px", background: "rgba(0, 114, 198, .04)", marginTop: "4px" }}>
              <Grid item>
                <UploadIcon2 />
              </Grid>
              <Grid item>
                <Grid container alignItems={'center'}>
                  <Grid item>
                    <Typography className={classes.title}>Drag Here or</Typography>
                  </Grid>
                  <Grid item>
                    <Button
                      style={{
                        fontSize: "14px",
                        height: "24px",
                      }}
                      variant="text"
                      size="small"
                      color="primary"
                      onClick={(e) => handleFileInput(e, "ActivityIcon")}
                      disableFocusRipple
                      className={classes.focusPrimary}
                      id={`${id}_BrowseBtn01`}
                    >
                      {t("Browse")}
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item>
                <Typography sx={{ color: "#606060", fontSize: "12px" }}>
                  Supported Format: png, jpg. Max Size: 10 kb
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        }
      </Grid>

      <Grid item xs>
        <Grid item container spacing={2}>
          <Grid item xs={6}>
            <Field
              id={`${id}_Version`}
              name="Version"
              label={t("Version")}
              type="number"
              step="0.1"
              min={1.0}
              {...version}
              onChange={handleChange}
            />
          </Grid>
          <Grid item xs={6}>
            <Field
              id={`${id}_DevelopedBy`}
              name="DevelopedBy"
              label={t("Developed By")}
              {...developedBy}
              onChange={handleChange}
            />
          </Grid>
        </Grid>
      </Grid>
      {/*<Grid item container alignItems="center">
            <Grid item xs={2}>
              {iconFilePreview ? (
                <>
                  <div>
                    <Typography style={{ fontSize: "10px", fontWeight: 600 }}>
                      Icon Preview
                    </Typography>
                  </div>
                  <img
                    src={iconFilePreview}
                    alt="PreviewIcon"
                    style={{ height: "70px", width: "70px" }}
                  />
                </>
              ) : (
                <>
                  <div>
                    <Typography style={{ fontSize: "10px", fontWeight: 600 }}>
                      Icon Preview
                    </Typography>
                  </div>
                  <div
                    style={{
                      height: "70px",
                      width: "70px",
                      border: "1px solid #d5d5d5",
                      backgroundColor: "grey",
                    }}
                  ></div>
                </>
              )}
            </Grid>
            <Grid item xs>
              <Grid container spacing={1} alignItems="flex-end">
                <Grid item xs>
                  <Field
                    name="Icon"
                    label="Upload icon (50 x 50) px"
                    {...icon}
                    // width={443}
                    onChange={handleChange}
                    readOnly={true}
                  />
                </Grid>
                <Grid item>
                  <Button
                    style={{ fontSize: "12px", height: "24px" }}
                    variant="contained"
                    size="small"
                    color="primary"
                    onClick={(e) => handleFileInput(e, "ActivityIcon")}
                  >
                    Browse
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <Grid item container spacing={1} alignItems="flex-end">
            <Grid item xs>
              <Field
                name="DocumentationFileName"
                label="Upload Documentation File (optional)"
                {...documentationFileName}
                // width={443}
                onChange={handleChange}
                readOnly={true}
              />
            </Grid>
            <Grid item>
              <Button
                style={{ fontSize: "12px", height: "24px" }}
                variant="contained"
                size="small"
                color="primary"
                onClick={(e) => handleFileInput(e, "DocumentationFile")}
              >
                Browse
              </Button>
            </Grid>
          </Grid>*/}
    </Grid >
  );
};
