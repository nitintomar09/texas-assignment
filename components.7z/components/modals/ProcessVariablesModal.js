import React, { useState, useContext, useEffect } from "react";
import { Button, Grid, Typography, Modal, Fade, Backdrop, Select } from "@mui/material";

import makeStyles from '@mui/styles/makeStyles';

import CircularProgress from "@mui/material/CircularProgress";
import Close from "@mui/icons-material/Close";
import PropertyField from "../script-editor/PropertyWindow/PropertyFields/PropertyField";
import { getAllVariables } from "./../script-editor/PropertyWindow/AllActivityWindows/Common/CommonMethods";
import { createInstance, handleNetworkRequestError } from "../../utils/common";
import { OMNIFLOW, PROCESS_VARIABLES } from "./../../config/index";
import { iBPSContext } from "./../../contexts/iBPSContext";
import { MappedVarContext } from "./../../contexts/MappedVarContext";
import { NotificationContext } from "./../../contexts/NotificationContext";
import { truncateString } from "../script-editor/PropertyWindow/AllActivityWindows/Common/CommonMethods";
import { useHistory } from "react-router-dom";
import "../../App.css";
import { getDecryptedString } from "../../utils/encryptions";
import { ConvertLtrRtl } from "../common";
import { useTranslation } from "react-i18next";

const useStyles = makeStyles((theme) => ({
  modal: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    outline: 0,
  },
  container: {
    width: 466,
    height: 610,
    backgroundColor: "white",
    display: "flex",
    flexDirection: "column",
    outline: 0,
  },
  title: { color: "#000000", opacity: 1, fontSize: 14, fontWeight: 600 },
  modalHeader: {
    paddingLeft: "10px",
    //paddingRight: "10px",
    boxShadow: "0px 2px 6px #00000029",
  },

  content: {
    paddingLeft: "10px",
    paddingRight: "10px",
    paddingTop: "16px",
    flex: 1,
    flexDirection: "coloumn",
    outline: 0,

    overflowY: "scroll",
    overflowX: "hidden",
  },
  padding: { paddingLeft: 15, paddingRight: 15, paddingTop: 5 },
  text_12: {
    fontSize: "12px",
  },
  lead: {
    fontSize: "12px",

    opacity: 0.4,
  },
  varTitle: {
    color: "#747474",
    fontSize: "12px",
  },
  input: {
    height: 24,
    backgroundColor: "white",
    fontSize: 12,
  },
  loading: {
    height: "300px",
    width: "300px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  btn_title: {
    fontSize: 12,
    color: "#FFFFFF",
  },
}));
const ProcessVariablesModal = (props) => {
  const classes = useStyles();
  const {t} = useTranslation()
  const history = useHistory();
  const { handleOpenModal, handleClose } = props;

  const [putMappedColToTop, setPutMappedColToTop] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [allMapped, setAllMapped] = useState([]);
  const [allProcessVariables, setAllProcessVariables] = useState([]);
  const { iBPSValues } = useContext(iBPSContext);
  const { mappedVarState, setAllMappedVariables } =
    useContext(MappedVarContext);
  const { setValue: setNotification } = useContext(NotificationContext);
  const { allMappedVariables } = mappedVarState;

  const getDiffArray = (arr1, arr2) => {
    return arr1.filter((obj1) => {
      return !arr2.some((obj2) => {
        return obj1.attrName === obj2.attrName;
      });
    });
  };
  const getAllProcessVariables = async () => {
    setIsLoading(true);
    const axiosInstance = createInstance();
    const { serverUrl, cabinetName, processName, queueName, sessionId } =
      iBPSValues;
    // const ibpsKey = getDecryptedString(sessionStorage.getItem("iBPS-key"));

    const inputData = {
      serverUrl,
      cabinetName,
      processName,
      queueName,
      userSessionId: sessionId,
    };

    try {
      let res = await axiosInstance.post(`${OMNIFLOW}${PROCESS_VARIABLES}`, {
        ...inputData,
      });

      if (res.status === 200) {
        let attributes = res.data?.data ? res.data?.data : [];

        if (attributes) {
          let processVariables = Object.keys(attributes).map(
            (key) => attributes[key]
          );

          //logic changed on 14-06-2022

          setAllProcessVariables([
            ...allMapped,
            ...getDiffArray(processVariables, allMapped),
            ...getDiffArray(allMapped, processVariables),
          ]);

          /*****************************************************************************************
           * @author asloob.ali BUG ID : 101931   Description :   iBPS activity: Create work item:variable mapping is not working correctly.
           * Reason: when clicked on 'Get Process Variables' we were not setting mapped variables to an empty array,because of that all mapped variables are there and while mapping the process variables the duplication of mapped vars was happening.
           *  Resolution :now setting allMapped variables as an empty array whenever clicked on get process variables..
           *  Date : 12/10/2021             ***************************************************************************************/
          // setAllMapped([]);
        }
        setIsLoading(false);
      }
    } catch (error) {
      console.log(error);
      setIsLoading(false);
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            title: "iBPS",
            message:
              errMsg ||
              "please connect to iBPS server.and provide process name and queue name.",
            notificationType: "ERROR",
          });
        },
      });
    }
  };
  useEffect(() => {
    if (mappedVarState) {
      setAllProcessVariables(allMappedVariables);
      setAllMapped(allMappedVariables);
    }
  }, []);
  const [openRole, setOpenRole] = useState(-1);

  //getting variables from context with name and value
  const allVariables = getAllVariables();

  const mapRPAWithProcessVar = (processVarToBeMapped, RPAVar) => {
    let newVars = [...allProcessVariables];
    let newVars1 = [...allMapped];
    //finding Index of document in the all process  var array

    const index = allProcessVariables.findIndex(
      (item) => item.attrName === processVarToBeMapped.attrName
    );

    //now setting RPAVar to the selected process var
    if (index !== -1) {
      const newVar = { ...allProcessVariables[index], RPAVar: RPAVar };
      newVars.splice(index, 1, newVar);
      setAllProcessVariables(newVars);

      const index1 = allMapped.findIndex(
        (item) => item.attrName === processVarToBeMapped.attrName
      );
      if (index1 !== -1) {
        /*****************************************************************************************
         * @author asloob_ali BUG ID : 103903   Description :    Ibps activity: Variable mapping - Same process variable created multiple times
         * Reason: when mapping in the logic we were not looking for the process var if it is already present in mapped variables.
         *  Resolution :now if a process variable exists in mapped variables(allMapped),changing its value of rpaVar.
         *  Date : 29/12/2021             ***************************************************************************************/
        const newVar1 = { ...allMapped[index], RPAVar: RPAVar };
        newVars1.splice(index, 1, newVar1);
        setAllMapped(newVars1);
      } else {
        setAllMapped([...allMapped, newVar]);
      }
    } else {
      console.log("process var not found");
    }
  };

  const handleChange = (e) => {
    const { name } = e.target;
    switch (name) {
      case "columnToTop":
        setPutMappedColToTop(!putMappedColToTop);
        break;
      default:
        break;
    }
  };
  const closeModal = (action) => {
    /*****************************************************************************************
     * @author asloob.ali BUG ID : 101930   Description :  iBPS activity: Variable mapping success message is not correct.
     * Reason: we were saving script rules when clicked on save button. because,before, the mapped variables were automatically getting saved in global state of component.thats why the message shown was of save rules api.
     *  Resolution : now on click on save button we are saving mapped variables object in global state of component and showning notification.
     *  Date : 12/10/2021             ***************************************************************************************/
    if (action && action === "save") {
      setAllMappedVariables({
        allMappedVariables: [...allMapped],
      });
      setNotification({
        isOpen: true,
        title: "Variables",
        message: "mapped successfully.",
        notificationType: "SUCCESS",
      });
    }
    handleClose();
  };

  const handleClearAll = () => {
    console.log("clearAll");
    //removing mapped RPAVar values from process variables
    setAllProcessVariables(
      allProcessVariables.map((item) => ({ ...item, RPAVar: "" }))
    );
    setAllMapped([]);
  };
  const handleCloseColumn = (index) => {
    setOpenRole(index);
  };
  const handleOpenColumn = (index) => {
    setOpenRole(index);
  };

  return (
    <Modal
      id={props.id}
      className={classes.modal}
      open={props.isOpen}
      onClose={closeModal}
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 50,
      }}
      disableScrollLock={true}
    >
      <Fade in={props.isOpen}>
        <div className={classes.container}>
          <div className={classes.modalHeader}>
            <Grid
              container
              className={classes.padding}
              spacing={2}
              alignItems="flex-end"
              style={{ marginTop: "5px" }}
            >
              <Grid item>
                <Typography className={classes.title}>
                  {t("Variable Mapping")}
                </Typography>
              </Grid>

              <Grid item>
                {allVariables && (
                  <Typography variant="subtitle2">
                    {ConvertLtrRtl([
                      allMapped ? allMapped.length : 0,
                      t(allMapped
                        ? allMapped.length === 1
                          ? "variable"
                          : "variables"
                        : "variables"),
                      t("mapped.")
                    ])}
                  </Typography>
                )}
              </Grid>

              <Grid
                item
                style={{
                  marginLeft: "auto",
                  height: "fit-content",
                  width: "fit-content",
                }}
                onClick={closeModal}
                id={`${props.id}_CloseIconBtn`}
                tabIndex={0}
              >
                <Close
                  style={{
                    marginTop: "5px",
                    height: "18px",
                    width: "18px",
                    color: "#707070",
                    cursor: "pointer",
                  }}
                />
              </Grid>
            </Grid>
            <Grid container className={classes.padding} spacing={1}>
              {/*<Grid item xs={7}>
                <PropertyField
                  checkbox={true}
                  name="columnToTop"
                  label="Put mapped columns to top"
                  value={putMappedColToTop}
                  onChange={handleChange}
                />
                </Grid>*/}
              <Grid item>
                <Button
                  color="primary"
                  variant="contained"
                  size="small"
                  onClick={() => getAllProcessVariables()}
                  id={`${props.id}_GetProcessVarsBtn`}
                  disableRipple
                >
                  <Typography className={classes.btn_title}>
                    {t("Get process variables")}
                  </Typography>
                </Button>
              </Grid>
            </Grid>
            <Grid container className={classes.padding} spacing={2}>
              <Grid item xs={5}>
                <Typography className={classes.varTitle}>
                  {t("Process Variables")}
                </Typography>
              </Grid>
              <Grid item xs>
                <Typography className={classes.varTitle}>
                  {t("RPA Variables")}
                </Typography>
              </Grid>
            </Grid>
          </div>

          {/* modal content  */}
          {isLoading ? (
            <div className={classes.loading}>
              <CircularProgress
                color="primary"
                style={{
                  height: "15px",
                  width: "15px",
                }}
              />
            </div>
          ) : (
            <>
              {allMapped.length > 0 && (
                <div
                  className="sticky"
                  style={{ marginLeft: "auto", padding: "10px" }}
                >
                  <Button
                    color="primary"
                    variant="contained"
                    size="small"
                    onClick={() => closeModal("save")}
                    id={`${props.id}_SaveBtn`}
                    disableRipple
                  >
                    <Typography className={classes.btn_title}>{t("Save")}</Typography>
                  </Button>
                  <Button
                    color="primary"
                    variant="contained"
                    size="small"
                    onClick={handleClearAll}
                    style={{ marginLeft: "8px" }}
                    id={`${props.id}_ClearAllBtn`}
                    disableRipple
                  >
                    <Typography className={classes.btn_title}>
                      {t("Clear All")}
                    </Typography>
                  </Button>
                </div>
              )}

              <div className={classes.content}>
                {allProcessVariables.map((variable, index) => (
                  <Grid
                    container
                    className={classes.padding}
                    spacing={2}
                    key={index}
                  >
                    <Grid item xs={5} id={`${props.id}_${variable.attrName}`}>
                      <Typography className={classes.text_12}>
                        {truncateString(variable.attrName)}
                      </Typography>
                    </Grid>

                    <Grid item xs>
                      <Select
                        native
                        variant="outlined"
                        fullWidth={true}
                        className={classes.input}
                        value={variable.RPAVar ? variable.RPAVar : ""}
                        onChange={(e) => {
                          mapRPAWithProcessVar(variable, e.target.value);
                        }}
                        open={openRole === index}
                        onClose={() => handleCloseColumn(index)}
                        onOpen={() => handleOpenColumn(index)}
                        SelectDisplayProps={{ shrink: true }}
                        style={{ width: "190px" }}
                        inputProps={{
                          "aria-labelledby": props.id + "_" + variable.attrName,
                        }}
                        /**If there is no option available: disable the select*/
                        disabled={
                          allVariables &&
                          allVariables.filter(
                            (item) => item.variableObjType === variable.attrType
                          ).length == 0
                        }
                      >
                        <option value="" hidden selected>
                          -Select-
                        </option>
                        {/*****************************************************************************************
                         * @author asloob.ali BUG ID : 101111  Description :  iBPS activity: Variable Mapping - RPA variable list should show only the variable matching with Process variable data types
                         *  Resolution : now filtering rpa variables on the bases of type of process variable
                         *  Date : 16/09/2021             ***************************************************************************************/}
                        {allVariables &&
                          allVariables
                            .filter(
                              (item) =>
                                item.variableObjType === variable.attrType
                            )
                            .map((obj) => {
                              return {
                                name: obj.variableName,
                                value: obj.variableName,
                              };
                            })
                            .map((item) => (
                              <option value={item.value} key={item.name}>
                                {item.name}
                              </option>
                            ))}

                        {/* WCAG[1.3.1] :Container element is empty 
                        Solution: 1) An option is provided in case there is no option available.
                                  2) Simultaneously, disabled the Select as well so that user cannot select it.*/}
                        {allVariables &&
                        allVariables.filter(
                          (item) => item.variableObjType === variable.attrType
                        ).length == 0 ? (
                          <option value="">-Select-</option>
                        ) : null}
                      </Select>
                    </Grid>
                  </Grid>
                ))}
              </div>
            </>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default ProcessVariablesModal;
