import React, { useState, useContext, useEffect } from "react";
import ModalForm from "../../utils/modalForm";
import Field from "./../../utils/field";
import { makeStyles } from "@mui/styles";
import { NotificationContext } from "../../contexts/NotificationContext";

import { Grid, Typography } from "@mui/material";
import { PUBLISH, SCRIPT } from "./../../config/index";
import {
  createInstance,
  handleNetworkRequestError,
} from "./../../utils/common";
import { useHistory } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import {
  isEmptyText,
  MaximumLengthText,
  MinimumLengthText,
  onlyLettersAndUnderscore,
  atleastContainsACharacter,
} from "../../utils/validations/validations";
import { useTranslation } from "react-i18next";
//import { getAllWorkgroupsOfUser } from "../../redux/actions";

const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};
const PublishScriptModal = (props) => {
  const { selectedScript, handleEndpointDetails } = props;
  const history = useHistory();
  const dispatch = useDispatch();

  /*const allWorkgroupsOfCurrentUser = useSelector(
    (state) => state.userDetails.workgroups
  );*/

  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [formHasError, setFormHasError] = useState(true);

  const [comments, setComments] = useState(makeFieldInputs(""));
  //const [pkgName, setPkgName] = useState(makeFieldInputs(""));
  //const [workgroup, setWorkgroup] = useState(makeFieldInputs(""));

  const { setValue: setNotification } = useContext(NotificationContext);
  useEffect(() => {
    /*****************************************************************************************
     * @author asloob_ali BUG ID : 102521 Description : Publish Package: Workgroup dropdown list values are static and not align with RPA control center
     *  Reason:list of Workgroups for current user,api was not developed and integrated yet.
     * Resolution : integrated api for list of workgroups for cureent user..
     *  Date : 15/11/2021             ***************************************************************************************/
    // dispatch(getAllWorkgroupsOfUser({ history }));
  }, []);

  /*  const workgroupOptions = allWorkgroupsOfCurrentUser
    ? allWorkgroupsOfCurrentUser.map((item) => {
        return { name: item.resourceGroupName, value: item.resourceGroupName };
      })
    : [];*/

  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";

    switch (name) {
      /* case "Availabe to Workgroup":
        setWorkgroup({
          ...workgroup,
          value,
          error: false,
          helperText: "",
        });

        break;*/
      case "Comments":
        errors = MaximumLengthText(value, 2000);

        setComments({ ...comments, value, error: errors, helperText: errors });
        break;
      /*****************************************************************************************
       * @author asloob_ali BUG ID : 102524 Description : - Publish Package: Package name is accepting numbers and validation msg is wrong
       *  Reason:validation was written for accepting letters,numbers and only underscores can be used,and in message there was a comma missing.
       * Resolution : removed numbers acceptence in validation and corrected the msg.
       *  Date : 10/11/2021             ***************************************************************************************/
      /*  case "PackageName":
          errors =
            isEmptyText(value) ||
            onlyLettersAndUnderscore(value) ||
            MinimumLengthText(value, 4) ||
            MaximumLengthText(value, 40) ||
            atleastContainsACharacter(value);
          setPkgName({ ...pkgName, value, error: errors, helperText: errors });
          break;*/
      default:
        break;
    }
  };
  useEffect(() => {
    if (comments?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [comments]);
  const validateFields = () => {
    /* const pkgNameErrors =
       isEmptyText(pkgName.value) ||
       onlyLettersAndUnderscore(pkgName.value) ||
       MinimumLengthText(pkgName.value, 4) ||
       MaximumLengthText(pkgName.value, 40) ||
       atleastContainsACharacter(pkgName.value);
     if (pkgNameErrors) {
       setPkgName({
         ...pkgName,
         error: pkgNameErrors,
         helperText: pkgNameErrors,
       });
     }*/
    const comErr = MaximumLengthText(comments.value, 2000);
    if (comErr) {
      setComments({
        ...comments,
        error: comErr,
        helperText: comErr,
      });
    }
    /* const workGrpErrors = isEmptyText(workgroup.value);
    if (workGrpErrors) {
      setWorkgroup({
        ...workgroup,
        error: workGrpErrors,
        helperText: workGrpErrors,
      });
    }*/
    if (comErr) {
      return false;
    }
    return true;
  };

  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };

  const publishScript = async () => {
    if (!validateFields()) {
      return;
    }
    setIsProcessing(true);
    const { versionId, scriptId, versionName, scriptName } = selectedScript;
    const axiosInstance = createInstance();

    const inputBody = {
      //  packageName: pkgName.value,
      versionId,
      scriptId,
      versionName,
      // workgroupId: workgroup.value,
      comments: comments.value,
    };

    try {
      let res = await axiosInstance.put(`${PUBLISH}${SCRIPT}`, {
        ...inputBody,
      });

      if (res.status === 200) {
        setNotification({
          isOpen: true,
          message: res.data.message || "published",
          title: scriptName || "",
          notificationType: "SUCCESS",
        });
        setIsProcessing(false);
        // handleClose();
        handleEndpointDetails(res?.data?.data ? res?.data?.data[0] : null)
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "error in publishing.",
            title: scriptName || "",
            notificationType: "ERROR",
          });
        },
      });

      setIsProcessing(false);
    }
  };
  const onClick1 = () => {
    console.log("close clicked");
    handleClose();
  };
  const onClick2 = () => {
    publishScript();
  };

  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title="Publish Service Flow"
      Content={
        <Content
          id={props.id}
          selectedScript={selectedScript}
          comments={comments}
          //pkgName={pkgName}
          // workgroup={workgroup}
          handleChange={handleChange}
        // workgroupOptions={workgroupOptions}
        // allWorkgroupsOfCurrentUser={allWorkgroupsOfCurrentUser}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      isProcessing={isProcessing}
      btn1Title="Cancel"
      onClick1={onClick1}
      btn2Title="Publish"
      onClick2={onClick2}
      btn2Disabled={formHasError}
      closeModal={handleClose}
      containerHeight={455}
      containerWidth={490}
    />
  );
};

export default PublishScriptModal;

const useStyles = makeStyles((theme) => ({
  text_Light: {
    fontSize: 12,
    color: "#606060",
    fontWeight: 600,
  },

  text_bold: {
    fontSize: 12,
    fontWeight: 600,
  },
  opacity_6: {
    fontSize: 10,
    color: "#767676",
  },
  profile: {
    width: "16px",
    height: "16px",
    borderRadius: "50px",
  },
  icon: {
    width: "12px",
    height: "16px",
  },
  note: {
    fontSize: "12px",
    fontWeight: 700,
  },
  usr: {
    color: `${theme.palette.primary.main}`,
  },
}));

const Content = (props) => {
  const classes = useStyles();
  const { t } = useTranslation()
  const {
    selectedScript,
    comments,

    handleChange,
    //  pkgName,
    id,
  } = props;

  return (
    <>
      <div>
        {/* <Field
          label={t("Package Name")}
          id={`${id}_PackageName`}
          name="PackageName"
          {...pkgName}
          //  width={442}
          paddingTop={"0px"}
          onChange={handleChange}
  />*/}
      </div>
      <div style={{ marginTop: "16px" }}>
        <Grid container direction="column" spacing={1}>
          <Grid item>
            <Typography className={classes.text_Light}>{t("Service Flow Name")}</Typography>
          </Grid>
          <Grid item>
            <Typography className={classes.text_bold}>
              {selectedScript && selectedScript.scriptName}
            </Typography>
          </Grid>
        </Grid>
        <Grid
          container
          direction="column"
          style={{ marginTop: "16px" }}
          spacing={1}
        >
          <Grid item>
            <Typography className={classes.text_Light}>
              {t("Service Flow Version")}
            </Typography>
          </Grid>
          <Grid item>
            <Typography className={classes.text_bold}>
              {selectedScript && selectedScript.versionName}
            </Typography>
          </Grid>
        </Grid>
      </div>
      <div>
        {/*<div style={{ marginTop: "16px" }}>
          <Typography className={classes.note}>
            Available to the all <span className={classes.usr}>users</span> of
            the Default workgroup.
          </Typography>
  </div>*/}
        <Field
          label={t("Comments")}
          id={`${id}_Comments`}
          name="Comments"
          {...comments}
          //  width={442}
          multiline={true}
          placeholder={t("write comments here(optional)..")}
          onChange={handleChange}
        />
      </div>
    </>
  );
};
