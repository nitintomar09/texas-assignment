import React, { useState } from "react";
import makeStyles from '@mui/styles/makeStyles';
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import { Description } from "@mui/icons-material";
import JohnDoe from "./../../assets/img/JohnDoe.png";

const useStyles = makeStyles((theme) => ({
  container: {
    marginTop: "4rem",
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};
const allUsersData = [
  {
    name: "Devnath Gowda",
    email: "devnath.gowda@newgen.co.in",
    img: JohnDoe,
  },
  {
    name: "Asloob Ali",
    email: "asloob.ali@newgen.co.in",
    img: JohnDoe,
  },
  {
    name: "Suzanne Seth",
    email: "suzanne.seth@newgen.co.in",
    img: JohnDoe,
  },
  {
    name: "Ramendra Singh",
    email: "ramendra.singh@newgen.co.in",
    img: JohnDoe,
  },
  {
    name: "Akshat Pokhriyal",
    email: "akshat.pokhriyal@newgen.co.in",
    img: JohnDoe,
  },
  {
    name: "Pranesh Ramesh",
    email: "pranesh.ramesh@newgen.co.in",
    img: JohnDoe,
  },
];

const ScriptSharingModal = (props) => {
  const { selectedScript, handleOpenModal } = props;

  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [allUsers, setAllUsers] = useState(allUsersData);
  const [textAreaForComments, setTextAreaForComments] = useState(
    makeFieldInputs("")
  );
  const [username, setUsername] = useState(makeFieldInputs(""));
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);

  const owner = {
    name: "Walter White",
    email: "walter.white@newgen.co.in",
    img: JohnDoe,
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(name);
    switch (name) {
      case "TextAreaForComments":
        setTextAreaForComments({ ...textAreaForComments, value });
        break;
      case "Invite Users":
        setUsername({ ...username, value });
        //filtering users which contains typed string in their name or email
        setFilteredUsers(
          value
            ? allUsers.filter(function (user) {
                if (user.name.includes(value) || user.email.includes(value)) {
                  return user;
                }
              })
            : []
        );
        break;
      default:
        break;
    }
  };

  //when clicking on any user in th list to invite.
  const onSelectUser = (user) => {
    if (user) {
      setUsername({ ...username, value: user.email });
      setFilteredUsers([]);
    }
  };
  const onInvite = () => {
    console.log("invite");
    //checking user with email is exist or not
    const user = allUsers.find((usr) => usr.email === username.value);
    if (user) {
      //setting user to selected users with whom sharing script
      setSelectedUsers([...selectedUsers, user]);

      //setting username field value as empty
      setUsername({ ...username, value: "" });

      //removing user from allUsers
      const updatedAllUsers = allUsers.filter(
        (user1) => user1.email !== username.value
      );
      setAllUsers(updatedAllUsers);
    } else {
      console.log("user not found");
    }
  };

  //providing role(edit and commit,edit ,commit and publish) to user

  const provideRole = (user, role) => {
    //searching user from selected users
    const updatedSelectedUsers = [...selectedUsers];
    const selectedUserIndex = selectedUsers.findIndex(
      (usr) => usr.email === user.email
    );

    if (selectedUserIndex !== -1) {
      const selectedUser = updatedSelectedUsers[selectedUserIndex];

      //removing user and adding with role
      updatedSelectedUsers.splice(selectedUserIndex, 1, {
        ...selectedUser,
        role,
      });

      setSelectedUsers(updatedSelectedUsers);
    } else {
      console.log(selectedUserIndex);
    }
  };

  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    console.log("cancel clicked");
    handleClose();
  };
  const onClick2 = () => {
    console.log("create clicked");
  };
  const onClick3 = () => {
    console.log("stop sharing");
    setOpen(false);

    handleOpenModal("Stop Sharing");
  };
  console.log(selectedScript);
  return (
    <ModalForm
      id="RPA_ScriptSharingModal"
      isOpen={open}
      title="Script Sharing"
      name={selectedScript ? "Script :" + selectedScript.scriptName : ""}
      icon={
        <Description
          fontSize="small"
          style={{ color: "black", opacity: 0.5 }}
        />
      }
      Content={
        <Content
          id="RPA_ScriptSharingModal"
          textAreaForComments={textAreaForComments}
          handleChange={handleChange}
          selectedUsers={selectedUsers}
          onInvite={onInvite}
          username={username}
          filteredUsers={filteredUsers}
          onSelectUser={onSelectUser}
          provideRole={provideRole}
          allUsers={allUsers}
          owner={owner}
        />
      }
      btn1Title="Cancel"
      btn2Title="Create"
      btn3Title="Stop Sharing"
      onClick1={onClick1}
      onClick2={onClick2}
      onClick3={onClick3}
      closeModal={handleClose}
      containerHeight={500}
    />
  );
};
export default ScriptSharingModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {
    textAreaForComments,
    handleChange,
    selectedUsers,
    onInvite,
    username,
    filteredUsers,
    onSelectUser,
    provideRole,
    allUsers,
    owner,
    id,
  } = props;
  return (
    <>
      <div>
        <Field
          id={`${id}_InviteUsers`}
          label="Invite Users"
          {...username}
          width={450}
          helperText="Write usernames or email id."
          onChange={handleChange}
          allUsers={allUsers}
          selectedUsers={selectedUsers}
          filteredUsers={filteredUsers}
          onInvite={onInvite}
          btn="Invite"
          userRights={[
            " ",
            "Edit and Commit",
            "Edit,Commit and Publish",
            "View only",
          ]}
          onSelectUser={onSelectUser}
          provideRole={provideRole}
          owner={owner}
        />
        <Field
          id={`${id}_TextAreadForComments`}
          label=""
          name="TextAreaForComments"
          {...textAreaForComments}
          width={490}
          multiline={true}
          placeholder={"write comments here(optional).."}
          onChange={handleChange}
        />
      </div>
    </>
  );
};
