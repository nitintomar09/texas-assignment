import React, { useState, useContext, useEffect } from "react";
import makeStyles from "@mui/styles/makeStyles";
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import { FolderIcon } from "../../utils/AllImages";
import { PROJECT } from "./../../config/index";
import { NotificationContext } from "../../contexts/NotificationContext";
import {
  createInstance,
  handleNetworkRequestError,
} from "./../../utils/common";
import { useHistory } from "react-router-dom";
import {
  isEmptyText,
  MaximumLengthText,
  isContainSpecialCharacters,
  isContainSpecialCharactersForProject,
} from "../../utils/validations/validations";

const useStyles = makeStyles(() => ({
  container: {
    marginTop: "4rem",
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

const AddProjectModal = (props) => {
  const { setValue } = useContext(NotificationContext);
  const history = useHistory();

  const { editedProject, setEditedProject } = props;
  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [isCreating, setIsCreating] = useState(false);
  const [formHasError, setFormHasError] = useState(true);

  const [projectName, setProjectName] = useState(makeFieldInputs(""));
  const [description, setDescription] = useState(makeFieldInputs(""));

  useEffect(() => {
    if (editedProject) {
      console.log(editedProject,"editedProject")
      const { projectName: name, description: editedDes } = editedProject;
      setProjectName({ ...projectName, value: name });
      setDescription({ ...description, value: editedDes });
    }
  }, [editedProject]);
    /**
@author - akshat_pokhriyal
@Date - 28/02/2024
@Bug Id - 143859
@Bug Description -   Script Designer --> Unable to Rename Project + Wrong Error message displayed.
@Bug Reason of occurence - null handling  issue for description
@Solution - handled null 
**/
  function trimString(input) {
    // Check if the input is a string
    if (typeof input === 'string') {
        // Trim the string and return
        return input.trim();
    } else {
        // If it's not a string, return the input as it is
        return input;
    }
}

  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";
    // BugId:Bug 142390 - Project Name should be combination of character and special character
    // Author:Dixita
    // Date:24-01-2024
    // RCA:New Regex old validation is not working
    switch (name) {
      case "Project Name":
        errors =
          isEmptyText(value) ||
          MaximumLengthText(value, 40) ||
          isContainSpecialCharactersForProject(value);
        setProjectName({
          ...projectName,
          value,
          error: errors,
          helperText: errors,
        });
        break;
      case "Description":
        errors = MaximumLengthText(value, 2000);
        setDescription({
          ...description,
          value,
          error: errors,
          helperText: errors,
        });
        break;
      default:
        break;
    }
  };
  useEffect(() => {
    if (projectName?.error || description?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [projectName, description]);
  const validateFields = () => {
    const projectNameErrors =
      isEmptyText(projectName.value) ||
      MaximumLengthText(projectName.value, 40) ||
      isContainSpecialCharactersForProject(projectName.value);

    if (projectNameErrors) {
      setProjectName({
        ...projectName,
        error: projectNameErrors,
        helperText: projectNameErrors,
      });
    }
    const desErr = MaximumLengthText(description.value, 2000);
    if (desErr) {
      setDescription({
        ...description,
        error: desErr,
        helperText: desErr,
      });
    }

    return desErr || projectNameErrors ? false : true;
  };

  const handleClose = () => {
    setOpen(false);

    props.handleClose();
  };
  const onClick1 = () => {
    if (editedProject) {
      setEditedProject(null);
    }
    handleClose();
  };
  const onClick2 = async () => {
    if (!validateFields()) {
      return;
    }
    const axiosInstance = createInstance();
    setIsCreating(true);
    if (editedProject) {
      if (projectName.value) {
        try {
          let res1 = await axiosInstance.put(`${PROJECT}`, {
            projectName: projectName.value,
            description: trimString(description.value),

            projectId: editedProject.projectId,
            createdOn: Date.now(),
          });

          if (res1.status === 200) {
            props.updateProjects(res1.data.data[0]);
            setIsCreating(false);
            //creating Notification
            debugger 
            setValue({
              isOpen: true,
              message: res1.data.message,
              notificationType: "SUCCESS",
              title: projectName.value,
            });
            setEditedProject(null);
            props.handleClose();
          }
        } catch (error) {
          setIsCreating(false);

          handleNetworkRequestError({
            error,
            history,
            onError: (errMsg) => {
              setValue({
                isOpen: true,
                message: errMsg || "updation failed.",
                notificationType: "ERROR",
                title: "",
              });
            },
          });
        }
      } else {
        console.log("provide name");
        setIsCreating(false);
      }
    } else {
      try {
          /**
@author - akshat_pokhriyal
@Date - 23/01/2024
@Bug Id - 142570
@Bug Description - RPA designer->script -> create project -> not able to create project when we enter project name and description at max limit -> getting error in create project and max limit reached for description 
@Bug Reason of occurence - it was accepting leading and trailing input spaces
@Solution - added trim method
**/
        var res = await axiosInstance.post(`${PROJECT}`, {
          projectName: projectName.value,
          description: trimString(description.value),
        });

        if (res.status === 200) {
          props.updateProjects(res.data.data[0]);
          setIsCreating(false);

          //creating Notification
          setValue({
            isOpen: true,
            message: res.data.message,
            notificationType: "SUCCESS",
            title: projectName.value,
          });
          props.handleClose();
        }
      } catch (error) {
        // changes to resolve the bug Id 142365
		//pragya.rai
        // alert("error in create project")
        setIsCreating(false);

        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "creation failed.",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
      }
    }
  };

  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={
        editedProject && editedProject.projectName
          ? "Update Folder"
          : "Create a Folder"
      }
      isProcessing={isCreating}
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      Content={
        <Content
          id={props.id}
          options={props.options}
          projectName={projectName}
          description={description}
          handleChange={handleChange}
        />
      }
      btn1Title="Cancel"
      btn2Title={editedProject ? "Update" : "Create Folder"}
      onClick1={onClick1}
      onClick2={onClick2}
      btn2Disabled={formHasError}
      closeModal={handleClose}
      containerHeight={300}
      containerWidth={490}
    />
  );
};
export default AddProjectModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const { id, projectName, description, handleChange } = props;
  return (
    <>
      <div>
        <Field
          id={`${id}_ProjectName`}
          name="Project Name"
          label="Folder Name"
          {...projectName}
          required={true}
          // width={442}
          onChange={handleChange}
          icon={FolderIcon}
          paddingTop={"0px"}
        />
        <Field
          id={`${id}_Description(Optional)`}
          label="Description(Optional)"
          name="Description"
          {...description}
          multiline={true}
          height={56}
          // width={442}
          onChange={handleChange}
        />
      </div>
    </>
  );
};
