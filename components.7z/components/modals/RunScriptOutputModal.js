import React, { useEffect, useState, useRef } from "react";
import Drawer from "@mui/material/Drawer";

import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import Close from "@mui/icons-material/Close";

import makeStyles from '@mui/styles/makeStyles';
import { Grid, Button, Tab, Tabs, IconButton } from "@mui/material";
import { useSelector } from "react-redux";

import {
  CancelOutlined,
  InfoOutlined,
  ReportProblemOutlined,
} from "@mui/icons-material";
import { ErrorIcon, InformationIcon, WarningIcon } from "../../utils/AllImages";
import LoadingIndicator from "../../utils/loadingIndicator";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";
const drawerWidth = window.innerWidth - 388;

const useStyles = makeStyles((theme) => ({
  root: {
    padding: "10px",
    //height: "272px",
    //WCAG- Resize upto 200%, the height must not be more than 1/4 of the screen as per UX.
    height: "25vh",
  },
  drawer: {
    //height: "272px",
    //WCAG- Resize upto 200%, the height must not be more than 1/4 of the screen as per UX.
   // height: "25vh",
    flexShrink: 0,
  },
  drawerPaper: {
    backgroundColor: "#FFFFFF",
    paddingRight: "20px",
    //paddingLeft: "15px",
    //height: "252px",
    //WCAG- Resize upto 200%, the height must not be more than 1/4 of the screen as per UX.
  //  height: "25vh",
    marginRight: "8px",
    minWidth: "700px",
    overflow: "auto hidden",
  },
  drawerPaper1: {
    backgroundColor: "#FFFFFF",

    // paddingRight: "15px",
    // paddingLeft: "15px",

    //height: "252px",
  //  height: `${drawerHeight}px`,
    overflowY: "hidden",
    overflowX: "auto",
    marginRight: "8px",
    minWidth: "700px",
    width: `calc(100vw - 390px)`,

    //width: drawerWidth,
  },

  header: {
    height: "30px",
  },
  backdrop: {
    zIndex: theme.zIndex.drawer + 1,
    color: "#fff",
  },
  output: {
    //marginTop: "-5px",
    fontSize: 14,
    fontWeight: 600,

    //For WCAG- Resize Text
    overflow: "auto",
  },
  items: {
    fontSize: "12px",
    marginRight: "5px",
    cursor: "pointer",
  },
  selectedItem: {
    fontSize: "12px",
    marginRight: "5px",
    cursor: "pointer",
    color: `${theme.palette.primary.main}`,
  },
  selectedTab: {
    borderBottom: `4px solid ${theme.palette.primary.main}`,
  },
  messages: {
    padding: "20px",
    height: "200px",
    overflowY: "scroll",
    overflowX: "hidden",
  },
  warning: {
    color: "#DFAD24",
    fontSize: "12px",
  },
  error: {
    color: "#DB1F1F",
    fontSize: "12px",
  },
  info: {
    fontSize: "12px",
  },
  lead: {
    fontSize: "12px",
    opacity: ".44",
  },
  loading: {
    height: "100px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  iconSize: {
    height: "16px",
    width: "16px",
    marginTop: '4px'
  },
  iconSizeMessage: {
    height: "16px",
    width: "16px",
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  closeIcon: {
    height: "16px",
    width: "16px",
  },
}));

const RunScriptOutputModal = (props) => {
  const classes = useStyles();
  const messageEndRef = useRef(null);
  const { isOpen, isPropertyWindowOpen, openTab, outputObj, handleOutputObj } =
    props;
  const [open, setOpen] = useState(isOpen ? true : false);
  const [selectedTab, setSelectedTab] = useState(0);
  const[drawerHeight,setDrawerHeight]=useState({height:200});
  const [isHovered, setIsHovered] = useState(false);

  const isExecutionPause = useSelector(
    (state) => state.editorHomepage.isExecutionPause
  );
  const isDebuging = useSelector((state) => state.editorHomepage.isDebuging);

  const isExecutingScript = useSelector(
    (state) => state.editorHomepage.isExecutingScript
  );

  const scrollToBottom = () => {
    messageEndRef.current?.scrollIntoView({ behaviour: "smooth" });
  };
  useEffect(() => {
    scrollToBottom();
  }, [outputObj]);
  useEffect(() => {
    if (openTab) {
      const index = allItems.findIndex((item) => item.name === openTab);
      if (index !== -1) {
        setSelectedTab(index);
      }
    }
  }, [openTab]);

  const handleSelectedTab = (index) => {
    setSelectedTab(index);
  };
  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const handleMouseDown=(e)=>{
   // e.preventDefault();
    const startHeight=drawerHeight.height;
    const startY=e.clientY;

    const handleMouseMove=(e)=>{
      const newHeight = Math.max(100, startHeight - (e.clientY - startY));
    
      setDrawerHeight({height:newHeight>=500?500:newHeight});
    };

    const handleMouseUp=(e)=>{
      window.removeEventListener('mousemove',handleMouseMove);
      window.removeEventListener('mouseup',handleMouseUp);
    };

    window.addEventListener('mousemove',handleMouseMove);
    window.addEventListener('mouseup',handleMouseUp);
  };
 //console.log(drawerHeight.height,"drawerHeight")
  const showIcon = (item, fromMessages) => {
    let iconToReturn = null;
    switch (item) {
      case "Warning":
        iconToReturn = (
          <UniqueIDGenerator>
            <WarningIcon className={fromMessages ? classes.iconSizeMessage : classes.iconSize} />
          </UniqueIDGenerator>
        );
        break;
      // case "Info":
      //   iconToReturn = (
      //     <UniqueIDGenerator>
      //       <InformationIcon className={fromMessages ? classes.iconSizeMessage : classes.iconSize} />
      //     </UniqueIDGenerator>
      //   );
      //   break;
      case "Error":
        iconToReturn = (
          <UniqueIDGenerator>
            <ErrorIcon className={fromMessages ? classes.iconSizeMessage : classes.iconSize} />
          </UniqueIDGenerator>
        );
        break;
      default:
        break;
    }
    return iconToReturn;
  };

  const getVisibleOutputArray = () => {
    let visibleOutputArray = [...outputObj];
    if (allItems[selectedTab].name !== "All") {
      visibleOutputArray = outputObj.filter(
        (item) => item.messageType === allItems[selectedTab].value
      );
    }
    return visibleOutputArray || [];
  };

  const handleTab = (e, newValue) => {
    handleSelectedTab(newValue)
  }
 // console.log(drawerHeight,"draweHeight")
  return (
    <div className={classes.root}>
      <Drawer
        className={classes.drawer}
        variant="permanent"
        anchor="bottom"
        open={open}
      
        classes={{
          paper: isPropertyWindowOpen
            ? classes.drawerPaper1
            : classes.drawerPaper,
        }}
        BackdropProps={{ invisible: true }}
        onClose={handleClose}
        id={`${props.id}_Drawer`}
        sx={{
          '& .MuiDrawer-paper': {
            height: `${drawerHeight.height}px`, // Use the state height dynamically
          }
        }}
      >
        
        <Grid
          container
          direction="row"
          spacing={1}
          alignItems="center"
          // alignContent="center"
          style={{
            //paddingTop: "8px",
            // paddingBottom: "10px",
            paddingLeft: "15px",
            paddingRight: "8px",
          }}
        >
          <Grid item className={classes.output}>
            Output Console
          </Grid>
          <Grid item>
            <Grid container direction="row">
              <Tabs
                value={selectedTab}
                onChange={(event, newValue) => handleTab(event, newValue)}
                indicatorColor="primary"
                textColor="primary"
                aria-label="Category wise message Tabs"
              >
                {allItems.map((item, index) => (
                  <Tab
                    id={`${props.id}_${item.name}_Tab`}
                    value={index}
                    icon={showIcon(item.value)} iconPosition="start"
                    label={
                      <div style={{ display: 'flex', alignItems: 'center', cursor: 'pointer', gap: '8px', marginLeft: '8px' }}>
                        <Typography className={classes.textBold}>{item.name}</Typography>
                        <Typography className={classes.textBold}>{`(${item.name === "All"
                          ? outputObj.length
                          // : item.value === "Info"
                          //   ? outputObj.filter(
                          //     (obj) => obj.messageType === "Info"
                          //   ).length
                            : outputObj.filter(
                              (obj) => obj.messageType === item.value
                            ).length})`}</Typography>

                      </div>
                    }

                  />))}
              </Tabs>
            </Grid>
          </Grid>
          <Grid item style={{ marginLeft: "auto" }}>
            <Grid container spacing={1}>
              <Grid item style={{ overflow: "auto" }}>
                <Button
                  variant="text"
                  color="primary"
                  size="small"
                  onClick={() => handleOutputObj([])}
                  disableRipple
                  disableTouchRipple
                  id={`${props.id}_ClearBtn`}
                >
                  Clear Console
                </Button>
              </Grid>
              <Grid
                item
                style={{ marginRight: "-8px", cursor: "pointer" }}

              >
                <IconButton
                  id={`${props.id}_CloseBtn`}
                  onClick={handleClose}
                  aria-label="Close Output Window"
                >
                  <Close
                    fontSize="small"
                    className={classes.closeIcon}
                    aria-hidden={false}
                  />
                </IconButton>
              </Grid>
            </Grid>
          </Grid>
        </Grid>

        <Divider variant="fullWidth" />

        <div
          className={classes.messages + " " + classes.focusVisible}
          tabIndex={0}
        >
          <Grid container direction="column" spacing={2}>
            {/* <Backdrop className={classes.backdrop} open={isExecutingScript}>
              <CircularProgress color="primary" />
                          </Backdrop>*/}
            {getVisibleOutputArray().map((message, index) => (
              <Grid container spacing={1} key={index}>
                {message.messageType && (
                  <Grid item>
                    <Typography>{showIcon(message.messageType, true)}</Typography>
                  </Grid>
                )}

                <Grid item>
                  <Typography
                    className={
                      message.messageType === "Warning"
                        ? classes.warning
                        : message.messageType === "Error"
                          ? classes.error
                          : classes.info
                    }
                  >
                    {message.message}
                  </Typography>
                </Grid>
                {index === getVisibleOutputArray().length - 1 &&
                  !isExecutionPause &&
                  (isDebuging || isExecutingScript) && (
                    <Grid item style={{ marginLeft: "10px" }}>
                      <LoadingIndicator />
                    </Grid>
                  )}
              </Grid>
            ))}
            <div ref={messageEndRef}></div>
          </Grid>
        </div>
        {/* Resizer Handle */}
        <div
          onMouseDown={handleMouseDown}
          onMouseEnter={() => setIsHovered(true)}   
          onMouseLeave={() => setIsHovered(false)}
          style={{
            height: '2px',
            backgroundColor: isHovered?'#0072C6':"",
            cursor: 'ns-resize',
            position: 'absolute',
            top:0,
            left:0,
            right:0,
          }}
        />
      </Drawer>
    </div>
  );
};

export default RunScriptOutputModal;

const allItems = [
  { name: "All", value: "All" },
  // { name: "Information", value: "Info" },
  { name: "Errors", value: "Error" },
  { name: "Warnings", value: "Warning" },
];
