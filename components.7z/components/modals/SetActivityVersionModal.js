import React, { useState, useEffect, useContext } from "react";
import { useSelector, useDispatch } from "react-redux";
import JohnDoe from "../../assets/img/johnDoe1.jpg";
import ModalForm from "../../utils/modalForm";
import LoadingIndicator from "./../../utils/loadingIndicator";
import { makeStyles } from "@mui/styles";
import {
  getDateStr,
  createInstance,
  handleNetworkRequestError,
  UseFormInput,
  getDateAndTimeStr,
} from "../../utils/common";

import {
  Grid,
  Typography,
  List,
  ListItem,
  CircularProgress,
  Button,
} from "@mui/material";
import { NotificationContext } from "../../contexts/NotificationContext";
import { useHistory } from "react-router-dom";
import {
  API_BASE_URL,
  ICONS,
  CUSTOM_ACTIVITY_GROUP,
  SET_CUSTOM_ACTIVITIES_VERSIONS,
} from "./../../config/index";
import { setActiveVersionsOfCustomActivities } from "../../redux/actions";
import Field from "./../../utils/field";
import { useTranslation } from "react-i18next";
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};
const SetActivityVersionModal = (props) => {
  const classes = useStyles();
  const history = useHistory();
  const dispatch = useDispatch();

  const scriptValues = useSelector((state) => state.script.openScriptDetails);

  const { setValue: setNotification } = useContext(NotificationContext);
  const [allCustomFetchedActivities, setAllCustomFetchedActivities] = useState(
    []
  );
  const [allCustomActivities, setAllCustomActivities] = useState([]);

  //const [latestVersion, setLatestVersion] = useState("");

  const [selCustomActivity, setSelCustomActivity] = useState(null);
  const [appliedVersion, setAppliedVersion] = useState(null);
  const [selCustomActivityVersion, setSelCustomActivityVersion] = useState(
    makeFieldInputs(null)
  );
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [open, setOpen] = useState(props.isOpen ? true : false);
  useEffect(() => {
    getCstomActivityDetails();
  }, []);
  const getCstomActivityDetails = async () => {
    if (scriptValues) {
      const { scriptId, versionId } = scriptValues;
      const axiosInstance = createInstance();
      setIsLoading(true);
      try {
        let res = await axiosInstance.get(
          `${CUSTOM_ACTIVITY_GROUP}/${scriptId}/${versionId}`
        );
        console.log(res);
        if (res.status === 200) {
          const cusActDtls = res.data.data;

          setAllCustomFetchedActivities(cusActDtls || []);
          const activeActivities = cusActDtls.filter((item) => item.isActive);
          setAllCustomActivities(activeActivities);
          if (activeActivities.length > 0) {
            setSelCustomActivity(activeActivities[0]);
            setSelCustomActivityVersion({
              ...selCustomActivityVersion,
              value: activeActivities[0].dependency,
            });
          }
          setIsLoading(false);
        }
      } catch (error) {
        console.log(error);
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setNotification({
              isOpen: true,
              message: errMsg || "could not fetch the custom activity details.",
              title: "",
              notificationType: "ERROR",
            });
          },
        });

        setIsLoading(false);
      }
    }
  };
  const handleChange = (e) => {
    const { name, value } = e.target;
    console.log(name, value);
    if (name === "ActivityVersion") {
      setSelCustomActivityVersion({ ...selCustomActivityVersion, value });
    }
  };
  const onApplyVersion = () => {
    {
      /*****************************************************************************************
       * @author asloob_ali BUG ID :  105948  Set Custom Activity Version: Not able to set previous versions from setting option
       * Reason:we did change the version/dependency type,thats why it was comparing versions with different data type.
       *  Resolution :changed the data type of selected custom Activity Version name value as we are getting in api response
       *  Date : 28/02/2022             ***************************************************************************************/
    }
    setAppliedVersion(selCustomActivityVersion?.value);
    const activityGroupForSelVer = allCustomFetchedActivities.find(
      (item) =>
        item.groupName === selCustomActivity.groupName &&
        item.dependency === +selCustomActivityVersion.value
    );
    const activityGroupForSelVerIndex = allCustomFetchedActivities.findIndex(
      (item) =>
        item.groupName === selCustomActivity.groupName &&
        item.dependency === +selCustomActivityVersion.value
    );

    if (activityGroupForSelVer) {
      const newCusActivities = [...allCustomActivities];
      let newCusFetchActivities = [...allCustomFetchedActivities];

      const indexInCustomList = allCustomActivities.findIndex(
        (item) => item.groupName === activityGroupForSelVer.groupName
      );
      //const itemInFetchedCustomList=allCustomFetchedActivities.find(item=>item.groupName===activityGroupForSelVer.groupName && item.dependency===selCustomActivity.dependency);

      // const indexInFetchedCustomList=allCustomFetchedActivities.findIndex(item=>item.groupName===activityGroupForSelVer.groupName && item.dependency===selCustomActivity.dependency);

      if (indexInCustomList !== -1) {
        newCusActivities.splice(indexInCustomList, 1, {
          ...activityGroupForSelVer,
          isActive: true,
        });
        newCusFetchActivities.splice(activityGroupForSelVerIndex, 1, {
          ...activityGroupForSelVer,
          isActive: true,
        });
        newCusFetchActivities = newCusFetchActivities.map((item) => {
          if (item.groupName === activityGroupForSelVer.groupName) {
            if (item.dependency === activityGroupForSelVer.dependency) {
              return { ...item, isActive: true };
            }
            return { ...item, isActive: false };
          }
          return item;
        });
        setAllCustomActivities(newCusActivities);
        setAllCustomFetchedActivities(newCusFetchActivities);
        setSelCustomActivity(activityGroupForSelVer);
      }
    }
  };
  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    console.log("cancel clicked");
    handleClose();
  };
  const onClick2 = async () => {
    const { scriptId, versionId } = scriptValues;
    const axiosInstance = createInstance();
    setIsProcessing(true);
    try {
      const groupIds = allCustomActivities.map((item) => item.groupId);
      let res = await axiosInstance.post(`${SET_CUSTOM_ACTIVITIES_VERSIONS}`, {
        scriptId,
        versionId,
        groupId: [...groupIds],
      });
      console.log(res);
      if (res.status === 200) {
        const cusActDtls = res.data.data || [];
        dispatch(setActiveVersionsOfCustomActivities(cusActDtls));
        setIsProcessing(false);
        setNotification({
          isOpen: true,
          message: res.data["message"] || "Success.",
          title: "",
          notificationType: "SUCCESS",
        });
        handleClose();
      }
    } catch (error) {
      console.log(error);
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setNotification({
            isOpen: true,
            message: errMsg || "could not set the custom activity version.",
            title: "",
            notificationType: "ERROR",
          });
        },
      });

      setIsProcessing(false);
    }
  };
  const handleSelCustomActivity = (activity) => {
    setSelCustomActivity(activity);
    const allActivitiesGrp = allCustomFetchedActivities.filter(
      (item) => item.groupName === activity?.groupName
    );
    if (allActivitiesGrp.length > 0) {
      // setLatestVersion(allActivitiesGrp[0]?.dependency);
      const activeVerActivity = allActivitiesGrp.find((item) => item.isActive);
      setSelCustomActivityVersion({
        ...selCustomActivityVersion,
        value: activeVerActivity?.dependency,
      });
    }
  };
  const Loading = () => {
    return (
      <Grid container justifyContent="center" alignItems="center">
        <Grid item>
          <LoadingIndicator />
        </Grid>
      </Grid>
    );
  };
  const isLatest = (item) => {
    const allCustomGroups = allCustomFetchedActivities.filter(
      (grp) => grp.groupName === item.groupName
    );
    if (
      allCustomGroups.length > 0 &&
      allCustomGroups[0].dependency === item.dependency
    ) {
      return "latest";
    }
    return "";
  };
  const isDeprecated = (item) => {
    const CustomGroup = allCustomFetchedActivities.find(
      (grp) =>
        grp.groupName === item.groupName && grp.dependency === item.dependency
    );
    if (CustomGroup?.isDeprecated) {
      return "Deprecated";
    }
    return "";
  };
  const getAllVersions = () => {
    const versions = allCustomFetchedActivities
      .filter((grp) => grp.groupName === selCustomActivity?.groupName)
      .map((item) => item.dependency);

    if (versions.length > 0) {
      return versions.map((ver) => {
        return {
          name:
            ver +
            " " +
            isLatest({
              ...selCustomActivity,
              dependency: ver,
            }) +
            isDeprecated({
              ...selCustomActivity,
              dependency: ver,
            }),
          value: ver,
          isDisabled: isDeprecated({
            ...selCustomActivity,
            dependency: ver,
          })
            ? true
            : false,
        };
      });
    }

    return [];
  };

  return (
    <ModalForm
      id="RPA_SetActivityVersionModal"
      isOpen={open}
      title="Set Custom Activity versions"
      Content={
        <Content
          id="RPA_SetActivityVersionModal"
          allCustomActivities={allCustomActivities}
          allCustomFetchedActivities={allCustomFetchedActivities}
          selCustomActivity={selCustomActivity}
          handleSelCustomActivity={handleSelCustomActivity}
          isLoading={isLoading}
          selCustomActivityVersion={selCustomActivityVersion}
          getAllVersions={getAllVersions}
          isLatest={isLatest}
          isDeprecated={isDeprecated}
          handleChange={handleChange}
          onApplyVersion={onApplyVersion}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      isProcessing={isProcessing}
      paddingLeftContent={"0pt"}
      paddingRightContent={"0pt"}
      btn1Title="Cancel"
      onClick1={onClick1}
      btn2Title="Save"
      onClick2={onClick2}
      btn2Disabled={!appliedVersion}
      closeModal={handleClose}
      containerHeight={500}
      containerWidth={800}
      footerText="The changes made will be reflected on this Service Flow only."
    />
  );
};

export default SetActivityVersionModal;

const useStyles = makeStyles((theme) => ({
  selectedTab: {
    background: `${theme.palette.primary.light} 0% 0% no-repeat padding-box`,
    opacity: 1,

    paddingLeft: "16px",
    paddingRight: "16px",
  },
  selectedTabText: {
    fontWeight: 600,
    color: "#606060",
  },
  tab: {
    paddingLeft: "16px",
    paddingRight: "16px",
  },
  icons: {
    width: "16px",
    height: "16px",
  },
  scrollDiv: {
    //  paddingRight: "8px",
    marginTop: "-10px",
    height: "410px",
    overflow: "hidden",
    "&:hover": {
      overflowY: "auto",
    },
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  title: {
    fontWeight: 700,
  },
  labels: {
    fontWeight: 600,
    color: "#606060",
  },
  groupName: {
    fontSize: "14px",
    fontWeight: 600,
  },
}));

const Content = ({
  isLoading,
  allCustomActivities,
  allCustomFetchedActivities,
  selCustomActivity,
  handleSelCustomActivity,
  selCustomActivityVersion,
  getAllVersions,
  isLatest,
  isDeprecated,
  handleChange,
  onApplyVersion,
  id,
}) => {
  const classes = useStyles();
  const {t} = useTranslation()
  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };
  const truncateString = (str) => {
    return str.trim().length > 26 ? str.substring(0, 20) + ".." : str;
  };
  return (
    <div style={{ paddingRight: "4px" }}>
      <Grid container>
        <Grid
          item
          container
          direction="column"
          xs={4}
          style={{ borderRight: "1px solid #C4C4C4" }}
        >
          <Grid item style={{ marginBottom: "10px", paddingLeft: "16px" }}>
            <Typography className={classes.title}>{t("Currently Using")}</Typography>
          </Grid>
          <div
            className={classes.scrollDiv + " " + classes.focusVisible}
            tabIndex={0}
          >
            <List>
              {isLoading && (
                <div
                  style={{
                    width: "100%",
                    height: "100%",
                    textAlign: "center",
                    zIndex: 1,
                    verticalAlign: "center",
                    marginTop: "10px",
                  }}
                >
                  <CircularProgress
                    style={{
                      alignItems: "center",
                      width: "20px",
                      height: "20px",
                      textAlign: "center",
                    }}
                  />
                </div>
              )}
              {!isLoading && allCustomActivities.length > 0 ? (
                allCustomActivities.map((item, index) => {
                  return (
                    <React.Fragment key={item.groupId || index}>
                      <ListItem
                        button
                        key={index}
                        onClick={() => handleSelCustomActivity(item)}
                        disableGutters
                        className={
                          selCustomActivity &&
                          selCustomActivity.groupId === item.groupId
                            ? classes.selectedTab
                            : classes.tab
                        }
                        id={`${id}_${index}`}
                      >
                        <Grid
                          container
                          direction="row"
                          justifyContent="flex-start"
                          alignItems="center"
                          spacing={1}
                        >
                          <Grid item>
                            <img
                              src={getImage(item?.groupName)}
                              className={classes.icons}
                              alt={`${item?.groupName} Icon`}
                            />
                          </Grid>

                          <Grid item>
                            <Typography
                              className={
                                selCustomActivity &&
                                selCustomActivity.groupId === item.groupId
                                  ? classes.selectedTabText
                                  : classes.labels
                              }
                              title={item.groupName}
                            >
                              {item.groupName
                                ? truncateString(item.groupName)
                                : "Unknown"}
                            </Typography>
                          </Grid>
                          <Grid item style={{ marginLeft: "auto" }}>
                            v {item.dependency || ""}
                          </Grid>
                        </Grid>
                      </ListItem>
                    </React.Fragment>
                  );
                })
              ) : (
                <Typography variant="subtitle2" style={{ paddingLeft: "15px" }}>
                  {t("There are no Custom Activities available.")}
                </Typography>
              )}
            </List>
          </div>
        </Grid>
        <Grid item xs style={{ paddingLeft: "25px" }}>
          {selCustomActivity && (
            <>
              <Grid container direction="column">
                <Grid item container spacing={1}>
                  <Grid item>
                    <img
                      src={getImage(selCustomActivity?.groupName)}
                      className={classes.icons}
                      alt={`${selCustomActivity?.groupName} Icon`}
                    />
                  </Grid>

                  <Grid item>
                    <Typography className={classes.groupName}>
                      {selCustomActivity.groupName
                        ? selCustomActivity.groupName
                        : t("Unknown")}
                    </Typography>
                  </Grid>
                </Grid>
                <Grid item container spacing={1} alignItems="flex-end">
                  <Grid item xs>
                    <Field
                      id={`${id}_ActivityVersion`}
                      name="ActivityVersion"
                      {...selCustomActivityVersion}
                      dropdown={true}
                      options={getAllVersions()}
                      onChange={handleChange}
                      height="28px"
                    />
                  </Grid>
                  <Grid item>
                    <Button
                      style={{
                        fontSize: "12px",
                        height: "28px",
                        textAlign: "center",
                      }}
                      variant="contained"
                      size="small"
                      color="primary"
                      disabled={
                        selCustomActivityVersion.value ===
                        selCustomActivity.dependency
                      }
                      onClick={(e) => onApplyVersion()}
                      id={`${id}_ApplyBtn`}
                    >
                      {t("Apply")}
                    </Button>
                  </Grid>
                </Grid>
              </Grid>
              <Grid container direction="column" style={{ marginTop: "26px" }}>
                <Grid item>
                  <Typography>
                    {selCustomActivity?.description || ""}
                  </Typography>
                </Grid>
              </Grid>
              <Grid
                container
                direction="row"
                spacing={1}
                style={{ marginTop: "26px" }}
              >
                <Grid item xs={4} container direction="column" spacing={1}>
                  <Grid item>
                    <Typography className={classes.labels}>
                      {t("No. of Subactivities")}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography>
                      {selCustomActivity?.activities?.length || ""}
                    </Typography>
                  </Grid>
                </Grid>
                <Grid item xs={4} container direction="column" spacing={1}>
                  <Grid item>
                    <Typography className={classes.labels}>
                      {t("Date Published")}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography>
                      {getDateAndTimeStr(selCustomActivity?.createdOn || "")}
                    </Typography>
                  </Grid>
                </Grid>
                <Grid item xs={4} container direction="column" spacing={1}>
                  <Grid item>
                    <Typography className={classes.labels}>
                      {t("Developed By")}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography>
                      {selCustomActivity?.developedBy || ""}
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
              {/* <Grid container direction="column" style={{ marginTop: "40px" }}>
                <Grid item>
                  <Typography className={classes.labels}>
                    Recommended Version for backward compatibility
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography>V 1.2.0 and above</Typography>
                </Grid>
              </Grid>
              <Grid container direction="column" style={{ marginTop: "40px" }}>
                <Grid item>
                  <Typography className={classes.labels}>
                    Recommended RPA Version to work
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography>V 1.4 and above</Typography>
                </Grid>
                    </Grid>*/}
            </>
          )}
        </Grid>
      </Grid>
    </div>
  );
};

const allCustomactivitiesList = [
  {
    groupId: 1,
    groupName: "Custom1",
    description: "Recently used activities.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    developedBy: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    activities: ["Create", "Delete", "Update"],
    readmeDoc: null,
    currentVersion: "1.4",
  },
  {
    groupId: 2,
    groupName: "Custom2",
    description: "Favourites activities.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    developedBy: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    activities: ["Create", "Delete", "Update"],
    readmeDoc: null,
    currentVersion: "1.3",
  },
  {
    groupId: 3,
    groupName: "Custom3",
    description: "to make a group of activities to perform a certain task.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    developedBy: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    activities: ["Create", "Delete", "Update"],
    readmeDoc: null,
    currentVersion: "1.5",
  },
  {
    groupId: 4,
    groupName: "Custom4",
    description:
      "By default, the UiPath.AbbayEmbedded.Activities pack is available for a wide range of languages. You can check the entire list by accessing the abbay Screen OCR activity page or the Abbay Document OCR,An extra bundle package available for ChinesePRC,ChineseTaiwan and Korean Hungell,but it need to be installed separately by using the manage packages button.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    developedBy: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    activities: ["Create", "Delete", "Update"],
    readmeDoc: "browser-file.pdf",
    currentVersion: "1.0",
  },
];
