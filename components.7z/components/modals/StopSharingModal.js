import React, { useState } from "react";
import ModalForm from "./../../utils/modalForm";
import { Description } from "@mui/icons-material";
import { Typography, Grid } from "@mui/material";
import { useTranslation } from "react-i18next";

const StopSharingModal = (props) => {
  const { selectedScript } = props;
  const {t} = useTranslation()

  const [open, setOpen] = useState(props.isOpen ? true : false);

  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    console.log("No clicked");
    handleClose();
  };
  const onClick2 = () => {
    console.log("Yes clicked");
  };

  return (
    <ModalForm
      id="RPA_StopSharingModal"
      isOpen={open}
      title={t("Stop Sharing")}
      name={selectedScript ? "Script :" + selectedScript.title : ""}
      icon={
        <Description
          fontSize="small"
          style={{ color: "black", opacity: 0.5 }}
        />
      }
      Content={<Content />}
      btn1Title={t("No")}
      btn2Title={t("Yes")}
      onClick1={onClick1}
      onClick2={onClick2}
      closeModal={handleClose}
      containerHeight={200}
      containerWidth={500}
    />
  );
};
export default StopSharingModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {t} = useTranslation()
  return (
    <>
      <div style={{ marginTop: "10px" }}>
        <Grid container spacing={2} direction="column">
          <Grid item>
            <Typography style={{ fontWeight: "bold" }}>
              {t("Are you sure you want to stop the sharing capability of this Service Flow?")}
            </Typography>
          </Grid>
          <Grid item>
            <Typography>
              {t("Stopping the share capability will make other members of the Service Flow unable to access.")}
            </Typography>
          </Grid>
        </Grid>
      </div>
    </>
  );
};
