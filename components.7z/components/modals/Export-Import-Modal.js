import React, { useState, useRef, useEffect, useContext } from "react";
import makeStyles from '@mui/styles/makeStyles';
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import { DocIcon, FolderBrowseIcon } from "../../utils/AllImages";
import PropertyField from "../script-editor/PropertyWindow/PropertyFields/PropertyField";
import { Typography, Grid } from "@mui/material";
import {
  isEmptyText,
  MaximumLengthText,
  isContainSpecialCharacters,
} from "../../utils/validations/validations";
import { createInstance, handleNetworkRequestError } from "../../utils/common";
import { API_BASE_URL, IMPORT } from "../../config";
import { useHistory } from "react-router";
import { EXPORT } from "./../../config/index";
import { NotificationContext } from "../../contexts/NotificationContext";
import { LoadingIndicatorWithProgress } from "../../utils/loadingIndicator";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";

const useStyles = makeStyles((theme) => ({
  container: {
    marginTop: "4rem",
  },
  colorPrimary: {
    color: "white",
    backgroundColor: `${theme.palette.primary.main}`,
    borderRadius: "2px",
  },
  btnIcon: {
    cursor: "pointer",
    height: "28px",
    width: "28px",

    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
      //background: "#add8e6 0% 0% no-repeat padding-box",
    },
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

const ExportImportModal = (props) => {
  const hiddenFileInput = useRef(null);
  const { setValue } = useContext(NotificationContext);
  const history = useHistory();
  const {
    selectedScript,
    actionType,
    selectedProject,
    updateScripts,
    allScripts,
  } = props;
  console.log(allScripts);
  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [dirLocation, setDirLocation] = useState(makeFieldInputs(""));
  const [comment, setComment] = useState(makeFieldInputs(""));
  const [importedScriptName, setImportedScriptName] = useState(
    makeFieldInputs("")
  );
  const [formHasError, setFormHasError] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [fileToBeImported, setFileToBeImported] = useState(null);
  const [percentUploaded, setPercentUploaded] = useState(0);

  const handleChange = (e) => {
    const { name, value } = e.target;
    let errors = "";

    switch (name) {
      case "DirLocation":
        errors = isEmptyText(value);
        setDirLocation({
          ...dirLocation,
          value,
          error: errors,
          helperText: errors,
        });
        break;
      case "Comment":
        errors = MaximumLengthText(value, 2000);
        setComment({ ...comment, value, error: errors, helperText: errors });
        break;
      case "ScriptName":
        errors =
          isEmptyText(value) ||
          MaximumLengthText(value, 40) ||
          isContainSpecialCharacters(value);
        setImportedScriptName({
          ...importedScriptName,
          value,
          error: errors || false,
          helperText: errors,
        });
        break;
      default:
        break;
    }
  };
  useEffect(() => {
    if (dirLocation?.error || comment?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [dirLocation, comment]);
  const validateFields = () => {
    const dirError =
      actionType !== "Export" ? isEmptyText(dirLocation.value) : null;

    if (dirError) {
      setDirLocation({
        ...dirLocation,
        error: dirError,
        helperText: dirError,
      });
    }
    const comErr = MaximumLengthText(comment.value, 2000);
    if (comErr) {
      setComment({
        ...comment,
        error: comErr,
        helperText: comErr,
      });
    }

    if (comErr || dirError) {
      return false;
    }
    return true;
  };

  const handleFileInput = (e) => {
    if (hiddenFileInput) {
      hiddenFileInput.current.click();
    }
  };
  // to handle the user-selected file
  const handleChangeFile = (event) => {
    const fileUploaded = event.target.files[0];

    if (fileUploaded) {
      try {
        setDirLocation({ ...dirLocation, value: fileUploaded.name });
        setFileToBeImported(fileUploaded);
        //parsing json content

        var fileread = new FileReader();
        fileread.onload = function (e) {
          try {
            var content = e.target.result;
            console.log(content);
            var jsonData = JSON.parse(content); // parse json
          } catch (error) {
            console.log(error);

            setValue({
              isOpen: true,
              message: "This file does not contain valid json format.",
              notificationType: "ERROR",
              title: "",
            });
            setDirLocation({ ...dirLocation, value: "" });
            setFileToBeImported(null);
            setImportedScriptName({
              ...importedScriptName,
              value: "",
            });
          }
          console.log(jsonData); //every object
          if (jsonData?.scriptName) {
            setImportedScriptName({
              ...importedScriptName,
              value: jsonData.scriptName,
            });
          }
        };
        fileread.readAsText(fileUploaded);
      } catch (error) {
        console.log(error);
      }
    }
  };

  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    console.log("cancel clicked");
    handleClose();
  };
  const onClick2Import = async () => {
    if (!validateFields()) {
      return;
    }
    let nameErr =
      isEmptyText(importedScriptName.value) ||
      MaximumLengthText(importedScriptName.value, 40) ||
      isContainSpecialCharacters(importedScriptName.value);
    nameErr = allScripts.find(
      (sc) => sc.scriptName === importedScriptName.value
    )
      ? "Folder already contains a Service Flow with this name,Service Flow Name should be unique"
      : nameErr;

    if (nameErr) {
      setImportedScriptName({
        ...importedScriptName,
        error: nameErr ? true : false,
        helperText: nameErr,
      });
      return;
    }
    if (fileToBeImported) {
      setIsProcessing(true);

      const axiosInstance = createInstance();

      const fileData = new FormData();
      fileData.append("file", fileToBeImported);
      fileData.append("scriptName", importedScriptName.value);
      fileData.append("projectId", selectedProject.projectId);
      if (comment) {
        fileData.append("comments", comment.value);
      }
      const config = {
        headers: {
          "content-type": "multipart/form-data",
        },
        onUploadProgress: (ProgressEvent) => {
          setPercentUploaded(
            (ProgressEvent.loaded * 100) / ProgressEvent.total
          );
        },
      };
      try {
        let res = await axiosInstance.post(
          `${API_BASE_URL}${IMPORT}`,
          fileData,
          config
        );
        console.log(res);
        if (res.status === 200) {
          setIsProcessing(false);
          updateScripts(res?.data?.data[0] || null);
          setValue({
            isOpen: true,
            message: res.data?.message || "Service Flow imported successfully.",
            notificationType: "SUCCESS",
            title: "",
          });

          handleClose();
        }
      } catch (error) {
        console.log(error);
        setIsProcessing(false);
        handleNetworkRequestError({
          error,
          history,
          onError: (err) => {
            setValue({
              isOpen: true,
              message: err || "import error.",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
      }
    }
  };
  const onClick2Export = () => {
    if (!validateFields()) {
      return;
    }
    let queryParam = `?scriptId=${selectedScript?.scriptId}`;

    /*****************************************************************************************
     * @author asloob_ali BUG ID : 104614   Description -: Export script: Getting "Invalid response" error while exporting a script if I don't enter the comments
     * Reason: when comments was not added by user,i was not sending the comments param in request.
     *  Resolution :i was Told to add a `comments` param as comments=null in case of there is no comment..
     *  Date : 01/02/2022             *************************/

    if (comment.value) {
      queryParam = queryParam + `&comments=${comment.value}`;
    } else {
      queryParam = queryParam + `&comments=${null}`;
    }
    setIsProcessing(true);
    const axiosInstance = createInstance();
    const config = {
      responseType: "arraybuffer",
      onDownloadProgress: (ProgressEvent) => {
        setPercentUploaded((ProgressEvent.loaded * 100) / ProgressEvent.total);
        if ((ProgressEvent.loaded * 100) / ProgressEvent.total === 100) {
          handleClose();
          setValue({
            isOpen: true,
            message: "Service Flow exported successfully.",
            notificationType: "SUCCESS",
            title: "",
          });
        }
      },
    };
    axiosInstance
      .get(`${API_BASE_URL}${EXPORT}${queryParam}`, config)
      .then((response) => {
        //console.log(response);
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute(
          "download",
          `${selectedScript.scriptName}_${selectedScript.versionName}.json`
        );
        document.body.appendChild(link);
        link.click();
        setIsProcessing(false);
      })
      .catch((error) => {
        const res = JSON.parse(
          String.fromCharCode.apply(
            null,
            new Uint8Array(Buffer.from(error?.response?.data))
          )
        );

        setIsProcessing(false);
        handleNetworkRequestError({
          error,
          history,
          onError: (err) => {
            setValue({
              isOpen: true,
              message: res?.data[0]?.errorMessage || err || "export error",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
      });
  };

  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={
        actionType === "Export"
          ? "Export Service Flow"
          : actionType === "Import"
            ? "Import Service Flow"
            : ""
      }
      Content={
        <Content
          id={props.id}
          dirLocation={dirLocation}
          handleChange={handleChange}
          selectedScript={selectedScript}
          comment={comment}
          actionType={actionType}
          headerCloseBtn={true}
          onClickHeaderCloseBtn={handleClose}
          handleChangeFile={handleChangeFile}
          handleFileInput={handleFileInput}
          hiddenFileInput={hiddenFileInput}
          percentUploaded={percentUploaded}
          isProcessing={isProcessing}
          importedScriptName={importedScriptName}
        />
      }
      btn1Title="Cancel"
      btn2Title={
        actionType === "Export"
          ? "Export Service Flow"
          : actionType === "Import"
            ? "Import Service Flow"
            : null
      }
      onClick1={onClick1}
      btn2Disabled={formHasError}
      onClick2={actionType === "Export" ? onClick2Export : onClick2Import}
      closeModal={handleClose}
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      containerHeight={347}
      containerWidth={490}
    />
  );
};
export default ExportImportModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {
    id,
    handleChange,
    actionType,
    comment,
    selectedScript,
    dirLocation,
    handleChangeFile,
    handleFileInput,
    hiddenFileInput,
    isProcessing,
    percentUploaded,
    importedScriptName,
  } = props;
  const classes = useStyles();
  const { t } = useTranslation()

  return <>
    <div>
      <input
        aria-label="inputFile"
        name="inputFile"
        id="inputFile"
        type="file"
        accept=".json"
        ref={hiddenFileInput}
        onChange={handleChangeFile}
        style={{
          display: "none",
        }} /* Make the file input element invisible */
      />
      {actionType === "Export" && selectedScript && (
        <Grid container direction="column" spacing={1}>
          <Grid item>
            <Typography>{t("Service Flow Name")}</Typography>
          </Grid>
          <Grid item container direction="row">
            <Grid item style={{ marginRight: "4px" }}>
              <UniqueIDGenerator>
                <DocIcon style={{ height: "14px", width: "14px" }} />
              </UniqueIDGenerator>
            </Grid>
            <Grid item>{selectedScript.scriptName}</Grid>
          </Grid>
        </Grid>
      )}
      {actionType !== "Export" && (
        <>
          <PropertyField
            id={`${id}_DirLocation`}
            name="DirLocation"
            label={
              actionType === "Export"
                ? "Export To"
                : actionType === "Import"
                  ? "Select Service Flow"
                  : null
            }
            btnIcon={
              <UniqueIDGenerator>
                <FolderBrowseIcon
                  className={classes.btnIcon}
                  onClick={(e) => handleFileInput(e)}
                  //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
                  tabIndex={0}
                  onKeyPress={(e) => e.key === "Enter" && handleFileInput(e)}
                  role="button"
                  id={`${id}_FolderBrowserIcon`}
                />
              </UniqueIDGenerator>
            }
            {...dirLocation}
            // value={dirLocation.value}
            onChange={handleChange}
            // width={443}
            paddingTop={"0px"}
            readOnly={true}
            btnIconDefaultHandler={true}
          />

          <Field
            id={`${id}_ScriptName`}
            name="ScriptName"
            label="Service Flow Name"
            {...importedScriptName}

            onChange={handleChange}

            paddingTop={actionType === "Export" ? "0px" : null}
          />
        </>
      )}

      <Field
        id={`${id}_Comment`}
        label="Comment"
        {...comment}
        // width={443}
        multiline={true}
        onChange={handleChange}
      />
      {isProcessing ? (
        <Grid
          container
          alignItems="center"
          justifyContent="center"
          style={{ marginTop: "10px" }}
        >
          <Grid item>
            <LoadingIndicatorWithProgress
              value={percentUploaded}
              color="#4ef542"
              height="25px"
              width="25px"
            />
          </Grid>
        </Grid>
      ) : null}
    </div>
  </>;
};
