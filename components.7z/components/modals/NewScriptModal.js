import React, { useState, useContext, useEffect } from "react";
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import JohnDoe from "./../../assets/img/JohnDoe.png";
import { Grid, Typography } from "@mui/material";
import { createInstance, handleNetworkRequestError } from "../../utils/common";
import { GET_MDM_GLOBAL_CATEGORIES, GET_MDM_VARIABLES, GET_PORTAL_VARIABLES, GET_PROCESS_VARIABLES, PROJECT, SCRIPT } from "./../../config/index";
import { NotificationContext } from "../../contexts/NotificationContext";
import CustomChip from "../../utils/CustomChip";
import { setOpenScriptDetails } from "../../redux/actions";
import { useDispatch } from "react-redux";
import { openScriptInNewTab, getUser, getToken } from "./../../utils/common";
import { useHistory } from "react-router-dom";
import {
  isContainSpecialCharacters,
  isContainSpecialCharactersForProject,
  isContainSpecialCharactersForServiceFlow,
  isEmptyText,
  MaximumLengthText,
} from "../../utils/validations/validations";
import { useTranslation } from "react-i18next";
import { ConvertLtrRtl } from "../common";
import MultiSelectWithSearch from "../../utils/MultiSelectWithSearchInput";
import MultiSelectWithSearchForCategories from "../../utils/MultiSelectWithSearchForCategories";
import MultiSelectWithSearchForMDMCategories from "../../utils/MultiSelectWithSearchForMDMCategories";
import CustomDropdown from '../../utils/Autocomplete/index'
import { makeStyles } from "@mui/styles";
import { response } from "msw";
import NestedSelect from "../common/MDMSelectComponent";
const useStyles = makeStyles((theme) => ({
  label: {
    fontSize: '12px',
    fontWeight: 600,
    opacity: '1'
  }
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};

const NewScriptModal = (props) => {
  const { editedScript, applicationDetails, folderOptions, isOpenFromDashboard } = props;
  const { setValue } = useContext(NotificationContext);
  const dispatch = useDispatch();
  const history = useHistory();

  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [isCreating, setIsCreating] = useState(false);
  const [formHasError, setFormHasError] = useState(true);
  const [tagHasError, setTagHasError] = useState(false);


  const [scriptName, setScriptName] = useState(makeFieldInputs(""));
  const [folderName, setFolderName] = useState(makeFieldInputs(""));
  const [inputCategory, setInputCategory] = useState(makeFieldInputs(""));
  const [outputCategory, setOutputCategory] = useState(makeFieldInputs(""));
  const [inputVariables, setInputVariables] = useState([]);
  const [outputVariables, setOutputVariables] = useState([]);
  const [allVariables, setAllVariables] = useState([]);

  const [categories, setCategories] = useState([])
  const [selectedInputVariables, setSelectedInputVariables] = useState([])
  const [selectedOutputVariables, setSelectedOutputVariables] = useState([])


  const [tag, setTag] = useState("");

  const [tags, setTags] = useState([]);


  const getAllCategories = async () => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.get(`${GET_MDM_GLOBAL_CATEGORIES}`)
      if (res.status === 200) {
        setCategories(res.data?.data || [])
      }
    } catch (error) {
      console.log(error)
    }
  }
  useEffect(() => {
    if (!isOpenFromDashboard) {
      getAllCategories()
    }
  }, [isOpenFromDashboard])
  useEffect(() => {
    if (editedScript) {
      const { scriptName: name, tagName } = editedScript;
      setScriptName({ ...scriptName, value: name });
      setTags([...tagName]);
    }
  }, [editedScript]);
  const getPortalVariables = async (payload) => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.post(`${GET_PORTAL_VARIABLES}`, { ...payload })
      if (res.status === 200) {
        // setInputVariables(res.data?.data)
        setAllVariables(res.data?.data)

      }
    } catch (error) {
      console.log(error)
    }
  }
  const getProcessVariables = async (payload) => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.post(`${GET_PROCESS_VARIABLES}`, { ...payload })
      if (res.status === 200) {
        //  setInputVariables(res.data?.data)
        setAllVariables(res.data?.data)

      }
    } catch (error) {
      console.log(error)
    }
  }

  const getCategoryVariables = async (payload, setStateFn) => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.post(`${GET_MDM_VARIABLES}`, { ...payload })
      if (res.status === 200) {
        setStateFn(res.data?.data)
        //setAllVariables(res.data?.data)
      }
    } catch (error) {
      console.log(error)
    }
  }
  useEffect(() => {
    if (applicationDetails) {
      const { formId, processdefId, processState, processName, id, name, status,launchpadNew } = applicationDetails;
      if (id && name && status) {
        getPortalVariables({ id, name, status })
      } else if (formId && processName && processdefId && processState) {
        getProcessVariables({ formId, processName, processdefId, processState })
      }else{
        //launchpadNew
        getCategoryVariables({launchpadNew});
      }
    }
  }, [applicationDetails]);


  const handleChange = (e) => {
    debugger
    const { name, value } = e.target;
    let errors = "";
    switch (name) {
      case "Script Name":
        errors =
          isEmptyText(value) ||
          MaximumLengthText(value, 40) ||
          isContainSpecialCharactersForServiceFlow(value);
        setScriptName({
          ...scriptName,
          value,
          error: errors || false,
          helperText: errors,
        });
        break;
      case "Folder Name":
        setFolderName({
          ...folderName,
          value,
        });
        break;
      default:
        break;
    }
  };

  useEffect(() => {
    if (scriptName?.error || folderName?.error) {
      setFormHasError(true);
    } else {
      setFormHasError(false);
    }
  }, [scriptName, folderName]);
  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    handleClose();
  };
  const onClick2 = async () => {
    const errors =
      isEmptyText(scriptName.value) ||
      MaximumLengthText(scriptName.value, 40) ||
      isContainSpecialCharacters(scriptName.value);
    if (errors) {
      setScriptName({
        ...scriptName,
        error: errors || false,
        helperText: errors,
      });
      return;
    }
    if (isOpenFromDashboard) {
      const errors =
        isEmptyText(folderName.value)
      if (errors) {
        setFolderName({
          ...folderName,
          error: errors || false,
          helperText: errors,
        });
        return;
      }
    }

    const axiosInstance = createInstance();
    setIsCreating(true);

    const projectId =
      props.selectedProject?.projectId || editedScript?.projectId || folderName.value;

    if (editedScript) {
      try {
        let res = await axiosInstance.put(`${SCRIPT}`, {
          projectId,
          scriptName: scriptName.value,
          // tagName: tags,
          tagName: tags.length > 0 ? tags : tag ? [tag] : [],

          scriptId: editedScript.scriptId,
          versionName: editedScript.versionName,
          createdOn: Date.now(),
        });

        if (res.status === 200) {
          props.updateScripts(res.data.data[0]);
          setIsCreating(false);
          //creating Notification
          setValue({
            isOpen: true,
            message: res.data.message,
            notificationType: "SUCCESS",
            title: scriptName.value,
          });

          props.handleClose();
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "updation failed.",
              notificationType: "ERROR",
              title: scriptName.value,
            });
          },
        });

        setIsCreating(false);
      }
    } else {
      try {
        let payload = {
          projectId,

          scriptName: scriptName.value,
          tagName: tags.length > 0 ? tags : tag ? [tag] : [],

          createdOn: Date.now(),
          inputVariables: selectedInputVariables,
          outputVariables: selectedOutputVariables,
        }
        let res = await axiosInstance.post(`${SCRIPT}`, payload);

        if (res.status === 200) {
          if (props.updateScripts) {
            props.updateScripts(res.data.data[0]);
          }
          

          setIsCreating(false);
          //creating Notification
          setValue({
            isOpen: true,
            message: res.data.message,
            notificationType: "SUCCESS",
            title: scriptName.value,
          });
          // BugId:Bug 142741 - create script: After click on create and open button then getting same screen again for few second
          // Author Name:Dixita Ruhela
          // Date:19 jan 2024
          // RCA:After the successful message of the script creation modal form getting closed.
          // Issue is that after the successful message modal is still in open state.
          props.handleClose();
          setTimeout(() => {
            console.log("waiting for notification");
            /*****************************************************************************************
             * @author asloob.ali BUG ID : 101215  Description : Create new script: success message flow is not correct
             *  Resolution : added 1 sec wait for notification before opening new tab.
             *  Date : 15/09/2021             ***************************************************************************************/
            const newScript = res.data?.data[0];

            dispatch(setOpenScriptDetails({
              scriptId: newScript.scriptId,
              versionName: newScript.versionName,
              scriptName: scriptName.value
            }));
            history.push(`/serviceflow`);
            /*  const user = getUser();
              const token = getToken();
              openScriptInNewTab({
                scriptId: newScript.scriptId,
                versionName: newScript.versionName,
                token: token,
                user: user,
              });*/

          }, 1000);
        }
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "creation failed.",
              notificationType: "ERROR",
              title: "",
            });
          },
        });
        setIsCreating(false);
      }
    }
  };

  const handleOnChange = (e) => {
    const { name, value } = e.target;

    if (name === "Tag") {
      if (value !== ",") {
        setTag(value);
        const isTagAvailable = tags.find((t) => t === value);
        let tagLength = 0
        let targetArray = isTagAvailable ? tags : [...tags, value]
        tagLength = targetArray.reduce((acc, str) => acc + str.toString().length, 0) + (2 * targetArray.length) + (targetArray.length + 1)
        console.log("TAGS", tagLength, targetArray)
        if (tagLength < 251) {

          setTagHasError(false)

        }

      }
    }
  };
  const handleKeyDown = (e) => {
    if (e.keyCode === 188 && tag?.trim().length > 0) {
      /*****************************************************************************************
       * @author asloob.ali BUG ID : 100664 Description : RPA:  I am able to create same tags multiple times while cresting script
       *  Resolution : if a user try to add any new tag (available in tags array) will not be added and string value will be discarded.
       *  Date : 06/09/2021             ***************************************************************************************/

      /**
     @author - akshat_pokhriyal
     @Date - 25/01/2024
     @Bug Id - 142578
     @Bug Description -  RPA designer->script -> project -> create script -> getting "exception occured" when we click on Create and Open button and 500 internal server error on console
     @Bug Reason of occurence -tags has a char limit of max 250 char due to which we were getting exception.
     @Solution - added char limit
     **/


      const isTagAvailable = tags.find((t) => t === tag);
      let tagLength = 0
      let targetArray = isTagAvailable ? tags : [...tags, tag]
      tagLength = targetArray.reduce((acc, str) => acc + str.toString().length, 0) + (2 * targetArray.length) + (targetArray.length + 1)
      console.log("TAGS", tagLength, targetArray)
      if (tagLength > 250) {

        setTagHasError(true)

      }
      // ["qwerty","asdfgh"]
      else if (!isTagAvailable && tag.trim() !== ",") {
        setTagHasError(false)
        setTags([...tags, tag]);
        setTag("");
      } else {
        setTag("");
      }
    } else if (e.keyCode === 8 && !tag) {
      const newTags = [...tags];
      newTags.pop();
      setTags(newTags);
    }
  };

  const onDeleteTag = (index) => {
    const newTags = [...tags];
    newTags.splice(index, 1);
    setTags(newTags);
    // if (tags.reduce((acc, str) => acc + str.length, 0) > 251) {
    //   setTagHasError(false)
    // }
  };

  const handleSelectedInputVariables = (arrOfSelectedItems) => {
    setSelectedInputVariables(arrOfSelectedItems)
  }
  const handleSelectedOutputVariables = (arrOfSelectedItems) => {
    setSelectedOutputVariables(arrOfSelectedItems)

  }

  const validateFields = (value) => {
    const projectNameErrors =
      isEmptyText(value) ||
      MaximumLengthText(value, 40) ||
      isContainSpecialCharactersForProject(value);

    if (projectNameErrors) {
      setFolderName({
        ...folderName,
        value: value,
        error: projectNameErrors,
        helperText: projectNameErrors,
      });
    }
    return projectNameErrors ? false : true;
  };
  const handleCreateNewFolder = async (folderName) => {
    debugger
    if (!validateFields(folderName)) {
      return;
    }
    const axiosInstance = createInstance();
    try {
      var res = await axiosInstance.post(`${PROJECT}`, {
        projectName: folderName,
        description: "",
      });

      if (res.status === 200) {
        props.updateProjects(res.data.data[0]);
        //creating Notification
        const projectId=res.data.data[0].projectId;
        setValue({
          isOpen: true,
          message: res.data.message,
          notificationType: "SUCCESS",
          title: folderName,
        });
        //Bug 155749 - In case of folder created directly from create serviceflow link then getting error of field required message
        //nitin_tomar
        //Date: 24 JAN 2025
        //Description : After folder creation folder Name and Value is being updated in State.
        setFolderName({
          ...folderName,
          value:projectId,
        });
        // props.handleClose();
      }
    } catch (error) {
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setValue({
            isOpen: true,
            message: errMsg || "creation failed.",
            notificationType: "ERROR",
            title: "",
          });
        },
      });
    }
  }
  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={editedScript ? "Update Service Flow" : "Create a Service Flow"}
      isProcessing={isCreating}
      Content={
        <Content
          id={props.id}
          editedScript={editedScript}
          selectedProject={props.selectedProject}
          scriptName={scriptName}
          tags={tags}
          tag={tag}
          tagHasError={tagHasError}
          handleChange={handleChange}
          handleOnChange={handleOnChange}
          handleKeyDown={handleKeyDown}
          onDeleteTag={onDeleteTag}
          applicationDetails={applicationDetails}
          folderName={folderName}
          folderOptions={folderOptions}
          isOpenFromDashboard={isOpenFromDashboard}
          inputCategory={inputCategory}
          outputCategory={outputCategory}
          categories={categories}
          selectedInputVariables={selectedInputVariables}
          selectedOutputVariables={selectedOutputVariables}
          handleSelectedInputVariables={handleSelectedInputVariables}
          handleSelectedOutputVariables={handleSelectedOutputVariables}
          allVariables={allVariables}
          inputVariables={inputVariables}
          outputVariables={outputVariables}
          handleCreateNewFolder={handleCreateNewFolder}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      btn1Title="Cancel"
      btn2Title={editedScript ? "Update" : "Create and Open"}
      onClick1={onClick1}
      onClick2={onClick2}
      btn2Disabled={formHasError}
      closeModal={handleClose}
      containerHeight={tags.reduce((acc, str) => acc + str.length, 0) > 200 ? isOpenFromDashboard ? 520 : 550 : isOpenFromDashboard ? 447 : 477}
      containerWidth={690}
    />
  );
};
export default NewScriptModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const {
    id,
    scriptName,
    editedScript,
    selectedProject,
    tags,
    tag,
    handleChange,
    handleKeyDown,
    handleOnChange,
    onDeleteTag,
    tagHasError,
    applicationDetails,
    folderName,
    folderOptions,
    isOpenFromDashboard,
    inputCategory,
    outputCategory,
    categories,
    selectedInputVariables,
    selectedOutputVariables,
    handleSelectedInputVariables,
    handleSelectedOutputVariables,
    allVariables,
    inputVariables,
    outputVariables,
    handleCreateNewFolder
  } = props;
  const classes = useStyles();

  const { t } = useTranslation()
  if (isOpenFromDashboard) {
    return (
      <>
        <Grid container direction={'column'} spacing={2}>
          <Grid item container alignItems='flex-start' spacing={1}>
            <Grid item xs={6}>
              <Field
                name={t("Script Name")}
                label={t("Service Flow Name")}
                id={`${id}_ScriptName`}
                {...scriptName}
                required={true}
                // width={442}
                paddingTop={"0px"}
                onChange={handleChange}
                height={32}
              />
            </Grid>
            <Grid item xs={6}>
              {/*<Field
                name={t("Folder Name")}
                label={t("Folder Name")}
                id={`${id}_FolderName`}
                {...folderName}
                required={true}
                // width={442}
                dropdown={true}
                options={folderOptions || []}
                paddingTop={"0px"}
                onChange={handleChange}
                height={32}
    />*/}
              <CustomDropdown
                name={t("Folder Name")}
                label={t("Folder Name")}
                id={`${id}_FolderName`}
                {...folderName}
                required={true}
                // width={442}
                dropdown={true}
                options={folderOptions || []}
                paddingTop={"0px"}
                onChange={handleChange}
                height={32}
                handleCreateNewFolder={handleCreateNewFolder}
              //marginTop={'8px'}
              />
            </Grid>
          </Grid>

          <Grid item style={{ maxWidth: '100%' }}>
            <MultiSelectWithSearchForCategories
              optionList={allVariables}
              selectedOptionList={selectedInputVariables || []}
              optionRenderKey="variableName"
              showTags={true}
              getSelectedItems={handleSelectedInputVariables}
              id="input_List"
              label={'Input Variables'}
              maxTagsToShow={4}
            // style={{ width: '315px', marginBottom: '8px' }}

            />
          </Grid>

          <Grid item style={{ maxWidth: '100%' }}>
            <MultiSelectWithSearchForCategories
              optionList={allVariables}
              selectedOptionList={selectedOutputVariables || []}
              optionRenderKey="variableName"
              showTags={true}
              getSelectedItems={handleSelectedOutputVariables}
              id="output_List"
              label={'Output Variables'}
              maxTagsToShow={4}


            // style={{ width: '315px', marginBottom: '8px' }}

            />
          </Grid>




          <Grid item style={{ maxWidth: '100%' }}>
            <CustomChip
              id={id}
              handleOnChange={handleOnChange}
              tags={tags}
              tag={tag}
              label={t("Tags")}
              name="Tag"
              handleKeyDown={handleKeyDown}
              onDeleteTag={onDeleteTag}
              //width={657}
              height={28}
              helperText={t('Write tags and use "," to separate.')}
              errorText={"Maximum 250 characters are allowed for Tags."}
              error={tagHasError}
            />
          </Grid>
        </Grid>
      </>
    );
  }
  return (
    <>
      <Grid container direction={'column'} spacing={2}>
        <Grid item container spacing={2}>
          <Grid item xs={6}>
            <Field
              name={t("Script Name")}
              label={t("Service Flow Name")}
              id={`${id}_ScriptName`}
              {...scriptName}
              required={true}
              // width={442}
              paddingTop={"0px"}
              onChange={handleChange}
              height={32}
            />
          </Grid>
          <Grid item xs={6}>
            <Field
              name={t("Folder Name")}
              label={t("Folder Name")}
              id={`${id}_FolderName`}
              //{...folderName}
              value={editedScript?.projectName || selectedProject?.projectName}
              required={true}
              disabled={true}
              // width={442}
              //dropdown={true}
              //options={folderOptions || []}
              paddingTop={"0px"}
              onChange={handleChange}
              height={32}
            />
          </Grid>
        </Grid>

        <Grid item container spacing={1}>
          <Grid item xs={12}><Typography className={classes.label}>Input Variables</Typography></Grid>

          {/*<Grid item xs={6}>
            <Field
              name={t("InputCategory")}
              label={t("Category")}
              id={`${id}_Categories`}
              {...inputCategory}
              //  required={true}
              // width={442}
              dropdown={true}
              paddingTop='0'
              options={categories.map(cat => ({ name: cat.categoryName, value: cat.categoryId })) || []}

              onChange={handleChange}
              height={32}
            />
  </Grid>*/}
          <Grid item xs>
            <MultiSelectWithSearchForMDMCategories
              optionList={categories.map(item => ({ ...item, variableName: item.categoryDisplayName }))}
              selectedOptionList={selectedInputVariables || []}
              optionRenderKey="variableName"
              showTags={true}
              getSelectedItems={handleSelectedInputVariables}
              id="input_List"
              //label={'Variables'}
              // style={{ width: '315px', marginBottom: '8px' }}
              // width="50%"
              maxTagsToShow={4}
            />
          </Grid>
        </Grid>

        <Grid item container spacing={1}>
          <Grid item xs={12}><Typography className={classes.label}>Output Variables</Typography></Grid>

          {/*<Grid item xs={6}>
            <Field
              name={t("OutputCategory")}
              label={t("Category")}
              id={`${id}_OutputCategories`}
              {...outputCategory}
              // required={true}
              // width={442}
              dropdown={true}
              options={categories.map(cat => ({ name: cat.categoryName, value: cat.categoryId })) || []}
              paddingTop='0'

              onChange={handleChange}
              height={32}
            />
</Grid>*/}
          <Grid item xs>
            <MultiSelectWithSearchForMDMCategories
              optionList={categories.map(item => ({ ...item, variableName: item.categoryDisplayName }))}

              selectedOptionList={selectedOutputVariables || []}
              optionRenderKey="variableName"
              showTags={true}
              getSelectedItems={handleSelectedOutputVariables}
              id="output_List"
             // label={'Variables'}
              // width="25%"
              maxTagsToShow={4}
            // style={{ width: '315px', marginBottom: '8px' }}

            />
          </Grid>
        </Grid>

        <Grid item xs={12} style={{ maxWidth: '100%' }}>
          <CustomChip
            id={id}
            handleOnChange={handleOnChange}
            tags={tags}
            tag={tag}
            label={t("Tags")}
            name="Tag"
            handleKeyDown={handleKeyDown}
            onDeleteTag={onDeleteTag}
            // width={650}
            height={28}
            helperText={t('Write tags and use "," to separate.')}
            errorText={"Maximum 250 characters are allowed for Tags."}
            error={tagHasError}
          />
        </Grid>
        {/* <Grid item xs={6}>
          <NestedSelect options={options} onSelectionChange={(selected) => console.log(selected)} />
        </Grid> */}
      </Grid>
    </>
  );
};

