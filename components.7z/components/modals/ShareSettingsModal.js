import React, { useState, useEffect, useContext } from "react";
import makeStyles from '@mui/styles/makeStyles';
import ModalForm from "./../../utils/modalForm";
import Field from "./../../utils/field";
import JohnDoe from "../../assets/img/johnDoe1.jpg";
import { Grid, IconButton, Typography } from "@mui/material";
import SearchBox from "../../utils/Search-Component";
import {
  FolderIcon,
  AddIcon,
  DeleteIcon,
  DocIcon,
} from "../../utils/AllImages";
import { NotificationContext } from "../../contexts/NotificationContext";

import { useSelector } from "react-redux";
import LoadingIndicator from "./../../utils/loadingIndicator";
import { getUserId } from "../../utils/common";
import {
  handleNetworkRequestError,
  createInstance,
} from "./../../utils/common";
import { useHistory } from "react-router";
import { API_BASE_URL, SHARE } from "./../../config/index";
import CustomTooltip from "../../utils/CustomTooltip";
import { useTranslation } from "react-i18next";
import { ConvertLtrRtl } from "../common";
import { UniqueIDGenerator } from "../../utils/UniqueIDGenerator";

const useStyles = makeStyles((theme) => ({
  container: {
    marginTop: "4rem",
  },
  item: {
    background: "#F8F8F8 0% 0% no-repeat padding-box",
    borderRadius: "2px",
    width: "362px",
    height: "319px",
    padding: "12px 21px 23px 16px",
    overflow: "hidden",
    "&:hover": {
      overflowY: "auto",
    },
  },
  addBtn: {
    width: "16px",
    height: "16px",
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
  },
  title: {
    fontWeight: 600,
  },
  scrollDiv: {
    marginTop: "8px",
    height: "204px",
    overflow: "hidden",
    "&:hover": {
      overflowY: "auto",
    },
  },
  img: {
    height: "16px",
    width: "16px",
    borderRadius: 50,
  },
  owner: {
    color: "#606060",
    textAlign: "right",
  },
  input: {
    height: 24,
    paddingRight: "10px",
    fontSize: 12,
  },
  noBorder: {
    border: "none",
  },
  selectIcon: {
    color: "#0072C6",
    marginTop: "3px",
  },
  root: {
    color: "#0072C6",
  },
  opacityLow: {
    opacity: 0.3,
    pointerEvents: "none",
  },
  deleteBtn: {
    height: "16px",
    width: "16px",
    filter: `invert(17%) sepia(74%) saturate(5916%) hue-rotate(356deg) brightness(101%) contrast(118%)`,
  },
  icons: {
    height: "16px",
    width: "16px",
    // filter: `invert(17%) sepia(74%) saturate(5916%) hue-rotate(356deg) brightness(101%) contrast(118%)`,
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
}));
{
  /*Making inputs for fields */
}
const makeFieldInputs = (value) => {
  return {
    value: value,
    error: false,
    helperText: "",
  };
};
const allUsersData = [
  {
    fullName: "Devnath Gowda",
    emailId: "devnath.gowda@newgen.co.in",
    img: JohnDoe,
  },
  {
    fullName: "Asloob Ali",
    emailId: "asloob.ali@newgen.co.in",
    img: JohnDoe,
  },
  {
    fullName: "Suzanne Seth",
    emailId: "suzanne.seth@newgen.co.in",
    img: JohnDoe,
  },
  {
    fullName: "Nidhi Bansal",
    emailId: "nidhi.bansal@newgen.co.in",
    img: JohnDoe,
  },
  {
    fullName: "Ramendra Singh",
    emailId: "ramendra.singh@newgen.co.in",
    img: JohnDoe,
  },
  {
    fullName: "Akshat Pokhriyal",
    emailId: "akshat.pokhriyal@newgen.co.in",
    img: JohnDoe,
  },
  {
    fullName: "Pranesh Ramesh",
    emailId: "pranesh.ramesh@newgen.co.in",
    img: JohnDoe,
  },
];

const SharingSettingModal = (props) => {
  const {
    id,
    selectedScript,
    selectedProject,
    isFetchingUsers,
    updateScripts,
    updateProjects,
  } = props;
  const { setValue } = useContext(NotificationContext);
  const classes = useStyles();
  const { t } = useTranslation()
  const allUsers1 = useSelector((state) => state.scriptsAndProjects.allUsers);
  const [open, setOpen] = useState(props.isOpen ? true : false);
  const [isSharing, setSharing] = useState(false);

  const [allUsers, setAllUsers] = useState(allUsersData);
  const [allUsersOrg, setAllUsersOrg] = useState(allUsersData);

  const [sharingValue, setSharingValue] = useState(
    selectedProject?.isShared || selectedScript?.isShared || false
  );
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [selectedUsersOrg, setSelectedUsersOrg] = useState([]);
  const [owner, setOwner] = useState(null);

  const currentUserId = getUserId();
  const history = useHistory();

  const updateUsers = () => {
    //removing current user from the list of users
    const newAllUsers = allUsers1
      .map((item) => {
        return { ...item, img: JohnDoe };
      })
      .filter(
        (item) =>
          item.userIndex !== +currentUserId &&
          item.userIndex !== selectedProject?.createdBy &&
          item.userIndex !== selectedScript?.createdBy
      );

    setAllUsers(newAllUsers);
    setAllUsersOrg(newAllUsers);
    const OwnerUser = allUsers1.find(
      (obj) =>
        obj.userIndex === selectedProject?.createdBy ||
        obj.userIndex === selectedScript?.createdBy
    );
    setOwner(OwnerUser ? { ...OwnerUser, img: JohnDoe } : null);
  };

  useEffect(() => {
    updateUsers();
  }, [allUsers1]);
  useEffect(() => {
    if (selectedProject && selectedProject.sharedUserId && allUsers1) {
      const arrOfUIds = selectedProject.sharedUserId.map((item) => item.userId);
      const newSelUsers = allUsers1.filter((item) =>
        arrOfUIds.includes(item.userIndex)
      );
      const newAllUsers = allUsers1.filter(
        (item) =>
          !arrOfUIds.includes(item.userIndex) &&
          item.userIndex !== selectedProject.createdBy
      );
      setSelectedUsers(newSelUsers);
      setSelectedUsersOrg(newSelUsers);
      setAllUsers(newAllUsers);
      setAllUsersOrg(newAllUsers);
    } else if (selectedScript && selectedScript.sharedUserId && allUsers1) {
      const arrOfUIds = selectedScript.sharedUserId.map((item) => item.userId);
      const newSelUsers = allUsers1.filter((item) =>
        arrOfUIds.includes(item.userIndex)
      );
      const newAllUsers = allUsers1.filter(
        (item) =>
          !arrOfUIds.includes(item.userIndex) &&
          item.userIndex !== selectedScript.createdBy
      );
      setSelectedUsers(newSelUsers);
      setSelectedUsersOrg(newSelUsers);
      setAllUsers(newAllUsers);
      setAllUsersOrg(newAllUsers);
    }
  }, [selectedProject, selectedScript, allUsers1]);

  const handleChange = (e) => {
    const { name } = e.target;
    if (name === "Sharing") {
      setSharingValue(!sharingValue);
    }
  };

  const onClickOnUser = (clickedUsr) => {
    //checking user with emailId is exist or not
    const user = allUsers.find((usr) => usr.userIndex === clickedUsr.userIndex);
    if (user) {
      //setting user to selected users with whom sharing script
      setSelectedUsers([...selectedUsers, user]);
      setSelectedUsersOrg([...selectedUsersOrg, user]);

      //removing user from allUsers
      const updatedAllUsers = allUsers.filter(
        (user1) => user1.userIndex !== clickedUsr.userIndex
      );
      setAllUsers(updatedAllUsers);
    } else {
      console.log("user not found");
    }
  };

  //removing user from selected users
  const onClickOnDelete = (clickedUsr) => {
    const user = selectedUsers.find(
      (usr) => usr.userIndex === clickedUsr.userIndex
    );
    if (user) {
      //setting user to all users
      setAllUsers([...allUsers, user]);

      //removing user from selected users
      const updatedSelUsers = selectedUsers.filter(
        (user1) => user1.userIndex !== clickedUsr.userIndex
      );
      setSelectedUsers(updatedSelUsers);
      setSelectedUsersOrg([...updatedSelUsers]);
    } else {
      console.log("user not found");
    }
  };

  const handleClose = () => {
    setOpen(false);
    props.handleClose();
  };
  const onClick1 = () => {
    handleClose();
  };
  const onClick2 = async () => {
    setSharing(true);
    try {
      const userIds = selectedUsersOrg.map((item) => item.userIndex);
      const axiosInstance = createInstance();

      const response = await axiosInstance.post(`${API_BASE_URL}${SHARE}`, {
        projectId:
          selectedProject?.projectId || selectedScript?.projectId || null,
        scriptId: selectedScript?.scriptId || null,
        userId: userIds,
        isShared: sharingValue,
      });
      console.log(response);
      if (response.status === 200) {
        setValue({
          isOpen: true,
          message: response.data.message || "shared.",
          notificationType: "SUCCESS",
          title: "",
        });
        setSharing(false);
        handleClose();
      }
      selectedScript
        ? updateScripts(response.data.data[0])
        : selectedProject
          ? updateProjects(response.data.data[0])
          : console.log("not updated");
    } catch (error) {
      setSharing(false);
      handleNetworkRequestError({
        error,
        history,
        onError: (errMsg) => {
          setValue({
            isOpen: true,
            message: errMsg || "sharing failed.",
            notificationType: "ERROR",
            title: "",
          });
        },
      });
    }
  };

  const filterUsers = (users, sText) => {
    /**
@author - akshat_pokhriyal
@Date - 28/02/2024
@Bug Id - 143857
@Bug Description -  Script Designer --> users searchbox not functional + Page crash on data entry in available users searchbox
@Bug Reason of occurence - for few users email was null due to which it was throwing error.
@Solution - handled null cases for email and name
**/
    return users.filter(
      (usr) => {
        const checkName = usr.fullName ? usr.fullName.toLowerCase().includes(sText.toLowerCase()) : false
        const checkEmail = usr.emailId ? usr.emailId.toLowerCase().includes(sText.toLowerCase()) : false

        return checkName || checkEmail
        // usr.fullName.toLowerCase().includes(sText.toLowerCase()) ||
        // usr.emailId.toLowerCase().includes(sText.toLowerCase())

      }

    );
  };
  const handleSearchChange = (sText, type) => {
    if (type) {
      if (sText) {
        const newAllUsers = filterUsers(allUsersOrg, sText);
        setAllUsers(newAllUsers);
      } else {
        setAllUsers(allUsersOrg);
      }
    } else {
      if (sText) {
        const newSelectedUsers = filterUsers(selectedUsersOrg, sText);
        setSelectedUsers(newSelectedUsers);
      } else {
        setSelectedUsers(selectedUsersOrg);
      }
    }
  };

  return (
    <ModalForm
      id={id}
      isOpen={open}
      title={t("Share Settings")}
      name={
        selectedScript
          ? "Service Flow : " + selectedScript.scriptName
          : selectedProject
            ? selectedProject.projectName
            : ""
      }
      /*****************************************************************************************
      * @author asloob.ali BUG ID : 101300 Description : Share Settings screen: script/project icon is not matching as per xd designs *
      Resolution : changed icons. * Date :
      07/10/2021
     ***************************************************************************************/
      icon={
        selectedScript ? (
          <UniqueIDGenerator>
            <DocIcon className={classes.icons} />
          </UniqueIDGenerator>
        ) : selectedProject ? (
          <UniqueIDGenerator>
            <FolderIcon className={classes.icons} />
          </UniqueIDGenerator>
        ) : null
      }
      Content={
        <Content
          id={id}
          sharingValue={sharingValue}
          isFetchingUsers={isFetchingUsers}
          handleChange={handleChange}
          handleSearchChange={handleSearchChange}
          selectedUsers={selectedUsers}
          onClickOnDelete={onClickOnDelete}
          onClickOnUser={onClickOnUser}
          allUsers={allUsers}
          owner={owner}
          selectedProject={selectedProject}
          selectedScript={selectedScript}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      btn1Title={t("Cancel")}
      btn2Title={t("Save Share Settings")}
      onClick1={onClick1}
      onClick2={onClick2}
      btn2Disabled={
        ((selectedScript &&
          (selectedScript?.sharedUserId?.length === 0 ||
            !selectedScript.sharedUserId)) ||
          (selectedProject &&
            (selectedProject?.sharedUserId?.length === 0 ||
              !selectedProject.sharedUserId))) &&
        selectedUsersOrg.length === 0
      }
      isProcessing={isSharing}
      closeModal={handleClose}
      containerHeight={545}
      containerWidth={800}
    />
  );
};
export default SharingSettingModal;

{
  /*Fields, content of the modal */
}
const Content = (props) => {
  const classes = useStyles();
  const { t } = useTranslation()
  const {
    id,
    isFetchingUsers,
    sharingValue,
    handleChange,
    selectedUsers,
    onClickOnUser,
    onClickOnDelete,
    allUsers,
    owner,
    handleSearchChange,
    selectedProject,
    selectedScript,
  } = props;

  return <>
    <div>
      <Field
        paddingTop={"0px"}
        sharingValue={sharingValue}
        SwitchLabel={t("Sharing")}
        onChange={handleChange}
        tooltipTitle={
          !sharingValue
            ?
            ConvertLtrRtl([
              t("Switch on to share this"),
              t(selectedScript
                ? "Service Flow "
                : selectedProject
                  ? "folder "
                  : ""),
              t("with others.")
            ])
            : ""
        }
        id={`${id}_Sharing`}
      />

      <div style={{ marginTop: "18px", marginBottom: "20px" }}>
        <Typography>
          {t(selectedScript
            ? "Select the users from the list of Available users with whom you want to share the Service Flow."
            : selectedProject
              ? "Select the users from the list of Available users with whom you want to share the folder. This will share all the service flows with the selected members in this folder and member rights will be applicable to all the service flows."
              : "")}
        </Typography>
      </div>
      {isFetchingUsers ? (
        <LoadingIndicator />
      ) : (
        <Grid
          container
          direction="row"
          justifyContent="space-between"
          className={!sharingValue ? classes.opacityLow : null}
        >
          <Grid
            item
            container
            direction="column"
            spacing={1}
            className={classes.item}
            style={{ overflow: "visible" }}
          >
            <Grid item>
              <Typography className={classes.title}>
                {t("Available Users")}
              </Typography>
            </Grid>
            <Grid item>
              <SearchBox
                id={`${id}_AvailableUsers_SearchBox`}
                onSearchChange={(sText) => handleSearchChange(sText, "all")}
                width="325px"
                placeholder={t("Search Users")}
                name="AvailableUsers"
                disabledFocus={!sharingValue}
              />
            </Grid>
            <Grid
              item
              className={classes.scrollDiv}
              style={{ overflow: "visible" }}
            >
              <Grid container direction="column" spacing={1}>
                {allUsers &&
                  allUsers.map((usr, index) => (
                    <Grid
                      item
                      container
                      direction="row"
                      spacing={1}
                      style={{ paddingRight: "15px" }}
                      key={index}
                      alignItems={"center"}
                    >
                      <Grid item>
                        <img
                          src={usr.img || JohnDoe}
                          alt="user Img"
                          className={classes.img}
                        />
                      </Grid>
                      <Grid item>
                        {/* <CustomTooltip
                          title={usr?.userLoginId}
                          placement="right-end"
                       >*/}
                        <Typography>
                          {usr?.fullName} ({usr?.userLoginId})
                        </Typography>
                        {/* </CustomTooltip>*/}
                      </Grid>

                      <Grid
                        item
                        style={{ marginLeft: "auto", cursor: "pointer" }}
                      >

                        <IconButton
                          id={`${id}_All_${usr?.fullName}(${usr?.userLoginId})`}
                          onClick={() => onClickOnUser(usr)}
                          tabIndex={sharingValue ? 0 : -1}
                          aria-label="Add User">


                          <AddIcon
                          //className={classes.focusVisible}

                          />

                        </IconButton>

                      </Grid>
                    </Grid>
                  ))}
              </Grid>
            </Grid>
          </Grid>
          <Grid
            item
            container
            direction="column"
            spacing={1}
            className={classes.item}
            style={{ overflow: "visible" }}
          >
            <Grid item>
              <Typography className={classes.title}>
                {t("Selected Users")}
              </Typography>
            </Grid>
            <Grid item>
              <SearchBox
                id={`${id}_SearchUsers_SearchBox`}
                onSearchChange={handleSearchChange}
                width="325px"
                placeholder={t("Search Users")}
                name="SelectedUsers"
                disabledFocus={!sharingValue}
              />
            </Grid>
            <Grid
              item
              className={classes.scrollDiv}
              style={{ overflow: "visible" }}
            >
              <Grid
                container
                direction="column"
                spacing={1}
                style={{ paddingRight: "5px" }}
              >
                {owner && (
                  <Grid item container direction="row" spacing={1}>
                    <Grid item>
                      <img
                        src={owner?.img || ""}
                        alt="user Img"
                        className={classes.img}
                      />
                    </Grid>
                    <Grid item>
                      <Typography>{owner?.fullName || ""}</Typography>
                    </Grid>
                    <Grid item style={{ marginLeft: "auto" }}>
                      <Typography className={classes.owner}>{t("Owner")}</Typography>
                    </Grid>
                  </Grid>
                )}
                {selectedUsers &&
                  selectedUsers.map((user, index) => (
                    <Grid
                      item
                      container
                      direction="row"
                      spacing={1}
                      key={index}
                      alignItems={"center"}
                    >
                      <Grid item>
                        <img
                          src={user.img || JohnDoe}
                          alt="user Img"
                          className={classes.img}
                        />
                      </Grid>
                      <Grid item>
                        {/*<CustomTooltip
                          title={user?.userLoginId}
                          placement="right-end"
                        >*/}
                        <Typography>
                          {user.fullName} ({user?.userLoginId})
                        </Typography>
                        {/*</CustomTooltip>*/}
                      </Grid>
                      <Grid
                        item
                        style={{ marginLeft: "auto", cursor: "pointer" }}
                      >
                        <IconButton
                          onClick={() => onClickOnDelete(user)}
                          id={`${id}_Selected_${user?.fullName}(${user?.userLoginId})`}
                          tabIndex={sharingValue ? 0 : -1}
                          aria-label="Delete User"
                        >
                          <DeleteIcon
                            className={classes.deleteBtn}
                          />
                        </IconButton>
                      </Grid>

                      {/* <Grid item style={{ marginLeft: "auto" }}>
                      <Grid
                        container
                        item
                        direction="row"
                        justify="flex-end"
                        alignItems="flex-start"
                        // xs={6}
                      >
                        <Grid item>
                          <TextField
                            type={"text"}
                            size="small"
                            fullWidth={true}
                            InputProps={{
                              className: classes.input,
                              classes: {
                                notchedOutline: classes.noBorder,
                              },
                            }}
                            value={user.role ? user.role : ""}
                            onChange={(e) => {
                              console.log(e.target.value);
                              provideRole(user, e.target.value);
                            }}
                            variant="outlined"
                            select={true}
                            SelectProps={{
                              native: true,
                              classes: {
                                icon: classes.selectIcon,
                                root: classes.root,
                              },
                            }}
                            open={openRole === index}
                            onClose={() => handleCloseRole(index)}
                            onOpen={() => handleOpenRole(index)}
                            style={{ border: "0px" }}
                          >
                            {userRights
                              ? userRights.map((item) => (
                                  <option value={item} key={item}>
                                    {item}
                                  </option>
                                ))
                              : null}
                          </TextField>
                        </Grid>
                      </Grid>
                              </Grid>*/}
                    </Grid>
                  ))}
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      )}
    </div>
  </>;
};
