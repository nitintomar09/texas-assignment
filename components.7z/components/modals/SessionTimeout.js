import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import { Grid, Typography } from "@mui/material";
import ModalForm from "./../../utils/modalForm";
import { useHistory } from "react-router-dom";
import { removeUserSession } from "../../utils/common";
import { useDispatch } from "react-redux";
import { setSessionTimeout } from "../../redux/actions";
import { useTranslation } from "react-i18next";
import { SessionIcon } from "../../utils/AllImages";
const useStyles = makeStyles(() => ({
  container: {
    marginTop: "4rem",
  },
}));

const SessionTimeoutModal = (props) => {
  const { isOpen } = props;
  const history = useHistory();
  const dispatch = useDispatch();
  const { t } = useTranslation()
  const onClick2 = () => {
    removeUserSession();
    const redirect=window.location.origin+"/automationstudio";
    //history.push("/");

    //dispatch(setSessionTimeout(true));
    window.location.href=redirect;
  };
  /* const handleCloseMain = () => {
    handleClose();
  };*/

  return (
    <ModalForm
      isOpen={isOpen}
      title={t("Session Expired")}
      Content={<Content />}
      btn2Title={t("OK")}
      onClick2={onClick2}
      closeModal={onClick2}
      headerCloseBtn={true}
      onClickHeaderCloseBtn={onClick2}
      containerHeight={350}
      containerWidth={600}
    />
  );
};
export default SessionTimeoutModal;

{
  /*Fields, content of the modal */
}
const Content = () => {
  const { t } = useTranslation()
  return (
    <>
    {/* //BugId:Bug 155116 - Session expire notification message box should be consistent with the others tools
    // Author: dixita.ruhela
    Date: 7 JAN 2025
    RCA: Changed the modal according to the new UX Screens. */}
      <div>
        <Grid container direction="column" spacing={1} alignItems={"center"} justifyContent={"center"}>
          <Grid item>
            <SessionIcon/>
          </Grid>
          <Grid item>
            <Typography>
              {t("Your session has expired, Please login again to continue.")}
            </Typography>
          </Grid>
        </Grid>
      </div>
    </>
  );
};
