import React, { useState } from "react";
import { Grid, Typography, Tabs, Tab, Box } from "@mui/material";
import MultiSelectWithSearchForMDMCategories from "../../utils/MultiSelectWithSearchForMDMCategories";

export default function InputOutputTabs({
  categories,
  selectedInputVariables,
  handleSelectedInputVariables,
  selectedOutputVariables,
  handleSelectedOutputVariables,
  classes,
}) {
  const [activeTab, setActiveTab] = useState(0);

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  return (
    <Box>
      <Tabs value={activeTab} onChange={handleTabChange} aria-label="Input and Output Variables Tabs">
        <Tab label="Input Variables" />
        <Tab label="Output Variables" />
      </Tabs>

      {activeTab === 0 && (
        <Box sx={{ p: 2 }}>
          <Grid container spacing={1}>
            <Grid item xs={12}>
              <Typography className={classes.label}>Input Variables</Typography>
            </Grid>
            <Grid item xs>
              <MultiSelectWithSearchForMDMCategories
                optionList={categories.map((item) => ({
                  ...item,
                  variableName: item.categoryDisplayName,
                }))}
                selectedOptionList={selectedInputVariables || []}
                optionRenderKey="variableName"
                showTags={true}
                getSelectedItems={handleSelectedInputVariables}
                id="input_List"
                maxTagsToShow={4}
              />
            </Grid>
          </Grid>
        </Box>
      )}

      {activeTab === 1 && (
        <Box sx={{ p: 2 }}>
          <Grid container spacing={1}>
            <Grid item xs={12}>
              <Typography className={classes.label}>Output Variables</Typography>
            </Grid>
            <Grid item xs>
              <MultiSelectWithSearchForMDMCategories
                optionList={categories.map((item) => ({
                  ...item,
                  variableName: item.categoryDisplayName,
                }))}
                selectedOptionList={selectedOutputVariables || []}
                optionRenderKey="variableName"
                showTags={true}
                getSelectedItems={handleSelectedOutputVariables}
                id="output_List"
                maxTagsToShow={4}
              />
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
}
