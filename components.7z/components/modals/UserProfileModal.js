import React, { useState } from "react";
import ModalForm from "../../utils/modalForm";
import { makeStyles } from "@mui/styles";
import { Grid, Typography } from "@mui/material";
import Field from "../../utils/field";
import { getUser } from "../../utils/common";
import JohnDoe from "../../assets/img/johnDoe1.jpg";
import { useSelector, useDispatch } from "react-redux";
import { setProfileModalView } from "../../redux/actions";
import { useTranslation } from "react-i18next";
const UserProfileModal = (props) => {
  const [selTab, setSelTab] = useState("Personal Details");
  const dispatch = useDispatch();

  const [open, setOpen] = useState(props.isOpen ? true : false);
  const userArr = getUser();
  const fullName = userArr ? userArr[0]?.authUser?.fullName : "";
  const userLoginId = userArr ? userArr[0]?.authUser?.userLoginId : "";
  const userEmailId = userArr ? userArr[0]?.authUser?.emailId : "";

  const handleClose = () => {
    setOpen(false);
    dispatch(setProfileModalView(false));
  };
  const onClick1 = () => {
    handleClose();
  };
  const handleTabChange = (tabItem) => {
    setSelTab(tabItem);
  };

  return (
    <ModalForm
      id="RPA_UserProfileModal"
      isOpen={open}
      title="Profile"
      tabs={["Personal Details"]}
      selTab={selTab}
      handleTabChange={handleTabChange}
      Content={
        <Content
          id="RPA_UserProfileModal"
          fullName={fullName}
          userEmailId={userEmailId}
          userLoginId={userLoginId}
          selTab={selTab}
        />
      }
      btn1Title="Close"
      onClick1={onClick1}
      closeModal={handleClose}
      containerHeight={533}
      containerWidth={800}
    />
  );
};

export default UserProfileModal;

const useStyles = makeStyles({
  root: {
    paddingTop: "24px",
  },
  table: {
    minWidth: 900,
    overflow: "hidden",
  },
  profile: {
    height: "16px",
    width: "16px",
    borderRadius: "50px",
  },
  text_12: {
    fontSize: "12px",
    textAlign: "left",
  },
  text_bold: {
    color: "#606060",
    fontWeight: 600,
  },
  opacity_3: {
    opacity: 0.3,
  },
  headers: {
    fontSize: "11px",
    fontWeight: 600,
    color: "#767676",
  },
  workgroupName: {
    fontWeight: 600,
    fontSize: "12px",
  },
  row: {
    backgroundColor: "#F8F8F8",
  },
});

const Content = ({ fullName, userEmailId, userLoginId, selTab, id }) => {
  const classes = useStyles();
  const {t} = useTranslation()
  const allworkgroups = useSelector((state) => state.userDetails.workgroups);
  const allUsers = useSelector((state) => state.scriptsAndProjects.allUsers);
  const getUserDetails = (userId) => {
    if (allUsers) {
      const usr = allUsers.find((item) => item.userIndex === userId);
      if (usr) return usr;
    }
    return null;
  };

  const handleChange = () => {
    console.log("readOnly");
  };
  if (selTab === "Workgroup Access") {
    return (
      <div className={classes.root}>
        {allworkgroups && allworkgroups.length > 0 ? (
          <Grid container direction="column">
            <Grid item>
              <Grid container spacing={1}>
                <Grid item xs={2}>
                  <Typography className={classes.headers}>S.I</Typography>
                </Grid>
                <Grid item xs={3}>
                  <Typography className={classes.headers}>
                    {t("Workgroup Name")}
                  </Typography>
                </Grid>
                <Grid item xs={4}>
                  <Typography className={classes.headers}>
                    {t("Description")}
                  </Typography>
                </Grid>
                <Grid item xs={3}>
                  <Typography className={classes.headers}>{t("Owner")}</Typography>
                </Grid>
              </Grid>
            </Grid>
            {allworkgroups.map((workgroup, key) => (
              <Grid item key={key}>
                <Grid
                  container
                  spacing={1}
                  className={classes.row}
                  style={{ minHeight: "40px" }}
                  alignItems="center"
                >
                  <Grid item xs={2}>
                    <Typography>{key + 1}.</Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Typography className={classes.workgroupName}>
                      {workgroup.resourceGroupName || ""}
                    </Typography>
                  </Grid>
                  <Grid item xs={4}>
                    <Typography>{workgroup.description || ""}</Typography>
                  </Grid>
                  <Grid item xs={3}>
                    <Grid container spacing={1}>
                      <Grid item>
                        <img
                          src={JohnDoe}
                          style={{
                            height: "20px",
                            width: "20px",
                            borderRadius: "50px",
                          }}
                          alt="User Image"
                        />
                      </Grid>
                      <Grid item>
                        <Typography>
                          {getUserDetails(workgroup.createdBy)?.fullName ||
                            t("Details Not Available")}
                        </Typography>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography>{t("No Workgroups Assigned to you yet.")}</Typography>
        )}
      </div>
    );
  }
  return (
    <div className={classes.root}>
      <Grid container spacing={1}>
        <Grid item xs={6}>
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Field
                label={t("Full Name")}
                id={`${id}_FullName`}
                fullWidth={true}
                readOnly={true}
                value={fullName}
                // width={442}
                onChange={handleChange}
              />
            </Grid>
            <Grid item>
              <Field
                label={t("Email Id")}
                id={`${id}_EmailId`}
                fullWidth={true}
                readOnly={true}
                value={userEmailId}
                // width={442}
                onChange={handleChange}
              />
            </Grid>
            <Grid item>
              <Field
                label={t("Username")}
                id={`${id}_Username`}
                fullWidth={true}
                readOnly={true}
                value={userLoginId}
                // width={442}
                onChange={handleChange}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid item xs={6}>
          <Grid
            container
            direction="column"
            spacing={1}
            alignItems="center"
            justifyContent="center"
          >
            <Grid item>
              <img
                src={JohnDoe}
                style={{
                  height: "120px",
                  width: "120px",
                  borderRadius: "50px",
                }}
                alt="User Image"
              />
            </Grid>
            <Grid item>
              <Typography style={{ color: "#0072C6", fontWeight: 600 }}>
                {t("Change profile picture")}
              </Typography>
            </Grid>
            <Grid item>
              <Typography style={{ color: "#D53D3D", fontWeight: 600 }}>
                {t("Remove picture")}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </div>
  );
};
