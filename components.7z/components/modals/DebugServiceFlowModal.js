import React, { useState, useContext, useEffect } from "react";
import {
  TextField,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  Box,
  Grid,
} from "@mui/material";
import ModalForm from "../../utils/modalForm";
import { MDMDataObject } from "../../utils/AllImages";
import { createInstance, handleNetworkRequestError } from "../../utils/common";
import { VARIABLES } from "./../../config/index";
import { useDispatch, useSelector } from "react-redux";
import { NotificationContext } from "./../../contexts/NotificationContext";
import { useHistory } from "react-router-dom";
import LoadingIndicator from "../../utils/loadingIndicator";
import { setIsDebuging, setRunScriptModal } from "../../redux/actions";
const DebugServiceFlow = (props) => {
  
  const { isOpen, endpointDetails,updatedData,debugValue,setDefaultValue,handleClose,setIsDebuging,invokeScript } = props;
  const history = useHistory();
 
  
  const [allVariablesOrg, setAllVariablesOrg] = useState([]);
  const [allVariables, setAllVariables] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const scriptValues = useSelector((state) => state.script.openScriptDetails);
  const [data, setData] = useState([]);
  
  const versionId = scriptValues && scriptValues.versionId;
  const scriptId = scriptValues && scriptValues.scriptId;
  const recordsToFetch = 2;
  const { setValue } = useContext(NotificationContext);
  const dispatch = useDispatch();

  const [open, setOpen] = useState(isOpen ? true : false);
//   const handleClose = () => {
//     setOpen(false);
//     props.handleClose();
//   };

  const scriptInvoke = () => {
    //Bug 156223 - after the execution of the scriptin debug mode getting error that the newly created serviceflow are displayed in running mode
    //Author: nitin_tomar
    //Date: 28 JAN 2025
    //Description : for Every Debug Action APi was getting called two times. Now prevent the API call for more than once 
    
    // invokeScript("debugExecution");
    dispatch(setIsDebuging(true));
    dispatch(setRunScriptModal("Output"));
    //setIsDebuging(true);
    handleClose();
  };

  const getAllVariables = async () => {
    const axiosInstance = createInstance();
    if (versionId) {
      setIsLoading(true);
      try {
        let res = await axiosInstance.get(`${VARIABLES}/${versionId}`);
        setAllVariables(res.data.data ? res.data.data : []);
        setAllVariablesOrg(res.data.data ? res.data.data : []);
        setIsLoading(false);
      } catch (error) {
        handleNetworkRequestError({
          error,
          history,
          onError: (errMsg) => {
            setValue({
              isOpen: true,
              message: errMsg || "",
              title: "",
              notificationType: "ERROR",
            });
          },
        });
        setIsLoading(true);
      }
    } else {
      console.log("version id is not available", versionId);
    }
  };



 

  useEffect(() => {
    getAllVariables();
    setData(allVariables);
  }, []);

  return (
    <ModalForm
      id={props.id}
      isOpen={open}
      title={"Debug ServiceFlow"}
      Content={
        <Content
          id={props.id}
          initialData={allVariables}
          isLoading={isLoading}
          defaultValue={debugValue}
          setDefaultValue={setDefaultValue}
          data={allVariables}
          setData={setData}
          updatedData={updatedData}
        />
      }
      headerCloseBtn={true}
      onClickHeaderCloseBtn={handleClose}
      btn2Title="Debug"
      onClick2={scriptInvoke}
      closeModal={handleClose}
      containerHeight={500}
      containerWidth={800}
      btn1Title="Cancel"
      onClick1={handleClose}
    />
  );
};

export default DebugServiceFlow;

const Content = ({
  id,
  initialData,
  isLoading,
  data,
  setData,
  setDefaultValue,
  defaultValue,
  updatedData
}) => {
  const handleInputChange = (index, newValue) => {
    setDefaultValue((prevState) => ({
      ...prevState,
      [index]: newValue,
    }));
  };

  const handleSetDefault = (index, value) => {
    setDefaultValue((prevState) => ({
      ...prevState,
      [index]: value, // Set default value only for the clicked row
    }));
  };
  const getButtonState = (row, index) => {
    const isDisabled = row.debugValue === row.varDefaultValue;
    return isDisabled ? 'disabled' : 'enabled';
  };
const handleClearAll=()=>{
    
    setDefaultValue({});
}


  const typeOptions = [
    { name: "Integer", value: 2 },
    { name: "Float", value: 8 },
    { name: "Text", value: 1 },
    { name: "Date", value: 4 },
    { name: "Boolean", value: 3 },
    { name: "List", value: 5 },
    { name: "DataRecord", value: 7 },
    { name: "DataTable", value: 6 },
    { name: "MailMessage", value: 10 },
    { name: "DateTime", value: 9 },
    { name: "JSONObject", value: 11 },
    { name: "JSONArray", value: 12 },
  ];

  const getObjectTypeName = (TypeValue) => {
    return typeOptions.filter((type) => type.value == TypeValue)[0].name;
  };

  if (isLoading) {
    return <LoadingIndicator />;
  }
  return (
    <TableContainer component={Paper}>
      <Table size="small" stickyHeader>
        <TableHead>
          <TableRow
            sx={{
              "& .MuiTableCell-root": {
                fontWeight: "bold",
              },
            }}
          >
            <TableCell>Name</TableCell>
            <TableCell>Data Type</TableCell>
            <TableCell>Value</TableCell>
            <TableCell>
                <Button onClick={handleClearAll}
                disabled={Object.keys(defaultValue).length === 0} 
                >Clear All</Button>
               </TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {updatedData.map((row, index) => (
            <TableRow key={index} sx={{ height: "30px" }}>
              <TableCell>
                <Grid container direction={"column"}>
                  <Grid item>{row.variableDisplayName}</Grid>
                  <Grid item>
                    <Grid container spacing={1}>
                      <Grid item>
                        <MDMDataObject />
                      </Grid>
                      <Grid item>
                        <Typography variant="caption" color={"#606060"}>
                          {"Global Category"}
                        </Typography>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </TableCell>
              <TableCell>{getObjectTypeName(row.variableObjType)}</TableCell>
              <TableCell>
                <TextField
                  fullWidth
                  variant="outlined"
                  size="small"
                  value={defaultValue[index] || ""}
                  onChange={(e) => handleInputChange(index, e.target.value)}
                  placeholder="Enter Value"
                  sx={{
                    "& .MuiInputBase-root": {
                      height: "30px",
                    },
                  }}
                />
              </TableCell>
              <TableCell>
                <Button
                  onClick={() => handleSetDefault(index, row.varDefaultValue)}
                  disabled={getButtonState(row, index) === 'disabled'} 
                >
                  Set as Default
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};
