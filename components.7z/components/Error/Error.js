import React from "react";
import { removeUserSession } from "../../utils/common";

import { useDispatch } from "react-redux";
import { setSessionTimeout } from "../../redux/actions";

import SessionTimeoutModal from "../modals/SessionTimeout";
function Error(props) {
  // handle click event of logout button
  const dispatch = useDispatch();
  dispatch(setSessionTimeout(true));

  const handleLogout = () => {
    removeUserSession();
    props.history.push("/");
  };
  return <SessionTimeoutModal isOpen={true} handleClose={handleLogout} />;
}

export default Error;
