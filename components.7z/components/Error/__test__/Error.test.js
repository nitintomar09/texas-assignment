import React from "react";
import ReactDom from "react-dom";
import Error from "../Error";

import renderer from "react-test-renderer";
import { render, cleanup } from "../../../components/common/test-utils";
import "@testing-library/jest-dom/extend-expect";

afterEach(cleanup);
it("renders without crashing", () => {
  //   const div = document.createElement("div");
  render(<Error />);
});
