import { useLayoutEffect } from 'react';
import { useDispatch } from 'react-redux';
import { setWindowInnerHeight } from '../../redux/AppGlobalState/actions';

const useWindowDimension = () => {
  const dispatch = useDispatch();

  useLayoutEffect(() => {
    const updateWindowInnerHeight = () => {
      dispatch(setWindowInnerHeight(window.innerHeight));
    };
    updateWindowInnerHeight();

    window.addEventListener("resize", updateWindowInnerHeight);
    return () => window.removeEventListener("resize", updateWindowInnerHeight);
  }, [dispatch]);
};

export default useWindowDimension;
