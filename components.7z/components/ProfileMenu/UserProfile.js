import * as React from "react";

import {
  Box,
  Avatar,
  Menu,
  MenuItem,
  ListItemIcon,
  Divider,
  IconButton,
  Grid,
  Typography,
  CircularProgress,
  ClickAwayListener,
  Paper,
} from "@mui/material";
import makeStyles from "@mui/styles/makeStyles";
import { withRouter, useHistory } from "react-router-dom";
import { setProfileModalView, userLogout } from "../../redux/actions";
import { getUser, truncateStringValues } from "../..//utils/common";
import { useDispatch, useSelector } from "react-redux";
import CustomTooltip from "./../../utils/CustomTooltip";
import JohnDoe from "../../assets/img/johnDoe1.jpg";
import { ProfileIcon, LogoutIcon } from "../../utils/AllImages";
import moment from "moment";
import { useTranslation } from "react-i18next";
import { getAppDirection } from "../common";
import "./UserProfile.css"
import secureLocalStorage from "react-secure-storage";
import ModalForm from "../../utils/modalForm";
const useStyles = makeStyles((theme) => ({
  info: {
    fontSize: "10px",
    color: "#606060",
    fontStyle: "italic",
  },
  tooltip: {
    backgroundColor: "#FFFFFF",
    fontSize: "12px",
    color: "#000000",
    border: "1px solid #C4C4C4",
  },
  icon: {
    width: "14px",
    height: "14px",
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
    },
  },
  label: {
    fontSize: "12px",
    color: "#606060",
  },
  bold: {
    fontSize: "12px",
    fontWeight: 600,
  },
  bold1: {
    fontSize: "12px",
    //fontWeight: 400,
  },
  userName: {
    fontSize: '12px'
  },
  fullName: {
    fontSize: '16px',
    fontWeight: 600
  },
  userImg:{
    width: "30px",
    height: "30px",
    borderRadius: "50%",
    marginInlineEnd: "1rem",
    marginBlockStart: "4px",
    cursor: "pointer",
  }
}));
const UserProfile = () => {
  
  const classes = useStyles();
  const userArr = getUser();
  const { t } = useTranslation();
  const dispatch = useDispatch();
  const history = useHistory();
  const [showUserProfile, setShowUserProfile] = React.useState(false);
  const [isLogout, setIsLogout] = React.useState(false);
  const cabinet = secureLocalStorage.getItem("cabinet");

 
  const handleLogout = () => {
    dispatch(userLogout({ history }));
  };
  const isLogoutLoading = useSelector(
    (state) => state.userDetails.isLogoutLoading
  );
  
  const logoutAlert = () => {
    setIsLogout(true);
  };


  const userDisplay = (val) => {
    let name = val?.split(" ") || "";
    let initials;

    if (name.length === 1) {
      initials = name[0]?.charAt(0);
    } else {
      initials = name[0]?.charAt(0) + "" + name[name.length - 1]?.charAt(0);
    }

    return initials;
  };
  if (!userArr) {
    return (<div></div>)
  }
  const handleKeyLogoutAlert = (e) => {
    if (e.keyCode === 13) {
      logoutAlert();
      e.stopPropagation();
    }
  };
  const dontLogout = () => {
    setIsLogout(false);

  }
  const yesLogout = () => {
    handleLogout();
  }
  return (

    <div style={{ marginLeft: "auto", display: "flex" }}>

      <div className="relative">
        {userArr[0]?.authUser?.profileImage ? (
          <img
            src={
              userArr[0]?.authUser.profileImage.indexOf("data:image/") === -1
                ? `data:image/${userArr[0]?.authUser?.profileImageExtension};base64,${userArr[0]?.authUser?.profileImage}`
                : userArr[0]?.authUser.profileImage
            }
            alt={"User Settings"}
            role="button"
            aria-label="User Settings"
           className={classes.userImg}
            onClick={() => {
              setShowUserProfile(true);
            }}
            id="pmweb_AppHeader_userProfileName"
            tabIndex={0}
            onKeyUp={(e) => {
              if (e.key === "Enter") {
                setShowUserProfile(true);
              }
            }}
          />
        ) : (
          <Box
            style={{ display: "flex", alignItems: "center", textAlign: "center" }}
          >
            {userArr && userArr[0]?.authUser?.userLoginId && (
              <CustomTooltip title={`${userArr[0]?.authUser?.userLoginId}`}>
                <IconButton
                  //  onClick={handleClick}
                  onClick={() => {
                    setShowUserProfile(true);
                  }}
                  size="small"
                  style={{ ml: 2 }}
                  //WCAG guidelines
                  //  tabIndex={0}
                  className={classes.focusVisible}
                  // role="button"
                  aria-pressed="false"
                  id="RPA_UserProfile_Avatar"
                >
                  <Avatar
                    variant="circular"
                    style={{ width: 34, height: 34, background: "#9d5b38" }}
                  >
                    {userArr[0]?.authUser?.fullName?.charAt(0).toUpperCase()}
                  </Avatar>
                </IconButton>
              </CustomTooltip>
            )}
          </Box>
        )}
        {showUserProfile && (
          <ClickAwayListener onClickAway={() => setShowUserProfile(false)}>
            <Paper
              className="userProfileDiv"
              id="pmweb_AppHeader_userProfileTab"
             
            >
              <Grid container style={{ height: '60px', background: '#FBF6EC', padding: '16px' }}>
                <Grid item>
                  {userArr[0]?.authUser?.profileImage ? (
                    <img
                      src={
                        userArr[0]?.authUser.profileImage.indexOf("data:image/") === -1
                          ? `data:image/${userArr[0]?.authUser?.profileImageExtension};base64,${userArr[0]?.authUser?.profileImage}`
                          : userArr[0]?.authUser.profileImage
                      }
                      alt={"User Settings"}
                      style={{
                        width: "30px",
                        height: "30px",
                        borderRadius: "50%",
                        marginInlineEnd: "1rem",
                        marginBlockStart: "4px",
                      }}
                    />
                  ) : (
                    <Box
                      style={{ display: "flex", alignItems: "center", textAlign: "center" }}
                    >
                      {userArr && userArr[0]?.authUser?.userLoginId && (
                        <CustomTooltip title={`${userArr[0]?.authUser?.userLoginId}`}>
                          <IconButton

                            size="small"
                            style={{ ml: 2 }}

                            className={classes.focusVisible}
                            tabIndex={-1}
                          >
                            <Avatar
                              variant="circular"
                              style={{ width: 34, height: 34, background: "#9d5b38" }}
                            >
                              {userArr[0]?.authUser?.fullName?.charAt(0).toUpperCase()}
                            </Avatar>
                          </IconButton>
                        </CustomTooltip>
                      )}
                    </Box>
                  )}
                </Grid>
                <Grid item >
                  <Grid container direction={'column'} spacing={1} style={{marginInlineStart:0}}>
                    <Grid item>
                      <CustomTooltip
                        id="pmweb_AppHeader_FullNameTooltip"
                        arrow={true}
                        placement="bottom"
                        title={userArr[0]?.authUser?.fullName}
                      >
                        <span className={classes.fullName}>
                          {userArr[0]?.authUser?.fullName?.length > 17
                            ? userArr[0]?.authUser?.fullName?.slice(0, 17) + "..."
                            : userArr[0]?.authUser?.fullName}
                        </span>
                      </CustomTooltip>
                    </Grid>
                    <Grid item>
                      <CustomTooltip
                        id="pmweb_AppHeader_UserNameTooltip"
                        arrow={true}
                        placement="bottom"
                        title={userArr[0]?.authUser?.userLoginId}
                      >
                        {userArr[0]?.authUser?.userLoginId ? <span className={classes.userName}>
                          {userArr[0]?.authUser?.userLoginId?.length > 17
                            ? userArr[0]?.authUser?.userLoginId?.slice(0, 17) + "..."
                            : userArr[0]?.authUser?.userLoginId}
                        </span> : <span className={classes.userName}>
                          {userArr[0]?.authUser?.userLoginId?.length > 17
                            ? userArr[0]?.authUser?.userLoginId?.slice(0, 17) + "..."
                            : userArr[0]?.authUser?.userLoginId}
                        </span>}
                      </CustomTooltip>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid container direction={'column'} spacing={1} style={{ padding: '16px' }}>
                <Grid item container spacing={1}
                >
                  <Grid item>
                    <Typography className={classes.label}> {t("Cabinet")} :</Typography>
                  </Grid>
                  <Grid item>
                    <Typography className={classes.bold}> {cabinet || "Fake Cabinet"}</Typography>
                  </Grid>
                </Grid>
                <Grid item container spacing={1}
                >
                  <Grid item>
                    <Typography className={classes.label}>
                      {t("Last login time:")}{" "}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography className={classes.bold}>{userArr &&
                      userArr[0]?.authUser?.lastLoginTime &&
                      moment(
                        userArr[0]?.authUser?.lastLoginTime,
                       "YYYY-MM-DD HH:mm:ss"
                      ).format("DD MMM YYYY, HH:mm")}</Typography>
                  </Grid>
                </Grid>

              </Grid>
              <Divider variant="fullWidth" style={{ marginLeft: '16px', marginRight: '16px' }} />
              <Grid container style={{ padding: '16px' }}>

                <Grid item container alignItems={'center'}
                  id="pmweb_logoutAlert"
                  onClick={logoutAlert}
                  tabIndex={0}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleKeyLogoutAlert(e)
                    }
                  }}
                  style={{ cursor: 'pointer' }}
                >
                  <Grid item>
                    <LogoutIcon
                      style={{
                        width: "16px",
                        height: "16px",
                        marginTop: '5px',
                        marginRight: "8px",

                      }} />
                  </Grid>
                  <Grid item>
                    <Typography className={classes.label}>
                      {t("Logout")}
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
            </Paper>
          </ClickAwayListener>
        )}
        <ModalForm
          id="RPA_LoginModal"
          title={t("Logout")}
          containerHeight={210}
          isOpen={isLogout ? true : false}
          closeModal={dontLogout}
          Content={
            <Grid container spacing={1} direction={'column'}>
              <Grid item>
            <Typography>
            Logging out here would log you out from all the active tabs. Please ensure you save the data before logging out.
            </Typography>
              </Grid>
              <Grid item>
              <Typography>{t("Are you sure you want to logout from this session?")}</Typography>
              </Grid>
            </Grid>
            
          }
          btn1Title="Cancel"
          onClick1={dontLogout}
          headerCloseBtn={true}
          onClickHeaderCloseBtn={dontLogout}
          btn2Title="Logout"
          isProcessing={isLogoutLoading}
          onClick2={yesLogout}
        />
      </div>
    </div>
  );
};
export default withRouter(UserProfile);

/*return (
    <React.Fragment>
      <Box
        style={{ display: "flex", alignItems: "center", textAlign: "center" }}
      >
        {userArr && userArr[0]?.authUser?.userLoginId && (
          <CustomTooltip title={`${userArr[0]?.authUser?.userLoginId}`}>
            <IconButton
              onClick={handleClick}
              size="small"
              style={{ ml: 2 }}
              //WCAG guidelines
              tabIndex={0}
              className={classes.focusVisible}
              role="button"
              aria-pressed="false"
              id="RPA_UserProfile_Avatar"
            >
              <Avatar
                variant="circular"
                style={{ width: 32, height: 32, background: "#036594" }}
              >
                {userArr[0]?.authUser?.fullName?.charAt(0).toUpperCase()}
              </Avatar>
            </IconButton>
          </CustomTooltip>
        )}
      </Box>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        getContentAnchorEl={null}
        anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
        transformOrigin={{ vertical: "top", horizontal: "center" }}
        onClose={handleClose}
        PaperProps={{
          elevation: 0,
          style: {
            overflow: "visible",
            filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
            mt: 1.5,
            "& .MuiAvatarRoot": {
              width: 32,
              height: 32,
              ml: -0.5,
              mr: 1,
            },
            "&:before": {
              content: '""',
              display: "block",
              position: "absolute",
              top: 0,
              right: 18,
              width: 12,
              height: 12,
              bgcolor: "background.paper",
              transform: "translateY(-50%) rotate(45deg)",
              zIndex: 0,
            },
          },
        }}
        // transformOrigin={{ horizontal: "right", vertical: "top" }}
        //anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
      >
        <MenuItem style={{ backgroundColor: "#FBF6EC" }}>
          <img
            src={JohnDoe}
            style={{
              height: "30px",
              width: "30px",
              marginRight: "12px",
              borderRadius: "50px",
            }}
            alt="User Image"
          />{" "}

          {/* {BugId:Bug 143344 - User Name should be display on Right Top corner 
          Author:Dixita Ruhela
          Date:08 feb 2024
          RCA:replace fullName with userLoginId
          } */
/* <span
   style={{ fontSize: "16px", fontWeight: 600 }}
   title={userArr && userArr[0]?.authUser?.userLoginId}
 >
   {truncateStringValues({
     str: userArr ? userArr[0]?.authUser?.userLoginId : "",
     max: 24,
     min: 20,
   })}
 </span>
</MenuItem>
<Divider />
<MenuItem>
 <Grid container direction="column">
   <Grid item>
     <Typography className={classes.info}>
       {t("Last login time:")}{" "}
       {userArr &&
         userArr[0]?.authUser?.lastLoginTime &&
         moment(
           userArr[0]?.authUser?.lastLoginTime,
           "DD-MM-yyyy HH:mm:ss"
         ).format("DD MMM YYYY, HH:mm")}
     </Typography>
   </Grid>
   {/*<Grid item className={classes.info}>
     <Typography className={classes.info}>
       Failure attempts: 3
     </Typography>
       </Grid>*/
/*  </Grid>
</MenuItem>
<Divider />
{/*<MenuItem onClick={handleProfile}>
  <ListItemIcon style={{ marginRight: "-35px" }}>
    <ProfileIcon className={classes.icon} />
  </ListItemIcon>
  Profile
  </MenuItem>*/

{/* {BugId:"Bug 142571 - RPA designer->logout word and symbol are overlapping",
          AuthorName:Dixita Ruhela
          Date:19 jan 2024
          RCA:It is a padding issue. Due to which the icons and logout title is overlapping.

          } */}

/* <MenuItem onClick={handleLogout} autoFocus>
   <ListItemIcon style={{ [MARGIN_RIGHT]: "-35px" }}>
     <LogoutIcon
       style={{
         width: "14px",
         height: "14px",
         marginTop:'3px',
         marginRight: "8px",

       }}
     />
     {isLogoutLoading && (
       <CircularProgress
         // color="#606060"
         style={{
           height: "15px",
           width: "15px",
           marginRight: "8px",
           color: "#606060",
         }}
       ></CircularProgress>
     )}

     {t("Logout")}
   </ListItemIcon>
   {/* <Grid container >
     <Grid item>
       <ListItemIcon tabIndex={0}>
         <LogoutIcon className={classes.icon} />
       </ListItemIcon>
     </Grid>
     {isLogoutLoading && (
       <Grid item>
         <CircularProgress
           // color="#606060"
           style={{
             height: "15px",
             width: "15px",
             marginRight: "8px",
             color: "#606060"
           }}
         ></CircularProgress>
       </Grid>)}
     <Grid item xs>
       {t("Logout")}

     </Grid>

   </Grid> */
/*   </MenuItem>
 </Menu>
</React.Fragment>
);*/