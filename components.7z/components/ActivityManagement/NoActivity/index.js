import { Button } from '@mui/material'
import React from 'react'
import { CreatedIcon } from '../../../utils/AllImages'
import { useTranslation } from 'react-i18next'
import { makeStyles } from '@mui/styles';
import Layer_7 from "../../../assets/images/Layer_7.svg";

const useStyles = makeStyles({
    container: {
        width: "100%",
        display: 'flex',
        justifyContent: 'center',  
        alignItems: 'center',     
        height: '90vh',           
    },
    centeredDiv: {
        display: 'flex',          
        justifyContent: 'center', 
        alignItems: 'center',      
        flexDirection: "column",
    },
    heading: {
        marginBottom: '4px',
    },
    listItem: {
        marginBottom: '10px',
        display: 'flex',
        fontFamily: 'Open Sans',  // Apply the font-family
        fontSize: '12px',         // Apply the font-size
        fontWeight: 400,          // Apply the font-weight
        lineHeight: '14px',       // Apply the line-height
        textAlign: 'left',        // Apply text alignment
    },
});

const NoActivity = ({handleOpenModal}) => {
    const {t} = useTranslation();
    const classes = useStyles();

    return (
        <div className={classes.container}>
            <div className={classes.centeredDiv}>
                <img src={Layer_7} alt={"image"} />
                <h3 className={classes.heading}>Upload Custom Activity</h3>
                <ul>
                    <li className={classes.listItem}>Add your own activity to enhance automation capabilities</li>
                    <li className={classes.listItem}>Supported file formats (e.g., .zip, .dll, .json, etc.)</li>
                </ul>
                <Button
                    variant="contained"
                    color="primary"
                    startIcon={<CreatedIcon />}
                    disableFocusRipple
                    tabIndex={0}
                    id="RPA_ScriptDesigner_CreateScriptBtn"
                    onClick={() => {
                        handleOpenModal("Upload Custom Activity")
                    }}
                >
                    {t("Add Activity")}
                </Button>
            </div>
        </div>
    )
}

export default NoActivity;
