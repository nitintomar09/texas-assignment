import React, { useState, useEffect, useContext } from "react";
import { Grid, Typography, Paper, Divider, Box } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import ActivityManagementTop from "./../Top/index";
import SearchBox from "../../../utils/Search-Component";
import CustomTabs from "../../../utils/CustomTabs";
import ActivityManagementLeft from "./../Left/index";
import ActivityManagementRight from "../Right";
import UploadActivityModal from "../../modals/UploadActivityModal";
import { useTranslation } from "react-i18next";
import {
  ACTIVITY_GROUP,
  MODIFY_CUSTOM_INDEX,
  REMOVE_CUSTOM_INDEX,
  UPLOAD_CUSTOM_INDEX,
} from "../../../config";
import {
  createInstance,
  doesUserHavePermission,
  handleNetworkRequestError,
} from "../../../utils/common";
import { useHistory } from "react-router-dom";
import DeprecateCustomActivityModal from "./../../modals/DeprecateCustomActivityModal";
import { NotificationContext } from "../../../contexts/NotificationContext";
import NoActivity from "../NoActivity";

const useStyles = makeStyles((theme) => ({
  paper1: {
    paddingTop: 20,
    fontSize: 12,

    width: "270px",
    marginBottom: 1,
    marginRight: 1,
    boxShadow: "0px 2px 6px #00000014",
  },
  paddingItems: {
    paddingLeft: 13,
    paddingRight: 13,
  },
  title: {
    fontWeight: 600,
    fontSize: "16px",
  },
  selectedTab: {
    //paddingBottom: "4px",
    borderBottom: `2px solid ${theme.palette.primary.main}`,
    // marginRight: "24px",
  },
  divider: {
    marginTop: "2px",
    height: 0,
    border: "1px solid #C4C4C4",
  },
  padding: {
    paddingLeft: "20px",
    paddingRight: "20px",
    display: "flex",
  },
}));
const ActivityManagement = () => {
  const classes = useStyles();
  const history = useHistory();
  const { setValue } = useContext(NotificationContext);
  const { t } = useTranslation();
  const [selectedTab, setSelectedTab] = useState(t("Custom"));
  const [selectedActivity, setSelectedActivity] = useState(null);
  const [editedActivity, setEditededActivity] = useState(null);
  const [openModal, setOpenModal] = useState(null);
  const [listOfActivities, setListOfActivities] = useState([]);

  const [allFetchedActivities, setAllFetchedActivities] = useState([]);
  const [isFetchingActivities, setIsFetchingActivities] = useState(false);
  const [makePublicIsLoading, setmakePublicIsLoading] = useState(false);

  const [errorFetchingActivityGroup, setErrorFetchingActivityGroup] =
    useState(null);
  //const [searchTextVal, setSearchTextVal] = useState("");

  const getActivitiesGroup = async () => {
    const axiosInstance = createInstance();
    setIsFetchingActivities(true);
    try {
      let res = await axiosInstance.get(`${ACTIVITY_GROUP}/0/0`);

      if (res.status === 200) {
        const activitiesGroupData = res.data.data;
        setAllFetchedActivities(activitiesGroupData || []);
        setListOfActivities(activitiesGroupData || []);
        /*   const recentActivitiesObj = {
          groupName: "Recents",
          groupId: "Recents",
          activities: [],
        };
        const favActivitiesObj = {
          groupName: "Favourites",
          groupId: "Favourites",
          activities: [],
        };
        setShownActivities(
          activitiesGroupData
            ? [recentActivitiesObj, favActivitiesObj, ...activitiesGroupData]
            : []
        );*/
        setIsFetchingActivities(false);
      }
    } catch (error) {
      handleNetworkRequestError({ error, history });

      setErrorFetchingActivityGroup(
        error.response
          ? error.response.data["errorMessage"]
          : "Something went wrong at server."
      );
      setIsFetchingActivities(false);
      setAllFetchedActivities([]);
      setListOfActivities([]);
    }
  };

  const makePublic = async (groupId, callback) => {
    const axiosInstance = createInstance();
    setmakePublicIsLoading(true);
    try {
      let res = await axiosInstance.put(`/publiccustomactivity/${groupId}`);

      if (res.status === 200) {
        setListOfActivities(listOfActivities.map((item) => {
          if (parseInt(item.groupId) === parseInt(groupId)) {


            return { ...item, isPrivate: 0 };
          } else {
            console.log("case rejected", item, allFetchedActivities, groupId);

            return item;
          }
        }))

        setAllFetchedActivities(
          allFetchedActivities.map((item) => {
            if (parseInt(item.groupId) === parseInt(groupId)) {
              console.log(
                "case accepted",
                item,
                { ...item, isPrivate: 0 },
                allFetchedActivities,
                groupId
              );

              return { ...item, isPrivate: 0 };
            } else {
              console.log("case rejected", item, allFetchedActivities, groupId);

              return item;
            }
          })
        );
        setSelectedActivity(
          allFetchedActivities.map((item) => {
            if (parseInt(item.groupId) === parseInt(groupId)) {
              return { ...item, isPrivate: 0 };
            }
          })
        );
        setmakePublicIsLoading(false);
        callback(0);
      }
      setmakePublicIsLoading(false);

    } catch (error) {
      handleNetworkRequestError({ error, history });

      setErrorFetchingActivityGroup(
        error.response
          ? error.response.data["errorMessage"]
          : "Something went wrong at server."
      );
      setmakePublicIsLoading(false);
    }
  };

  useEffect(() => {
    getActivitiesGroup();
  }, []);
  const handleSelectedTab = (tab) => {
    setSelectedTab(tab);
  };
  const handleSelectedActivity = (activity) => {
    setSelectedActivity(activity);
  };
  const handleOpenModal = (name) => {
    setOpenModal(name);
  };
  const handleCloseModal = () => {
    setOpenModal(null);
  };

  const updateActivities = (activityGroup) => {
    if (activityGroup) {
      const newAllActivities = [...listOfActivities];
      const newFetchedActivities = [...allFetchedActivities];

      if (selectedActivity) {
        if (newFetchedActivities) {
          const activityGroupIndex = newFetchedActivities.findIndex(
            (obj) => obj.groupId === activityGroup.groupId
          );
          const activityObj = newFetchedActivities.find(
            (obj) => obj.groupId === activityGroup.groupId
          );

          if (activityGroupIndex !== -1) {
            newFetchedActivities.splice(activityGroupIndex, 1, {
              ...activityObj,
              ...activityGroup,
            });
          } else {
            newFetchedActivities.unshift({ ...activityGroup });
          }
        }
        if (newAllActivities) {
          const activityGroupIndex1 = newAllActivities.findIndex(
            (obj) => obj.groupId === activityGroup.groupId
          );
          const activityGroupObj = newAllActivities.find(
            (obj) => obj.groupId === activityGroup.groupId
          );

          if (activityGroupIndex1 !== -1) {
            newAllActivities.splice(activityGroupIndex1, 1, {
              ...activityGroupObj,
              ...activityGroup,
            });
          } else {
            newAllActivities.unshift({ ...activityGroup });
          }
        }
      } else {
        newAllActivities.push(activityGroup);
        newFetchedActivities.push(activityGroup);
      }

      setAllFetchedActivities(newFetchedActivities);
      setListOfActivities(newAllActivities);
      setEditededActivity(null);

      if (
        activityGroup.isCustomActivity &&
        !selectedActivity?.isCustomActivity
      ) {
        setSelectedTab("Custom");
      }
      if (!activityGroup?.deprecating) {
        setSelectedActivity(activityGroup);
      }

      /* const newAllActivities = [...listOfActivities];
      const newFetchedActivities = [...allFetchedActivities];
      if (newFetchedActivities) {
        const activityGroupIndex = newFetchedActivities.findIndex(
          (obj) => obj.groupId === activityGroup.groupId
        );
        const activityObj = newFetchedActivities.find(
          (obj) => obj.groupId === activityGroup.groupId
        );

        if (activityGroupIndex !== -1) {
          newFetchedActivities.splice(activityGroupIndex, 1, {
            ...activityObj,
            ...activityGroup,
          });
        } else {
          newFetchedActivities.push(activityGroup);
        }
        setAllFetchedActivities(newFetchedActivities);
      }
      if (newAllActivities) {
        const activityGroupIndex1 = newAllActivities.findIndex(
          (obj) => obj.groupId === activityGroup.groupId
        );
        const activityGroupObj = newAllActivities.find(
          (obj) => obj.groupId === activityGroup.groupId
        );
        if (activityGroupIndex1 !== -1) {
          newAllActivities.splice(activityGroupIndex1, 1, {
            ...activityGroupObj,
            ...activityGroup,
          });
        } else {
          newAllActivities.push(activityGroup);
        }

        setListOfActivities(newAllActivities);
      } else {
        newAllActivities.push(activityGroup);

        setListOfActivities(newAllActivities);
      }
      setSelectedActivity(activityGroup);

      if (activityGroup.isCustomActivity) {
        setSelectedTab("Custom");
      } else {
        setSelectedTab("System");
      }
      */
    }
  };
  /* const handleEditedActivity=(activityGroup)=>{
    setEditededActivity(activityGroup)
  }*/
  const showModal = () => {
    let modalToOpen = null;
    switch (openModal) {
      case "Upload Custom Activity":
      case "Update Activity":
        if (
          doesUserHavePermission({
            isShared: false,
            permissionNum:
              openModal === "Upload Custom Activity"
                ? UPLOAD_CUSTOM_INDEX
                : MODIFY_CUSTOM_INDEX,
            componentId: 13,
          })
        ) {
          modalToOpen = (
            <UploadActivityModal
              id="RPA_ActivityMngmt_UploadActivity"
              isOpen={true}
              handleClose={handleCloseModal}
              updateActivities={updateActivities}
              editedActivity={
                openModal === "Update Activity" ? selectedActivity : null
              }
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: `You Don't have permission to  ${openModal}.`,
            notificationType: "ERROR",
            title: "",
          });
          setOpenModal(null);
        }
        break;

      case "Deprecate Activity":
        if (
          doesUserHavePermission({
            isShared: false,
            permissionNum: REMOVE_CUSTOM_INDEX,
            componentId: 13,
          })
        ) {
          modalToOpen = (
            <DeprecateCustomActivityModal
              id="RPA_ActivityMngmt_DeprecateActivity"
              isOpen={true}
              handleClose={handleCloseModal}
              updateActivities={updateActivities}
              selectedCustomActivity={selectedActivity}
              listOfActivities={allFetchedActivities}
            />
          );
        } else {
          setValue({
            isOpen: true,
            message: `You Don't have permission to  ${openModal}.`,
            notificationType: "ERROR",
            title: "",
          });
          setOpenModal(null);
        }
        break;

      default:
        break;
    }
    return modalToOpen;
  };

  const handleActivitySearch = (searchText) => {
    const newListOfAct = allFetchedActivities.filter((item) =>
      item?.groupName.toLowerCase().includes(searchText.toLowerCase())
    );
    setListOfActivities(newListOfAct);
    //  setSearchTextVal(searchText);
  };
  /* const filteredActivities = () => {
    return allFetchedActivities.filter((item) =>
      item?.groupName.toLowerCase().includes(searchTextVal.toLowerCase())
    );
  };*/

  //filtering unique custom groups
  //latest versions are the first ones
  const getUniqueCustomActivitiesGrp = (item, index, self) => {
    if (item.isCustomActivity) {
      const indexOfItem = self.findIndex(
        (grp) => grp.groupName === item.groupName
      );
      if (indexOfItem === index) {
        return true;
      }
      return false;
    }
    return false;
  };
  return (
    <div className={classes.padding}>
      {/* <NoActivity handleOpenModal={handleOpenModal}/> */}
      <Grid container direction="column">
        <Grid item>
          <ActivityManagementTop handleOpenModal={handleOpenModal} />
        </Grid>
        <Grid item container direction="row" style={{ flexWrap: "nowrap" }}
          spacing={3}
        >
          <Grid item>
            <Paper square elevation={2} className={classes.paper1}>
              <Grid
                container
                direction="column"
                className={classes.paddingItems}
              >
                <Grid item style={{ marginBottom: "12px" }}>
                  <Typography variant="h6" className={classes.title}>
                    {t("Activities")}
                  </Typography>
                </Grid>
                <Grid item style={{ marginBottom: "16px" }}>
                  <SearchBox
                    id="RPA_ActivityMgmt"
                    width="245px"
                    onSearchChange={handleActivitySearch}
                  />
                </Grid>
                <Grid item>
                  {/* <CustomTabs
                    id="RPA_ActivityMgmt"
                    tabItems={[t("System"), t("Custom")]}
                    selectedTab={selectedTab}
                    handleTabChange={handleSelectedTab}
                    className={classes.selectedTab}
                    justify="flex-start"
                  /> */}
                </Grid>
              </Grid>
              {/* <Divider variant="fullWidth" className={classes.divider} /> */}

              <Box
                component={Grid}
                item
                xs={12}
                style={{ display: "flex", flexDirection: "column" }}
              >
                <ActivityManagementLeft
                  selectedTab={selectedTab}
                  isFetchingActivities={isFetchingActivities}
                  selectedActivity={selectedActivity}
                  listOfActivities={
                    selectedTab === t("System")
                      ? listOfActivities.filter(
                        (item) => !item.isCustomActivity
                      )
                      : // .filter(filteredActivities)
                      listOfActivities.filter(getUniqueCustomActivitiesGrp)
                  }
                  handleSelectedActivity={handleSelectedActivity}
                />
              </Box>
            </Paper>
          </Grid>
          <Grid item xs>
            <ActivityManagementRight
              selectedActivity={selectedActivity}
              handleOpenModal={handleOpenModal}
              listOfActivities={listOfActivities}
              makePublic={makePublic}
              makePublicIsLoading={makePublicIsLoading}
            />
          </Grid>
        </Grid>
      </Grid>
      {/*will return the modal whichever selected */}
      {openModal ? showModal() : null}
    </div>
  );
};

export default ActivityManagement;
const activitiesList = [
  {
    activityId: 1,
    activityName: "Recents",
    description: "Recently used activities.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    author: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    subActivities: ["Create", "Delete", "Update"],
    readmeDoc: null,
  },
  {
    activityId: 2,
    activityName: "Favourites",
    description: "Favourites activities.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    author: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    subActivities: ["Create", "Delete", "Update"],
    readmeDoc: null,
  },
  {
    activityId: 3,
    activityName: "Group",
    description: "to make a group of activities to perform a certain task.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    author: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    subActivities: ["Create", "Delete", "Update"],
    readmeDoc: null,
  },
  {
    activityId: 4,
    activityName: "Browser",
    description:
      "By default, the UiPath.AbbayEmbedded.Activities pack is available for a wide range of languages. You can check the entire list by accessing the abbay Screen OCR activity page or the Abbay Document OCR,An extra bundle package available for ChinesePRC,ChineseTaiwan and Korean Hungell,but it need to be installed separately by using the manage packages button.",
    versionsList: ["1.4.2", "1.4.1", "1.4.0", "1.3.9"],
    author: "Newgen",
    dateOfUpload: "20th June 2021, 4:55pm",
    subActivities: ["Create", "Delete", "Update"],
    readmeDoc: "browser-file.pdf",
  },
];
