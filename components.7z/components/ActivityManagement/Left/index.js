import React, { useEffect } from "react";
import { Grid, ListItem, List, Typography, CircularProgress } from "@mui/material";

import makeStyles from '@mui/styles/makeStyles';

import { API_BASE_URL, ICONS } from "./../../../config/index";
import { truncateStringValues } from "../../../utils/common";
import { useTranslation } from "react-i18next";
const useStyles = makeStyles((theme) => ({
  selectedTab: {
    background: `${theme.palette.primary.light} 0% 0% no-repeat padding-box`,
    opacity: 1,
  },

  title: {
    fontWeight: 600,
    color: "#606060",
  },

  text_12: {
    fontSize: 12,
  },
  text_bold: {
    fontWeight: 700,
  },

  cursor: {
    cursor: "pointer",
  },
  margin_top_3: {
    marginTop: 3,
  },
  icons: {
    width: "16px",
    height: "16px",
  },
  scrollDiv: {
    //paddingRight: "8px",
    marginTop: "10px",
    //Height: "510px"
    height: "350px",
    overflow: "hidden",
    "&:hover": {
      overflowY: "auto",
    },
  },
  paddingItems: {
    paddingLeft: 13,
    paddingRight: 13,
  },
  selectedTabText: {
    fontWeight: 600,
  },
}));

const ActivityManagementLeft = ({
  selectedTab,
  isFetchingActivities,
  listOfActivities,
  handleSelectedActivity,
  selectedActivity,
}) => {
  useEffect(() => {
    if (!selectedActivity) {
      handleSelectedActivity(listOfActivities[0]);
    } else if (selectedActivity) {
      const index = listOfActivities.findIndex(
        (activity) => activity.groupId === selectedActivity.groupId
      );
      if (index === -1) {
        /* if (selectedTab === "Custom") {
          handleSelectedActivity(listOfActivities[0]);
        }*/
        handleSelectedActivity(listOfActivities[0]);
      }
    }
  }, [listOfActivities, selectedActivity]);
  const handleActiveTab = (item) => {
    handleSelectedActivity(item);
  };
  const classes = useStyles();
const {t}= useTranslation()
  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };
  return <>
    <div className={classes.scrollDiv}>
      <List>
        {isFetchingActivities && (
          <div
            style={{
              width: "100%",
              //height: "100%",
              textAlign: "center",
              zIndex: 1,
              verticalAlign: "center",
              marginTop: "10px",
            }}
          >
            <CircularProgress
              style={{
                alignItems: "center",
                width: "20px",
                height: "20px",
                textAlign: "center",
              }}
            />
          </div>
        )}
        {!isFetchingActivities && listOfActivities.length > 0 ? (
          listOfActivities.map((item, index) => {
            return (
              <React.Fragment key={item.groupId || index}>
                <div
                  className={
                    selectedActivity &&
                    selectedActivity.groupId === item.groupId
                      ? classes.selectedTab
                      : classes.tab
                  }
                  role="listitem"
                >
                  <ListItem
                    button
                    keyIndex={-1}
                    key={index}
                    onClick={() => handleActiveTab(item)}
                    disableGutters
                    className={classes.paddingItems}
                    id={`RPA_Activity_Mgmt_${item?.groupName}`}
                    aria-label={item?.groupName}
                  >
                    <Grid
                      container
                      direction="row"
                      justifyContent="flex-start"
                      //alignItems="center"
                      spacing={1}
                    >
                      <Grid item>
                        <img
                          src={getImage(item?.groupName)}
                          className={classes.icons}
                          alt={`${item?.groupName} Icon`}
                        />
                      </Grid>
                      <Grid item>
                        <Typography
                          style={{ overflow: "auto" }}
                          className={
                            selectedActivity &&
                            selectedActivity.groupId === item.groupId
                              ? classes.selectedTabText
                              : classes.tabText
                          }
                          title={item.groupName || ""}
                        >
                          {truncateStringValues({
                            str: item.groupName ? item.groupName : "Unknown",
                            min: 26,
                            max: 30,
                          })}
                        </Typography>
                      </Grid>
                    </Grid>
                  </ListItem>
                </div>
              </React.Fragment>
            );
          })
        ) : (
          <Typography variant="subtitle2" style={{ paddingLeft: "15px" }}>
            {t("There are not any Activities yet.")}
          </Typography>
        )}
      </List>
    </div>
  </>;
};

export default ActivityManagementLeft;
