import React, { useState, useEffect } from "react";
import { Paper, Grid, Typography, CircularProgress, Divider } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import MenuPopper from "./../../../utils/MenuPopper";
import ModalForm from "./../../../utils/modalForm";
import { useTranslation } from "react-i18next";
import { ExpandMore } from "@mui/icons-material";
import { API_BASE_URL, ICONS } from "./../../../config/index";
import { getDateAndTimeStr } from "../../../utils/common";
import LoadingButton from "../../common/Button"
const useStyles = makeStyles((theme) => ({
  root: {
    padding: "20px",
  },
  paper2: {
    boxShadow: "0px 2px 6px #00000014",
    padding: "25px 20px 20px 25px",
    marginBottom: "24px",
    //height: "530px",
    height: "450px",
    "&:hover": {
      overflowY: "auto",
    },
  },
  subActivities: {
    // height: "220px",
    overflowY: "auto",
  },
  icon: {
    width: "45px",
    height: "45px",
    /* filter:
      "brightness(0) saturate(100%) invert(0%) sepia(7%) saturate(7500%) hue-rotate(38deg) brightness(98%) contrast(108%)",
  */
  },
  text: {
    fontWeight: 600,
  },
  deprecatedText: {
    color: "#D53D3D",
    fontWeight: 600,
  },
  textLink: {
    fontWeight: 600,
    color: `${theme.palette.primary.main}`,
    cursor: "pointer",
    "& :hover": {
      textDecoration: "underline",
    },
  },
  title: {
    fontWeight: 600,
    fontSize: "16px",
  },
  heading: {
    color: "#606060",
    fontWeight: 600,
  },
}));
const ActivityManagementRight = ({
  selectedActivity,
  handleOpenModal,
  listOfActivities,
  makePublic,
  makePublicIsLoading,
}) => {
  const classes = useStyles();
  const { t } = useTranslation();
  const [selectedVersion, setSelectedVersion] = useState("1.4.2 latest");
  const [shownActivity, setShownActivity] = useState(null);
  const [openModal, setOpenModal] = useState(false);

  const [versionsList, setVersionList] = useState([]);

  const closeModal = () => {
    setOpenModal(false);
  };

  const handleSelectedVersion = (e, selVersion, clickedOnItem) => {
    setSelectedVersion(selVersion);
    const newShownActivity = listOfActivities.find(
      (act) =>
        act.groupName === selectedActivity?.groupName &&
        act.dependency === selVersion
    );
    console.log("newShownActivity", newShownActivity);
    setShownActivity(newShownActivity);
  };

  const getImage = (name) => {
    return `${API_BASE_URL}${ICONS}/${name}`;
  };
  useEffect(() => {
    if (selectedActivity && selectedActivity?.isCustomActivity) {
      setSelectedVersion(selectedActivity?.dependency + " latest" || "");
    } else {
      setSelectedVersion("1.4.2" + " latest");
    }
    setShownActivity(selectedActivity);
  }, [selectedActivity]);
  const getAllVersions = () => {
    const versions = listOfActivities
      .filter((grp) => grp.groupName === selectedActivity?.groupName)
      .map((item) => item.dependency);

    setVersionList([...versions]);
  };
  useEffect(() => {
    if (
      selectedActivity &&
      selectedActivity?.isCustomActivity &&
      listOfActivities
    ) {
      getAllVersions();
    } else {
      setVersionList(allVersions);
    }
  }, [selectedActivity, listOfActivities]);

  return !shownActivity ? (
    <div
      style={{
        width: "100%",
        height: "100%",
        textAlign: "center",
        zIndex: 1,
        verticalAlign: "center",
        marginTop: "10px",
      }}
    >
      {/*  <CircularProgress
        style={{
          alignItems: "center",
          width: "20px",
          height: "20px",
          textAlign: "center",
        }}
      />*/}
      <Typography>{t("No Selected Activity Group.")}</Typography>
    </div>
  ) : (
    <Paper className={classes.paper2}>
      <ModalForm
        id="RPA_ActivityMgmt_MakeItPublic"
        title={t("Are you sure you want to make this activity public ?")}
        containerHeight={170}
        isOpen={openModal}
        closeModal={closeModal}
        Content={
          <Typography>
            {t(
              "Making the activity as public will make it available in activity catalogue for all the users. Do you want to continue?"
            )}
          </Typography>
        }
        btn1Title={t("No")}
        onClick1={closeModal}
        headerCloseBtn={true}
        onClickHeaderCloseBtn={closeModal}
        btn2Title={t("Yes")}
        isProcessing={makePublicIsLoading}
        onClick2={() => makePublic(shownActivity.groupId, (flag) => {
          closeModal()
          setShownActivity({ ...shownActivity, isPrivate: flag })
        })}
      // onlo={makePublicIsLoading}
      />
      <Grid container direction="column" spacing={2}>
        <Grid item>
          <Grid
            container
            spacing={1}
            alignItems={!shownActivity.isCustomActivity ? "center" : null}
          >
            <Grid item>
              <img
                src={getImage(shownActivity?.groupName)}
                className={classes.icon}
                alt={`${shownActivity?.groupName} Icon`}
              />
            </Grid>
            <Grid item>
              <Grid container direction="column">
                <Grid item>
                  <Typography className={classes.title}>
                    {shownActivity?.groupName || ""}
                  </Typography>
                </Grid>
                {shownActivity.isCustomActivity && (
                  <Grid item>
                    <div
                      style={{
                        padding: "2px",
                        border: "1px solid #d5d5d5",
                        display: "flex",
                        maxWidth: "130px",
                      }}
                    >
                      <span style={{ marginRight: "8px" }}>
                        <Typography>
                          {selectedVersion && `version ${selectedVersion}`}
                        </Typography>
                      </span>
                      <span>
                        <MenuPopper
                          MenuIcon={ExpandMore}
                          handleSelectedItem={handleSelectedVersion}
                          // items={shownActivity?.versionsList || []}
                          items={versionsList}
                        />
                      </span>
                    </div>
                  </Grid>
                )}
              </Grid>
            </Grid>
            {console.log("shownActivity", shownActivity)}
            {shownActivity?.isCustomActivity && (
              <Grid item style={{ marginLeft: "auto" }}>
                <Grid container spacing={2}>
                  {shownActivity?.isPrivate === 1 && (
                    <Grid item>
                      <Typography
                        className={classes.textLink}
                        onClick={() => setOpenModal(true)}
                        //WCAG Keyboard Accessible
                        tabIndex={0}
                        onKeyPress={(e) =>
                          e.key === "Enter" && setOpenModal(true)
                        }
                        role="button"
                        id="RPA_ActivityMgmt_MakeItPublicBtn"
                      >
                        {t("Make it Public")}
                      </Typography>
                    </Grid>
                  )}
                  <Grid item>
                    <Typography
                      className={classes.textLink}
                      onClick={() => handleOpenModal("Deprecate Activity")}
                      //WCAG Keyboard Accessible : [19-06-2023] - Added tabIndex and onKeyPress event
                      tabIndex={0}
                      onKeyPress={(e) =>
                        e.key === "Enter" &&
                        handleOpenModal("Deprecate Activity")
                      }
                      role="button"
                      id="RPA_ActivityMgmt_DeprecateBtn"
                    >
                      {t("Deprecate Activity Version")}
                    </Typography>
                  </Grid>
                  <Grid item>
                    <Typography
                      className={classes.textLink}
                      onClick={() => handleOpenModal("Update Activity")}
                      //WCAG Keyboard Accessible : [19-06-2023] - Added tabIndex and onKeyPress event
                      tabIndex={0}
                      onKeyPress={(e) =>
                        e.key === "Enter" && handleOpenModal("Update Activity")
                      }
                      role="button"
                      id="RPA_ActivityMgmt_UpdateActivityBtn"
                    >
                      {t("Update This Activity")}
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
            )}
          </Grid>
        </Grid>
        {shownActivity?.isDeprecated && (
          <Grid item>
            <Typography className={classes.deprecatedText}>
              {"This version is deprecated."}
            </Typography>
          </Grid>
        )}
        <Grid item>
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography className={classes.heading}>
                {t("Description")}
              </Typography>
            </Grid>
            <Grid item xs>
              <Typography className={classes.text}>
                {shownActivity?.description || ""}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        <Grid item>
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography className={classes.heading}>Scope</Typography>
            </Grid>
            <Grid item xs>
              <Typography className={classes.text}>
                {shownActivity?.isPrivate === 0 ? "Public" : "Private"}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        <Divider />
        {shownActivity?.readmeDoc && (
          <Grid item>
            <Grid container direction="column" spacing={1}>
              <Grid item>
                <Typography className={classes.heading}>
                  {t("Read Me File")}
                </Typography>
              </Grid>
              <Grid item xs>
                <a href={shownActivity?.readmeDoc || "#"}>
                  <Typography className={classes.textLink}>
                    {shownActivity?.readmeDoc || ""}
                  </Typography>
                </a>
              </Grid>
            </Grid>
          </Grid>
        )}
        <Grid item>
          <Grid container direction="column" spacing={1}>
            <Grid item>
              <Typography className={classes.heading}>
                {t("Sub-Activities")}
              </Typography>
            </Grid>
            {shownActivity?.activities ? (
              <Grid item className={classes.subActivities} tabIndex={0}>
                {shownActivity.activities.map((item, index) => (
                  <Grid container key={index} spacing={1}>
                    <Grid item style={{ marginRight: "3px" }}>
                      <Typography className={classes.text}>
                        {index + 1}.
                      </Typography>
                    </Grid>
                    <Grid item>
                      <Typography className={classes.text}>
                        {item?.activityName || ""}
                      </Typography>
                    </Grid>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Grid item>
                <Typography>{t("There is no sub activity yet.")}</Typography>
              </Grid>
            )}
          </Grid>
        </Grid>
        <Divider />
        {shownActivity?.isCustomActivity && (
          <Grid item>
            <Grid container direction="column" spacing={1}>
              <Grid item>
                <Typography className={classes.heading}>
                  {t("Developed By")}
                </Typography>
              </Grid>
              <Grid item xs>
                <Typography className={classes.text}>
                  {shownActivity?.developedBy || "Newgen"}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        )}
        <Divider />
        {shownActivity?.isCustomActivity && (
          <Grid item>
            <Grid container direction="column" spacing={1}>
              <Grid item>
                <Typography className={classes.heading}>
                  {t("Uploaded By")}
                </Typography>
              </Grid>
              <Grid item xs>
                <Typography className={classes.text}>
                  {shownActivity?.userLoginId || "Newgen"}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        )}
        <Divider />
        {shownActivity?.isCustomActivity && (
          <Grid item>
            <Grid container direction="column" spacing={1}>
              <Grid item>
                <Typography className={classes.heading}>
                  {t("Date Of Upload")}
                </Typography>
              </Grid>
              <Grid item xs>
                <Typography className={classes.text}>
                  {getDateAndTimeStr(shownActivity?.createdOn || "")}
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        )}
      </Grid>
    </Paper >
  );
};

export default ActivityManagementRight;
const allVersions = ["1.4.2", "1.4.1", "1.4.0", "1.3.9"];
