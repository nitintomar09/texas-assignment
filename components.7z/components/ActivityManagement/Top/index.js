import React from "react";
import { useHistory } from "react-router";
import { Grid, Paper, Typography, Button } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import { useTranslation } from "react-i18next";
import { getAppDirection } from "../../common";
import { getCssRgbFromHexByDiff } from "../../../utils/HexToFilter";
import { CreatedIcon } from "../../../utils/AllImages";
const useStyles = makeStyles((theme) => ({
  root: {
    paddingLeft: "20px",
    //paddingRight: "20px",
  },
  title: {
    fontWeight: 600,
    fontSize: "16px",
  },

  focusPrimary: {
    "&:focus": {
      background: `${getCssRgbFromHexByDiff(`${theme.palette.primary.main}`)}`,
    },
  },

  btns: {
    // padding: "5px 8px 6px 8px",
    lineHeight: 1.35,
    fontSize: "12px",
    fontWeight: 600,
  },
  paper2: {
    boxShadow: "0px 2px 6px #00000014",
    height: "50px",

    padding: "12px 17px 24px 12px",
    marginTop: "13px",
    marginBottom: "24px",
  },

  scrollDiv: {
    height: "460px",
    overflow: "hidden",
    "&:hover": {
      overflowY: "auto",
    },
  },
}));
const ActivityManagementTop = ({ handleOpenModal }) => {
  const history = useHistory();
  const classes = useStyles();
  const AppDirection = getAppDirection();
  const { t } = useTranslation();
  return (
    <Paper className={classes.paper2}>
      <Grid container alignItems="center" justifyContent={"space-between"}>
        <Grid item xs>
          <Grid container direction="column" spacing={1} justifyContent="center">
            <Grid item>
              <Typography variant="h6" className={classes.title}>
                {t("Upload Custom Activity")}
              </Typography>
            </Grid>
            <Grid item>
              <Typography>{t("Add your own activity to enhance automation capabilities")}</Typography>
            </Grid>
          </Grid>
        </Grid>
        <Grid item style={{ marginLeft: "auto" }}>
          <Button
            variant="contained"
            color="primary"
            startIcon={<CreatedIcon />}
            className={classes.btns + " " + classes.focusPrimary}
            onClick={() => handleOpenModal("Upload Custom Activity")}
            disableFocusRipple
            id="RPA_ActivityMgmt_UploadCustomBtn"
          >
            {t("AddActivity")}
          </Button>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default ActivityManagementTop;
