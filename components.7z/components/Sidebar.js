import React from "react";
import { Typography, Grid, Drawer, List, ListItem } from "@mui/material";

import makeStyles from '@mui/styles/makeStyles';

import {
  ActivityManagementIcon,
  ActivityManagementEnabledIcon,
  ScriptsIcon,
  ScriptsEnabledIcon,
  HomeIcon,
  HomeEnabledIcon,
  CreateIcon,
  NewNewgenWhiteLogoIcon,
  NewScriptIcon,
  NewScriptEnableIcon
} from "../utils/AllImages";
import { getAppDirection } from "../components/common";
import { useLocation, useHistory, withRouter } from "react-router-dom";
import { UniqueIDGenerator } from "../utils/UniqueIDGenerator";
const drawerWidth = "84px";

const useStyles = makeStyles((AppTheme) => ({
  drawer: {
    flexShrink: 0,
    width: drawerWidth,
  },
  drawerPaper: {
    width: drawerWidth,
    backgroundColor: "#222222",
  },
  drawerContainer: {
    overflow: "auto",
    paddingTop: AppTheme.spacing(6),
    height: "100%",
  },
  listItemText: {
    fontSize: "10px",
    color: "#F8F8F8",
    backgroundColor: "blue",
    paddingTop: AppTheme.spacing(8),
  },
  icon: {
    color: "#FFFFFF",
  },
  scriptIcon: {
    height: "24px",
    width: "24px",
  },
  selectedTab: {
    marginBottom: "12px",
    background: "#606060 0% 0% no-repeat padding-box",

    opacity: 1,
    borderLeft: `4px solid ${AppTheme.palette.secondary.main}`,

    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      outline: "2px solid #FFFFFF",
    },
  },
  tab: {
    marginBottom: "12px",
    // borderLeft: `4px solid #222222`,

    "& :hover": {
      background: "#606060 0% 0% no-repeat padding-box",
      borderColor: "#606060",
    },
    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      background: "#606060 0% 0% no-repeat padding-box",
      outline: "2px solid #FFFFFF",
    },
  },
  icons: {
    height: "24px",
    width: "24px",
    color: "#FFFFFF",
  },
  addIcon: {
    backgroundColor: `${AppTheme.palette.secondary.main}`,
    height: "34px",
    width: "34px",
  },
  selectedTabText: {
    fontSize: "10px",
    color: "#FFFFFF",
    textAlign: "center",
    fontWeight: 600,
  },
  tabText: {
    fontSize: "10px",
    color: "#F8F8F8",
    textAlign: "center",
    fontWeight: 500,
  },
}));

const Sidebar = () => {
  const history = useHistory();
  const classes = useStyles();
  const location = useLocation();
  const AppDirection = getAppDirection();
  const options = [
    {
      name: "Home",
      icon: location.pathname === "/Dashboard" ? HomeEnabledIcon : HomeIcon,

      pageLink: "/Dashboard",
      display: ["Home"],
    },
    {
      name: "Service Flows",
      icon: location.pathname === "/serviceflows" ? NewScriptEnableIcon : NewScriptIcon,
      pageLink: "/serviceflows",

      display: ["Service Flows"],
    },
    {
      name: "Activity Management",
      icon:
        location.pathname === "/activityManagement"
          ? ActivityManagementEnabledIcon
          : ActivityManagementIcon,

      pageLink: "/activityManagement",
      display: ["Activity Manager"],
    },
  ];
  const activeTabOption = options
    .map((item, index) => {
      return { ...item, index };
    })
    .filter((item) => item.pageLink === location.pathname);
  const activeTab = activeTabOption.length === 0 ? 0 : activeTabOption[0].index;

  const handleClick = (page) => {
    history.push(page.pageLink);
  };
  return (
    <Drawer
      variant="permanent"
      anchor={AppDirection === "ltr" ? "left" : "right"}
      className={classes.drawer}
      classes={{ paper: classes.drawerPaper }}
      role="navigation"
    >
      <div className={classes.drawerContainer}>
        <List role="tablist">
          {options.map((item, index) => {
            return (
              <div
                className={
                  activeTab === index ? classes.selectedTab : classes.tab
                }
                key={index}
                //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
                tabIndex={0}
                onKeyPress={(e) => e.key === "Enter" && handleClick(item)}
                role="tab"
                aria-selected={activeTab === index}
                id={`Navigation_${item.name}`}
              >
                <ListItem
                  button
                  tabIndex={-1}
                  onClick={() => handleClick(item)}
                  id={`Navigation_button_${item.name}`}
                >
                  <Grid
                    container
                    //  justify="center"
                    alignItems="center"
                    direction="column"
                  >
                    <Grid item>
                      {item.name === "Script" ? (
                        /*
                       <Avatar variant="circular" className={classes.addIcon}>
                          <AddIcon
                            style={{
                              height: "28px",
                              width: "28px",
                              color: "white",
                            }}
                          />
                          </Avatar>*/
                        <UniqueIDGenerator>
                          <CreateIcon
                            style={{
                              height: "28px",
                              width: "28px",
                              color: "white",
                            }}
                          />
                        </UniqueIDGenerator>
                      ) : (
                        <UniqueIDGenerator>
                          <item.icon
                            style={{
                              height: "24px",
                              width: "24px",
                            }}
                          />
                        </UniqueIDGenerator>
                      )}
                    </Grid>

                    {item.display.map((name) => {
                      return (
                        <Grid
                          container
                          justifyContent="center"
                          alignItems="center"
                          key={name}
                        >
                          <Grid item>
                            <Typography
                              className={
                                activeTab === index
                                  ? classes.selectedTabText
                                  : classes.tabText
                              }
                            >
                              {name}
                            </Typography>
                          </Grid>
                        </Grid>
                      );
                    })}
                  </Grid>
                </ListItem>
              </div>
            );
          })}
        </List>
      </div>
      <Grid container  alignItems="center"
          direction="column"
          style={{ marginTop: "auto" }}>
        <Grid item>
          <Typography
            style={{ fontSize: "10px", color: "#C4C4C4", opacity: 1 }}
          >
            Powered by:
          </Typography>
        </Grid>
        <Grid item>
          <NewNewgenWhiteLogoIcon
            style={{ height: "15px", width: "59px", opacity: 1 }}
          />
        </Grid>
      </Grid>
    </Drawer>
  );
};
export default withRouter(Sidebar);
