import { createTheme, adaptV4Theme } from "@mui/material/styles";
const orange = "#FF6600";
const orange2 = "#FD6620";
const dark = "#222222";
const blue = "#0072C6";
const lightblue = "#E5F1F9";
const blue2 = "#57A5DE";
const dodgerBlue = "#19B5FE";
//const lightSkyBlue = "#0072C614";
const lightSkyBlue = "#E5F1F9";
const tabFocusColor = "#00477A";

const _theme = {

  overrides: {
    MuiOutlinedInput: {
      input: {
        padding: "6.5px 6px",
        height: "28px",
      },
      multiline: {
        padding: "6.5px 6px",
      },
      root: {
        borderRadius: 2,
        border: `0px solid #C4C4C4`,
        "&$focused": {
          outline: `2px solid ${tabFocusColor}`,
        },

      },
      adornedStart: {
        paddingLeft: "9px",
      },

      /*   marginDense: {
        padding: "6.5px 6px",
      },*/
    },
    MuiIconButton: {
      root: {
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
        },
      },
    },
    MuiTabs: {
      root: {
        minHeight: '32px',
      },
      indicator: {
        height: '2px',    // Customize the height of the indicator
      },
    },
    MuiTab: {
      root: {
        minHeight: '32px',
        maxHeight: '48px'
        /* "&:focus-visible": {
           border: `2px solid ${tabFocusColor}`,
         },*/
      },

    },
    MuiSelect: {
      select: {
        "&:focus": {
          backgroundColor: "transparent",
        },
        color: "#000000",
      },
      selectMenu: {
        paddingLeft: "10px",
        alignItems: "center",
      },
    },
    MuiButton: {
      root: {
        "&$disabled": {
          pointerEvents: "none",
          cursor: "default",
          //backgroundColor: "transparent",
          opacity: 0.9,
          //color: "#000000",
          backgroundColor: "#B2D5EE",
          color: "#FFFFFF"
        },
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
        },
        minWidth: 35,
        minHeight: 28,
        padding: "5px 8px 6px 8px",
        borderRadius: 2,
        //fontSize: 12,
        containedPrimary: {
          backgroundColor: blue,

          '&$disabled': {
            backgroundColor: "#B2D5EE",
            opacity: 0.5,
            color: "#ffffff",
          },
        }
      },
      sizeSmall: {
        fontSize: 12,
        fontWeight: 600,
      },
      label: { fontWeight: 600 },

    },
    MuiGrid: {
      root: {
        outline: "none",
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
          borderRadius: "2px",
        },
      },
    },
    MuiCheckbox: {
      colorSecondary: {
        "&.Mui-focusVisible": {
          color: `${tabFocusColor}`,
          "& span": {
            outline: `2px solid ${tabFocusColor}`,
            borderRadius: "2px",
          },
        },
      },
    },
    MuiTypography: {
      root: {
        outline: "none",
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
          borderRadius: "2px",
        },
      },
    },
    MuiPaper: {
      root: {
        outline: "none",
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
          //borderRadius: "2px",
        },
      },
    },
    MuiBadge: {
      root: {
        outline: "none",
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
          borderRadius: "2px",
        },
      },
    },
    MuiMenuItem: {
      root: {
        outline: "none",
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
          //borderRadius: "2px",
        },
      },
    },
    MuiListItem: {
      root: {
        outline: "none",
        "&:focus-visible": {
          outline: `2px solid ${tabFocusColor}`,
          //borderRadius: "2px",
        },
      },
    },
  },
  palette: {
    common: {
      dark: `${dark}`,
      orange: `${orange2}`,
      blue: `${blue}`,
    },
    primary: {
      main: `${blue}`,
      light: `${lightSkyBlue}`,
      secondary: `${lightblue}`,
    },
    secondary: {
      main: `${orange2}`,
    },
    tabFocus: {
      mainColor: `${tabFocusColor}`,
    },
  },
  typography: {
    button: {
      textTransform: "none",
      fontSize: 12,
    },
    lineHeight: 17,
    fontSize: 10,
    fontWeightRegular: 500,
    htmlFontSize: 15,
    fontFamily: ["Open Sans", "sans-serif"].join(","),
  },
  shadows: ["none"],
};

const theme = createTheme(adaptV4Theme({ direction: "rtl", ..._theme }));
export default theme;
export const ThemeRTL = createTheme(adaptV4Theme({ direction: "rtl", ..._theme }));
export const ThemeLTR = createTheme(adaptV4Theme({ direction: "ltr", ..._theme }));
