// // import React, { useState } from 'react';
// // import { Autocomplete, TextField, InputAdornment, IconButton } from '@mui/material';
// // import CreateNewFolderIcon from '@mui/icons-material/CreateNewFolder';

// // const options = ['PAN Creation', 'PAN Check']; // Replace with your dynamic data

// // export default function CustomDropdown() {
// //   const [inputValue, setInputValue] = useState('');

// //   const handleCreateFolder = () => {
// //     console.log(`Creating folder: ${inputValue}`);
// //     // Add your folder creation logic here
// //   };

// //   return (
// //     <Autocomplete
// //       options={options}
// //       freeSolo
// //       inputValue={inputValue}
// //       onInputChange={(event, newInputValue) => {
// //         setInputValue(newInputValue);
// //       }}
// //       renderInput={(params) => (
// //         <TextField
// //           {...params}
// //           label="Folder"
// //           variant="outlined"
// //           InputProps={{
// //             ...params.InputProps,
// //             endAdornment: (
// //               <>
// //                 {inputValue && !options.includes(inputValue) && (
// //                   <InputAdornment position="end">
// //                     <IconButton onClick={handleCreateFolder} edge="end">
// //                       <CreateNewFolderIcon />
// //                     </IconButton>
// //                   </InputAdornment>
// //                 )}
// //                 {params.InputProps.endAdornment}
// //               </>
// //             ),
// //           }}
// //         />
// //       )}
// //     />
// //   );
// // }
// import React, { useState } from 'react';
// import { Autocomplete, TextField, InputAdornment, IconButton } from '@mui/material';
// import CreateNewFolderIcon from '@mui/icons-material/CreateNewFolder';
// import makeStyles from '@mui/styles/makeStyles';

// const useStyles = makeStyles((theme) => ({
//     input: {
//         height: (props) => props.height || 28,
//         backgroundColor: '#FFFFFF',
//         fontSize: (props) => props.fontSize || 12,
//     },
//     notchedOutline: {
//         borderWidth: '1px',
//         borderColor: '#d5e5d6 !important',
//     },
//     label: {
//         fontSize: 12,
//         color: '#606060',
//         opacity: 1,
//         fontWeight: 600,
//         marginBottom: '4px',
//     },
//     icon: {
//         height: '16px',
//         width: '16px',
//         marginRight: '5px',
//     },
//     labelText: {
//         fontSize: 12,
//         color: '#606060',
//         opacity: 1,
//         fontWeight: 500,
//         marginBottom: '8px',
//     },
// }));

// const CustomDropdown = (props) => {
//     const [inputValue, setInputValue] = useState('');
//     const classes = useStyles({ height: props.height });
//     const options = [
//         { name: 'PAN Creation', value: 'creation' },
//         { name: 'PAN Check', value: 'check' },
//     ];
//     const handleCreateFolder = () => {
//         console.log(`Creating folder: ${inputValue}`);
//         // Add your folder creation logic here
//     };

//     return (
//         <div style={{marginBottom:props.marginBottom||""}}>
//             <label htmlFor='' className={classes.labelText}>
//                 {props.label}
//             </label>
//             <Autocomplete
//                 id={`${props.label + '_autocomplete'}`}
//                 options={props.options || options}
//                 freeSolo
//                 getOptionLabel={(option) => option.name}
//                 inputValue={inputValue}
//                 onInputChange={(event, newInputValue) => {
//                     setInputValue(newInputValue);
//                 }}
//                 renderInput={(params) => (
//                     <TextField
//                         {...params}
//                         // label="Folder"
//                         variant="outlined"
//                         /*   InputLabelProps={{
//                                className: classes.label,
//                            }}*/
//                         InputProps={{
//                             ...params.InputProps,
//                             className: classes.input,
//                             classes: {
//                                 notchedOutline: classes.notchedOutline,
//                             },
//                             endAdornment: (
//                                 <>
//                                     {inputValue && !(props.options || options).some(option => option.name === inputValue) && (
//                                         <InputAdornment position="end">
//                                             <IconButton onClick={handleCreateFolder} edge="end">
//                                                 <CreateNewFolderIcon className={classes.icon} />
//                                             </IconButton>
//                                         </InputAdornment>
//                                     )}
//                                     {params.InputProps.endAdornment}
//                                 </>
//                             ),
//                         }}
//                     />
//                 )}
//             />
//         </div>
//     );
// };

// export default CustomDropdown;

import React, { useState, useEffect } from 'react';
import { Autocomplete, TextField, InputAdornment, IconButton, Paper, Typography } from '@mui/material';
import CreateNewFolderIcon from '@mui/icons-material/CreateNewFolder';
import makeStyles from '@mui/styles/makeStyles';
import { AddFolderIcon } from '../AllImages';

const useStyles = makeStyles((theme) => ({
    input: {
        height: (props) => props.height || 28,
        backgroundColor: '#FFFFFF',
        fontSize: (props) => props.fontSize || 12,
    },
    notchedOutline: {
        borderWidth: '1px',
        borderColor: '#d5e5d6 !important',
    },
    label: {
        fontSize: 12,
        color: '#606060',
        opacity: 1,
        fontWeight: 600,
        marginBottom: '4px',
    },
    icon: {
        height: '14px',
        width: '14px',
        // marginRight: '5px',
    },
    //Bug 155341 - UI issues on the create a serviceflow window
    //Author: dixita.ruhela
    //Date: 08 JAN 2024
    //Description: Class defined for lsit view Font Size
    listbox: {
        fontSize: "12px", // Adjust the font size of the list options
        "& li": {
          fontSize: "12px", // Ensure the `li` elements also inherit the font size
        },
      },
    labelText: {
        fontSize: 12,
        color: '#606060',
        opacity: 1,
        fontWeight: 600,
        marginBottom: '4px',
    },
    paper: {
        boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)',  // Add shadow to dropdown
    },
}));

const CustomDropdown = (props) => {
    const [inputValue, setInputValue] = useState('');
    const classes = useStyles({ height: props.height });

    const options = [
        { name: 'PAN Creation', value: 'creation' },
        { name: 'PAN Check', value: 'check' },
    ];

    useEffect(() => {
        const selectedOption = (props.options || options).find(option => option.value === props.value)
        if (selectedOption) {
            setInputValue(selectedOption.name)
        }
    }, [props.value])

    const handleCreateFolder = () => {
        console.log(`Creating folder: ${inputValue}`);
        if (props.handleCreateNewFolder) {
            props.handleCreateNewFolder(inputValue)
        }

    };


    return (
        <>
            <Typography className={classes.labelText}>
                {props.label}
            </Typography>
            <Autocomplete
                id={`${props.label + '_autocomplete'}`}
                options={props.options || options}
                freeSolo
                getOptionLabel={(option) => option.name}
                inputValue={inputValue}
                onInputChange={(event, newInputValue) => {
                    setInputValue(newInputValue);
                    if (props.onChange) {
                        /* if (inputValue && (props.options || options).some(option => option.name === inputValue)) {
                             props.onChange({ target: { name: props.name, value: newInputValue } })
                         }*/
                        const selectedOption = (props.options || options).find(option => option.name === newInputValue);
                        if (selectedOption) {
                            props.onChange({ target: { name: props.name, value: selectedOption.value } });
                        }
                    }
                }}
                PaperComponent={(props) => <Paper {...props} className={classes.paper} />}
                classes={{
                    listbox: classes.listbox,
                  }}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        variant="outlined"
                        InputProps={{
                            ...params.InputProps,
                            className: classes.input,
                            classes: {
                                notchedOutline: classes.notchedOutline,
                            },
                            endAdornment: (
                                <>
                                    {inputValue && !(props.options || options).some(option => option.name === inputValue) && (
                                        <InputAdornment position="end" onClick={handleCreateFolder} style={{ cursor: 'pointer' }}>
                                            <IconButton edge="end">
                                                <AddFolderIcon className={classes.icon} />
                                            </IconButton>
                                            <Typography style={{ marginInlineStart: '8px', fontWeight: 500, fontSize: '12px', color: '#0072C6' }}>Create Folder</Typography>
                                        </InputAdornment>
                                    )}
                                    {params.InputProps.endAdornment}
                                </>
                            ),
                        }}
                        helperText={props.helperText}
                        error={props.error}
                    />
                )}
            />
        </>
    );
};

export default CustomDropdown;

