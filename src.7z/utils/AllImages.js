import {
  Clear,
  SkipNext,
  Add,
  InsertDriveFileOutlined,
  Brightness1,
} from "@mui/icons-material";
import SearchIcon from "@mui/icons-material/Search";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import CachedIcon from "@mui/icons-material/Cached";
import LaunchIcon from "@mui/icons-material/Launch";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import GetAppSharpIcon from "@mui/icons-material/GetAppSharp";
import PrintOutlinedIcon from "@mui/icons-material/PrintOutlined";
import VerticalAlignBottomIcon from "@mui/icons-material/VerticalAlignBottom";
import FilterListIcon from "@mui/icons-material/FilterList";
import Filter1Icon from "@mui/icons-material/Filter1";
import BarChartIcon from "@mui/icons-material/BarChart";
import DehazeIcon from "@mui/icons-material/Dehaze";
import CancelIcon from "@mui/icons-material/Cancel";
import AccountTreeIcon from "@mui/icons-material/AccountTree";
import DragIndicatorIcon from "@mui/icons-material/DragIndicator";
import CloseIcon from "@mui/icons-material/Close";
import CheckBoxOutlineBlankIcon from "@mui/icons-material/CheckBoxOutlineBlank";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import CheckIcon from "@mui/icons-material/Check";
import SyncAltIcon from "@mui/icons-material/SyncAlt";
import FormatAlignJustifyIcon from "@mui/icons-material/FormatAlignJustify";
import FormatAlignLeftIcon from "@mui/icons-material/FormatAlignLeft";
import FormatAlignRightIcon from "@mui/icons-material/FormatAlignRight";
import Language from "@mui/icons-material/Language";
import Settings from "@mui/icons-material/Settings";
import { CircularProgress, IconButton } from "@mui/material";
import ConnectorsIcon1 from "../assets/images/Connectors.svg";
import ScriptsIcon1 from "../assets/icons/Scripts.svg";
import ReportGoodIcon from "../assets/images/report_good.svg";
import ReportAverageIcon from "../assets/images/report_average.svg";
import ReportCriticalIcon from "../assets/images/report_critical.svg";
import NewgenLogo from "../assets/img/newgenlogo11.svg";
import PublishScript from "../assets/icons/Published Script.svg";
//import NewgenLogoIcon from "../assets/images/NewgenLogoSvg.svg";
import NewgenLogoIcon from "../assets/icons/RPAHeaderLogo.svg";
import NewNewgenWhiteLogo from "../assets/icons/NewgenLogoWhiteSvg.svg";
import NewgenOneLogo from "../assets/icons/NewgenOneLogo.svg";
import ExpandIcon from "../assets/icons/expandIcon.svg";
import LineIcon from "../assets/icons/lineIcons.svg";
//import MDMDataObject from "../assets/icons/Data-Object.svg";


//export { ReactComponent as NewgenLogoIcon } from "../assets/images/NewgenLogoSvg.svg";

const components = {
  SearchIcon: SearchIcon,
  AddIcon: AddIcon,
  EditIcon: EditIcon,
  DeleteIcon: DeleteIcon,
  LaunchIcon: LaunchIcon,
  CachedIcon: CachedIcon,
  ArrowBackIosIcon: ArrowBackIosIcon,
  ArrowForwardIosIcon: ArrowForwardIosIcon,
  MoreVertIcon: MoreVertIcon,
  ExpandMoreIcon: ExpandMoreIcon,
  LockOutlinedIcon: LockOutlinedIcon,
  GetAppSharpIcon: GetAppSharpIcon,
  PrintOutlinedIcon: PrintOutlinedIcon,
  VerticalAlignBottomIcon: VerticalAlignBottomIcon,
  FilterListIcon: FilterListIcon,
  Filter1Icon: Filter1Icon,
  BarChartIcon: BarChartIcon,
  DehazeIcon: DehazeIcon,
  CancelIcon: CancelIcon,
  AccountTreeIcon: AccountTreeIcon,
  DragIndicatorIcon: DragIndicatorIcon,
  CheckBoxIcon: CheckBoxIcon,
  CheckBoxOutlineBlankIcon: CheckBoxOutlineBlankIcon,
  CheckIcon: CheckIcon,
  FormatAlignJustifyIcon: FormatAlignJustifyIcon,
  FormatAlignLeftIcon: FormatAlignLeftIcon,
  FormatAlignRightIcon: FormatAlignRightIcon,
  SyncAltIcon: SyncAltIcon,
  Language: Language,
  Settings: Settings,
  CloseIcon: CloseIcon,
};

export { ReactComponent as DashboardIcon } from "../assets/images/Dashboard.svg";
export { ReactComponent as AddEmptyGroupIcon } from "./../assets/images/add empty Group.svg";
export { ReactComponent as AddProjectIcon } from "../assets/images/Add Project.svg";
export { ReactComponent as ImportIcon } from "../assets/images/Import.svg";
export { ReactComponent as UnsharedProjectIcon } from "../assets/images/Unshared Project MyProjects.svg";
export { ReactComponent as CalenderIcon } from "../assets/images/calender.svg";
export { ReactComponent as PartiallySharedProjectIcon } from "../assets/images/Partially shared project MyProjects.svg";
export { ReactComponent as SharedProjectIcon } from "../assets/images/Shared Project MyProjects.svg";

export { ReactComponent as ListViewIcon } from "../assets/icons/RPA_Listview.svg";

export { ReactComponent as TileViewIcon } from "../assets/icons/RPA_TileView.svg";

//export { ReactComponent as PinIcon } from "../assets/images/PinIcon1.svg";
export { ReactComponent as PinIcon } from "../assets/images/PinnedIcon.svg";

//Login screen icons
export { ReactComponent as Login_Username } from "./../assets/icons/Login_Username.svg";
export { ReactComponent as Login_Password } from "./../assets/icons/Login_Password.svg";
export { ReactComponent as Login_Show } from "./../assets/icons/Login_Show.svg";
export { ReactComponent as Login_Hide } from "./../assets/icons/Login_Hide.svg";
//sidebar
export { ReactComponent as HomeIcon } from "./../assets/icons/Home.svg";
export { ReactComponent as HomeEnabledIcon } from "./../assets/icons/Home Enabled.svg";
//export { ReactComponent as HomeEnabledIcon } from "./../assets/icons/HomePresentation.svg";
export { ReactComponent as CreateIcon } from "./../assets/icons/Create.svg";

export { ReactComponent as ScriptStoreIcon } from "./../assets/icons/ScriptStore.svg";
export { ReactComponent as ScriptStoreEnabledIcon } from "./../assets/icons/ScriptStoreEnabled.svg";
export { ReactComponent as ActivityManagementIcon } from "./../assets/icons/Activity Management.svg";
export { ReactComponent as ActivityManagementEnabledIcon } from "./../assets/icons/Activity Management Enabled.svg";
export { ReactComponent as ScriptsEnabledIcon } from "../assets/icons/Script Enabled.svg";
export { ReactComponent as ScriptsIcon } from "../assets/icons/Script.svg";
export { ReactComponent as ScriptIcon } from "../assets/icons/ServiceFlowRecent.svg";
export { ReactComponent as DocIcon } from "../assets/icons/ServiceFlowRecent.svg";

export { ReactComponent as HorizontleMore } from "../assets/images/HorMore.svg";
//export { ReactComponent as AddBreakpointIcon } from "../assets/icons/Breakpoint.svg";
export { ReactComponent as AddBreakpointIcon } from "../assets/icons/BreakpointNew.svg";
export { ReactComponent as BotIcon } from "../assets/icons/Bot.svg";
export { ReactComponent as UploadIcon } from "../assets/images/UploadIcon.svg";
export { ReactComponent as CrossPathIcon } from "../assets/images/CrossPathIcon.svg";
// export { ReactComponent as WebRec } from "../assets/icons/Web Recorder.svg";
// export { ReactComponent as WindowsRec } from "../assets/icons/Window Recorder.svg";
//export { ReactComponent as VariableIcon } from "../assets/icons/Variable.svg";

// export { ReactComponent as CommitIcon } from "../assets/icons/Commit.svg";
// export { ReactComponent as DebugIcon } from "../assets/icons/debug.svg";
// export { ReactComponent as SaveIcon } from "../assets/icons/Save.svg";
// export { ReactComponent as OutputIcon } from "../assets/icons/Output.svg";
// export { ReactComponent as RunScriptIcon } from "../assets/icons/Play.svg";
// export { ReactComponent as PauseIcon } from "../assets/icons/Pause.svg";
export { ReactComponent as CommitIcon } from "../assets/icons/CommitNew.svg";
export { ReactComponent as DebugIcon } from "../assets/icons/DebugNew.svg";
export { ReactComponent as SaveIcon } from "../assets/icons/SaveNew.svg";
export { ReactComponent as OutputIcon } from "../assets/icons/OutputNew.svg";
export { ReactComponent as RunScriptIcon } from "../assets/icons/RunScriptNew.svg";
export { ReactComponent as PauseIcon } from "../assets/icons/Pause.svg";
export { ReactComponent as VariableIcon } from "../assets/icons/VariablesNew.svg";

export { ReactComponent as PasteIcon } from "../assets/icons/Paste.svg";
export { ReactComponent as CutIcon } from "../assets/icons/Cut.svg";
export { ReactComponent as CopyIcon } from "../assets/icons/Copy.svg";
export { ReactComponent as DeleteIcon } from "../assets/icons/Delete.svg";
export { ReactComponent as RedoIcon } from "../assets/icons/Redo.svg";
export { ReactComponent as UndoIcon } from "../assets/icons/Undo.svg";
export { ReactComponent as StopDebugIcon } from "../assets/icons/Red record.svg";

export { ReactComponent as MoreIcon } from "../assets/icons/More.svg";
export { ReactComponent as MoreVerticalIcon } from "../assets/icons/more-vertical.svg";

export { ReactComponent as MenuIcon } from "../assets/icons/Hamburger.svg";

//property window icons
export { ReactComponent as InputTypeTextIcon } from "../assets/icons/InputTypeText.svg";
export { ReactComponent as InputTypeDropdownIcon } from "../assets/icons/InputTypeDropdown.svg";
//export { ReactComponent as ErrorIcon } from "../assets/icons/Error.svg";
//export { ReactComponent as InputIcon } from "../assets/icons/NewInput.svg";

//export { ReactComponent as PropOutputIcon } from "../assets/icons/NewOutput.svg";
export { ReactComponent as InputIcon } from "../assets/icons/NewInputMicroflow.svg";

export { ReactComponent as PropOutputIcon } from "../assets/icons/NewOutputMicroflow.svg";
export { ReactComponent as ErrorHandlingIcon } from "../assets/icons/Error Handling1.svg";
export { ReactComponent as SetActivityVersionIcon } from "../assets/icons/Error Handling2.svg";

//output window icons
export { ReactComponent as ErrorIcon } from "../assets/icons/Error.svg";
export { ReactComponent as InformationIcon } from "../assets/icons/Information.svg";
export { ReactComponent as InformationIcon1 } from "../assets/icons/Info.svg";

export { ReactComponent as WarningIcon } from "../assets/icons/Warning.svg";
export { ReactComponent as WarningIcon1 } from "../assets/icons/Warning1.svg";

//variable modal icons
export { ReactComponent as CloseIcon } from "../assets/icons/Close.svg";
export { ReactComponent as FilterIcon } from "../assets/icons/VarFilter.svg";
export { ReactComponent as ForwardTailRightIcon } from "../assets/icons/ForwardTailRight.svg";
export { ReactComponent as ExpandDataIcon } from "../assets/icons/ExpandData.svg";

//design area icons
export { ReactComponent as DropdownIcon } from "../assets/icons/Dropdown.svg";

export { ReactComponent as ActivityIcon } from "../assets/icons/Activity.svg";
export { ReactComponent as WindowsPropertiesExpandIcon } from "../assets/icons/WindowsPropertiesExpand.svg";
export { ReactComponent as WindowsPropertiesCollapseIcon } from "../assets/icons/WindowsPropertiesCollapse.svg";

export { ReactComponent as HelpIcon } from "../assets/icons/Help.svg";
export { ReactComponent as NotificationIcon } from "../assets/icons/Notification.svg";
export { ReactComponent as EditIcon } from "../assets/icons/Edit1.svg";
export { ReactComponent as FolderIcon } from "../assets/icons/Folder.svg";
export { ReactComponent as FolderBrowseIcon } from "../assets/icons/FolderOnBlue.svg";

export { ReactComponent as ShareIcon } from "../assets/icons/Share.svg";
//export { ReactComponent as DocIcon } from "../assets/icons/Doc1.svg";
export { ReactComponent as PublishIcon } from "../assets/icons/PublishNew.svg";
export { ReactComponent as AddVariableIcon } from "./../assets/icons/VariableAdd.svg";
export { ReactComponent as IconShare } from "../assets/icons/SharedIcon.svg";

export { ReactComponent as ProfileIcon } from "../assets/icons/Profile.svg";
export { ReactComponent as LogoutIcon } from "../assets/icons/Logout.svg";
//export { ReactComponent as PublishScriptIcon } from "../assets/icons/Published Script.svg";
export { ReactComponent as FolderFilledIcon } from "../assets/icons/Folder Filled.svg";
export { ReactComponent as LaptopIcon } from "../assets/icons/Laptop.svg";
export { ReactComponent as SortingAtoZIcon } from "../assets/icons/Sorting.svg";
export { ReactComponent as SortingZtoAIcon } from "../assets/icons/SortingZtoA.svg";
export { ReactComponent as IconExpanded } from "../assets/icons/iconExpanded.svg";
export { ReactComponent as DeleteAction } from "../assets/icons/DeleteAction.svg";
export { ReactComponent as DropDownVariableOption } from "../assets/icons/DropDownVLM.svg"
export { ReactComponent as ActionsMenu } from "../assets/icons/ActionsMenuVLM.svg"
export { ReactComponent as IconCollapsed } from "../assets/icons/iconCollapsed.svg";
export { ReactComponent as IllustrationIcon } from "../assets/icons/Illustration.svg";
export { ReactComponent as BotsIcon } from "../assets/icons/Bots.svg";
export { ReactComponent as DownloadBotIcon } from "../assets/icons/DownloadBot.svg";
export { ReactComponent as RPADESIGNERLOGINIcon } from "../assets/icons/RPA_Script_Designer.svg";
export { ReactComponent as ClearIcon } from "../assets/icons/NewClear.svg";
export { ReactComponent as AddNewVariableIcon } from "../assets/icons/AddVariable.svg";
export { ReactComponent as MainScript } from "../assets/icons/MainScriptNew.svg";
export { ReactComponent as FlowChart } from "../assets/icons/FlowChartNew.svg";
export { ReactComponent as DragIndicator } from "../assets/images/dragIndicator.svg";
export { ReactComponent as PrintOutput } from "../assets/icons/PrintOutput.svg";
export { ReactComponent as AssignmentIcon } from "../assets/icons/Assignment.svg";
export { ReactComponent as RepeatIcon } from "../assets/icons/Repeat.svg";
export { ReactComponent as ExcelIcon } from "../assets/icons/excelIcon.svg";
export { ReactComponent as CSVIcon } from "../assets/icons/CSVIcon.svg";
export { ReactComponent as DateTimeIcon } from "../assets/icons/DateTimeIcon.svg";
export { ReactComponent as ErrorHandleIcon } from "../assets/icons/ErrorHandlingIcon.svg";
export { ReactComponent as DataBaseIcon } from "../assets/icons/DataBaseActivityIcon.svg";
export { ReactComponent as CollapseIcon } from "../assets/icons/Collapse.svg";
export { ReactComponent as ExpandNewIcon } from "../assets/icons/ExpandNew.svg";
export { ReactComponent as ConditionIcon } from "../assets/icons/Condition.svg";
export { ReactComponent as WebServiceIcon } from "../assets/icons/WebService.svg";
export { ReactComponent as PathIcon } from "../assets/icons/PathIcon.svg";
export { ReactComponent as URLIcon } from "../assets/icons/URLIcon.svg";
export { ReactComponent as MailIcon } from "../assets/icons/MailIcon.svg";
export { ReactComponent as StringIcon } from "../assets/icons/StringIcon.svg";
export { ReactComponent as NewgenOneIcon } from "../assets/icons/NewgenOne.svg";
export { ReactComponent as DataObjectIcon } from "../assets/icons/Data Object.svg";
export { ReactComponent as FTPIcon } from "../assets/icons/FtpIcon.svg";
export { ReactComponent as PopoutIcon } from "../assets/icons/Popout.svg";
export { ReactComponent as AddFolderIcon } from "../assets/icons/Add-Folder.svg";
export { ReactComponent as CodeBlockIcon } from "../assets/icons/codeBlock.svg";
export { ReactComponent as CopyToClipboardIcon } from "../assets/icons/CopyToClipboard.svg";
export { ReactComponent as GroupIcon } from "../assets/icons/GroupIcon.svg";
export { ReactComponent as SFEmptyIcon } from "../assets/icons/SFEmptyIcon.svg";
export { ReactComponent as NewScriptIcon } from "../assets/icons/NewScriptIcons.svg";

export { ReactComponent as ActCollapseIcon } from "../assets/icons/panelcollapse.svg"
export { ReactComponent as ActExpandIcon } from "../assets/icons/panelexpand.svg"

export { ReactComponent as TileScriptIcon } from "../assets/icons/Pinned service flow icon.svg"
export { ReactComponent as NewScriptEnableIcon } from "../assets/icons/NewScriptEnableIcon.svg";
export { ReactComponent as UnPinIcon } from "../assets/icons/PD_Pinned_Enabled.svg";
export { ReactComponent as RenameIcon } from "../assets/icons/RenameIcon.svg";
export { ReactComponent as IconDelete } from "../assets/icons/DeleteIcon.svg";
export { ReactComponent as CreatedIcon } from "../assets/icons/CreateIcon.svg";
export { ReactComponent as ImportedIcon } from "../assets/icons/ImportIcon.svg";
export { ReactComponent as HorizontalIcon } from "../assets/icons/HorizontalIcon.svg";
export { ReactComponent as OpenIcon } from "../assets/icons/OpenIcon.svg";
export { ReactComponent as PreviousVersionIcon } from "../assets/icons/PreviousVersion.svg";
export { ReactComponent as HistoryIcon } from "../assets/icons/HistoryIcon.svg";
export { ReactComponent as ExportIcon } from "../assets/icons/ExportIcon.svg";
export { ReactComponent as MoveIcon } from "../assets/icons/MoveIcon.svg";
export { ReactComponent as ChartIcon } from "../assets/icons/ChartIcon.svg";
export { ReactComponent as EndPointIcon } from "../assets/icons/EndPoint.svg";
export { ReactComponent as PinnedIcon } from "../assets/icons/PinnedIcon.svg";
export { ReactComponent as MDMDataObject } from "../assets/icons/Data-Object.svg";
export { ReactComponent as AddVaribaleIcon } from "../assets/icons/Add-Variable.svg";
export { ReactComponent as PublishedDotIcon } from "../assets/icons/PublishedDot.svg";
export { ReactComponent as SessionIcon } from "../assets/images/Session.svg";
export { ReactComponent as NoVariableIcon } from "../assets/icons/NoVariablesAdded.svg";
export { ReactComponent as NoVariableFoundIcon } from "../assets/icons/NoVariablesFound.svg";
export { ReactComponent as DropDownArrowIcon } from "../assets/icons/DropdownArrow.svg";

//ToastIcons
export {ReactComponent as ToastSuccessIcon} from "../assets/icons/ToastSuccessIcon.svg";
export {ReactComponent as ToastErrorIcon} from "../assets/icons/ToastErrorIcon.svg";
export {ReactComponent as ToastWarningIcon} from "../assets/icons/ToastWarningIcon.svg";
export {ReactComponent as ToastInfoIcon} from "../assets/icons/ToastInfoIcon.svg";
export {ReactComponent as SuccessCross} from "../assets/icons/SuccessCrossIcon.svg";
export {ReactComponent as ErrorCross} from "../assets/icons/ErrorCrossIcon.svg";
export {ReactComponent as WarningCross} from "../assets/icons/WarningCrossIcon.svg";
export {ReactComponent as InfoCross} from "../assets/icons/InfoCrossIcon.svg";
export {ReactComponent as InfoIcon} from "../assets/icons/InfoIconPropertyPanel.svg";
export {ReactComponent as FileIcon2} from "../assets/icons/FileIcon2.svg";
export {ReactComponent as UploadIcon2} from "../assets/icons/UploadIcon2.svg";
/**
     * @author sanya.mahajan For Bug 156086 - UX Home screen table not according to NODS
     * Reason:Added to update the icon in Dashboard as per NODS
     * Date : 28/01/2025             
     * */
export {ReactComponent as ChevronIcon} from "../assets/icons/ChevronIcon.svg";
export {ReactComponent as HoverPinIcon} from "../assets/icons/PinIcon.svg";
export {ReactComponent as SFIcon} from "../assets/icons/ServiceFlowIconTopBar.svg";
/**
     * @author sanya.mahajan For Bug 155812 - UX Shared folder icon change
     * Reason:New icon to be updated as per the design
     * Date : 03/02/2025             
     * */
export {ReactComponent as SharedFolderIcon} from "../assets/icons/SharedFolder.svg";
const icon = {
  width: "16px",
  height: "16px",
};
export const ConnectorsIcon = () => {
  return <img src={ConnectorsIcon1} className={icon} alt="Connector Icon" />;
};

export {
  Clear as DiscardChangesIcon,
  SkipNext as StepByStepIcon,
  Add as AddIcon,
  ScriptsIcon1 as Script1,
  PublishScript as PublishScriptIcon,
  CircularProgress,
  InsertDriveFileOutlined as FileIcon,
  Brightness1 as StatusIcon,
  NewgenLogo,
  NewgenLogoIcon,
  ReportAverageIcon,
  ReportGoodIcon,
  ReportCriticalIcon,
  NewgenOneLogo,
  ExpandIcon,
  LineIcon,

};

export const IconsButton = ({
  type,
  disabled = false,
  color = "default",
  ...rest
}) => {
  const TagName =
    components[type] == null ? components["AddIcon"] : components[type];
  return (
    <IconButton disabled={disabled} color={color} {...rest} size="large">
      <TagName disabled={disabled} />
    </IconButton>
  );
};
export const NewNewgenWhiteLogoIcon = (props) => (
  <img src={NewNewgenWhiteLogo} alt="LogoIcon" style={props.style || ""} />
);
export const IconImage = ({
  url,
  width = 15,
  height = 10,
  disabled = false,
  ...rest
}) => {
  return (
    <IconButton disabled={disabled} {...rest} size="large">
      <img src={`${url}`} width={width} height={height} alt="Icon Button" />
    </IconButton>
  );
};
/**
 * 	.st0{fill:#D3D3D3;}
  .st1{fill:#606060;}
  .st2{fill:none;stroke:#606060;stroke-miterlimit:10;}
  .st3{opacity:0.2;}
  .st4{fill:#F2F1EF;}
  .st5{fill:#FFFFFF;}
  .st6{fill:#A6A5A5;}
  .st7{fill:#0861AD;}
  .st8{opacity:0.3;}
  .st9{fill:#F7F5F5;}
  .st10{fill:#959494;}
  .st11{opacity:0.3;fill:#A6A5A5;}
 */
