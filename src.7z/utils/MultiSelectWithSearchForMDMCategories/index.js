import React, { useState, useEffect } from "react";
import {
  Checkbox,
  FormControlLabel,
  Chip,
  ClickAwayListener,
  Typography,
  Grid,
  IconButton,
  Collapse,
  Button,
} from "@mui/material";
//import { Check,Clear,ArrowDropDown } from "@mui/icons-material";
import CheckIcon from "@mui/icons-material/Check";

import ClearIcon from "@mui/icons-material/Clear";
//import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import styled from "styled-components";
import styles from "./index.module.css";
import { useTranslation } from "react-i18next";
import "./index.css";
//import SearchBox from "../Search Component";
import { StyledTooltip } from '../StyledToolTip/index';
import arabicStyles from "./ArabicStyles.module.css";
import { GET_MDM_GLOBAL_CATEGORY_DATA_OBJECTS, GET_MDM_VARIABLES, RTL_DIRECTION } from "../../config/index";
import { ExpandLess, ExpandMore } from "@mui/icons-material";
import { ClearIcon as AllClearIcon, CollapseIcon, DataObjectIcon, ExpandDataIcon, ExpandIcon, FolderIcon } from "../AllImages";
import { createInstance } from "../common";

const InputWrapper = styled("div")`
  width: 100%;
  height: 28px;
  border: 1px solid #c4c4c4;
  border-radius: 2px;
  background-color: #fff;
  padding: 1px;
  display: flex;
  flex-wrap: wrap;
  position: relative;
  align-content:center;
  align-items:center;
  font:normal normal normal 12px/17px Open Sans;

  & input {
    font: normal normal normal 12px/17px Open Sans;
    height: 2.125rem;
    box-sizing: border-box;
    padding: 0.125rem 0.5vw;
    color: #606060;
    width: 0;
    min-width: 30px;
    flex-grow: 1;
    border: 0;
    margin: 0;
    outline: 0;
    cursor: pointer;
  }

  & input:disabled {
    background-color: #f8f8f8;
  }
`;

const Listbox = styled("ul")`
  width: 100%;
  margin: 2px 0 0;
  padding: 0 !important;
  list-style: none;
  background-color: #fff;
  overflow: auto;
  max-height: 250px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 1;

  & li {
    padding: 0.25rem 0vw;
    display: flex;

    & span {
      flex-grow: 1;
    }

    & svg {
      color: transparent;
    }
  }

  & li[aria-selected="true"] {
    background-color: #fafafa;
    font-weight: 600;

    & svg {
      color: #1890ff;
    }
  }

  & li[data-focus="true"] {
    background-color: #e6f7ff;
    cursor: pointer;

    & svg {
      color: #000;
    }
  }
`;

export default function MultiSelectWithSearchForCategories(props) {
  let { t } = useTranslation();
  const direction = `${t("HTML_DIR")}`;
  const { stopUserScroll, setUserRowCount, defaultRowCount, maxTagsToShow = 3 } = props;
  const [groupedOptions, setGroupedOptions] = useState([]);
  const [tagList, setTagList] = useState([]);
  const [inputVal, setInputVal] = useState(null);
  const [checked, setChecked] = useState(null);
  const [showList, setShowList] = useState(false);
  const [isHoveringOnChip, setIsHoveringOnChip] = useState(false)
  const [collapsedCategories, setCollapsedCategories] = useState([])


  useEffect(() => {
    if (!props.isDisabled) {
      setGroupedOptions([...props.optionList]);
      let tempTagList = [];

      // Create a new checked state based on selectedOptionList
      const newChecked = {};

      props.selectedOptionList.forEach((item) => {
       // const uniqueKey = `${item.variableId}_${item[props.optionRenderKey]}`;
       const uniqueKey = `${item.dataObjectName}_${item.variableId}_${item[props.optionRenderKey]}`;
        newChecked[uniqueKey] = true;
        tempTagList.push({ ...item });
      });
      setChecked(newChecked);
      setTagList(tempTagList);
    }
  }, [props.optionList, props.selectedOptionList]);


  useEffect(() => {
    if (inputVal && inputVal.trim()) {
      let tempList = [];
      props.optionList &&
        props.optionList.forEach((elem) => {
          if (
            elem[props.optionRenderKey].toLowerCase().includes(inputVal.trim())
          ) {
            tempList.push(elem);
          }
        });
      setGroupedOptions(tempList);
    } else {
      setGroupedOptions([...props.optionList]);
    }
  }, [inputVal]);


  useEffect(() => {
    if (props.filterCleared) {
      setTagList((prev) => []);
      setInputVal(null);
      setChecked(null);
      props.getSelectedItems([]);
    }
  }, [props.filterCleared]);

  const handleChange = (data, type) => {
    if (type === 0) {
      //type 0 is to add new fields to selected field list
      setTagList((prev) => {
        let newArr = [...prev];
        newArr.push(data);
        props.getSelectedItems(newArr, 0, data);
        return newArr;
      });
    } else if (type === 1) {
      //type 1 is to delete some fields from selected field list
      setTagList((prev) => {
        let newArr = [...prev];

        let indexVal = newArr.findIndex(
          (item) => item[props.optionRenderKey] === data[props.optionRenderKey]
        );

        newArr.splice(indexVal, 1);
        props.getSelectedItems(newArr, 1, data);
        return newArr;
      });
    }
  };

  const toggleCheckbox = (dataKey, dataValue) => {
    setInputVal("");

   // const uniqueKey = `${dataValue.variableId}_${dataKey}`;
   const uniqueKey = `${dataValue.dataObjectName}_${dataValue.variableId}_${dataKey}`;



    setChecked((prev) => ({
      ...prev,
      [uniqueKey]: !prev[uniqueKey],
    }));

    if (checked[uniqueKey]) {
      handleChange(dataValue, 1)
    } else {
      handleChange(dataValue, 0)
    }
  };




  const deleteEntityFromList = (data) => {
    const itemToDelete = props.selectedOptionList.find(
      (item) => item[props.optionRenderKey] === data
    );

    if (itemToDelete) {
      //const uniqueKey = `${itemToDelete.variableId}_${itemToDelete[props.optionRenderKey]}`;
      const uniqueKey = `${itemToDelete.dataObjectName}_${itemToDelete.variableId}_${itemToDelete[props.optionRenderKey]}`;


      setChecked((prev) => ({
        ...prev,
        [uniqueKey]: false,
      }));
      handleChange(itemToDelete, 1);
    }
  };



  let tagListTitle = tagList?.slice(maxTagsToShow, tagList.length)?.map((el) => {
    return el[props.optionRenderKey];
  });

  /* const searchHandler = (keyword) => {
     setInputVal(keyword);
     if (props.onSearchSubmitUsername) {
       props.onSearchSubmitUsername(keyword);
     }
   };
 */
  const deleteAllTags = () => {
    setTagList((prev) => ([]))
    props.getSelectedItems([]);

  }
  const handleCollapseCategories = (catId) => {
    if (collapsedCategories.includes(catId)) {
      setCollapsedCategories(collapsedCategories.filter(item => item !== catId))
    } else {
      setCollapsedCategories([...collapsedCategories, catId])
    }
  }
  return (
    <div className="relative" style={props.style}>
      {props.label && <label htmlFor={`multiSelectSearch_${props.id}`} ><Typography className={styles.label}>{props.label}</Typography></label>}
      <InputWrapper
        style={{ backgroundColor: props.isDisabled ? "#f8f8f8" : "#fff", width: 'inherit' }}
        id={`multiSelectSearch_${props.id}`}
        onClick={() => setShowList(true)}
        tabIndex={0}
        onKeyUp={(e) => {
          if (e.key === "Enter") {
            setShowList(true);
          }
        }}
        role="list"
        aria-description={
          props.showTags && tagList?.length < 1
            ? "Select Multiple Values"
            : `${tagListTitle}`
        }
      >
        {props.showTags
          ? tagList?.length > maxTagsToShow
            ? tagList?.slice(0, maxTagsToShow)?.map((option, index) => (
              <div title={option[props.optionRenderKey]} onMouseEnter={() => setIsHoveringOnChip(index)} onMouseLeave={() => setIsHoveringOnChip(null)}>
                <Chip
                  key={option[props.optionRenderKey]}
                  label={option[props.optionRenderKey]}
                  clickable
                  deleteIcon={
                    isHoveringOnChip === index ? <ClearIcon
                      onMouseDown={(event) => event.stopPropagation()}
                      id={`multiSelectSearch_clearIcon_${index}`}
                      className={styles.multiSelectDeleteIcon}
                    /> : null
                  }
                  className={styles.multiSelectChip}
                  onDelete={isHoveringOnChip === index ? () => {
                    deleteEntityFromList(
                      option[props.optionRenderKey],
                      option
                    );
                  } : null}
                  id={`multiSelectSearch_chip_${index}`}
                />
              </div>
            ))
            : tagList.map((option, index) => (
              <div title={`${option.dataObjectName + "*" + option[props.optionRenderKey]}`} onMouseEnter={() => setIsHoveringOnChip(index)} onMouseLeave={() => setIsHoveringOnChip(null)}>
                <Chip
                  key={option[props.optionRenderKey]}
                  label={option[props.optionRenderKey]}
                  clickable
                  deleteIcon={
                    isHoveringOnChip === index ? <ClearIcon
                      onMouseDown={(event) => event.stopPropagation()}
                      id={`multiSelectSearch_clearIcon_${index}`}
                      className={styles.multiSelectDeleteIcon}
                    /> : null
                  }
                  className={styles.multiSelectChip}
                  onDelete={isHoveringOnChip === index ? () => {
                    deleteEntityFromList(
                      option[props.optionRenderKey],
                      option
                    );
                  } : null}
                  id={`multiSelectSearch_chip_${index}`}
                />
              </div>
            ))
          : null}

        {props.showTags && tagList?.length < 1 && (
          <span
            style={{
              color: "#606060",
              marginLeft: "0.5rem",
            }}
            disabled={true}
            aria-hidden="true"
          >
            {" "}
            --{t("Select")}--
          </span>
        )}
        {props.showTags && tagList?.length > maxTagsToShow && (
          <StyledTooltip title={`${tagListTitle}`}>
            <span
              title={tagListTitle.join(", ")}
              style={{

                color: "#606060",
                cursor: "default",
              }}
            >
              +{tagList?.length - maxTagsToShow}
            </span>
          </StyledTooltip>
        )}
        {tagList?.length > 1 &&
          <AllClearIcon
            className={
              direction === RTL_DIRECTION
                ? arabicStyles.allClearIcon
                : styles.allClearIcon
            }
            onClick={deleteAllTags}
          />

        }
        <ExpandMore
          className={
            direction === RTL_DIRECTION
              ? arabicStyles.arrowIcon
              : styles.arrowIcon
          }
        />
      </InputWrapper>
      {showList ? (
        <ClickAwayListener
          onClickAway={() => {
            if (props.clearSearchResult) {
              props?.clearSearchResult();
            }
            setShowList(false);
            setCollapsedCategories([])
          }}
        >
          <div className={styles.outerDiv} >
            <Listbox className={styles.listDropdown} id={props.id}>
              <ListboxComponent groupedOptions={groupedOptions} toggleCheckbox={toggleCheckbox} collapsedCategories={collapsedCategories} handleCollapseCategories={handleCollapseCategories}
                optionRenderKey={props.optionRenderKey}
                checked={checked}
                id={props.id}
              />
            </Listbox>

          </div>
        </ClickAwayListener>
      ) : null}
    </div>
  );
}

const ListboxComponent = (props) => {
  const { groupedOptions, toggleCheckbox, collapsedCategories, handleCollapseCategories, checked, fetchSubVariables } = props;
  const recordsToFetch = 2;
  const { t } = useTranslation();
  const [subVariables, setSubVariables] = useState({});

  const fetchDataObjects = async (payload) => {
    const axiosInstance = createInstance();
    let page_no = 1;
    if (subVariables[payload.categoryId]) {
      const len = subVariables[payload.categoryId].length;
      page_no = (len / recordsToFetch) + 1
    }
    try {
      const res = await axiosInstance.post(`${GET_MDM_GLOBAL_CATEGORY_DATA_OBJECTS}`, {
        "records_to_fetch": `${recordsToFetch}`,
        "page_no": page_no,
        "parent_id": payload.categoryId,
        ...payload
      })
      if (res.status === 200) {
        // setInputVariables(res.data?.data)
        //setSubVariables(res.data?.data)
        return res.data?.data
      }
    } catch (error) {
      console.log(error)
    }
  }
  const handleExpandClick = async (payload) => {
    if (!subVariables[payload.categoryId] && !collapsedCategories.includes(payload.categoryId)) {
      const fetchedDataObjects = await fetchDataObjects(payload);
      console.log(fetchedDataObjects)
      if (fetchedDataObjects) {
        setSubVariables((prev) => ({ ...prev, [payload.categoryId]: fetchedDataObjects.map(item => ({ ...item, variableType: "C" })) }));
      }
    }
    handleCollapseCategories(payload.categoryId);
  };

  const handleFetchMore = async (payload) => {
    if (subVariables[payload.categoryId] && subVariables[payload.categoryId].length < payload.count) {
      const fetchedDataObjects = await fetchDataObjects(payload);
      console.log(fetchedDataObjects)
      if (fetchedDataObjects) {
        setSubVariables((prev) => ({ ...prev, [payload.categoryId]: [...prev[payload.categoryId], ...fetchedDataObjects.map(item => ({ ...item, variableType: "C" }))] }));
      }
    }
  };

  const fetchVariablesOfDataObjects = async (payload) => {
    const axiosInstance = createInstance();
    try {
      const res = await axiosInstance.post(`${GET_MDM_VARIABLES}`, { ...payload })
      if (res.status === 200) {
        return res.data?.data
        //setAllVariables(res.data?.data)
      }
    } catch (error) {
      console.log(error)
    }
  }
  const handleExpandClickForVariables = async (payload) => {
    if (!subVariables[payload.dataObjectId] && !collapsedCategories.includes(payload.dataObjectId)) {
      const fetchedSubVariables = await fetchVariablesOfDataObjects(payload); // Fetch the subVariables from API

      if (fetchedSubVariables) {
        setSubVariables((prev) => ({ ...prev, [payload.dataObjectId]: fetchedSubVariables }));
      }
    }
    handleCollapseCategories(payload.dataObjectId);
  };
  return (
    <>
      {groupedOptions && groupedOptions.length > 0 ? (
        <React.Fragment>
          {groupedOptions
            ?.filter((opt) => opt[props.optionRenderKey] && opt[props.optionRenderKey] !== "")
            .map((option, index) => {
              const uniqueKey = `${option.dataObjectName}_${option.variableId}_${option[props.optionRenderKey]}`;
              return (
                <li className={styles.multiSelect_listItem} key={index}>
                  {option.categoryDisplayName && (
                    <Grid container spacing={1} alignItems={'center'}>
                      <Grid item><FolderIcon style={{
                        width: "16px",
                        height: "16px",
                        color: "#606060"
                      }} /></Grid>
                      <Grid item>
                        <Typography className={styles.multiSelect_dropdown_main}>
                          {option.categoryDisplayName}
                        </Typography>
                      </Grid>
                      <Grid item>
                        <IconButton onClick={() => handleExpandClick(option)}>
                          {collapsedCategories.includes(option.categoryId) ? <ExpandLess
                            style={{
                              width: "20px",
                              height: "20px",
                              color: "#606060"
                            }} /> : <ExpandMore
                            style={{
                              width: "20px",
                              height: "20px",
                              color: "#606060"
                            }}
                          />}
                        </IconButton>
                      </Grid>
                      {subVariables[option.categoryId] && collapsedCategories.includes(option.categoryId) && <Grid item>
                        <Button variant="contained" color="primary" className={(subVariables[option.categoryId] && subVariables[option.categoryId].length === option.count) ? styles.fetchMore_disabledBtn : ""} onClick={() => handleFetchMore(option)}
                          disabled={subVariables[option.categoryId] && subVariables[option.categoryId].length === option.count}>
                          Fetch more
                        </Button>
                      </Grid>}
                    </Grid>
                  )}
                  {subVariables[option.categoryId] && collapsedCategories.includes(option.categoryId) && (
                    <ul className={styles.nestedList}>
                      <ListboxComponent
                        //optionRenderKey={props.optionRenderKey}
                        optionRenderKey={"dataObjectDisplayName"}
                        checked={checked}
                        id={props.id}
                        groupedOptions={subVariables[option.categoryId]}
                        toggleCheckbox={toggleCheckbox}
                        collapsedCategories={collapsedCategories}
                        handleCollapseCategories={handleCollapseCategories}
                        fetchSubVariables={fetchSubVariables}
                      />
                    </ul>
                  )}

                  {option.variableType === 'C' ? (
                    <>
                      <Grid container spacing={1} alignItems={'center'}>
                        {/*<Grid item>
                        <FormControlLabel
                          id={`multiSelectSearch_list_${index}`}
                           control={
                             <Checkbox
                               checkedIcon={
                                 <span
                                   className={
                                     props.checkedCheckBoxStyle
                                       ? `${props.checkedCheckBoxStyle} ${styles.multiSelect_checked}`
                                       : styles.multiSelect_checked
                                   }
                                 >
                                   <CheckIcon
                                     className={
                                       props.checkIcon
                                         ? `${props.checkIcon} ${styles.multiSelect_checkIcon}`
                                         : styles.multiSelect_checkIcon
                                     }
                                   />
                                 </span>
                               }
                               icon={
                                 <span
                                   className={
                                     props.checkboxStyle
                                       ? `${props.checkboxStyle} ${styles.multiSelect_checkboxStyle}`
                                       : styles.multiSelect_checkboxStyle
                                   }
                                 />
                               }
                               value={option[props.optionRenderKey]}
                               checked={
                                 checked &&
                                 checked[option[props.optionRenderKey]] === true
                                   ? true
                                   : false
                               }
                               onChange={() => toggleCheckbox(option[props.optionRenderKey], option)}
                               name="check"
                               id={`${props.id}_${option[props.optionRenderKey]}`}
                               onKeyUp={(e) => {
                                 if (e.key === "Enter") {
                                   toggleCheckbox(option[props.optionRenderKey], option);
                                 }
                               }}
                             />
                           }
                          label={
                            <Grid container spacing={1} alignItems={'center'}>
                              <Grid item>
                                <DataObjectIcon style={{ marginTop: '7px' }} />
                              </Grid>
                              <Grid item>
                                <Typography className={styles.multiSelect_dropdown}>
                                  {option[props.optionRenderKey]} {option.subDescription && `( ${option.subDescription})`}
                                 </Grid> {option.dataObjectDisplayName}
                                </Typography>
                              </Grid>
                              <Grid item>
                                <IconButton onClick={(e) => { e.preventDefault(); handleExpandClickForVariables(option); e.stopPropagation() }}>
                                  {collapsedCategories.includes(option.dataObjectId) ?
                                    <ExpandLess
                                      style={{
                                        width: "20px",
                                        height: "20px",
                                        color: "#606060"
                                      }} /> : <ExpandMore
                                      style={{
                                        width: "20px",
                                        height: "20px",
                                        color: "#606060"
                                      }}
                                    />
                                  }
                                </IconButton>
                                </Grid>
                                </Grid>
                          }
                        />
                        </Grid>
                        
                        </li>*/}
                        <Grid container spacing={1} alignItems={'center'}>
                          <Grid item>
                            <DataObjectIcon style={{ marginTop: '7px' }} />
                          </Grid>
                          <Grid item>
                            <Typography className={styles.multiSelect_dropdown_main}>

                              {option.dataObjectDisplayName || option[props.optionRenderKey]}
                            </Typography>
                          </Grid>
                          <Grid item>
                            <IconButton onClick={(e) => {
                              e.preventDefault(); if (option.dataObjectDisplayName) { handleExpandClickForVariables(option) } else {
                                handleCollapseCategories(option.variableId);
                              }; e.stopPropagation()
                            }}>
                              {collapsedCategories.includes(option.dataObjectId || option.variableId) ?
                                <ExpandLess
                                  style={{
                                    width: "20px",
                                    height: "20px",
                                    color: "#606060"
                                  }} /> : <ExpandMore
                                  style={{
                                    width: "20px",
                                    height: "20px",
                                    color: "#606060"
                                  }}
                                />
                              }
                            </IconButton>
                          </Grid>
                        </Grid>
                      </Grid>
                      {(subVariables[option.dataObjectId] || option.subVariables) && collapsedCategories.includes(option.dataObjectId || option.variableId) && (
                        <ul className={styles.nestedList}>
                          <ListboxComponent
                            //optionRenderKey={props.optionRenderKey}
                            optionRenderKey={'variableName'}
                            checked={checked}
                            id={props.id}
                            groupedOptions={subVariables[option.dataObjectId] || option.subVariables}
                            toggleCheckbox={toggleCheckbox}
                            collapsedCategories={collapsedCategories}
                            handleCollapseCategories={handleCollapseCategories}
                            fetchSubVariables={fetchSubVariables}
                          />
                        </ul>
                      )}
                    </>
                  ) : option.categoryDisplayName ? null : (
                    <Grid container spacing={1} alignItems={'center'}>
                      <Grid item>
                        <FormControlLabel
                          id={`multiSelectSearch_list_${index}`}
                          control={
                            <Checkbox
                              checkedIcon={
                                <span
                                  className={
                                    props.checkedCheckBoxStyle
                                      ? `${props.checkedCheckBoxStyle} ${styles.multiSelect_checked}`
                                      : styles.multiSelect_checked
                                  }
                                >
                                  <CheckIcon
                                    className={
                                      props.checkIcon
                                        ? `${props.checkIcon} ${styles.multiSelect_checkIcon}`
                                        : styles.multiSelect_checkIcon
                                    }
                                  />
                                </span>
                              }
                              icon={
                                <span
                                  className={
                                    props.checkboxStyle
                                      ? `${props.checkboxStyle} ${styles.multiSelect_checkboxStyle}`
                                      : styles.multiSelect_checkboxStyle
                                  }
                                />
                              }
                              // value={option[props.optionRenderKey]}
                              // checked={
                              //   checked &&
                              //     checked[option[props.optionRenderKey]] === true
                              //     ? true
                              //     : false
                              // }
                              value={uniqueKey}
                              checked={
                                checked &&
                                  checked[uniqueKey] === true
                                  ? true
                                  : false
                              }
                              onChange={() => toggleCheckbox(option[props.optionRenderKey], option)}
                              name="check"
                              id={`${props.id}_${option[props.optionRenderKey]}`}
                              onKeyUp={(e) => {
                                if (e.key === "Enter") {
                                  toggleCheckbox(option[props.optionRenderKey], option);
                                }
                              }}
                            />
                          }
                          label={
                            <div className={styles.multiSelect_dropdown}>
                              {option[props.optionRenderKey]} {option.subDescription && `( ${option.subDescription})`}
                            </div>
                          }
                        />
                      </Grid>
                    </Grid>
                  )}
                </li>
              )
            })}
        </React.Fragment>
      ) : (
        <li className={styles.noDataFound}>{t("noRecords")}</li>
      )}
    </>
  );
};
/*const ListboxComponent = (props) => {
  const { groupedOptions, toggleCheckbox, collapsedCategories, handleCollapseCategories, checked } = props;

  let { t } = useTranslation();
  return (
    <>
      {groupedOptions && groupedOptions.length > 0 ? (
        <React.Fragment>
          {groupedOptions
            ?.filter(
              (opt) =>
                opt[props.optionRenderKey] &&
                opt[props.optionRenderKey] !== ""
            )
            .map((option, index) => (
              <li className={styles.multiSelect_listItem} key={index}>
                {option.categoryName && (
                  <Grid container spacing={1} alignItems={'center'}>
                    <Grid item><FolderIcon /></Grid>
                    <Grid item>{option.categoryName}</Grid>
                    <Grid item>
                      <IconButton onClick={() => handleCollapseCategories(option.id)}>
                        {collapsedCategories.includes(option.id) ? <ExpandMore

                        /> : <CollapseIcon

                        />}
                      </IconButton>
                    </Grid>
                  </Grid>
                )}
                {option?.variables && collapsedCategories.includes(option.id) && (
                  <ul className={styles.nestedList}>
                    <ListboxComponent
                      optionRenderKey={props.optionRenderKey}
                      checked={checked}
                      id={props.id}
                      groupedOptions={option.variables}
                      toggleCheckbox={toggleCheckbox}
                      collapsedCategories={collapsedCategories}
                      handleCollapseCategories={handleCollapseCategories}
                    />
                  </ul>
                )}

                {option.variableType === 'C' ? (
                  <>
                    <Grid container spacing={1} alignItems={'center'}>
                      <Grid item>
                        <FormControlLabel
                          id={`multiSelectSearch_list_${index}`}
                          control={
                            <Checkbox
                              checkedIcon={
                                <span
                                  className={
                                    props.checkedCheckBoxStyle
                                      ? `${props.checkedCheckBoxStyle} ${styles.multiSelect_checked}`
                                      : styles.multiSelect_checked
                                  }
                                >
                                  <CheckIcon
                                    className={
                                      props.checkIcon
                                        ? `${props.checkIcon} ${styles.multiSelect_checkIcon}`
                                        : styles.multiSelect_checkIcon
                                    }
                                  />
                                </span>
                              }
                              icon={
                                <span
                                  className={
                                    props.checkboxStyle
                                      ? `${props.checkboxStyle} ${styles.multiSelect_checkboxStyle}`
                                      : styles.multiSelect_checkboxStyle
                                  }
                                />
                              }
                              value={option[props.optionRenderKey]}
                              checked={
                                checked &&
                                  checked[option[props.optionRenderKey]] === true
                                  ? true
                                  : false
                              }
                              onChange={() =>
                                toggleCheckbox(
                                  option[props.optionRenderKey],
                                  option
                                )
                              }
                              name="check"
                              id={`${props.id}_${option[props.optionRenderKey]}`}
                              onKeyUp={(e) => {
                                if (e.key === "Enter") {
                                  toggleCheckbox(
                                    option[props.optionRenderKey],
                                    option
                                  );
                                }
                              }}
                            />
                          }
                          label={

                            <Grid container spacing={1} alignItems={'center'}>
                              <Grid item>
                                <DataObjectIcon style={{ marginTop: '7px' }} />
                              </Grid>
                              <Grid item >
                                <Typography className={styles.multiSelect_dropdown}>


                                  {option[props.optionRenderKey]} {option.subDescription && `( ${option.subDescription})`}
                                </Typography>
                              </Grid>
                              <Grid item>
                                <IconButton onClick={(e) => { e.preventDefault(); handleCollapseCategories(option.id); e.stopPropagation() }}>
                                  {collapsedCategories.includes(option.id) ? <ExpandLess
                                    style={{
                                      width: "20px",
                                      height: "20px",
                                      color: "#606060"
                                    }} /> : <ExpandMore
                                    style={{
                                      width: "20px",
                                      height: "20px",
                                      color: "#606060"
                                    }}
                                  />}
                                </IconButton>
                              </Grid>
                            </Grid>

                          }
                        />
                      </Grid>

                    </Grid>
                    {collapsedCategories.includes(option.id) && option.subVariables && (
                      <ul className={styles.nestedList}>
                        <ListboxComponent
                          optionRenderKey={props.optionRenderKey}
                          checked={checked}
                          id={props.id}
                          groupedOptions={option.subVariables}
                          toggleCheckbox={toggleCheckbox}
                          collapsedCategories={collapsedCategories}
                          handleCollapseCategories={handleCollapseCategories}
                        />
                      </ul>
                    )}
                  </>
                ) : (
                  <Grid container spacing={1} alignItems={'center'}>
                    <Grid item>
                      <FormControlLabel
                        id={`multiSelectSearch_list_${index}`}
                        control={
                          <Checkbox
                            checkedIcon={
                              <span
                                className={
                                  props.checkedCheckBoxStyle
                                    ? `${props.checkedCheckBoxStyle} ${styles.multiSelect_checked}`
                                    : styles.multiSelect_checked
                                }
                              >
                                <CheckIcon
                                  className={
                                    props.checkIcon
                                      ? `${props.checkIcon} ${styles.multiSelect_checkIcon}`
                                      : styles.multiSelect_checkIcon
                                  }
                                />
                              </span>
                            }
                            icon={
                              <span
                                className={
                                  props.checkboxStyle
                                    ? `${props.checkboxStyle} ${styles.multiSelect_checkboxStyle}`
                                    : styles.multiSelect_checkboxStyle
                                }
                              />
                            }
                            value={option[props.optionRenderKey]}
                            checked={
                              checked &&
                                checked[option[props.optionRenderKey]] === true
                                ? true
                                : false
                            }
                            onChange={() =>
                              toggleCheckbox(
                                option[props.optionRenderKey],
                                option
                              )
                            }
                            name="check"
                            id={`${props.id}_${option[props.optionRenderKey]}`}
                            onKeyUp={(e) => {
                              if (e.key === "Enter") {
                                toggleCheckbox(
                                  option[props.optionRenderKey],
                                  option
                                );
                              }
                            }}
                          />
                        }
                        label={
                          <div className={styles.multiSelect_dropdown}>
                            {option[props.optionRenderKey]} {option.subDescription && `( ${option.subDescription})`}
                          </div>
                        }
                      />
                    </Grid>
                  </Grid>
                )}
              </li>
            ))}
        </React.Fragment>
      ) : (
        <li className={styles.noDataFound}>{t("noRecords")}</li>
      )}
    </>
  );
};


/*const ListboxComponent = (props) => {
  const { groupedOptions, toggleCheckbox, collapsedCategories, handleCollapseCategories, checked } = props;
  console.log('ali', props)
  return (
    <>

      {groupedOptions && groupedOptions.length > 0 ? (
        <React.Fragment>
          {groupedOptions
            ?.filter(
              (opt) =>
                opt[props.optionRenderKey] &&
                opt[props.optionRenderKey] !== ""
            )
            .map((option, index) => (
              <li className={styles.multiSelect_listItem}>
                {option.categoryName && <Grid container spacing={1} alignItems={'center'}>
                  <Grid item><FolderIcon /></Grid>
                  <Grid item>{option.categoryName}</Grid>
                  <Grid item

                  ><IconButton onClick={() => handleCollapseCategories(option.id)}>{collapsedCategories.includes(option.id) ? <ExpandIcon /> : <CollapseIcon />}</IconButton></Grid>
                </Grid>}
                {option?.variables && collapsedCategories.includes(option.id) && <ListboxComponent
                  optionRenderKey={props.optionRenderKey}
                  checked={checked}
                  id={props.id}
                  groupedOptions={option.variables} toggleCheckbox={toggleCheckbox} collapsedCategories={collapsedCategories} handleCollapseCategories={handleCollapseCategories} />}

                {option.variableType === 'C' ?
                  <>
                    <Grid container spacing={1} alignItems={'center'}>
                      <Grid item>
                        <FormControlLabel
                          id={`multiSelectSearch_list_${index}`}
                          control={
                            <Checkbox
                              checkedIcon={
                                <span
                                  className={
                                    props.checkedCheckBoxStyle
                                      ? `${props.checkedCheckBoxStyle} ${styles.multiSelect_checked}`
                                      : styles.multiSelect_checked
                                  }
                                >
                                  <CheckIcon
                                    className={
                                      props.checkIcon
                                        ? `${props.checkIcon} ${styles.multiSelect_checkIcon}`
                                        : styles.multiSelect_checkIcon
                                    }
                                  />
                                </span>
                              }
                              icon={
                                <span
                                  className={
                                    props.checkboxStyle
                                      ? `${props.checkboxStyle} ${styles.multiSelect_checkboxStyle}`
                                      : styles.multiSelect_checkboxStyle
                                  }
                                />
                              }
                              value={option[props.optionRenderKey]}
                              checked={
                                checked &&
                                  checked[option[props.optionRenderKey]] === true
                                  ? true
                                  : false
                              }
                              onChange={() =>
                                toggleCheckbox(
                                  option[props.optionRenderKey],
                                  option
                                )
                              }
                              name="check"
                              id={`${props.id}_${option[props.optionRenderKey]
                                }`}
                              onKeyUp={(e) => {
                                if (e.key === "Enter") {
                                  toggleCheckbox(
                                    option[props.optionRenderKey],
                                    option
                                  );
                                }
                              }}
                            />
                          }
                          label={
                            <div className={styles.multiSelect_dropdown}>
                              <Grid container spacing={1} alignItems={'center'}>
                                <Grid item>
                                  <DataObjectIcon />
                                </Grid>
                                <Grid item>
                                  {option[props.optionRenderKey]} {option.subDescription && `( ${option.subDescription})`}
                                </Grid>
                              </Grid>
                            </div>
                          }

                        />
                      </Grid>
                      <Grid item><IconButton onClick={() => handleCollapseCategories(option.id)}>{collapsedCategories.includes(option.id) ? <ExpandDataIcon /> : <CollapseIcon />}</IconButton></Grid>

                    </Grid>
                    {collapsedCategories.includes(option.id) && option.subVariables && <ListboxComponent
                      optionRenderKey={props.optionRenderKey}
                      checked={checked}
                      id={props.id}
                      groupedOptions={option.subVariables} toggleCheckbox={toggleCheckbox} collapsedCategories={collapsedCategories} handleCollapseCategories={handleCollapseCategories} />}
                  </> :
                  <FormControlLabel
                    id={`multiSelectSearch_list_${index}`}
                    control={
                      <Checkbox
                        checkedIcon={
                          <span
                            className={
                              props.checkedCheckBoxStyle
                                ? `${props.checkedCheckBoxStyle} ${styles.multiSelect_checked}`
                                : styles.multiSelect_checked
                            }
                          >
                            <CheckIcon
                              className={
                                props.checkIcon
                                  ? `${props.checkIcon} ${styles.multiSelect_checkIcon}`
                                  : styles.multiSelect_checkIcon
                              }
                            />
                          </span>
                        }
                        icon={
                          <span
                            className={
                              props.checkboxStyle
                                ? `${props.checkboxStyle} ${styles.multiSelect_checkboxStyle}`
                                : styles.multiSelect_checkboxStyle
                            }
                          />
                        }
                        value={option[props.optionRenderKey]}
                        checked={
                          checked &&
                            checked[option[props.optionRenderKey]] === true
                            ? true
                            : false
                        }
                        onChange={() =>
                          toggleCheckbox(
                            option[props.optionRenderKey],
                            option
                          )
                        }
                        name="check"
                        id={`${props.id}_${option[props.optionRenderKey]
                          }`}
                        onKeyUp={(e) => {
                          if (e.key === "Enter") {
                            toggleCheckbox(
                              option[props.optionRenderKey],
                              option
                            );
                          }
                        }}
                      />
                    }
                    label={
                      <div className={styles.multiSelect_dropdown}>
                        {option[props.optionRenderKey]} {option.subDescription && `( ${option.subDescription})`}
                      </div>
                    }
                  />}
              </li>
            ))}
        </React.Fragment>
      ) : (
        <li className={styles.noDataFound}>{t("noRecords")}</li>
      )}
    </>
  )
}*/