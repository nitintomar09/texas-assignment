import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import makeStyles from '@mui/styles/makeStyles';
import { useSelector } from "react-redux";
import InputBase from "@mui/material/InputBase";
import { useTranslation } from "react-i18next";
import SearchLens from "./icons/search_lens.png";
import { Grid } from "@mui/material";
import HighlightOffIcon from '@mui/icons-material/HighlightOff';

const useStyles = makeStyles((theme) => ({
  searchBox: (props) => {
    return {
      position: "relative",
      marginLeft: 0,
      display: "flex",
      maxWidth: "289px",
      background: "#FFFFFF",
      border: "1px solid #C4C4C4",
      borderRadius: "2px",
      height: props.height,
      width: props.width ? props.width : "289px",
      [theme.breakpoints.up("sm")]: {
        maxWidth: "360px",
      },
    };
  },
  searchIcon: {
    position: "absolute",
    right: "6px",
    height: "100%",
    display: "grid",
    placeItems: "center",
    cursor: "pointer",
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  cancelIcon: {
    position: "absolute",
    top: "50%",
    right: "28px",
    transform: "translateY(-50%)",
    display: "grid",
    placeItems: "center",
    cursor: "pointer",
  },
  inputRoot: {
    color: "inherit",
  },
  inputInput: {
    padding: theme.spacing(0.5, 1),
    fontSize: "12px",
    background: "#fff",
    transition: theme.transitions.create("width"),
    overflow: "hidden",
    whiteSpace: "nowrap",
    textOverflow: "ellipsis",
    "&::placeholder": {
      fontSize: "12px",
      textOverflow: "ellipsis",
    },
    outline: "none",
    "&:focus-visible": {
      //outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      //borderRadius: "2px",
    },
  },
  popoverBlock: {
    position: "absolute",
    top: "30px",
    left: "-1px",
    width: (props) => (props.width ? props.width : "200px"),
    boxShadow: " 0px 3px 6px #00000029",
    border: "1px solid #C4C4C4",
    borderRadius: "2px",
    zIndex: 999,
    opacity: 1,
    background: "#fff",
    maxHeight: "250px",
    overflowY: "scroll",
  },
  popoverItem: {
    listStyle: "none",
    margin: 0,
    padding: "0 0 4px",
    "& li": {
      fontSize: "12px",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      textAlign: "left",
      padding: "5.5px 8px",
      cursor: "pointer",
      "&.heading": {
        fontWeight: 600,
        color: "#000",
      },
    },
  },
  listItem: {
    background: "#fff",
    transition: "all 100ms ease-in",
    "&:hover": {
      background: "#F0F0F0",
    },
  },
}));

const SearchBox = (props) => {
  const { t } = useTranslation();
  const {
    id,
    name,
    width = "200px",
    height = "28px",
    placeholder = t("Search"),
    onSearchChange = () => console.log("forget to pass onSearchChange()"),
    onSearchSubmit = () => console.log("you missed to passed onSearchSubmit()"),
    clearSearchResult = () => console.log("forget to pass clearSearchResult()"),
    haveSuggestions = false,
    haveRecents = false,
    onLoadSuggestions = null,
    onLoadRecents = null,
    recentData = [],
    suggestionData = [],
    disabledFocus = false,
  } = props;

  const classes = useStyles({ height, width });

  const [searchValue, setSearchValue] = useState("");
  const [showSuggestion, setShowSuggestion] = useState(false);
  const [showRecents, setShowRecents] = useState(false);

  /* useEffect(() => {
    if (haveRecents) if (onLoadRecents !== null) onLoadRecents();
  }, []);*/

  /* useEffect(() => {
    function onClickEvent(event) {
      let isEleFound = false;

      for (let i = 0; i < 4; i++) {
        const ele = event.path[i];
        if (ele.id === "searchBoxId") {
          isEleFound = true;
          return;
        }
      }
      if (!isEleFound) {
        setShowRecents(false);
        setShowSuggestion(false);
      }
    }

    window.addEventListener("click", onClickEvent);
    return () => window.removeEventListener("click", onClickEvent);
  }, []);*/

  const onKeyDownEvent = (event) => {
    if (event.keyCode === 13) {
      searchHandler();
    }
  };

  const onChangeHandler = (e) => {
    if(e.target.value.length<40){
    setSearchValue(e.target.value);
    onSearchChange(e.target.value);
    }
    //hide recents when we start the typing
    if (haveRecents) setShowRecents(e.target.value.length === 0 ? true : false);

    //show suggestion when we start the typing
    if (haveSuggestions) {
      if (e.target.value.length > 2) {
        if (e.target.value.length % 3 === 0)
          if (onLoadSuggestions !== null) onLoadSuggestions(e.target.value);
        setShowSuggestion(true);
      } else {
        setShowSuggestion(false);
      }
    }
  };

  const cancelHandler = () => {
    setSearchValue("");
    onSearchChange("");
    setShowSuggestion(false);

    if (haveRecents) {
      setShowRecents(true);
      if (onLoadRecents !== null) onLoadRecents();
    }
    if (clearSearchResult != null) clearSearchResult();
  }

  const searchHandler = (item) => {
    //let val = document.getElementById("searchBoxInput").value;
    let val = document.getElementById(id).value;
    if (item !== undefined) {
      item = {
        ...item,
        searchString: val,
      };

      setSearchValue(item.label);
      setShowRecents(false);
      setShowSuggestion(false);
      onSearchSubmit(item);
    } else onSearchSubmit({ searchString: val });
  };

  const onFocusHandler = (event) => {
    if (haveRecents && searchValue === "") {
      setShowRecents(true);
    }
  };

  const [globalSetting] = useSelector((state) => {
    return [state.globalSettings];
  });

  return (
    <div container className={classes.searchBox} style={{ width: width }}>
      
      <InputBase
        name={name}
        //id="searchBoxInput"
        id={id}
        placeholder={placeholder ? placeholder : `${t("bam:TITLE_SEARCH")}`}
        value={searchValue}
        classes={{
          root: classes.inputRoot,
          input: classes.inputInput,
        }}
        style={{ width: `calc(${width} - 42px)` }}
        inputProps={{ "aria-label": "Search" }}
        onFocus={onFocusHandler}
        onChange={onChangeHandler}
        onKeyDown={onKeyDownEvent}
        disabled={disabledFocus}
      />
     
      {showRecents && recentData.length > 0 && (
        <div className={classes.popoverBlock}>
          <ul className={classes.popoverItem}>
            <li className="heading">Recent Searches</li>
            {recentData.map((item, index) => {
              return (
                <React.Fragment key={item.id}>
                  <li
                    className={classes.listItem}
                    onClick={() => searchHandler(item)}
                  >
                    {item.label}
                  </li>
                </React.Fragment>
              );
            })}
          </ul>
        </div>
      )}
      {showSuggestion && suggestionData.length > 0 && (
        <div className={classes.popoverBlock}>
          <ul className={classes.popoverItem}>
            {suggestionData.map((item, index) => {
              return (
                <React.Fragment key={item.id}>
                  <li
                    className={classes.listItem}
                    onClick={() => searchHandler(item)}
                  >
                    {item.label}
                  </li>
                </React.Fragment>
              );
            })}
          </ul>
        </div>
      )}
      
      {/* //Bug 155119 - UI issues with the search icon on the service flows
      //Author : nitin_tomar
      //Date: 06 JAN 2025
      //Description: Search Icon with clear serach is added. */}
      {  searchValue != "" && <div className={classes.cancelIcon} onClick={cancelHandler}>
          <HighlightOffIcon sx={{height:"16px", width:"16px"}} color="disabled"/>
        </div>
      }
      <div item
        className={classes.searchIcon}
        onClick={() => searchHandler()}
        //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
        tabIndex={disabledFocus ? -1 : 0}
        role={disabledFocus ? "none" : "button"}
        onKeyPress={(e) => e.key === "Enter" && searchHandler()}
        id={`${id}_LensIcon`}
        aria-label="Search Input"
      >
        <img src={SearchLens} alt="lens" width="16px" height="16px" />
      </div>
    </div>
  );
};

export default SearchBox;

SearchBox.propTypes = {
  name: PropTypes.string,
  placeholder: PropTypes.string,
  width: PropTypes.string,
  height: PropTypes.string,
  onSearchChange: PropTypes.func,
  onSearchSubmit: PropTypes.func, // return object {id:"", label:"", searchString:""}
  clearSearchResult: PropTypes.func,

  haveSuggestions: PropTypes.bool,
  onLoadSuggestions: PropTypes.func,
  suggestionData: PropTypes.array,
  haveRecents: PropTypes.bool,
  onLoadRecents: PropTypes.func,
  recentData: PropTypes.array,
};
