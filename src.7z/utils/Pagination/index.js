import React from "react";
import { Grid } from "@mui/material";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
const Pagination = ({ numberOfPages, handleOpenPage, selectedPage }) => {
  const arr = [];

  for (let i = 0; i <= numberOfPages; i++) {
    arr.push(i);
  }
  return (
    <Grid container justifyContent="center" spacing={2} alignItems="center">
      {selectedPage - 1 > 0 && (
        <Grid item>
          <ChevronLeft onClick={() => handleOpenPage(selectedPage - 1)} />
        </Grid>
      )}
      {arr.map((item, index) => (
        <Grid
          item
          key={index}
          onClick={() => handleOpenPage(index)}
          style={{
            backgroundColor: selectedPage === index ? "lightblue" : "lightgray",
            width: "25px",
            height: "25px",
            borderRadius: "50px",
            cursor: "pointer",
            margin: "5px",
          }}
        >
          <span style={{ marginRight: "2px" }}>{"P" + `${index + 1}`}</span>
        </Grid>
      ))}
      {selectedPage + 1 < numberOfPages && (
        <Grid item>
          <ChevronRight onClick={() => handleOpenPage(selectedPage + 1)} />
        </Grid>
      )}
    </Grid>
  );
};

export default Pagination;
