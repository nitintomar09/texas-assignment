export const getEncryptedId = (data) => {
  const objStr = JSON.stringify(data);
  const objJsonB64 = btoa(objStr);

  return objJsonB64;
};
export const getDecryptData = (str) => {
 
  try {
    return JSON.parse(atob(str));
} catch (error) {
    console.error('Failed to parse base64-encoded string:', error);
    return null; // or any default value you prefer
}
};
export const getEncryptedString = (str) => {
  if (typeof str === "string") {
    return btoa(str);
  }

  return null;
};
export const getDecryptedString = (str) => {
  if (typeof str === "string") {
    return atob(str);
  }
  return null;
};
