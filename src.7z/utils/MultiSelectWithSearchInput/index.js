import React, { useState, useEffect } from "react";
import {
  Checkbox,
  FormControlLabel,
  Chip,
  ClickAwayListener,
} from "@mui/material";
//import { Check,Clear,ArrowDropDown } from "@mui/icons-material";
import CheckIcon from "@mui/icons-material/Check";

import ClearIcon from "@mui/icons-material/Clear";
//import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
import styled from "styled-components";
import styles from "./index.module.css";
import { useTranslation } from "react-i18next";
import "./index.css";
//import SearchBox from "../Search Component";
import { StyledTooltip } from '../StyledToolTip/index';
import arabicStyles from "./ArabicStyles.module.css";
import { RTL_DIRECTION } from "../../config/index";
import { ExpandMore } from "@mui/icons-material";
import { ClearIcon as AllClearIcon } from "../AllImages";

const InputWrapper = styled("div")`
  width: 100%;
  height: 28px;
  border: 1px solid #c4c4c4;
  border-radius: 2px;
  background-color: #fff;
  padding: 1px;
  display: flex;
  flex-wrap: wrap;
  position: relative;
  align-content:center;
  align-items:center;
  font:normal normal normal 12px/17px Open Sans;

  & input {
    font: normal normal normal 12px/17px Open Sans;
    height: 2.125rem;
    box-sizing: border-box;
    padding: 0.125rem 0.5vw;
    color: #606060;
    width: 0;
    min-width: 30px;
    flex-grow: 1;
    border: 0;
    margin: 0;
    outline: 0;
    cursor: pointer;
  }

  & input:disabled {
    background-color: #f8f8f8;
  }
`;

const Listbox = styled("ul")`
  width: 100%;
  margin: 2px 0 0;
  padding: 0 !important;
  list-style: none;
  background-color: #fff;
  overflow: auto;
  max-height: 250px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 1;

  & li {
    padding: 0.25rem 0vw;
    display: flex;

    & span {
      flex-grow: 1;
    }

    & svg {
      color: transparent;
    }
  }

  & li[aria-selected="true"] {
    background-color: #fafafa;
    font-weight: 600;

    & svg {
      color: #1890ff;
    }
  }

  & li[data-focus="true"] {
    background-color: #e6f7ff;
    cursor: pointer;

    & svg {
      color: #000;
    }
  }
`;

export default function MultiSelectWithSearch(props) {
  let { t } = useTranslation();
  const direction = `${t("HTML_DIR")}`;
  const { stopUserScroll, setUserRowCount, defaultRowCount, maxTagsToShow = 3 } = props;
  const [groupedOptions, setGroupedOptions] = useState([]);
  const [tagList, setTagList] = useState([]);
  const [inputVal, setInputVal] = useState(null);
  const [checked, setChecked] = useState(null);
  const [showList, setShowList] = useState(false);
  const [isHoveringOnChip, setIsHoveringOnChip] = useState(false)

  

  useEffect(() => {
    if (!props.isDisabled) {
      setGroupedOptions([...props.optionList]);
      let tempTagList = [];
      props.optionList &&
        props.optionList.forEach((item) => {
          if (props.selectedOptionList.includes(item[props.optionRenderKey])) {
            setChecked((prev) => {
              return { ...prev, [item[props.optionRenderKey]]: true };
            });
            //tempTagList.push(item);
          } else {
            setChecked((prev) => {
              return { ...prev, [item[props.optionRenderKey]]: false };
            });
          }
        });
      props?.selectedOptionList?.forEach((item) => {
        let newJson = {};
        newJson[props.optionRenderKey] = item;
        tempTagList.push({ ...newJson });
      });
      setTagList(tempTagList);
    }
  }, [props.optionList, props.selectedOptionList]);

  useEffect(() => {
    if (inputVal && inputVal.trim()) {
      let tempList = [];
      props.optionList &&
        props.optionList.forEach((elem) => {
          if (
            elem[props.optionRenderKey].toLowerCase().includes(inputVal.trim())
          ) {
            tempList.push(elem);
          }
        });
      setGroupedOptions(tempList);
    } else {
      setGroupedOptions([...props.optionList]);
    }
  }, [inputVal]);


  useEffect(() => {
    if (props.filterCleared) {
      setTagList((prev) => []);
      setInputVal(null);
      setChecked(null);
      props.getSelectedItems([]);
    }
  }, [props.filterCleared]);

  const handleChange = (data, type) => {
    if (type === 0) {
      //type 0 is to add new fields to selected field list
      setTagList((prev) => {
        let newArr = [...prev];
        newArr.push(data);
        props.getSelectedItems(newArr, 0, data);
        return newArr;
      });
    } else if (type === 1) {
      //type 1 is to delete some fields from selected field list
      setTagList((prev) => {
        let newArr = [...prev];

        let indexVal = newArr.findIndex(
          (item) => item[props.optionRenderKey] === data[props.optionRenderKey]
        );

        newArr.splice(indexVal, 1);
        props.getSelectedItems(newArr, 1, data);
        return newArr;
      });
    }
  };

  const toggleCheckbox = (data, dataValue) => {
    setInputVal("");
    // setShowList(false);
    //function to handle toggle on the checkbox
    props.optionList &&
      props.optionList.forEach((item) => {
        if (item[props.optionRenderKey] === data) {
          setChecked((prev) => {
            return {
              ...prev,
              [item[props.optionRenderKey]]: !prev[item[props.optionRenderKey]],
            };
          });
        }
      });
    if (checked[data] === false) handleChange(dataValue, 0); //to add to list
    if (checked[data] === true) handleChange(dataValue, 1); //to delete from list
  };

  const deleteEntityFromList = (data, dataValue) => {
    //function called when delete icon on chip of selected field is clicked
    props.optionList &&
      props.optionList.forEach((item) => {
        if (item[props.optionRenderKey] === data) {
          setChecked((prev) => {
            return {
              ...prev,
              [item[props.optionRenderKey]]: !prev[item[props.optionRenderKey]],
            };
          });
        }
      });
    handleChange(dataValue, 1);
  };

  let tagListTitle = tagList?.slice(maxTagsToShow, tagList.length)?.map((el) => {
    return el[props.optionRenderKey];
  });

  /* const searchHandler = (keyword) => {
     setInputVal(keyword);
     if (props.onSearchSubmitUsername) {
       props.onSearchSubmitUsername(keyword);
     }
   };
 */
const deleteAllTags=()=>{
  setTagList((prev)=>([]))
  props.getSelectedItems([]);

}
  return (
    <div className="relative" style={props.style}>
      <InputWrapper
        style={{ backgroundColor: props.isDisabled ? "#f8f8f8" : "#fff" }}
        id="multiSelectSearch"
        onClick={() => setShowList(true)}
        tabIndex={0}
        onKeyUp={(e) => {
          if (e.key === "Enter") {
            setShowList(true);
          }
        }}
        role="list"
        aria-description={
          props.showTags && tagList?.length < 1
            ? "Select Multiple Values"
            : `${tagListTitle}`
        }
      >
        {props.showTags
          ? tagList?.length > maxTagsToShow
            ? tagList?.slice(0, maxTagsToShow)?.map((option, index) => (
              <div title={option[props.optionRenderKey]} onMouseEnter={() => setIsHoveringOnChip(index)} onMouseLeave={() => setIsHoveringOnChip(null)}>
                <Chip
                  key={option[props.optionRenderKey]}
                  label={option[props.optionRenderKey]}
                  clickable
                  deleteIcon={
                    isHoveringOnChip === index ? <ClearIcon
                      onMouseDown={(event) => event.stopPropagation()}
                      id={`multiSelectSearch_clearIcon_${index}`}
                      className={styles.multiSelectDeleteIcon}
                    /> : null
                  }
                  className={styles.multiSelectChip}
                  onDelete={isHoveringOnChip === index ? () => {
                    deleteEntityFromList(
                      option[props.optionRenderKey],
                      option
                    );
                  } : null}
                  id={`multiSelectSearch_chip_${index}`}
                />
              </div>
            ))
            : tagList.map((option, index) => (
              <div title={option[props.optionRenderKey]} onMouseEnter={() => setIsHoveringOnChip(index)} onMouseLeave={() => setIsHoveringOnChip(null)}>
                <Chip
                  key={option[props.optionRenderKey]}
                  label={option[props.optionRenderKey]}
                  clickable
                  deleteIcon={
                    isHoveringOnChip === index ? <ClearIcon
                      onMouseDown={(event) => event.stopPropagation()}
                      id={`multiSelectSearch_clearIcon_${index}`}
                      className={styles.multiSelectDeleteIcon}
                    /> : null
                  }
                  className={styles.multiSelectChip}
                  onDelete={isHoveringOnChip === index ? () => {
                    deleteEntityFromList(
                      option[props.optionRenderKey],
                      option
                    );
                  } : null}
                  id={`multiSelectSearch_chip_${index}`}
                />
              </div>
            ))
          : null}

        {props.showTags && tagList?.length < 1 && (
          <span
            style={{
              color: "#606060",
              marginLeft: "0.5rem",
            }}
            disabled={true}
            aria-hidden="true"
          >
            {" "}
            --{t("Select")}--
          </span>
        )}
        {props.showTags && tagList?.length > maxTagsToShow && (
          <StyledTooltip title={`${tagListTitle}`}>
            <span
              title={tagListTitle.join(", ")}
              style={{

                color: "#606060",
                cursor: "default",
              }}
            >
              +{tagList?.length - maxTagsToShow}
            </span>
          </StyledTooltip>
        )}
        {tagList?.length > 1 &&
          <AllClearIcon
            className={
              direction === RTL_DIRECTION
                ? arabicStyles.allClearIcon
                : styles.allClearIcon
            }
            onClick={deleteAllTags}
          />

        }
        <ExpandMore
          className={
            direction === RTL_DIRECTION
              ? arabicStyles.arrowIcon
              : styles.arrowIcon
          }
        />
      </InputWrapper>
      {showList ? (
        <ClickAwayListener
          onClickAway={() => {
            if (props.clearSearchResult) {
              props?.clearSearchResult();
            }
            setShowList(false);
          }}
        >
          <div className={styles.outerDiv}>
            <Listbox className={styles.listDropdown} id={props.id}>
              {/*props.defaultSearchComponent ? (
                <SearchBox
                  placeholder={t("SearchUsers")}
                  onSearchSubmit={(val) => searchHandler(val.searchString)}
                  title={"multiSearchInput"}
                  disabled={props.isDisabled}
                  width="95%"
                  marginLeft={"8px"}
                  style={{
                    zIndex: 100,
                    position: "-webkit-sticky",
                    position: "sticky",
                    top: 0,
                  }}
                  clearSearchResult={props.clearSearchResult}
                />
              ) : (
                <input
                  id="inputSearchUser"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  disabled={props.isDisabled}
                  autoFocus
                  className={styles.searchInput}
                  placeholder={t("SearchUsers")}
                />
              )*/}
              {groupedOptions && groupedOptions.length > 0 ? (
                <React.Fragment>
                  {groupedOptions
                    ?.filter(
                      (opt) =>
                        opt[props.optionRenderKey] &&
                        opt[props.optionRenderKey] !== ""
                    )
                    .map((option, index) => (
                      <li className={styles.multiSelect_listItem}>
                        <FormControlLabel
                          id={`multiSelectSearch_list_${index}`}
                          control={
                            <Checkbox
                              checkedIcon={
                                <span
                                  className={
                                    props.checkedCheckBoxStyle
                                      ? `${props.checkedCheckBoxStyle} ${styles.multiSelect_checked}`
                                      : styles.multiSelect_checked
                                  }
                                >
                                  <CheckIcon
                                    className={
                                      props.checkIcon
                                        ? `${props.checkIcon} ${styles.multiSelect_checkIcon}`
                                        : styles.multiSelect_checkIcon
                                    }
                                  />
                                </span>
                              }
                              icon={
                                <span
                                  className={
                                    props.checkboxStyle
                                      ? `${props.checkboxStyle} ${styles.multiSelect_checkboxStyle}`
                                      : styles.multiSelect_checkboxStyle
                                  }
                                />
                              }
                              value={option[props.optionRenderKey]}
                              checked={
                                checked &&
                                  checked[option[props.optionRenderKey]] === true
                                  ? true
                                  : false
                              }
                              onChange={() =>
                                toggleCheckbox(
                                  option[props.optionRenderKey],
                                  option
                                )
                              }
                              name="check"
                              id={`${props.id}_${option[props.optionRenderKey]
                                }`}
                              onKeyUp={(e) => {
                                if (e.key === "Enter") {
                                  toggleCheckbox(
                                    option[props.optionRenderKey],
                                    option
                                  );
                                }
                              }}
                            />
                          }
                          label={
                            <div className={styles.multiSelect_dropdown}>
                              {option[props.optionRenderKey]} {option.subDescription && `( ${option.subDescription})`}
                            </div>
                          }
                        />
                      </li>
                    ))}
                </React.Fragment>
              ) : (
                <li className={styles.noDataFound}>{t("noRecords")}</li>
              )}
            </Listbox>
            {groupedOptions.length && <div className={styles.footer}>
              <button
                className={styles.cancelBtn}
                onClick={() => setShowList(false)}
                id="multiSelectSearch_cancel"
              >
                Cancel
              </button>
              <button
                className={styles.okBtn}
                onClick={() => setShowList(false)}
                id="multiSelectSearch_done"
              >
                Done
              </button>
            </div>}
          </div>
        </ClickAwayListener>
      ) : null}
    </div>
  );
}
