import React from "react";
import { Grid, Box, Typography } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import CircularProgress from "@mui/material/CircularProgress";
import PropTypes from "prop-types";

// Inspired by the former Facebook spinners.
const useStylesFacebook = makeStyles((theme) => ({
  root: {
    position: "relative",
  },
  bottom: {
    color: theme.palette.grey[theme.palette.mode === "light" ? 200 : 700],
  },
  top: {
    color: `${theme.palette.primary.main}`,
    animationDuration: "550ms",
    position: "absolute",
    left: 0,
  },
  circle: {
    strokeLinecap: "round",
  },
}));

function FacebookCircularProgress(props) {
  const classes = useStylesFacebook();

  return (
    <div className={classes.root}>
      <CircularProgress
        //variant="indeterminate"
        className={classes.top}
        size={20}
        thickness={4}
        {...props}
        value={100}
      />
    </div>
  );
}

const useStyles = makeStyles({
  root: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});

export default function LoadingIndicator() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Grid container justifyContent="center">
        <Grid item>
          <FacebookCircularProgress />
        </Grid>
      </Grid>
    </div>
  );
}

function CircularProgressWithLabel(props) {
  return (
    <Box
      style={{
        position: "relative",
        display: "inline-flex",
      }}
    >
      <CircularProgress
        variant="determinate"
        {...props}
    style={{
       height: props?.height || "15px",
       width: props?.width || "15px",
         marginRight: "8px",
       }}
      />
      <Box
        style={{
          top: 0,
          left: 0,
          bottom: 0,
          right: 0,
          position: "absolute",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Typography variant="caption" component="div" color="text.secondary">
          {`${Math.round(props.value)}%`}
        </Typography>
      </Box>
    </Box>
  );
}

CircularProgressWithLabel.propTypes = {
  /**
   * The value of the progress indicator for the determinate variant.
   * Value between 0 and 100.
   * @default 0
   */
  value: PropTypes.number.isRequired,
};
export function LoadingIndicatorWithProgress(props) {
  const classes = useStyles();

  return (
    <div className={classes.root}>
          {/* 
 @author - akshat_pokhriyal
 @Date - 22/01/2024
  @Bug Id - 142421
 @Bug Description - After Import a script we are not getting successful message pop-up and we are not redirecting on same page
 @Bug Reason of occurence - muiv5 migration issue for circular progress
 @Solution - changed prop for circular progress
  */}
      <CircularProgressWithLabel
        value={props?.value}
        //  color={props?.color || "#FFFFFF"}
        style={{ color: props?.color || "#FFFFFF" }}
        width={20}
        height={20}
      />
    </div>
  );
}
