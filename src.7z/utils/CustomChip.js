import React from "react";
import useAutocomplete from '@mui/material/useAutocomplete';
import NoSsr from "@mui/material/NoSsr";
import CloseIcon from "@mui/icons-material/Close";
import styled from "styled-components";
import makeStyles from '@mui/styles/makeStyles';
import { generateUniqueId } from "./common";
import { Typography } from "@mui/material";

const useStyles = makeStyles((theme) => ({
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
}));

const Label = styled("label")`
  padding: 0 0 4px;
  font-size: 12px;
  line-height: 1.5;
  display: block;
  font-size: 12px;
  color: #606060;
  opacity: 1;
  font-weight: 500;
  
`;
//width: 300px;
const InputWrapper = styled("div")`
  
  border: 1px solid #c4c4c4;
  background-color: #fff;
  border-radius: 2px;
  padding: 1px;
  display: flex;
  flex-wrap: wrap;
  align-items: center;

  &:hover {
    border-color: #000000;
  }

  &.focused {
    border-color: #005EA3; 
  }

  & input {
    font-size: 12px;

    height: 24px;
    box-sizing: border-box;
    padding: 4px 6px;
    width: 0;
    min-width: 30px;
    flex-grow: 1;
    border: 0;
    margin: 0;
    outline: 0;
  }
`;

const Tag = styled(({ label, onDelete, disabled, classes, ...props }) => (
  <div {...props} style={{ overflow: "auto" }}>
    <span>{label}</span>
    {!disabled && <CloseIcon
      onClick={onDelete}
      tabIndex={0}
      className={classes.focusVisible}
      onKeyPress={(e) => e.key === "Enter" && onDelete(e)}
      role="button"
      id={`RPA_CustomChip_${generateUniqueId()}`}
    />}
  </div>
))`
  display: flex;
  align-items: center;
  height: 24px;
  margin: 2px;
  line-height: 22px;
  font-size: 12px;
  background-color: #ffbb0029;
  border: 1px solid #e8e8e8;
  border-radius: 2px;
  box-sizing: content-box;
  padding: 0 4px 0 5px;
  outline: 0;
  overflow: hidden;

  &:focus {
    border-color: #40a9ff;
    background-color: #e6f7ff;
  }

  & span {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }

  & svg {
    font-size: 12px;
    cursor: pointer;
    padding: 4px;
  }
`;

const Listbox = styled("ul")`
  width: 300px;
  margin: 2px 0 0;
  padding: 0;
  position: absolute;
  list-style: none;
  background-color: #fff;
  overflow: auto;
  max-height: 250px;
  border-radius: 4px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 1;

  & li {
    padding: 5px 12px;
    display: flex;

    & span {
      flex-grow: 1;
    }

    & svg {
      color: transparent;
    }
  }

  & li[aria-selected="true"] {
    background-color: #fafafa;
    font-weight: 600;

    & svg {
      color: #1890ff;
    }
  }

  & li[data-focus="true"] {
    background-color: #e6f7ff;
    cursor: pointer;

    & svg {
      color: #000;
    }
  }
`;

const CustomChip = (props) => {
  const {
    id,
    handleOnChange,
    tags,
    tag,
    name,
    handleKeyDown,
    onDeleteTag,
    helperText,
    width,
    error = false,
    errorText = "",
    height = 24,
    disabled
  } = props;
  const {
    getRootProps,
    getInputLabelProps,
    getInputProps,
    getTagProps,
    focused,
    setAnchorEl,
  } = useAutocomplete({
    id: "Custom-chips",
    defaultValue: [],
    multiple: true,
    options: [],
    onChange: handleOnChange,
    disabled: disabled
  });
  const classes = useStyles();

  return (
    <NoSsr>
      <div style={{ width: width }}>
        <div {...getRootProps()} role={undefined}>
          <Label {...getInputLabelProps()}>{props.label || ""}</Label>
          <InputWrapper
            ref={setAnchorEl}
            //Bug 151144 - Create service flow modal
            //Author : nitin_tomar
            //Date :  09 JAN 2024
            //Description : Tag filed call is updated with border details
            className={focused ? "focused" : ""}
            style={{ width: width }}
          >
            {tags.map((option, index) => (
              <Tag
                id={`${id}_${option}`}
                label={option}
                {...getTagProps({ index })}
                onDelete={() => onDeleteTag(index)}
                classes={classes}
                disabled={disabled}
              />
            ))}

            <input
              {...getInputProps()}
              value={tag}
              name={`${name}`}
              onChange={handleOnChange}
              onKeyDown={handleKeyDown}
              style={{ height: height }}
            />
          </InputWrapper>
          {error && <p style={{ marginTop: "8px", color: "red", fontSize: 12 }}>
            {errorText}
          </p>}
          <div style={{ marginTop: "8px" }}>
            <Typography style={{ color: "#767676" }}> {helperText || ""}</Typography>
          </div>
        </div>
      </div>
    </NoSsr>
  );
};
export default CustomChip;
