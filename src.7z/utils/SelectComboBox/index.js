/* eslint-disable no-use-before-define */
import React, { useState } from "react";
import useAutocomplete from "@mui/material/useAutocomplete";
import NoSsr from "@mui/material/NoSsr";
import { Grid } from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";
import CheckIcon from "@mui/icons-material/Check";
import CloseIcon from "@mui/icons-material/Close";
import styled from "styled-components";
import { ExpandMore } from "@mui/icons-material";
import { AddNewVariableIcon } from "../AllImages";
import { useStyles } from "./../../components/script-editor/PropertyWindow/AllActivityWindows/Common/CommonStyles";
import AddVariableModal from "../../components/modals/AddVariableModal";
import { generateUniqueId, truncateStringValues } from "../common";
import CustomTooltip from "../CustomTooltip";
const Label = styled("label")`
  padding: 0 0 4px;
  display: block;
  color: #606060;
  font-size: 12px;
  font-weight:600;
`;

//width: 320px;
/**
 *  border:${(props) => {
    return props.error ? "1px solid #FF0000" : "1px solid #d9d9d9";
  }}

    border-color: #40a9ff;

     &.focused {
    border-color: #40a9ff;
    //box-shadow: 0 0 0 2px rgba(24, 144, 255, 0.2);
    border-color: ${(props) => {
      return props.error ? "#FF0000;" : "#40a9ff;";
    }}
  }

 */

const InputWrapper = styled("div")`
  width: ${(props) => {
    // console.log(props.width);
    return props.width ? `${props.width - 15}px;` : "320px;";
  }};
 
  border:${(props) => {
    return props.error ? "1px solid #FF0000;" : "1px solid #d9d9d9;";
  }}
  background-color: #fff;
  border-radius: 2px;
  padding: 1px;
  display: flex;
  flex-wrap: wrap;

  &:hover {
   border-color: ${(props) => {
    return props.error ? "#FF0000;" : "#40a9ff;";
  }}
  }

  &.focused {
    border-color: ${(props) => {
    return props.error ? "#FF0000;" : "#40a9ff;";
  }}
  }

  & input {
    font-size: 12px;
    height: 28px;
    box-sizing: border-box;
    padding: 4px 6px;
    width: 0;
    min-width: 230px

    border: 0;
    margin: 0;
    outline: 0;
  }
`;
//input min-width: 230px; min-width: 100px;
const Tag = styled(({ label, onDelete, classes, ...props }) => {
  const [isHovering, setIsHovering] = useState(false)
  return (
    <div
      {...props}
      style={{
        maxWidth: props.width ? props.width - 50 : "225px",
        // minWidth: props.width ? props.width - 103 : "225px",
        overflow: "auto",
      }}
      title={label || ""}
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      <span>
        {props.width < 140
          ? truncateStringValues({ str: label, max: 7, min: 5 })
          : props.width < 200
            ? truncateStringValues({ str: label, max: 22, min: 19 })
            : truncateStringValues({ str: label, max: 35, min: 28 })}
      </span>
      {isHovering && <CloseIcon
        onClick={(e) => {
          const item = { target: { name: props.name, value: "" } };
          props.handleChangefn(item);
          e.stopPropagation();
        }}
        style={{ marginLeft: "auto" }}
        //WCAG Keyboard Accessible: [21-06-2023] Added tabIndex, onKeyPress and style
        tabIndex={0}
        onKeyPress={(e) => {
          if (e.key === "Enter") {
            const item = { target: { name: props.name, value: "" } };
            props.handleChangefn(item);
            e.stopPropagation();
          }
        }}
        className={classes.focusVisible}
        role="button"
        id={`RPA_Tag_${generateUniqueId()}`}
        aria-hidden="false"
      />}
    </div>
  );
})`
  display: flex;

  align-items: center;
  height: 22px;

  line-height: 22px;
  background-color:#F8F8F8;
  border: 1px solid #E9E9E9;
  border-radius: 2px;
  box-sizing: content-box;
  padding: 0 4px 0 6px;
  margin:2px;
  outline: 0;
  overflow: hidden;

  &:focus {
    border-color: #40a9ff;
    background-color: #e6f7ff;
  }

  & span {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    font-size: 12px;
  }

  & svg {
    font-size: 12px;
    cursor: pointer;
    padding: 4px;
  }
`;

//width: 320px;=>display:flex
/**
 *  min-width: 200px;
  display: flex;
  flex-direction: column;
 */
const Listbox = styled("ul")`
  width: ${(props) => {
    return props.width ? `${props.width - 15}px;` : "320px;";
  }};

  margin: 2px 0 0;
  padding: 0;
  position: absolute;
  list-style: none;
  background-color: #fff;
  overflow: auto;
  max-height: 250px;
  border-radius: 2px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  z-index: 1;

  & li {
    padding: 5px 6px;
    display: flex;

    & span {
      flex-grow: 1;
    }

    & svg {
      color: transparent;
    }
  }

  & li[aria-selected="true"] {
    background-color: #fafafa;
    font-weight: 600;

    & svg {
      color: #1890ff;
    }
  }

  & li[data-focus="true"] {
    background-color: #e6f7ff;
    cursor: pointer;

    & svg {
      color: #000;
    }
  }
`;

const SelectComboBox = (props) => {
  const [open, setOpen] = useState(false);
  // const [showInfoMessage, setShowInfoMessage] = useState(false);
  const [showMessage, setShowMessage] = useState(false);
  const showInfoMessage = () => {
    setShowMessage(true);
    // setTimeout(() => setShowMessage(false), 5000);
  };
  const {
    handleOnChange = () => {
      console.log("pls provide handleOnChange fn");
    },
    handleChange = () => {
      console.log("pls provide handleOnChange fn");
    },
    value,
    name,
    label,
    paramObj,
    dropdown = false,
    readOnly = false,
    secret = false,
    type = "text",
    endAdornment = null,
    helperText = "",
    helperTextColor="#606060",
    varType,
    canType = false,
    error,
    id,
    hideSubDescription = false,
  } = props;
  const classes = useStyles({helperTextColor:helperTextColor});

  const handleCloseModal = () => {
    setOpen(false);
  };
  const {
    getRootProps,
    getInputLabelProps,
    getInputProps,
    getTagProps,
    getListboxProps,
    getOptionProps,
    groupedOptions,
    focused,
    value: autoValue,
    setAnchorEl,
  } = useAutocomplete({
    // id: "customized-hook-demo",
    openOnFocus: true,
    value: value,
    multiple: false,
    options: props.options || [],
    getOptionSelected: (option, valueTest) => {
      return (option.value === value &&
        paramObj &&
        paramObj?.paramType === "V" || paramObj?.paramVariableType === "V") ||
        typeof value === "number"
        ? option.value === value && dropdown
        : option.value === +value && dropdown;
    },

    getOptionLabel: (option) => {
      return typeof option === "string" || option instanceof String
        ? option
        : "";
    },
    onChange: (e, v, r) => {
      handleOnChange(e, v);
    },
    onInputChange: (e, v, r) => { },
  });

  const OnSuccess = (variable) => {
    if (variable) {
      handleOnChange(undefined, { value: variable.variableName });
    }
  };
  return (
    <NoSsr>
      <Grid container>
        <Grid item xs>
          <div
            {...getRootProps()}
            role={undefined}
          // onMouseEnter={() => setShowInfoMessage(true)}
          // onMouseLeave={() => setShowInfoMessage(false)}
          >
            {label ? (
              <Label {...getInputLabelProps()} style={{ display: 'flex', alignItems: 'center' }}>
                {label || ""}{" "}
                {/* {props.infoMessage &&
                showInfoMessage && (
                    <span style={{ marginLeft: "8px", color: "#0072C6" }}>
                      {props.infoMessage}
                    </span>
                  )} */}
                {props.infoMessage && (
                  <Grid item>
                    <CustomTooltip
                      open={showMessage}
                      title={props.infoMessage}
                      placement="top"
                    >
                      <a
                        tabIndex={0}
                        onFocus={() => setShowMessage(true)}
                        onBlur={() => setShowMessage(false)}
                        onMouseEnter={() => setShowMessage(true)}
                        onMouseLeave={() => setShowMessage(false)}

                      >
                        <InfoIcon
                          style={{
                            height: "2.5vh",
                            cursor: "pointer",
                            paddingLeft: "0.1vw",
                            width: "2vw",
                            marginTop: "5px"
                          }}
                          onClick={showInfoMessage}
                        />
                      </a>
                    </CustomTooltip>
                  </Grid>
                )}
              </Label>
            ) : (
              <Label
                {...getInputLabelProps()}
                className={classes.visuallyhidden}
              >
                {name}
              </Label>
            )}

            <InputWrapper
              ref={setAnchorEl}
              //className={focused ? "focused" : ""}
              tabIndex={0}
              className={classes.focusVisible}
              width={props.width}
              error={error}
              style={{ position: "relative" }}
            >
              {props.options?.find(
                (item) => item.value === value || item.value === +value
              ) &&
                (paramObj?.paramType === "V" || paramObj?.paramVariableType === "V" || dropdown) && (
                  <Tag
                    label={
                      props.options?.find(
                        (item) => item.value === value || item.value === +value
                      )?.name || value
                    }
                    {...getTagProps({
                      index: props.options?.findIndex(
                        (item) => item.value === value || item.value === +value
                      ),
                    })}
                    name={name}
                    handleChangefn={handleChange}
                    width={props.width}
                    classes={classes}
                  />
                )}

              <input
                {...getInputProps()}
                tabIndex={0}
                //className={classes.focusVisible}
                name={`${name}`}
                type={secret ? "password" : type}
                //  value={typeof value === "boolean" ? "" : value}
                value={
                  props.options?.find(
                    (item) => item.value === value || item.value === +value
                  ) &&
                    (paramObj?.paramType === "V" || paramObj?.paramVariableType === "V" || dropdown)
                    ? ""
                    : typeof value === "boolean"
                      ? ""
                      : value
                }
                readOnly={
                  (dropdown &&
                    props.options?.find(
                      (item) => item.value === value || item.value === +value
                    )) ||
                  readOnly ||
                  (dropdown && !canType)
                }
                onChange={handleChange}
                style={{
                  /*  minWidth:
                    props.options?.find(
                      (item) => item.value === value || item.value === +value
                    ) &&
                    (paramObj?.paramType === "V" ||paramObj?.paramVariableType==="V" || dropdown)
                      ? "0px"
                      : // : "200px",
                      endAdornment
                      ? "220px"
                      : props.width - 40 || "270px",*/
                  /* visibility:
                    props.options?.find(
                      (item) => item.value === value || item.value === +value
                    ) &&
                    (paramObj?.paramType === "V" ||paramObj?.paramVariableType==="V" || dropdown)
                      ? "hidden"
                      : "visible",*/
                  minWidth:
                    props.options?.find(
                      (item) => item.value === value || item.value === +value
                    ) &&
                      (paramObj?.paramType === "V" || paramObj?.paramVariableType === "V" || dropdown)
                      ? props.width > 240 || !props.width
                        ? "70px"
                        : "20px"
                      : // : "200px",
                      endAdornment
                        ? "240px"
                        : props.width - 35 || "302px",
                  border: "None",
                }}
                //placeholder={props.placeholder}
                placeholder={props.options?.find(
                  (item) => item.value === value || item.value === +value
                ) &&
                  (paramObj?.paramType === "V" || paramObj?.paramVariableType === "V" || dropdown)
                  ? ""
                  : typeof value === "boolean"
                    ? ""
                    : props.placeholder}
              />
              {endAdornment && (
                <span style={{ marginTop: "5px" }}>{endAdornment}</span>
              )}
              <ExpandMore
                style={{
                  zIndex: 0,
                  position: "absolute",
                  marginTop: "5px",
                  right: "8px",
                  pointerEvents: "none",
                  cursor: "pointer",
                }}
              />
            </InputWrapper>
            <div
              className={error ? classes.helperTextErr : classes.helperText}
              style={{ marginTop: "8px" }}
            >
              {helperText}
            </div>
          </div>
          {/*****************************************************************************************
           * @author asloob_ali BUG ID : 105936 Description : 105936 - Variable: There is no option to create variable from property window when there is no variable defined in script
           *  Reason:when options list was empty , we were not showing the option to add variable as well.
           * Resolution : in case of option list is empty , add variable option will be visible to the user.
           *  Date : 01/03/2022             ****************************************
           *
           *   {groupedOptions.length > 0 ||
          (focused && props.options.length === 0) ?
           */}
          {(groupedOptions.length > 0 && (dropdown || paramObj)) ||
            (focused && (dropdown || paramObj) && props.options.length === 0) ? (
            <Listbox {...getListboxProps()} width={props.width}>
              {paramObj && (
                <li style={{ paddingTop: "8px", cursor: "pointer", alignItems: 'center' }}
                onClick={() => setOpen(true)}
                >
                  <AddNewVariableIcon
                    htmlColor="#0072C6"
                    style={{
                      height: "16px",
                      width: "16px",
                      color: "#0072C6",

                    }}
                  //  onClick={() => setOpen(true)}
                    className={classes.focusVisible}
                    id="RPA_Select_AddIcon"
                  />
                  <span style={{ color: "#0072C6", marginLeft: '8px', fontSize: '12px' }}>Add Variable</span>

                </li>
              )}
              {groupedOptions.filter((item) =>
                item?.name?.toString()?.includes(autoValue || "")
              ).length === 0 && (
                  <li>
                    <span style={{ color: "#606060" }}>No variable found</span>
                  </li>
                )}
              {groupedOptions.map(
                (option, index) =>
                  option?.name?.toString()?.includes(autoValue || "") && (
                    <React.Fragment key={index}>

                      <li {...getOptionProps({ option, index })} style={{ pointerEvents: option?.disabled ? 'none' : 'auto', cursor: option?.disabled ? 'default' : 'pointer', backgroundColor: option?.disabled ? "#f7f7f7" : "" }}>
                        <Grid container direction="column">
                          <Grid item container direction="row">
                            <Grid item xs={7} title={option.name || ""}>
                              {/*truncateString(option.name || "")*/}

                              {props.width < 140
                                ? truncateStringValues({
                                  str: option.name.toString() || "",
                                  max: 12,
                                  min: 7,
                                })
                                : props.width < 200
                                  ? truncateStringValues({
                                    str: option.name.toString() || "",
                                    max: 24,
                                    min: 21,
                                  })
                                  : truncateStringValues({
                                    str: option.name.toString() || "",
                                    max: 35,
                                    min: 28,
                                  })}
                            </Grid>
                            <Grid item style={{ marginLeft: "auto" }}>
                              <CheckIcon fontSize="small" htmlColor="#0072C6" />
                            </Grid>
                          </Grid>
                          {option.description && (
                            <Grid item style={{ fontSize: '12px', color: '#606060' }}>{option.description}{!hideSubDescription && option.subDescription && `(${option.subDescription})`}</Grid>
                          )}
                        </Grid>
                        {/* <span>{option.name}</span>
                    {option.description && (
                      <div
                        style={{
                          display: "flex",
                          flexGrow: 1,
                          flexDirection: "column",
                          justifyItems: "center",
                        }}
                      >
                        {option.description}
                      </div>
                    )}
                      <CheckIcon fontSize="small" htmlColor="#0072C6" />*/}
                      </li>
                    </React.Fragment>
                  )
              )}
            </Listbox>
          ) : null}
          {open && (
            <AddVariableModal
              id="RPA_AddVariableModal"
              handleClose={handleCloseModal}
              isOpen={open}
              varType={varType}
              OnSuccess={OnSuccess}
            />
          )}
        </Grid>
      </Grid>
    </NoSsr>
  );
};
export default SelectComboBox;
