import React, { Fragment } from "react";
import { Typography, Grid, Tab, Tabs } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';

  /**
     * @author sanya.mahajan For Bug 155811 - UX - Shared with me folder - tabs not correct on screen
     * Description: Updated the styling as per the figma
     * Date : 03/02/2025             
     * */
const useStyles = makeStyles((theme) => ({
  selectedTab: {
    fontWeight: 400,
    borderBottom: `2px solid ${theme.palette.primary.main}`,
    paddingBottom:"4px",
  },
  tabs: {
    cursor: "pointer",
  },
  selectedItem: {
    fontWeight: 400,
  },
  tab: {
    color: "#000000",
    paddingBottom:"4px",
    fontSize:"12px",
    padding: "12px 12px", // Default padding for all except first
    "&:first-child": {
      paddingLeft: 0, // Remove left padding for the first tab
    },
    minWidth:"auto",
    width:"auto",
  },
  indicator: {
    backgroundColor: theme.palette.primary.main, 
    height: "2px", 
    width: "fit-content",
  },
}));

const CustomTabs = ({
  tabItems = [],
  selectedTab,
  handleTabChange = () => console.log("handleTabChange fn not provided."),
  className,
  justify = "space-between",
  id,
}) => {
  const classes = useStyles();
  return (
  
     <Grid container alignItems={"flex-start"}>
      <Grid item>
      <Tabs
      value={selectedTab}
      onChange={(event, newValue) => handleTabChange(newValue)}
      //indicatorColor="primary"
      textColor="primary"
      // For Bug 155811 - UX - Shared with me folder - tabs not correct on screen
      variant="standard"
      classes={{ indicator: classes.indicator }}
    >


      {tabItems.map((tabItem,i) => (
        <Tab
          value={tabItem}
          label={tabItem}
          key={`${id}_${i}`}
          // For Bug 155811 - UX - Shared with me folder - tabs not correct on screen
          className={`${classes.tab} ${selectedTab === tabItem ? classes.selectedTab : ""}`}
          sx={{ minWidth: "auto", width: "auto", display: "inline-flex" }}
        />
        
      ))}
    </Tabs>
      </Grid>
      </Grid>
   
    /* </Grid>*/
  );
};

export default CustomTabs;
