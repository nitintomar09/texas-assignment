import React, { useContext, useState, useEffect } from "react";
import { Typography, Grid, Box, IconButton } from "@mui/material";
import makeStyles from '@mui/styles/makeStyles';
import { Close } from "@mui/icons-material";
import Snackbar from "@mui/material/Snackbar";
import Alert from '@mui/material/Alert';
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import InfoIcon from "@mui/icons-material/Info";
//import "./Toast/index.css";
import "../utils/Toast/index.css";

import Slide from "@mui/material/Slide";

import { NotificationContext } from "../contexts/NotificationContext";
import { ToastSuccessIcon, ToastErrorIcon,ToastWarningIcon,ToastInfoIcon, SuccessCross, ErrorCross,WarningCross,InfoCross} from "./AllImages";

const useStyles = makeStyles((theme) => ({
  container: {
    marginTop: "50px",
    alignContent: "center",
    height: "30px",
  },
  error: {
    backgroundColor: "red",
    borderRadius: "12px",
    boxShadow: "1px 3px 10px #00000040",
    paddingLeft: "15px",
    paddingRight: "15px",
  },
  success: {
    backgroundColor: "#C9E29A",
    borderRadius: "12px",
    boxShadow: "1px 3px 10px #00000040",
    height:"41px",
    paddingLeft: "15px",
    paddingRight: "15px",
  },
  unavailable: {

  },
  title: {
    fontSize: "12px",
    color: "#FFFFFF",
    fontWeight: "bold",
  },
  message: {
    fontSize: "12px",
    color: "#FFFFFF",
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
    },
  },
}));
const Notification = (props) => {
  const { value, setValue } = useContext(NotificationContext);
  const { isOpen, title, message, notificationType, onClose, anchorOrigin } = value;

  /*const [state, setState] = useState({
    Transition: Slide,
  });*/

  const classes = useStyles();
  let cssClass = null;

  const handleClose = () => {
    /*  setState({
      ...state,
    });*/
    setValue({
      isOpen: false,
      message: null,
      notificationType: null,
      title: null,
    });
    onClose ? onClose() : console.log("null");
  };


  switch (notificationType) {
    case "ERROR":
      cssClass = classes.error;
      break;
    case "SUCCESS":
      cssClass = classes.success;
      break;
    default:
      break;
  }
  const getCloseIcon = (notificationType) => {
    switch (notificationType) {
      case "SUCCESS":
        return <SuccessCross />;
      case "ERROR":
        return <ErrorCross />;
      case "WARNING":
        return <WarningCross />;
      case "INFO":
        return <InfoCross/>;
      default:
        return null;  
    }
  };

  return (
    <div>
      {["SUCCESS", "ERROR"].includes(notificationType) && <Snackbar
        open={isOpen}
        /**
@author - akshat.pokhriyal
@Date - 10/01/2024
@Bug Id - 142396
@Bug Description - when we get error pop-up it' should be automatic close in few seconds .
@Bug Reason of occurence - onClose was not provided
@Solution - added auto-close feature
**/

    
     /**Bug 155834 - UX Toast message position
        Author: Sanya Mahajan
        Date: 24th January, 2025
        Resolution: Updated the position for toast messages and updated all the icons as per the NODS */

        onClose={notificationType === "SUCCESS" ? handleClose : null}
        // TransitionComponent={state.Transition}
        anchorOrigin={anchorOrigin || {  vertical: "top", horizontal: "center"}
        } autoHideDuration={notificationType === "SUCCESS" ? 6000 : null}
        tabIndex={0}
        className={classes.focusVisible}
        role="alert"
      >
        <Alert
          iconMapping={{
            success: <ToastSuccessIcon/>,
            error: <ToastErrorIcon />,
            warning: <ToastWarningIcon />,
            info: <ToastInfoIcon />,
          }}
          onClose={handleClose}
          severity={notificationType?.toLowerCase()}
          tabIndex={0}
          className={classes.focusVisible}
          action={
            <IconButton
              size="small"
              color="inherit"
              onClick={handleClose}
            >
              {getCloseIcon(notificationType)} 
            </IconButton>
          }
        >
          {message}
        </Alert>
      </Snackbar>}
    </div>
  );
};

export default Notification;
