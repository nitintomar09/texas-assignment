import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import Tooltip from "@mui/material/Tooltip";

const useStyles = makeStyles((theme) => ({
  arrow: {
    // color: "#E6E6E6",
    // Color: "#C4C4C4",
    color: "#b5b5b5",
  },
  tooltip: {
    backgroundColor: "#FFFFFF",
    fontSize: "12px",
    color: "#000000",
    border: "1px solid #C4C4C4",
    borderRadius: "2px",
  },
}));

const CustomTooltip = (props) => {
  const classes = useStyles();

  return <Tooltip arrow classes={classes} {...props} />;
};
export default CustomTooltip;
