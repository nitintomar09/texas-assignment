export const isEmpty = (string) => {
  if (string.trim() === "") {
    return { status: true, msg: "This field is required" };
  }
  return { status: false, msg: "" };
};

export const isMobile = (string) => {
  if (string.trim().length !== 10) {
    return { status: true, msg: "Invalid mobile number" };
  }
  return { status: false, msg: "" };
};

export const isEmptyText = (string) => {
  if (("" + string).trim().length === 0) {
    // Changes error message to resolve the bug Id 142367
    return "This field is required.";
  }
  return "";
};
export const MaximumLengthText = (str, length) => {
  if (typeof str === "string" || str instanceof String) {
    return str.trim().length > length
      ? `Maximum ${length} characters are allowed.`
      : "";
  } else {
    return "";
  }
};
export const MinimumLengthText = (str, length) => {
  if (typeof str === "string" || str instanceof String) {
    return str.trim().length < length
      ? `There should be Minimum ${length} characters.`
      : "";
  } else {
    return "";
  }
};
export const isContainSpecialCharacters = (str) => {
  const regex = /^[A-Za-z0-9_.]+$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str)
      ? `Special Characters except ( _ and . ), and Spaces are not allowed.`
      : "";
  } else {
    return "";
  }
};

export const isContainSpecialCharactersForServiceFlow = (str) => {
  //const regex = /^[A-Za-z0-9][\w.]*[A-Za-z0-9]+$/;
  const regex = /^[A-Za-z0-9](?!.*\s$)[A-Za-z0-9_.]{0,38}[A-Za-z0-9]$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str)
      ? `The name must be 2 to 40 characters long. It cannot start and end with special characters, and spaces are not allowed at the beginning or end.`
      : "";
  } else {
    return "";
  }
};


// BugId:Bug 142390 - Project Name should be combination of character and special character
// Author:Dixita
// Date:24-01-2024
// RCA:New Regex old validation is not working

export const isContainSpecialCharactersForProject = (str) => {
  //const regex = /^[A-Za-z0-9][\w.]*[A-Za-z0-9]+$/;
  const regex = /^[A-Za-z0-9](?!.*\s$)[A-Za-z0-9_.]{0,38}[A-Za-z0-9]$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str)
      ? `The name must be 2 to 40 characters long. It cannot start and end with special characters, and spaces are not allowed at the beginning or end.`
      : "";
  } else {
    return "";
  }
};

export const onlyFloatNumbersWithOneDecPoint = (str) => {
  const regex = /^\d+\.\d{0,1}$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str)
      ? `Only float numbers are alowed with only one decimal point.`
      : "";
  } else {
    return "";
  }
};
export const isContainSpecialCharacters2 = (str) => {
  const regex = /^[A-Za-z0-9_]+$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str)
      ? `Special Characters except ( _ ), and Spaces are not allowed.`
      : "";
  } else {
    return "";
  }
};
export const isContainSpecialCharacters3 = (str) => {
  const regex = /^[A-Za-z0-9 ]+$/;
  if (
    (typeof str === "string" || str instanceof String) &&
    str.trim().length > 0
  ) {
    return !regex.test(str) ? `Special Characters are not allowed.` : "";
  } else {
    return "";
  }
};
export const onlyLettersAndUnderscore = (str) => {
  const regex = /^[A-Za-z_]+$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str)
      ? `Special Characters except ( _ ), numbers and Spaces are not allowed.`
      : "";
  } else {
    return "";
  }
};
export const atleastContainsACharacter1 = (str) => {
  const regex = /^[A-Za-z0-9 ]*[a-zA-Z][A-Za-z0-9 ]*$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str) ? `should contain atleast one character.` : "";
  } else {
    return "";
  }
};
export const atleastContainsACharacter = (str) => {
  const regex = /^[A-Za-z_]*[a-zA-Z][A-Za-z_]*$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str) ? `should contain atleast one character.` : "";
  } else {
    return "";
  }
};

export const validateDirName = (str) => {
  const regex = /^(?:[\w]\:|\\)(\\[a-z_\-\s0-9\.]+)+\.(json)$/;
  if (typeof str === "string" || str instanceof String) {
    return !regex.test(str) ? `Please enter valid json file path.` : "";
  } else {
    return "";
  }
};

export const vaildateParamValue = (string) => {
  if (typeof string === "string" && string.trim() === "") {
    return { errorStatus: true, msg: "This is required field." };
  }
  return { errorStatus: false, msg: "" };
};
