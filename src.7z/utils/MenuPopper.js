import React, { useEffect } from "react";
import ClickAwayListener from "@mui/material/ClickAwayListener";
import Grow from "@mui/material/Grow";
import Paper from "@mui/material/Paper";
import Popper from "@mui/material/Popper";
import MenuItem from "@mui/material/MenuItem";
import MenuList from "@mui/material/MenuList";
import makeStyles from "@mui/styles/makeStyles";
import { MoreVert } from "@mui/icons-material";
import { Typography, Grid, IconButton } from "@mui/material";
import { UniqueIDGenerator } from "./UniqueIDGenerator";

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    zIndex: 3,
  },
  menuItems: {
    height: 24,
    fontSize: "12px",
    paddingLeft: "8px",
    paddingRight: "8px",
  },
  icon: {
    cursor: "pointer",
    height: "18px",
    borderRadius: "2px",
  },
  focusVisible: {
    //for WCAG - Keyboard accessible
    outline: "none",
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  moreVerticalIcon: {
    cursor: "pointer",
    height: "14px",
    width: "14px",
  },
}));

export default function MenuPopper(props) {
  console.log(props, "iconBurop");
  const classes = useStyles();
  const {
    id = "MenuPopper",
    handleSelectedItem = () =>
      console.log("please provide handleSelectedItem fn"),
    items = [],
    selfClicked,
    MenuIcon,
    placement = "right-start",
    color = "inherit",
    className = null,
    returnSelectedObject = false,
  } = props;
  const [open, setOpen] = React.useState(false);
  const anchorRef = React.useRef(null);

  const handleToggle = (e) => {
    e.preventDefault();
    setOpen((prevOpen) => !prevOpen);
    e.stopPropagation();
  };

  const handleClick = (e, item) => {
    handleSelectedItem(e, item, selfClicked);
    handleClose(e);
  };
  const handleClose = (event) => {
    if (anchorRef.current && anchorRef.current.contains(event.target)) {
      return;
    }

    setOpen(false);
  };

  function handleListKeyPress(event) {
    if (event.key === "Escape" || event.key === "Tab") {
      event.preventDefault();
      setOpen(!open);
    } else if (event.key === "Enter") {
      //handleClick(event, event.target.querySelector("p").innerHTML);
    } else {
      event.stopPropagation();
    }
  }
  function handleListKeyPressItem(event, item) {
    event.stopPropagation();
    if (event.key === "Escape" || event.key === "Tab") {
      event.preventDefault();
    } else if (event.key === "Enter") {
      if (returnSelectedObject && typeof item === "object") {
        handleClick(event, item);
      } else if (typeof item === "object") {
        handleClick(event, item.name);
      } else {
        handleClick(event, item);
      }
    } else {
      event.stopPropagation();
    }
  }
  function handleListKeyDown(event) {
    if (event.key === "Escape" || event.key === "Tab") {
      event.preventDefault();
      setOpen(false);
    }
  }

  return (
    <div className={classes.root}>
      {MenuIcon ? (
        <IconButton
          data-testid="menuPopper"
          ref={anchorRef}
          aria-controls={open ? "menu-list-grow" : undefined}
          aria-haspopup="true"
          onClick={handleToggle}
          onKeyPress={(e) => e.key == "Enter" && handleToggle(e)}
          //role="button"
          // aria-hidden="false"
          aria-label="Action menu"
        >
          <MenuIcon
            color={color}
            className={className ? className : [classes.icon].join(" ")}
            // //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
            // tabIndex={0}
            // onKeyPress={(e) => e.key == "Enter" && handleToggle(e)}
            // id={id}
            // role="button"
            // aria-hidden="false"
          />
        </IconButton>
      ) : (
        <IconButton
          data-testid="menuPopper"
          ref={anchorRef}
          aria-controls={open ? "menu-list-grow" : undefined}
          aria-haspopup="true"
          onClick={handleToggle}
          onKeyPress={(e) => e.key == "Enter" && handleToggle(e)}
          id={id}
          //  role="button"
          // aria-hidden="false"
          aria-label="Action menu"
        >
          <MoreVert
            // data-testid="menuPopper"
            // ref={anchorRef}
            // aria-controls={open ? "menu-list-grow" : undefined}
            // aria-haspopup="true"
            // onClick={handleToggle}
            //style={{ cursor: "pointer", height: "14px",width:'14px' }}
            // //WCAG - Keyboard Accessible: Provided tabIndex and onKeyPress
            // tabIndex={0}
            // onKeyPress={(e) => e.key == "Enter" && handleToggle(e)}
            className={classes.moreVerticalIcon}
            // id={id}
            // role="button"
            // aria-hidden="false"
          />
        </IconButton>
      )}

      <Popper
        open={open}
        anchorEl={anchorRef.current}
        role={undefined}
        transition
        disablePortal
        placement={placement}
        style={{ zIndex: 10 }}
      >
        {({ TransitionProps, placement }) => (
          <Grow
            {...TransitionProps}
            style={{
              transformOrigin: placement === "center top",
            }}
          >
            <Paper square elevation={4} tabIndex={-1}>
              <ClickAwayListener onClickAway={handleClose}>
                <MenuList
                  autoFocusItem={open}
                  id="menu-list-grow"
                  onKeyPress={handleListKeyPress}
                  onKeyDown={handleListKeyDown}
                  style={{ border: "1px solid #DEDEDE", minWidth: "4rem" }}
                  className={classes.focusVisible}
                >
                  {items.map((item, index) => (
                    <div
                      key={index}
                      className={classes.focusVisible}
                      tabIndex={-1}
                    >
                      <MenuItem
                        id={`${id}_${
                          typeof item === "object" ? item.name : item
                        }`}
                        onClick={
                          typeof item === "object"
                            ? (e) =>
                                returnSelectedObject
                                  ? handleClick(e, item)
                                  : handleClick(e, item.name)
                            : (e) => handleClick(e, item)
                        }
                        key={typeof item === "object" ? item.name : item}
                        className={classes.menuItems}
                      >
                        <Grid container spacing={1} alignItems="center">
                          {item.icon && (
                            <Grid item>
                              <IconButton size="small">{item.icon}</IconButton>
                            </Grid>
                          )}

                          <Grid item>
                            <Typography
                              style={{
                                fontSize: "12px",
                                color:
                                  item === "Delete" ? "#df5a5a" : "initial",
                              }}
                            >
                              {item.name}
                            </Typography>
                          </Grid>
                        </Grid>
                      </MenuItem>
                    </div>
                  ))}
                </MenuList>
              </ClickAwayListener>
            </Paper>
          </Grow>
        )}
      </Popper>
    </div>
  );
}
