import * as React from "react";
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Button,
} from "@mui/material";
import customStyles from "../../assets/css/customStyle";

const DialogBox = ({
  open,
  handleClose,
  btn1Title,
  onClick1,
  onClick2,
  content,
  title,
}) => {
  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle id="alert-dialog-title">
          {title || "Alert Dialog Title"}
        </DialogTitle>
        <DialogContent>
          {/* <DialogContentText id="alert-dialog-description">
            Let Google help apps determine location. This means sending
            anonymous location data to Google, even when no apps are running.
  </DialogContentText>*/}
          {content}
        </DialogContent>
        <DialogActions>
          <Button
            style={customStyles.btn1}
            variant="outlined"
            size="small"
            onClick={onClick1}
          >
            {btn1Title}
          </Button>
          <Button
            onClick={onClick2}
            style={{ fontSize: "12px" }}
            variant="contained"
            size="small"
            color="primary"
            autoFocus
          >
            btn2Title
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};
export default DialogBox;
