import React from "react";
import ReactDOMServer from "react-dom/server";
import { updateSvgIds } from "./common";
import { generateUniqueId } from "./common";

export const UniqueIDGenerator = (props) => {
  const orgProps = props.children.props;
  const componentString = ReactDOMServer.renderToString(props.children);
  const uniqueId = updateSvgIds(componentString, generateUniqueId());
  return React.cloneElement(uniqueId, {
    onClick: orgProps.onClick,
    onKeyPress: orgProps.onKeyPress,
  });
};
