import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import { TextField, InputAdornment, IconButton, Icon } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
const useStyles = makeStyles((theme) => ({
  search_box: {
    height: "24px",
    width: "288px",
    border: "1px solid #D8D8D8",
    marginTop: 8,
    paddingLeft: 2,
    paddingRight: 0,
    fontSize: 12,
    position: "relative",
    marginLeft: 0,
    backgroundColor: "#fff",
  },
  search_icon: {
    position: "absolute",
    top: 16,
    fontSize: 16,
  },
}));
const SearchInput = (props) => {
  const classes = useStyles();
  const {
    value,
    handleChange,
    placeholder,
    name,
    handleSerachInput,
    handleKeyDown,
  } = props;
  return (
    <TextField
      variant="outlined"
      name={name}
      placeholder={placeholder || ""}
      value={value || ""}
      onChange={
        handleChange
          ? handleChange
          : () => console.log("provide handle change function to search input.")
      }
      onKeyDown={handleKeyDown}
      inputProps={{
        "data-testid": "searchInputField",
      }}
      InputProps={{
        className: classes.search_box,

        endAdornment: (
          <InputAdornment onClick={handleSerachInput}>
            <IconButton disableFocusRipple disableRipple disableTouchRipple size="large">
              <Icon>
                <SearchIcon className={classes.search_icon} />
              </Icon>
            </IconButton>
          </InputAdornment>
        ),
      }}
    />
  );
};

export default SearchInput;
