import React from "react";
import Button from "@mui/material/Button";
import { useTheme } from "@mui/material/styles";
import makeStyles from '@mui/styles/makeStyles';
const useStyles = makeStyles((theme) => ({
  button: {
    margin: theme.spacing(1),
  },
}));

const Buttons = ({
  id,
  buttons = [],
  variant = "",
  startIcon = null,
  endIcon = null,
  color = "default",
  size = "small",
  className = null,
  disabled = false,
  handleOnClick = () => console.log("forget to pass handleOnClick()"),
}) => {
  const classes = useStyles();
  const theme = useTheme();

  return buttons.map((button, index) => {
    const StartIcon = startIcon;
    const EndIcon = endIcon;
    if (typeof button === "object") {
      return (
        <Button
          variant={variant}
          onClick={() => handleOnClick(button.name)}
          color={color}
          size={size}
          disabled={disabled}
          style={{ margin: theme.spacing(1) }}
          className={className ? className : classes.button}
          startIcon={startIcon && <StartIcon />}
          endIcon={endIcon && <EndIcon />}
          {...button}
          key={button.name || index}
          id={`${id}_${button.name || ""}`}
          disableRipple
        >
          {button.name || ""}
        </Button>
      );
    } else if (typeof button === "string") {
      return (
        <Button
          style={{ margin: theme.spacing(1) }}
          className={className ? className : classes.button}
          variant={variant}
          disabled={disabled}
          onClick={() => handleOnClick(button)}
          color={color}
          size={size}
          startIcon={startIcon && <StartIcon />}
          endIcon={endIcon && <EndIcon />}
          key={button || index}
          id={`${id}_${button.name || ""}`}
          disableRipple
        >
          {button || ""}
        </Button>
      );
    }
  });
};

export default Buttons;
