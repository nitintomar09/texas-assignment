import React from "react";
import { NotificationProvider } from "../contexts/NotificationContext";
import { VariablesProvider } from "../contexts/VariablesListContext";
import { IBPSProvider } from "../contexts/iBPSContext";
import { ThemeProvider, StyledEngineProvider } from "@mui/styles";
import theme from "../assets/theme/theme";
import store from "../redux/store";
import { Provider } from "react-redux";

import { BrowserRouter as Router } from "react-router-dom";
import { MappedVariablesProvider } from "./../contexts/MappedVarContext";

const CustomAppComp = ({ children }) => {
  return (
    <Provider store={store}>
      <StyledEngineProvider injectFirst>
        <ThemeProvider theme={theme}>
          <NotificationProvider>
            <IBPSProvider>
              <MappedVariablesProvider>
                <VariablesProvider>
                  <Router>{children}</Router>
                </VariablesProvider>
              </MappedVariablesProvider>
            </IBPSProvider>
          </NotificationProvider>
        </ThemeProvider>
      </StyledEngineProvider>
    </Provider>
  );
};

export default CustomAppComp;
