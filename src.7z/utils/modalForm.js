import React, { useEffect } from "react";
import {
  Button,
  Grid,
  Typography,
  Modal,
  Fade,
  Backdrop,
  Divider,
  IconButton,
} from "@mui/material";

import makeStyles from "@mui/styles/makeStyles";
import withStyles from "@mui/styles/withStyles";

import customStyle from "../assets/css/customStyle";
import CircularProgress from "@mui/material/CircularProgress";
import { red } from "@mui/material/colors";
import { CloseIcon } from "../utils/AllImages";
import CustomTabs from "./CustomTabs";
import SearchBox from "./Search-Component/index";
import { getCssRgbFromHexByDiff, getRgbafromHex } from "./HexToFilter";

const useStyles = makeStyles((theme) => ({
  modal: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    outline: 0,
  },
  container: {
    display: "flex",
    // alignItems: "center",
    //justifyContent: "center",
    width: 540,
    backgroundColor: "white",
    flexDirection: "column",
    outline: 0,
    maxWidth: "90vw",
    maxHeight: "90vh",
  },
  title: { color: "#000000", opacity: 1, fontSize: 14, fontWeight: 600 },
  modalHeader: {
    // paddingBottom: 14,
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    height: 40,
    // paddingTop: 14,
    outline: 0,
  },
  modalFooter: {
    paddingTop: 8,
    paddingBottom: 8,
    // paddingLeft: 16,
    // paddingRight: 16,
    outline: 0,
    backgroundColor: "#f7f9fc",
  },
  headerBtn: {
    color: `${theme.palette.primary.main}`,
  },
  addBtn: {
    backgroundColor: `${theme.palette.primary.main}`,
    color: "#FFFFFF",
  },
  deleteBtn: {
    backgroundColor: "#D53D3D",
    color: "#FFFFFF",
    fontWeight: 600,
  },
  content: {
    padding: "16px",
    paddingLeft: (props) =>
      props.paddingLeftContent ? props.paddingLeftContent : 16,
    paddingRight: (props) =>
      props.paddingRightContent ? props.paddingRightContent : 16,
    flex: 1,
    flexDirection: "column",
    outline: 0,
    backgroundColor: (props) => props?.contentBackground ? props?.contentBackground : "#f8f8f8",
    overflowY: (props) => (props.overflowHidden ? "hidden" : "auto"),
  },
  padding: {
    paddingLeft: 16,
    paddingRight: 16,
  },
  paddingContent: {
    /* paddingLeft: (props) =>
      props.paddingLeftContent ? props.paddingLeftContent : 16,
    paddingRight: (props) =>
      props.paddingRightContent ? props.paddingRightContent : 16,*/
  },
  text_12: {
    fontSize: "12px",
  },
  header: {},
  selectedTab: {
    fontWeight: 600,
    borderBottom: `2px solid ${theme.palette.primary.main}`,
    color: `${theme.palette.primary.main}`,
    // filter: ` invert(36%) sepia(100%) saturate(5475%) hue-rotate(191deg) brightness(94%) contrast(101%)`,
  },
  focusPrimary: {
    "&:focus": {
      background: `${getCssRgbFromHexByDiff(`${theme.palette.primary.main}`)}`,
    },
  },
  focusSecondary: {
    "&:focus": {
      //filter: "brightness(0.90)",
      background: `${getRgbafromHex(`${theme.palette.primary.main}`, 0.04)}`,
    },
  },
  focusTertiary: {
    "&:focus": {
      //filter: "brightness(0.90)",
      background: `#F8F8F8`,
    },
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },
  },
  disabledBtn: {
    background: "#B2D5EE !important",
    opacity: 1,
    color: "#FFFFFF !important",
  },
}));

const DeleteButton = withStyles((theme) => ({
  root: {
    color: theme.palette.getContrastText(red[600]),
    backgroundColor: "#df5a5a",
    "&:hover": {
      backgroundColor: red[700],
    },
    "&:focus-visible": {
      background: `${getCssRgbFromHexByDiff("#df5a5a")}`,
    },
  },
}))(Button);
const CancelButton = withStyles((theme) => ({
  root: {
    ...customStyle.btn1,
    color: customStyle?.btn1?.color,
    // color: "#df5a5a",
    backgroundColor: customStyle?.btn1?.background,
    "&:hover": {
      backgroundColor: "#F8F8F8",
    },
    "&:focus-visible": {
      background: `#F8F8F8`,
      outline: `1px solid ${theme.palette.tabFocus.mainColor}`,
    },
  },
}))(Button);

const ModalForm = (props) => {
  const { id, overflowHidden, paddingLeftContent, paddingRightContent } = props;
  const classes = useStyles({
    overflowHidden,
    paddingLeftContent,
    paddingRightContent,
    contentBackground:props?.contentBackground,
  });

  const closeModal = () => {
    props.closeModal();
  };

  return (
    <Modal
      className={classes.modal}
      open={props.isOpen}
      onClose={closeModal}
      // BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 50,
      }}
      disableScrollLock={true}
      role="dialog"
      aria-modal="true"
      aria-label={props.title || "modal"}
    >
      <Fade in={props.isOpen} tabIndex={-1}>
        {/* modal container */}
        <div
          style={{
            height: props.containerHeight ? props.containerHeight : 450,
            width: props.containerWidth ? props.containerWidth : 550,
          }}
          className={classes.container}
        >
          {/* modal header  */}
          {props.title && (
            <>
              <div
                className={classes.modalHeader}
                data-testid="modalForm"
                role="banner"
                aria-label={props.title}
              >
                <Grid
                  container
                  justifyContent="space-between"
                  className={classes.padding}
                >
                  <Grid item container spacing={2} alignItems="center">
                    <Grid item>
                      <Typography className={classes.title}>
                        {props.title}
                      </Typography>
                    </Grid>
                    {/*****************************************************************************************
      * @author asloob.ali BUG ID : 101301 Description : Share Settings screen: Gap between script\project icon and text is more *
      Resolution : reduced gap beetween icon and name. * Date :
      07/10/2021
     ***************************************************************************************/}
                    {props.name && (
                      <Grid item>
                        <Grid container alignItems="center">
                          <Grid
                            item
                            style={{ marginRight: "4px", marginTop: "2px" }}
                          >
                            {props.icon ? props.icon : null}
                          </Grid>
                          <Grid item>
                            <Typography className={classes.title}>
                              {props.name}
                            </Typography>
                          </Grid>
                        </Grid>
                      </Grid>
                    )}
                    {(props.headerBtn1Title ||
                      props.headerBtn2Title ||
                      props.headerCloseBtn ||
                      props.searchField) && (
                        <Grid item style={{ marginInlineStart: "auto" }}>
                          <Grid container spacing={2}>
                            {props.searchField && (
                              <Grid item style={{ marginTop: "2px" }}>
                                <SearchBox
                                  id={`${id}_SearchBox`}
                                  width="220px"
                                  onSearchChange={
                                    props.handleSearchChange
                                      ? props.handleSearchChange
                                      : () =>
                                        console.log(
                                          "please provide handleSearchChange Fn"
                                        )
                                  }
                                  placeholder="Search by Name"
                                />
                              </Grid>
                            )}
                            {props.headerBtn1Title && (
                              <Grid item>
                                <Button
                                  color="primary"
                                  variant="contained"
                                  onClick={props.onClick1Header}
                                  disableFocusRipple
                                  className={classes.focusPrimary}
                                  id={`${id}_${props.headerBtn1Title}Btn`}
                                >
                                  {props.headerBtn1Title}
                                </Button>
                              </Grid>
                            )}
                            {props.headerBtn2Title && (
                              <Grid item>
                                <Button
                                  variant="contained"
                                  color="primary"
                                  onClick={props.onClick2Header}
                                  disableFocusRipple
                                  className={classes.focusPrimary}
                                  id={`${id}_${props.headerBtn2Title}Btn`}
                                >
                                  {props.headerBtn2Title}
                                </Button>
                                {/*<Grid
                            container
                            alignItems="center"
                            spacing={1}
                            onClick={props.onClick2Header}
                            style={{ cursor: "pointer" }}
                            className={classes.headerBtn}
                          >
                            <Grid item>
                              <Typography className={classes.text_12}>
                                {props.headerBtn2Title}
                              </Typography>
                            </Grid>
                            {props.headerBtn2Icon && (
                              <Grid item>{props.headerBtn2Icon}</Grid>
                            )}
                            </Grid>*/}
                              </Grid>
                            )}
                            {props.headerCloseBtn && (
                              <Grid
                                item
                              //  tabIndex={0}
                              // className={classes.focusVisible}
                              >
                                <IconButton
                                  onClick={
                                    props.onClickHeaderCloseBtn
                                      ? () => props.onClickHeaderCloseBtn()
                                      : () => {
                                        console.log(
                                          "onClickHeaderCloseBtn fn not passed"
                                        );
                                      }
                                  }
                                  id={`${id}_CloseIconBtn`}
                                  aria-label="Close Button"
                                >
                                  <CloseIcon
                                    /* onKeyPress={(e) => {
                                         if (e.key === "Enter") {
                                           if (props.onClickHeaderCloseBtn) {
                                             props.onClickHeaderCloseBtn();
                                           }
                                         }
                                       }}*/
                                    style={{
                                      width: "16px",
                                      height: "16px",
                                      cursor: "pointer",
                                    }}
                                  />
                                </IconButton>
                              </Grid>
                            )}
                          </Grid>
                        </Grid>
                      )}
                  </Grid>
                </Grid>
              </div>
              <Divider variant="fullWidth" />
              {props.tabs && (
                <>
                  <Grid container className={classes.padding}>
                    <Grid item
                    // style={{ marginTop: "8px" }}
                    >
                      <CustomTabs
                        id={id}
                        tabItems={props.tabs}
                        selectedTab={props.selTab}
                        handleTabChange={props.handleTabChange}
                        className={classes.selectedTab}
                      />
                    </Grid>
                  </Grid>
                  <Divider
                    variant="fullWidth"
                  // style={{
                  //   marginLeft: props.marginLeft ? props.marginLeft : "16px",
                  //   marginRight: props.marginRight
                  //     ? props.marginRight
                  //     : "16px",
                  // }}
                  />
                </>
              )}
            </>
          )}

          {/* modal content  */}
          <div className={classes.content} aria-label="content">
            {props.Header ? (
              <div style={{ backgroundColor: "lightgray" }}>{props.Header}</div>
            ) : null}
            {/*<div className={classes.paddingContent}>*/}
            {props.description && (
              <Grid container style={{ marginBottom: "16px" }}>
                <Grid Item>
                  <Typography
                    className={classes.text_12}
                    style={{ color: "#000000" }}
                  >
                    {props.description}
                  </Typography>
                </Grid>
              </Grid>
            )}
            {props.Content}
            {/* </div>*/}
          </div>

          <Divider variant="fullWidth" />

          {/* modal footer  */}
          {(props.btn1Title || props.btn2Title || props.btn3Title) && (
            <div
              className={classes.modalFooter}
              role="contentinfo"
              aria-label="footer"
            >
              <div className={classes.padding}>
                <Grid container justifyContent="space-between">
                  {props.footerText && (
                    <Grid item>
                      <Typography>{props.footerText}</Typography>
                    </Grid>
                  )}

                  <Grid item>
                    <Grid
                      container
                      justifyContent="flex-start"
                      alignItems="center"
                    >
                      {/* btn3  */}
                      {props.btn3Title && (
                        <Grid item style={{ paddingRight: 5 }}>
                          <Button
                            variant="outlined"
                            size="small"
                            onClick={props.onClick3}
                            disableFocusRipple
                            className={classes.focusSecondary}
                            style={customStyle.btn}
                            id={`${id}_${props.btn3Title}Btn`}
                          >
                            {props.btn3Title}
                          </Button>
                        </Grid>
                      )}
                    </Grid>
                  </Grid>
                  <Grid item>
                    <Grid container justifyContent="flex-end" spacing={1}>
                      {/* btn1  */}
                      {props.btn1Title && (
                        <Grid item style={{ marginRight: "4px" }}>
                          {/* <Button
                            style={customStyle?.btn1}
                            variant="outlined"
                            size="small"
                            onClick={props.onClick1}
                            disableFocusRipple
                            className={classes.focusTertiary}
                            id={`${id}_${props.btn1Title}Btn`}
                          >
                            {props.btn1Title}
                      </Button>*/}
                          <CancelButton
                            style={{ fontSize: "12px", fontWeight: 600 }}
                            //  variant="contained"
                            size="small"
                            // color="primary"
                            onClick={props.onClick1}
                            disableFocusRipple
                            className={classes.focusTertiary}
                            id={`${id}_${props.btn1Title}Btn`}
                          >
                            {props.btn1Title}
                          </CancelButton>
                        </Grid>
                      )}
                      {/* btn2 */}
                      {props.btn2Title &&
                        (props.isProcessing ? (
                          <Grid item>
                            {props.btn2Title.indexOf("Delete") !== -1 ? (
                              <DeleteButton
                                style={{ fontSize: "12px", fontWeight: 600 }}
                                variant="contained"
                                size="small"
                                color="primary"
                                disableFocusRipple
                                id={props.btn2Title}
                              >
                                <CircularProgress
                                  // color="#FFFFFF"
                                  style={{
                                    height: "15px",
                                    width: "15px",
                                    marginRight: "8px",
                                    color: "#FFFFFF",
                                  }}
                                ></CircularProgress>

                                {props.btn2Title}
                              </DeleteButton>
                            ) : (
                              <Button
                                style={{ fontSize: "12px", fontWeight: 600 }}
                                variant="contained"
                                size="small"
                                color="primary"
                                // Commenting on 09-01-2024 to resolve the bug Id 142394
                                // sx={{
                                //   position: "relative",
                                //   display: "inline-flex",
                                //   height: "15px",
                                //   width: "20px",
                                // }}
                                disableFocusRipple
                                className={classes.focusPrimary}
                                id={props.btn2Title}
                              >
                                <CircularProgress
                                  // color="#FFFFFF"
                                  variant={
                                    props.withProgress
                                      ? "determinate"
                                      : "indeterminate"
                                  }
                                  style={{
                                    height: "20px",
                                    width: "20px",
                                    marginRight: "8px",
                                    color: "#FFFFFF",
                                  }}
                                  value={
                                    props.withProgress ? props.percentage : null
                                  }
                                ></CircularProgress>
                                {props.withProgress && (
                                  <Typography
                                    variant="caption"
                                    component="div"
                                    // color="#FFFFFF"
                                    style={{
                                      color: "#FFFFFF",
                                      fontSize: "8px",
                                      top: 0,
                                      left: -80,
                                      bottom: 0,
                                      right: 0,
                                      position: "absolute",
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "center",
                                      width: "100%",
                                    }}
                                  >
                                    {`${Math.round(props.percentage)}%`}
                                  </Typography>
                                )}

                                {props.btn2Title}
                              </Button>
                            )}
                          </Grid>
                        ) : (
                          <Grid item>
                            {props.btn2Title.indexOf("Delete") !== -1 ? (
                              <DeleteButton
                                style={{ fontSize: "12px", fontWeight: 600 }}
                                variant="contained"
                                size="small"
                                color="primary"
                                onClick={props.onClick2}
                                disableFocusRipple
                                id={`${id}_${props.btn2Title}Btn`}
                              >
                                {props.btn2Title}
                              </DeleteButton>
                            ) : (
                              <Button
                                style={{ fontSize: "12px", fontWeight: 600 }}
                                variant="contained"
                                size="small"
                                color="primary"
                                onClick={props.onClick2}
                                disabled={props.btn2Disabled}
                                tabIndex={props.btn2Disabled ? -1 : 0}
                                disableFocusRipple
                                className={
                                  props.btn2Disabled
                                    ? classes.disabledBtn
                                    : classes.focusPrimary
                                }
                                id={`${id}_${props.btn2Title}Btn`}
                              >
                                {props.btn2Title}
                              </Button>
                            )}
                          </Grid>
                        ))}
                    </Grid>
                  </Grid>
                </Grid>
              </div>
            </div>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default ModalForm;
