import React from "react";
import ChipInput from "material-ui-chip-input";

const ChipInputField = ({ chipArray, label, onAdd, onDelete, helperText }) => {
  return (
    <div data-testid="chip-label">
      <ChipInput
        value={chipArray}
        fullWidth={true}
        onAdd={(chip) => onAdd(chip)}
        onDelete={(chip, index) => onDelete(chip, index)}
        label={label || "Lable"}
        helperText={helperText}
      />
    </div>
  );
};

export default ChipInputField;
