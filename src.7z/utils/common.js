import React, { useState } from "react";
import XLSX from "xlsx";
import DOMPurify from 'dompurify';
import {
  getDecryptData,
  getDecryptedString,
  getEncryptedId,
  getEncryptedString,
} from "./encryptions";
import { API_BASE_URL, UNLOCK,CODE_EDITOR_LAUNCH } from "../config";
import moment from "moment";
import axios from "axios";
import secureLocalStorage from "react-secure-storage";
let openTabs ={};
export const extractHeader = (sheet) => {
  var headers = [];
  var range = XLSX.utils.decode_range(sheet["!ref"]);
  var C,
    R = range.s.r; /* start in the first row */
  /* walk every column in the range */
  for (C = range.s.c; C <= range.e.c; ++C) {
    var cell =
      sheet[
      XLSX.utils.encode_cell({ c: C, r: R })
      ]; /* find the cell in the first row */

    console.log(cell);

    var hdr = "Empty " + C; // <-- replace with your desired default
    console.log(hdr);

    if (cell && cell.t) hdr = XLSX.utils.format_cell(cell);

    if (hdr.indexOf("Empty") === -1) {
      headers.push(hdr);
    }
  }
  return headers;
};

export const removeSession = () => {
  secureLocalStorage.removeItem("scriptData");
};
export const setScriptDataInLs = ({ scriptId, versionName }) => {
  const enc = getEncryptedId({ scriptId: scriptId, versionName: versionName });
  secureLocalStorage.setItem("scriptData", enc);
};

// Form input fuction
export function UseFormInput(initialValue) {
  const [value, setValue] = useState(initialValue);

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  return {
    value,
    onChange: handleChange,
    error: false,
    helperText: "",
    setValue,
  };
}
export const getDateStr = (dateStr) => {
  let date = "";
  if (dateStr) {
    date = new Date(dateStr).toLocaleDateString();
  }
  return date;
};
export const getDateAndTimeStr = (dateStr) => {
  let date = "";
  if (dateStr) {
    /*****************************************************************************************
     * @author asloob_ali BUG ID : 103660 Description : 103660 -  Script list Screen: Time is incorrect in Last opened or Commited Date Column
     *  Reason:Date format was not correct.
     * Resolution : corrected date format.
     * it also fixed issue 102661
     *  Date : 27/12/2021             ****************/
    date = moment(dateStr).format("DD MMM YYYY, HH:mm");
  }
  return date;
};
export const getCalendarDate = (dateStr) => {
//  BugId:Bug 155253 - The date format on the homepage is different than the figma design 
//  Author:dixita.ruhela
//  Date:8 JAN 2025
//  RCA: Correct the date format 
  let date = "";
  if (dateStr) {
    date = moment(dateStr).calendar(null, {
      sameDay: "[Today at] HH:mm A",
      lastDay: "[Yesterday at] HH:mm A",
      lastWeek: "[Last] dddd [at] HH:mm A",
      nextDay: "DD MMM [at] HH:mm A",
      nextWeek: "DD MMM [at] HH:mm A",
      sameElse: "DD MMM [at] HH:mm A",
    });
  }
  return date;
};

export const getDateOnly = (dateStr) => {
  let date = "";
  if (dateStr) {
    date = moment(dateStr).format("DD MMM [at] HH:mm A");
  }
  return date;
};

export const getDateOnlyBy = (dateStr) => {
  let date = "";
  if (dateStr) {
    date = moment(dateStr).format("DD MMM YYYY");
  }
  return date;
};

export const getDateAndTimeStrForTile = (dateStr) => {
  let date = "";
  if (dateStr) {
    date = moment(dateStr).format("DD/MMM/YYYY, HH:mm:SS");
  }
  return date;
};
// return the user data from the session storage
export const getUser = () => {
  /*const userStr = sessionStorage.getItem("user");
  if (userStr) return JSON.parse(userStr);
  else return null;*/
  const userStr = secureLocalStorage.getItem("user");
  if (userStr) return getDecryptData(userStr);
  else return null;
};

export const getUserRights = ({ componentId }) => {
  const user = getUser();
  const compDetails =
    (user && user[0]?.rolePermissionsDto?.permissionList) || [];
  const compPermissions = compDetails.find(
    (comp) => comp.componentId === componentId
  );

  if (compPermissions) {
    const { memberPermissionRights, ownerPermissionRights } = compPermissions;

    return { memberPermissionRights, ownerPermissionRights };
  }
  return null;
};

export const doesUserHavePermission = ({
  isShared,
  permissionNum,
  componentId,
}) => {
  const permissionRights = getUserRights({ componentId: componentId || 7 });
  if (permissionRights) {
    const { ownerPermissionRights, memberPermissionRights } = permissionRights;
    const permissionStr = isShared
      ? memberPermissionRights
      : ownerPermissionRights;

    return permissionStr.charAt(permissionNum) === "1" ? true : false;
  }
  return false;
};

export const getUserId = () => {
  // const userId = sessionStorage.getItem("index");
  //if (userId) return userId;
  //else return null;
  const userId = secureLocalStorage.getItem("index");
  if (userId) return getDecryptedString(userId);
  else return null;
};
export const getUserRole = () => {
  /* const userStr = sessionStorage.getItem("user-role");
  if (userStr) return JSON.parse(userStr);
  else return null;*/
  const userStr = secureLocalStorage.getItem("user-role");
  if (userStr) return getDecryptData(userStr);
  else return null;
};

// return the token from the session storage
export const getToken = () => {
  return secureLocalStorage.getItem("x-access-token") || null;
};

// return the key from the session storage
export const getAuthKey = () => {
  return secureLocalStorage.getItem("x-access-key") || null;
};

// remove the token and user from the session storage
export const removeUserSession = () => {
  secureLocalStorage.removeItem("x-access-token");
  secureLocalStorage.removeItem("user");
  secureLocalStorage.removeItem("user-role");
  secureLocalStorage.removeItem("index");
  secureLocalStorage.removeItem("x-access-key");
  secureLocalStorage.removeItem("iBPS-key");
};

// set the token and user from the session storage
export const setUserSession = (token, user) => {
  // sessionStorage.setItem("x-access-token", token);
  //sessionStorage.setItem("user", JSON.stringify(user));
  //sessionStorage.setItem("user-role", JSON.stringify(user[0].currentRole));
  // sessionStorage.setItem("index", JSON.stringify(user[0].authUser.userIndex));
  const usrEncryptedInd = getEncryptedString(
    JSON.stringify(user[0].authUser.userIndex)
  );
  const encryptedUsr = getEncryptedId(user);
  const encryptedUsrRol = getEncryptedId(user[0].currentRole);
  secureLocalStorage.setItem("index", usrEncryptedInd);
  secureLocalStorage.setItem("x-access-token", token);
  secureLocalStorage.setItem("user", encryptedUsr);
  secureLocalStorage.setItem("user-role", encryptedUsrRol);
};

// set the token and user from the session storage
export const setAuthKey = (key) => {
  secureLocalStorage.setItem("x-access-key", key);
};

export const truncateStringValues = ({ str, min = 5, max = 10 }) => {
  if (str && typeof str === "string") {
    return str.trim().length > max ? str.substring(0, min) + ".." : str;
  } else if (str) {
    return str;
  }
  return "";
};

export const handleNetworkRequestError = ({ error, history, onError }) => {
  if (!error) {
    alert("Network error");
  } else if (error.response) {
    // Request made and server responded
    console.log(error.response);
    // unauthorised request
    if (error.response.status === 401) {
      history.push("/Error");
    } else if (
      (error.response.status > 401 && error.response.status < 500) ||
      error.response.status === 400
    ) {
      onError
        ? onError(
          error.response.data?.data
            ? error.response.data?.data[0]?.errorMessage
            : "Invalid response"
        )
        : console.log(
          "BAD REQUEST:" +
            //   JSON.parse(
            error.response.data?.data
            ? error.response.data?.data[0]?.errorMessage
            : error.response.data
          // )
        );
    } else if (error.response.status === 500) {
      onError
        ? onError(
          error.response?.data?.data
            ? error.response?.data?.data[0]?.errorMessage
            : "Internal server error"
        )
        : console.log(
          "Server is Down:" +
          (error.response.data?.data
            ? error.response?.data?.data[0]?.errorMessage
            : error.response?.data)
        );
    }
  } else if (error.request) {
    // The request was made but no response was received
    onError
      ? onError("No response from server")
      : alert("No response from server");
  } else {
    // Something happened in setting up the request that triggered an Error
    onError
      ? onError(
        "Something happened in setting up the request that triggered an Error:" +
        error.message
      )
      : alert(
        "Something happened in setting up the request that triggered an Error:" +
        error.message
      );
    console.log("Error", error.message);
  }
  return 1;
};
/*  
 //----------------------------------------------------------------------------------------------------
 // Changed By: akshat_pokhriyal
           // Date :13/02/2024
 // Reason / Cause (Bug No if Any):Hotfix RPA_1.0_00_00_01
 //  Hotfix changes merged into main baseline
 //----------------------------------------------------------------------------------------------------
 */

export const createInstance = function (url, header, token) {
  return axios.create({
    baseURL: url ? url : API_BASE_URL,
    headers: {
      Authorization: `Bearer ${token ? token : secureLocalStorage.getItem("x-access-token")}`,
      ...header
    },
  });
};
export const getCancelTokenAxios = function () {
  return axios.CancelToken.source();
};
export const openScriptInNewTab = ({ scriptId, versionName, token, user }) => {
  const encStr = getEncryptedId({
    scriptId: scriptId,
    versionName: versionName,
    token: token,
    user: user,
  });
  const sanitizedUrl = DOMPurify.sanitize(`${window.location.origin}/sfweb/serviceflow/${encStr}`);
  let element = document.createElement("a");
  /*  
  //----------------------------------------------------------------------------------------------------
  // Changed By: pranesh ramesh
            // Date :13/02/2024
  // Reason / Cause (Bug No if Any):Hotfix RPA_1.0_00_00_01
  //  Hotfix changes merged into main baseline
  //----------------------------------------------------------------------------------------------------
  */
  // element.setAttribute(
  //   "href",
  //   sanitizedUrl
  // );
  element.href = sanitizedUrl;
  element.setAttribute("target", "_blank");
  element.click();
};

export const openCodeEditorInNewTab = ({ scriptId, versionName, token, user, isCodeEditor, className, methodName, scriptName }) => {
  const encStr = getEncryptedId({
    scriptId: scriptId,
    versionName: versionName,
    token: token,
    user: user,
    isCodeEditor
  });
  //const sanitizedUrl = DOMPurify.sanitize(`${window.location.origin}/serviceflowweb/serviceflow/${encStr}`);
  const sanitizedUrl = DOMPurify.sanitize(`${CODE_EDITOR_LAUNCH}`+"/#/d:/workspace/"+scriptName+"_"+versionName+"/"+scriptName+"_"+versionName);
  // let element = document.createElement("a");
  // element.href = sanitizedUrl;
  // element.setAttribute("target", "_blank");
  // element.click();
  const tabName = `codeEditorTab_${scriptName}_${versionName}`;

  // Check if the tab is already open
  if (openTabs[tabName] && !openTabs[tabName].closed) {
    openTabs[tabName].location.href = sanitizedUrl;
    openTabs[tabName].focus();
  } else {
    // Open a new tab and store its reference
    openTabs[tabName] = window.open(sanitizedUrl, tabName);
  }
};

export const unlockScript = async ({ versionId }) => {
  const userId = getUserId();
  const queryParams = versionId
    ? `?versionId=${versionId}`
    : ``;
  const url = `${UNLOCK}${queryParams}`;
  const axiosInstance = createInstance();
  try {
    await axiosInstance.post(url);
  } catch (error) {
    console.log(error);
  }
};

export const RedefineEventTarget = (event, target) => {
  const newKeyPressEvent = new KeyboardEvent(event.type, {
    key: event.key,
    bubbles: event.bubbles,
    cancelable: event.cancelable,
  });

  Object.defineProperty(newKeyPressEvent, "target", {
    value: target,
    writable: false,
  });

  return newKeyPressEvent;
};

export const updateSvgIds = (svgContent, unid, prefix = "RPA") => {
  const parser = new DOMParser();
  const svgDoc = parser.parseFromString(svgContent, "image/svg+xml");
  const svgElements = svgDoc.querySelectorAll("[id]");

  svgElements.forEach((element) => {
    const originalId = element.getAttribute("id");
    //const uniqueId = prefix + "_" + originalId + "_" + unid;
    const uniqueId = originalId + "_" + unid;
    element.setAttribute("id", uniqueId);
  });
  //return svgDoc.documentElement.outerHTML;

  return React.createElement("div", {
    dangerouslySetInnerHTML: { __html: svgDoc.documentElement.outerHTML },
  });
};

let counter = 0;
export const generateUniqueId = () => {
  return ++counter;
};
