import React from "react";
import { Grid, Tab, Tabs } from "@mui/material";
import { makeStyles } from "@mui/styles";

const useStyles = makeStyles((theme) => ({
  tabsContainer: {
    display: "flex",
    alignItems: "center",
  },
  tabRoot: {
    textTransform: "none",
    fontWeight: 500,
    border: `1px solid ${theme.palette.grey[400]}`,
    borderRadius: "20px",
    margin: theme.spacing(0.5),
    minWidth: "auto",
    padding: theme.spacing(0.5, 2),
    "&:hover": {
      backgroundColor: theme.palette.action.hover,
    },
  },
  selectedTab: {
    // backgroundColor: theme.palette.primary.main,
    // color: theme.palette.primary.contrastText,
    border: `1px solid ${theme.palette.primary.main}`,
    color:'#F2F8FC',
    fontWeight: 600,
  },
}));

const TabsButton = ({
  tabItems = [],
  selectedTab,
  handleTabChange = () => console.log("handleTabChange fn not provided."),
  id,
}) => {
  const classes = useStyles();

  return (
    <Grid container className={classes.tabsContainer}>
      <Tabs
        value={selectedTab}
        onChange={(event, newValue) => handleTabChange(newValue)}
        TabIndicatorProps={{ style: { display: "none" } }} // Remove default indicator
      >
        {tabItems.map((tabItem, i) => (
          <Tab
            value={tabItem}
            label={tabItem}
            key={`${id}_${i}`}
            classes={{
              root: classes.tabRoot,
              selected: classes.selectedTab,
            }}
          />
        ))}
      </Tabs>
    </Grid>
  );
};

export default TabsButton;
