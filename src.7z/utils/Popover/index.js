import React from "react";
import makeStyles from '@mui/styles/makeStyles';
import Popover from "@mui/material/Popover";
import customStyles from "../../assets/css/customStyle";
import { CircularProgress, Grid, Button, Divider } from "@mui/material";

const useStyles = makeStyles((theme) => ({
  typography: {
    padding: theme.spacing(2),
  },
}));

const SimplePopover = ({
  anchorEl,
  handleClose,
  id,
  open,
  Content,
  paramObj,
  btn1Title,
  btn2Title,
  onClick1,
  onClick2,
  isProcessing,
  btn2Disabled,
}) => {
  const classes = useStyles();
  return (
    <div>
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
        style={{ padding: "20px" }}
      >
        <div>{Content}</div>
        <Divider variant="fullWidth" />
        <div
          style={{
            paddingRight: "12px",
            paddingBottom: "4px",
            paddingTop: "4px",
          }}
        >
          <Grid container spacing={1} justifyContent="flex-end">
            {/* btn1  */}
            {btn1Title && (
              <Grid item style={{ paddingRight: 5 }}>
                <Button
                  style={customStyles.btn1}
                  variant="outlined"
                  size="small"
                  onClick={onClick1}
                >
                  {btn1Title}
                </Button>
              </Grid>
            )}
            {/* btn2 */}
            {btn2Title && isProcessing ? (
              <Grid item>
                <Button
                  style={{ fontSize: "12px" }}
                  variant="contained"
                  size="small"
                  color="primary"
                  sx={{
                    position: "relative",
                    display: "inline-flex",
                    height: "15px",
                    width: "20px",
                  }}
                >
                  <CircularProgress
                    // color="#FFFFFF"
                    variant={"indeterminate"}
                    style={{
                      height: "20px",
                      width: "20px",
                      marginRight: "8px",
                      color:"#FFFFFF"
                    }}
                  ></CircularProgress>
                  ){btn2Title}
                </Button>
                )
              </Grid>
            ) : (
              <Grid item>
                <Button
                  style={{ fontSize: "12px" }}
                  variant="contained"
                  size="small"
                  color="primary"
                  onClick={onClick2}
                  disabled={btn2Disabled}
                >
                  {btn2Title}
                </Button>
              </Grid>
            )}
          </Grid>
        </div>
      </Popover>
    </div>
  );
};
export default SimplePopover;
