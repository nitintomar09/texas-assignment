import React from "react";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert from '@mui/material/Alert';
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import InfoIcon from "@mui/icons-material/Info";
import "./index.css";
function Alert(props) {
  return <MuiAlert elevation={6} {...props} />;
}

export default function Toast(props) {
  const { closeToast, open, severity, message, className } = props;
  const handleClose = (e, reason) => {
    if (reason === "clickaway") {
      return;
    }
    closeToast();
  };

  return (
    <Snackbar
      anchorOrigin={
       
           { vertical: "top", horizontal: "center" }
      }
      open={open}
      autoHideDuration={6000}
      onClose={handleClose}
      className={className}
    >
      <Alert
        iconMapping={{
          success: <CheckCircleIcon />,
          error: <ErrorIcon />,
          warning: <ErrorIcon />,
          info: <InfoIcon />,
        }}
        onClose={handleClose}
        severity={severity}
      >
        {message}
      </Alert>
    </Snackbar>
  );
}
