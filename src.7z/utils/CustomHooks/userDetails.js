import React from "react";
import { useSelector } from "react-redux";
export default function useGetUserDetails(userId) {
  const allUsers = useSelector((state) => state.scriptsAndProjects.allUsers);
  const getUserDetails = () => {
    if (allUsers) {
      const usr = allUsers.find((item) => item.userIndex === userId);
      if (usr) return usr;
    }
    return null;
  };
}
