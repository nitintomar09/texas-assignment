import React from "react";
import ReactDom from "react-dom";
import { render, cleanup, screen } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import SearchInput from "./../SearchInput";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(<SearchInput />, div);
  screen.debug();
});

it("renders correctly", () => {
  const { getByTestId } = render(<SearchInput name="name" value="test" />);
  expect(getByTestId("searchInputField")).toHaveDisplayValue("test");
});

it("matches snapshot", () => {
  const tree = renderer
    .create(<SearchInput name="Search Scripts" value="Search Scripts" />)
    .toJSON();
  expect(tree).toMatchSnapshot();
});
