import React from "react";
import ReactDom from "react-dom";
import { cleanup, screen, render } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import MenuPopper from "./../MenuPopper";
import userEvent from "@testing-library/user-event";

const items = ["Home", "SignIn", "SignUp"];
afterEach(cleanup);
describe("When everything is ok.", () => {
  test("renders without crashing", () => {
    const div = document.createElement("div");
    ReactDom.render(<MenuPopper />, div);
  });
  screen.debug();
});

it("on click on menu icon", async () => {
  render(<MenuPopper items={items} />);
  userEvent.click(screen.getByTestId("menuPopper"));
  expect(screen.getByText("Home"));
});

it("matches snapshot Menu Popper", () => {
  const tree = renderer.create(<MenuPopper items={items} />).toJSON();
  expect(tree).toMatchSnapshot();
});
