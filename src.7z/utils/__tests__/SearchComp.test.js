import React from "react";
import ReactDom from "react-dom";
import { render, cleanup, screen } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import SearchComp from "./../Search-Component/index";
import CustomAppComp from "./../CustomAppComp";
import userEvent from "@testing-library/user-event";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(
    <CustomAppComp>
      <SearchComp />
    </CustomAppComp>,
    div
  );
  screen.debug();
});

it("renders correctly", () => {
  const onSearchChange = jest.fn();
  const { getByPlaceholderText } = render(
    <CustomAppComp>
      <SearchComp
        name="Search Test"
        placeholder="Test"
        onSearchChange={onSearchChange}
      />
    </CustomAppComp>
  );
  userEvent.type(getByPlaceholderText("Test"), "Testing");
  expect(getByPlaceholderText("Test")).toHaveDisplayValue("Testing");
  expect(onSearchChange).toHaveBeenCalledTimes(7);
});

it("matches snapshot", () => {
  const tree = renderer
    .create(
      <CustomAppComp>
        <SearchComp name="Search Scripts" value="Search Scripts" />
      </CustomAppComp>
    )
    .toJSON();
  expect(tree).toMatchSnapshot();
});
