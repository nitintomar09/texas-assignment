import React from "react";
import ReactDom from "react-dom";
import { render, cleanup, screen } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import Field from "./../field";
import userEvent from "@testing-library/user-event";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(<Field />, div);
});

it("renders correctly", () => {
  const { getByTestId } = render(<Field label="label" value="Input Label" />);
  expect(getByTestId("inputField")).toHaveTextContent("label");
});

test("handles change correctly for input", () => {
  const handleChange = jest.fn();

  render(<Field name="Test" label="Test" value="" onChange={handleChange} />);
  userEvent.type(screen.getByRole("textbox"), "Testing TextField");
  expect(handleChange).toBeCalledTimes(17);
});

it("matches snapshot", () => {
  const tree = renderer.create(<Field label="label" value="test" />).toJSON();
  expect(tree).toMatchSnapshot();
});
