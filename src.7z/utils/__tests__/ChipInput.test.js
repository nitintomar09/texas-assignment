import React from "react";
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";
import renderer from "react-test-renderer";

import "@testing-library/jest-dom/extend-expect";
import ChipInputField from "./../ChipInput";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(<ChipInputField />, div);
});

it("renders correctly", () => {
  const { getByTestId } = render(<ChipInputField label="label" value="Chip" />);
  expect(getByTestId("chip-label")).toHaveTextContent("label");
});

it("matches snapshot", () => {
  const tree = renderer
    .create(<ChipInputField label="label" value="test" />)
    .toJSON();
  expect(tree).toMatchSnapshot();
});
