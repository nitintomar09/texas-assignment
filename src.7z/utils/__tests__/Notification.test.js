import React, { useEffect } from "react";
import ReactDom from "react-dom";
import { render, cleanup } from "@testing-library/react";

import "@testing-library/jest-dom/extend-expect";
import {
  NotificationProvider,
  NotificationContext,
} from "../../contexts/NotificationContext";

import Notification from "./../Notification";

afterEach(cleanup);
const LaunchNoti = () => {
  const { setValue } = React.useContext(NotificationContext);
  useEffect(() => {
    setValue({
      isOpen: true,
      message: "testing.",
      notificationType: "SUCCESS",
      title: "Test",
    });
  }, []);

  return <Notification />;
};

it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(
    <NotificationProvider>
      <LaunchNoti />
    </NotificationProvider>,
    div
  );
});

it("renders correctly", () => {
  const { getByTestId } = render(
    <NotificationProvider>
      <LaunchNoti />
    </NotificationProvider>
  );
  expect(getByTestId("notification")).toHaveTextContent("Test");
});
