import React from "react";
import ReactDom from "react-dom";
import { render, cleanup, fireEvent } from "@testing-library/react";

import "@testing-library/jest-dom/extend-expect";
import ModalForm from "./../modalForm";

afterEach(cleanup);
it("renders without crashing", () => {
  const div = document.createElement("div");
  ReactDom.render(<ModalForm />, div);
});

it("renders correctly", () => {
  const { getByTestId } = render(<ModalForm isOpen={true} title="test" />);
  expect(getByTestId("modalForm")).toHaveTextContent("test");
});

it("modal shows a close button", () => {
  const handleClose = jest.fn();
  const { getByText } = render(
    <ModalForm
      isOpen={true}
      btn2Title="close"
      onClick2={handleClose}
      Content={<div>test</div>}
    ></ModalForm>
  );

  expect(getByText("test")).toBeTruthy();
  fireEvent.click(getByText(/close/i));
  expect(handleClose).toHaveBeenCalledTimes(1);
});
