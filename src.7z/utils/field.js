import React, { useState, useContext, useRef } from "react";
import {
  Typography,
  TextField,
  Select,
  Grid,
  FormControlLabel,
  FormGroup,
  Switch,
  Button,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Paper,
  InputAdornment,
  MenuItem,
  IconButton,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import makeStyles from "@mui/styles/makeStyles";
import withStyles from "@mui/styles/withStyles";
import CustomTooltip from "./CustomTooltip";
import { RedefineEventTarget } from "./common";
import { useTranslation } from "react-i18next";
import { UniqueIDGenerator } from "./UniqueIDGenerator";
import { CopyToClipboardIcon } from "./AllImages";
import { NotificationContext } from "../contexts/NotificationContext";

const useStyles = makeStyles((theme) => ({
  input: {
    height: (props) => props.height || 28,
    backgroundColor: "#FFFFFF",
    width:(props)=>props.width ||"auto",
    fontSize: (props) => props.fontSize || 12,
    backgroundColor: (props) => (props.disabled ? '#F0F0F0' : '#FFFFFF'),
    color: '#000000'
  },
  selectStyles: {
    padding: "10px",
  },
  multilineInput: {
    minHeight: (props) => props.height || 28,
    fontSize: (props) => props.fontSize || 12,
    backgroundColor: (props) => (props.disabled ? '#F0F0F0' : '#FFFFFF'),
    color: '#000000'

  },
  notchedOutline: {
    borderWidth: "1px",
    borderColor: "#d5e5d6 !important",
  },
  label: {
    fontSize: 12,
    color: "#606060",
    opacity: 1,
    fontWeight: 600,
    marginBottom: "4px",
  },
  required: { color: "red" },
  text_lead: {
    fontSize: "10px",
    color: "#767676",
  },
  margin_y: {
    marginTop: 10,
    marginBottom: 10,
  },
  icon: {
    height: "13px",
    width: "11px",
  },
  switchInput: {
    height: "13px",
    width: "13px",
    color: "#FFFFFF",
    border: "1px solid #707070;",
  },
  username: {
    fontSize: "12px",
    color: "#000000",
  },
  owner: {
    fontSize: "12px",
    color: "#AAAAAA",
  },

  img: { height: 30, width: 30, borderRadius: 50 },
  checkedSwitch: {
    color: "#0D6F08",
  },
  focusVisible: {
    "&:focus-visible": {
      outline: `2px solid ${theme.palette.tabFocus.mainColor}`,
      borderRadius: "2px",
    },

  },
}));

const AntSwitch = withStyles((theme) => ({
  root: {
    width: 28,
    height: 16,
    padding: 0,
    display: "flex",
  },
  switchBase: {
    padding: 2,
    color: "#FFFFFF",
    "&$checked": {
      transform: "translateX(12px)",
      color: theme.palette.common.white,
      "& + $track": {
        opacity: 1,
        backgroundColor: "#005EA3",
        borderColor: "#005EA3",
      },
    },
  },
  thumb: {
    width: 12,
    height: 12,
    boxShadow: "none",
  },
  // Bugid:Bug 143345 - Share Setting : Toggle button should be visible properly
  // AuthorName:Dixita Ruhela
  // Date:9-feb-2024
  // RCA:Toggle button styling is not proper.
  track: {
    border: `1px solid #C4C4C4`,
    borderRadius: 16 / 2,
    opacity: 1,
    backgroundColor: "#C4C4C4",

    boxSizing: "border-box",
  },
  copyfrom: {
    position: "absolute",
    left: "-9999px"
  },
  checked: {},
}))(Switch);


const Field = (props) => {
  const classes = useStyles({
    height: props?.height,
    fontSize: props?.fontSize,
    disabled: props?.disabled,
    width:props?.width,
  });
  const textFieldRef = useRef(null);
  const [openRole, setOpenRole] = useState(-1);
  const [copied, setCopied] = useState(false);

  const { t } = useTranslation();
  const { setValue: setNotification } = useContext(NotificationContext);

  const handleCloseRole = (index) => {
    setOpenRole(false);
  };

  const handleOpenRole = (index) => {
    setOpenRole(true);
  };

  const iconWithClass = (IconDefined) => {
    return (
      <UniqueIDGenerator>
        <IconDefined
          style={{
            height: "16px",
            width: "16px",
            marginRight: "5px",
          }}
        />
      </UniqueIDGenerator>
    );
  };
  
  const handleCopyToClipboard = async (label, textToCopy) => {
    try {
      /* await navigator.clipboard.writeText(textToCopy);
       setCopied(true);
       setNotification({
         isOpen: true,
         notificationType: "SUCCESS",
         message: `'${props.label || props.name}' copied`,
         anchorOrigin: { vertical: "top", horizontal: "center" }
       });*/
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(textToCopy);
        setCopied(true);
        setNotification({
          isOpen: true,
          notificationType: "SUCCESS",
          message: `'${label}' copied`,
          anchorOrigin: { vertical: "top", horizontal: "center" }
        });
      } else {
        
        const inputElement = textFieldRef?.current;
        inputElement?.select();
        document.execCommand('copy');
        setCopied(true);
        setNotification({
          isOpen: true,
          notificationType: "SUCCESS",
          message: `'${label}' copied`,
          anchorOrigin: { vertical: "top", horizontal: "center" }
        });

        // const currProtocol = window.location.protocol;
        // if (currProtocol === "http:") {
        //   setNotification({
        //     isOpen: true,
        //     notificationType: "ERROR",
        //     message: "This functionality requires a secure network. Please switch to an HTTPS connection.",
        //     anchorOrigin: { vertical: "top", horizontal: "center" }
        //   });
        // }
      }
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy: ', err);
    }
  };
  return (
    <div
      style={{ paddingTop: props.paddingTop ? props.paddingTop : 12 }}
      data-testid="inputField"
    >
      <Grid container alignItems="center" id={props.id}>
        {props.icon && <Grid item>{iconWithClass(props.icon)}</Grid>}
        <Grid item>
          <Typography className={classes.label}>{props.label}</Typography>
        </Grid>
        {props.copyToClipboard && (
          <Grid item style={{ marginInlineStart: 'auto' }}>
            <IconButton aria-label="Copy" onClick={() => handleCopyToClipboard(props.label, props.value)}>
              <CopyToClipboardIcon />
            </IconButton>
          </Grid>
        )}

        {/*props.required && (
          <Grid item>
            <Typography className={classes.required}>*</Typography>
          </Grid>
        )*/}
      </Grid>
      {/*****************************************************************************************
      * @author asloob.ali BUG ID : 101297 Description : Share Settings screen:
      Gap between toggle icon and ON\OFF text is more as compared to XD design *
      Resolution : decrease margin beetween switch and ON/OFF. * Date :
      07/10/2021
     ***************************************************************************************/}
      <div style={{ width: props.width }}>
        {props.SwitchLabel ? (
          <Grid container item spacing={2} alignItems="center">
            <Grid item id={props.id + "_switch"}>
              <Typography style={{ fontSize: "12px", fontWeight: "bold" }}>
                {props.SwitchLabel || "Sharing"}
              </Typography>
            </Grid>
            <Grid item>
              <Grid container>
                <Grid item>
                  <FormGroup>
                    <FormControlLabel
                      //WCAG[Keyboard Accessible]: Provided tabIndex and onKeyPress event
                      tabIndex={0}
                      role="switch"
                      aria-checked={props.sharingValue === "On"}
                      aria-label={`${props.SwitchLabel !== undefined
                        ? props.SwitchLabel
                        : "Sharing"
                        }`}
                      className={classes.focusVisible}
                      onKeyPress={(e) => {
                        if (e.key === "Enter") {
                          const child = e.target.querySelector("input");
                          props.onChange(RedefineEventTarget(e, child));
                        }
                      }}
                      control={
                        <CustomTooltip
                          title={props.tooltipTitle || ""}
                          placement="bottom-start"
                        >
                          <AntSwitch
                            checked={props.sharingValue}
                            onChange={props.onChange}
                            name={props.SwitchLabel}
                            tabIndex={-1}
                            inputProps={{
                              "aria-label": props.id + "_switch",
                            }}
                          />
                        </CustomTooltip>
                      }
                    />
                  </FormGroup>
                </Grid>
                <Grid item>
                  <Typography
                    className={props.sharingValue ? classes.checkedSwitch : ""}
                    style={{ marginLeft: "-8px" }}
                  >
                    {props.sharingValue ? "ON" : "OFF"}
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        ) : (
          <>
            <Grid container spacing={1}>
              <Grid item xs={props.btn ? 11 : 12}>
                <TextField
                  type={
                    props.secret ? "password" : props.type ? props.type : "text"
                  }
                  inputRef={textFieldRef}
                  error={props.error}
                  helperText={props.helperText}
                  placeholder={props.placeholder || ""}
                  name={props.name || props.label}
                  size="small"
                  multiline={props.multiline}
                  // rows={props.multiline ? 5 : 1}
                  maxRows={props.multiline ? 5 : 2}
                  inputProps={{
                    step: props.step || null,
                    min: props.min || null,
                    "aria-labelledby": props.id,
                  }}
                  autoComplete={props?.autoComplete || "off"}
                  fullWidth={true}
                  InputProps={
                    props.InputProps
                      ? {
                        className: props.multiline
                          ? classes.multilineInput
                          : classes.input,
                        readOnly: props.readOnly || null,
                        endAdornment: props.endAdornment || null,
                        startAdornment: props.startAdornment ? (
                          <InputAdornment position="start" tabIndex={0}>
                            {props.startAdornment}
                          </InputAdornment>
                        ) : null,

                        spellCheck: false,
                        ...props.InputProps,
                      }
                      : {
                        className: props.multiline
                          ? classes.multilineInput
                          : classes.input,
                        readOnly: props.readOnly || null,
                        endAdornment: props.endAdornment || null,
                        startAdornment: props.startAdornment ? (
                          <InputAdornment position="start">
                            {props.startAdornment}
                          </InputAdornment>
                        ) : null,
                        spellCheck: false,
                      }
                  }
                  value={props.value}
                  onChange={props.onChange}
                  variant={"outlined"}
                  FormHelperTextProps={{
                    style: {
                      marginLeft: 0,
                      color: props.error ? "#D53D3D" : "#606060",
                    },
                  }}
                  select={props.dropdown}
                  disabled={props.disabled}
                  SelectProps={{
                    MenuProps: {
                      anchorOrigin: {
                        vertical: "bottom",
                        horizontal: "left",
                      },
                      transformOrigin: {
                        vertical: "top",
                        horizontal: "left",
                      },
                      getContentAnchorEl: null,
                      PaperProps: {
                        elevation: 3,
                        square: true,
                        style: {
                          border: "1px solid #CCCEEE",
                          boxShadow: "0px 3px 6px #00000029",
                          maxHeight: "280px",
                          backgroundColor: "#FFFFFF",
                        },
                      },
                      "aria-label":
                        props.label !== undefined ? props.label : props.name,
                    },
                  }}
                /* SelectProps={{
                  // classes: { select: classes.selectStyles },
                 // native: true,
                  /*startAdornment: props.startAdornment ? (
                    <InputAdornment position="start">
                      {props.startAdornment}
                    </InputAdornment>
                  ) : null,
                }}*/
                >
                  {/* <option hidden defaultValue>
                    -select-
                </option>*/}
                  {props.options &&
                    props.options.map((option, index) => {
                      /*<option
                        value={item.value}
                        key={item.value + index}
                        disabled={item?.isDisabled ? "disabled" : ""}
                      >
                        {item.name}
                    </option>*/
                      return (
                        <MenuItem
                          value={option?.value}
                          style={{
                            textAlign: "center",
                          }}
                          key={index}
                          disabled={option?.isDisabled ? "disabled" : ""}
                        >
                          <Typography
                            style={{
                              fontSize: "12px",
                              fontWeight:
                                props.value == option.value ? 600 : 400,
                            }}
                            variant="h6"
                          >
                            {option?.name}
                          </Typography>
                        </MenuItem>
                      );
                    })}
                </TextField>
                {props.btn && props.filteredUsers.length > 0 && (
                  <Paper
                    elevation={3}
                    style={{ overflow: "auto", maxHeight: 150, zIndex: 2 }}
                  >
                    <List disablePadding>
                      {props.filteredUsers.map((user) => (
                        <ListItem
                          style={{ cursor: "pointer" }}
                          onClick={() => props.onSelectUser(user)}
                          key={user.email}
                        >
                          <ListItemIcon>
                            <img
                              src={user.img}
                              alt="user"
                              className={classes.img}
                            />
                          </ListItemIcon>
                          <ListItemText
                            primaryTypographyProps={{
                              style: { fontSize: "12px" },
                            }}
                            primary={user.name || null}
                            secondary={user.email || null}
                          />
                        </ListItem>
                      ))}
                    </List>
                  </Paper>
                )}
              </Grid>
              {props.btn && (
                <Grid item xs={1}>
                  <Button
                    variant="contained"
                    color="primary"
                    size="small"
                    onClick={() => props.onInvite()}
                  >
                    {props.btn}
                  </Button>
                </Grid>
              )}
            </Grid>
          </>
        )}
      </div>
      {props.btn && props.owner && (
        <>
          <Grid
            container
            direction="row"
            spacing={3}
            className={classes.margin_y}
          >
            <Grid container item direction="row" alignItems="center" xs={7}>
              <Grid item style={{ marginRight: "13px" }}>
                <img
                  src={props.owner.img}
                  alt="owner"
                  className={classes.img}
                />
              </Grid>

              <Grid item xs>
                <Typography className={classes.username}>
                  {props.owner.name}
                </Typography>
                <Typography className={classes.text_lead}>
                  {props.owner.email.length > 30
                    ? props.owner.email.substring(0, 20) + ".."
                    : props.owner.email}
                </Typography>
              </Grid>
            </Grid>
            <Grid
              container
              item
              direction="row"
              alignItems="flex-start"
              justifyContent="flex-end"
              xs={4}
            >
              <Grid item>
                <Typography className={classes.owner}>{t("owner")}</Typography>
              </Grid>
            </Grid>
          </Grid>
          {props.selectedUsers && props.selectedUsers.length > 0 && (
            <Grid container spacing={2}>
              <Grid item>
                <Typography className={classes.label}>
                  {t("Sharing with")}
                </Typography>
              </Grid>
            </Grid>
          )}
          <Grid
            container
            direction="row"
            spacing={3}
            className={classes.margin_y}
          >
            {props.selectedUsers.map((user, index) => (
              <React.Fragment key={user.email}>
                <Grid container item direction="row" xs={6}>
                  <Grid item style={{ marginRight: "13px" }}>
                    <img src={user.img} alt="user" className={classes.img} />
                  </Grid>
                  <Grid item xs>
                    <Typography className={classes.username}>
                      {user.name}
                    </Typography>
                    <Typography className={classes.text_lead}>
                      {user.email.length > 30
                        ? user.email.substring(0, 20) + ".."
                        : user.email}
                    </Typography>
                  </Grid>
                </Grid>
                <Grid
                  container
                  item
                  direction="row"
                  justifyContent="flex-end"
                  alignItems="flex-start"
                  xs={6}
                >
                  <Grid item>
                    <Select
                      id={props.id}
                      native
                      variant="outlined"
                      fullWidth={true}
                      className={classes.input}
                      value={user.role ? user.role : ""}
                      onChange={(e) => {
                        console.log(e.target);
                        props.provideRole(user, e.target.value);
                      }}
                      open={openRole === index}
                      onClose={() => handleCloseRole(index)}
                      onOpen={() => handleOpenRole(index)}
                      SelectDisplayProps={{ shrink: true }}
                      style={{ width: "151px" }}
                    >
                      {props.userRights &&
                        props.userRights.map((item) => (
                          <option value={item}>{item}</option>
                        ))}
                    </Select>
                  </Grid>
                </Grid>
              </React.Fragment>
            ))}
          </Grid>
        </>
      )}
    </div>
  );
};

export default Field;
